﻿function common10000_Logic(f1_arg0)
    if COMMON_HiPrioritySetup(f1_arg0, COMMON_FLAG_EXPERIMENT) then
        return true
    end
    COMMON_EasySetup3(f1_arg0)
    
end

function common10000_Interupt(f2_arg0, f2_arg1)
    return false
    
end


