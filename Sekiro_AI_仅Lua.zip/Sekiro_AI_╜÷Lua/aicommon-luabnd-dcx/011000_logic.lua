﻿function Nanimosinai11000_Logic(f1_arg0)
    f1_arg0:AddTopGoal(GOAL_COMMON_Wait, 5, TARGET_NONE, 0, 0, 0)
    
end

function Nanimosinai11000_Interupt(f2_arg0, f2_arg1)
    return false
    
end


