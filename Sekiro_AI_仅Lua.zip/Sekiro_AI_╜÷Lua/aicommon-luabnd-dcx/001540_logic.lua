﻿function Wataa1540_Logic(f1_arg0)
    f1_arg0:AddTopGoal(GOAL_COMMON_MoveToSomewhere, -1, POINT_AutoWalkAroundTest, AI_DIR_TYPE_CENTER, 1, TARGET_LOCALPLAYER, false)
    
end

function Wataa1540_Interupt(f2_arg0, f2_arg1)
    return false
    
end


