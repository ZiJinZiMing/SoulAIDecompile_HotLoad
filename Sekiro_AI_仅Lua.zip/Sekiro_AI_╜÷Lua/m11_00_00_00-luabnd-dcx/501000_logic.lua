﻿RegisterTableLogic(501000)

Logic.Main = function (f1_arg0, f1_arg1)
    _COMMON_SetBattleGoal(f1_arg1)
    
end

Logic.Interrupt = function (f2_arg0, f2_arg1, f2_arg2)
    return false
    
end


