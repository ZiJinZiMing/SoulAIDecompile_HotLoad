﻿RegisterTableGoal(GOAL_ProlificRenala203100_Battle, "ProlificRenala203100_Battle")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_ProlificRenala203100_Battle, true)

Goal.Initialize = function (f1_arg0, f1_arg1, f1_arg2, f1_arg3)
    f1_arg1:GetStringIndexedNumber("MoonPosibleFlg")
    f1_arg1:GetStringIndexedNumber("Warp_Cnt")
    f1_arg1:SetStringIndexedNumber("BackStepFlg", 0)
    f1_arg1:SetStringIndexedNumber("MoonPosibleFlg", 0)
    f1_arg1:SetStringIndexedNumber("Warp_Cnt", 0)
    
end

Goal.Activate = function (f2_arg0, f2_arg1, f2_arg2)
    Init_Pseudo_Global(f2_arg1, f2_arg2)
    f2_arg1:SetStringIndexedNumber("Dist_SideStep", 5)
    f2_arg1:SetStringIndexedNumber("Dist_BackStep", 5)
    local f2_local0 = {}
    local f2_local1 = {}
    local f2_local2 = {}
    Common_Clear_Param(f2_local0, f2_local1, f2_local2)
    local f2_local3 = f2_arg1:GetDist(TARGET_ENE_0)
    local f2_local4 = f2_arg1:GetRandam_Int(1, 100)
    local f2_local5 = f2_arg1:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__thinkAttr_doAdmirer)
    local f2_local6 = f2_arg1:GetEventRequest()
    f2_arg1:SetStringIndexedNumber("MoonPosibleFlg", 0)
    if f2_arg1:IsExistMeshOnLine(TARGET_SELF, AI_DIR_TYPE_F, 2) == true and f2_arg1:IsExistMeshOnLine(TARGET_SELF, AI_DIR_TYPE_B, 2) == true and f2_arg1:IsExistMeshOnLine(TARGET_SELF, AI_DIR_TYPE_L, 2) == true and f2_arg1:IsExistMeshOnLine(TARGET_SELF, AI_DIR_TYPE_R, 2) == true and f2_arg1:IsExistMeshOnLine(TARGET_SELF, AI_DIR_TYPE_FL, 2) == true and f2_arg1:IsExistMeshOnLine(TARGET_SELF, AI_DIR_TYPE_FR, 2) == true and f2_arg1:IsExistMeshOnLine(TARGET_SELF, AI_DIR_TYPE_BL, 2) == true and f2_arg1:IsExistMeshOnLine(TARGET_SELF, AI_DIR_TYPE_BR, 2) == true then
        f2_arg1:SetStringIndexedNumber("MoonPosibleFlg", 1)
    end
    if f2_arg1:GetStringIndexedNumber("BackStepFlg") == 1 and f2_arg1:HasSpecialEffectId(TARGET_SELF, 14590) == false then
        f2_arg1:SetStringIndexedNumber("BackStepFlg", 0)
    end
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5028)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    if f2_arg1:IsEventFlag(14003970) and not f2_arg1:IsEventFlag(14003971) and f2_arg1:HasSpecialEffectId(TARGET_SELF, 14590) then
        if f2_arg1:GetStringIndexedNumber("BackStepFlg") == 0 then
            f2_local0[43] = 100
        elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 80, -1, 999) then
            f2_local0[47] = 100
        else
            f2_local0[42] = 100
        end
    elseif f2_arg1:IsEventFlag(14003920) and not f2_arg1:IsEventFlag(14003921) and f2_arg1:HasSpecialEffectId(TARGET_SELF, 14590) then
        if f2_arg1:GetStringIndexedNumber("BackStepFlg") == 0 then
            f2_local0[43] = 100
        elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 80, -1, 999) then
            f2_local0[47] = 100
        else
            f2_local0[42] = 100
        end
    elseif f2_arg1:IsEventFlag(14003960) and not f2_arg1:IsEventFlag(14003961) and f2_arg1:HasSpecialEffectId(TARGET_SELF, 14590) then
        if f2_arg1:GetStringIndexedNumber("BackStepFlg") == 0 then
            f2_local0[43] = 100
        elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 80, -1, 999) then
            f2_local0[47] = 100
        else
            f2_local0[42] = 100
        end
    elseif f2_arg1:IsEventFlag(14003935) and not f2_arg1:IsEventFlag(14003936) and f2_arg1:HasSpecialEffectId(TARGET_SELF, 14590) then
        if f2_arg1:GetStringIndexedNumber("BackStepFlg") == 0 then
            f2_local0[43] = 100
        elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 80, -1, 999) then
            f2_local0[47] = 100
        else
            f2_local0[42] = 100
        end
    elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 240, -1, 999) then
        if f2_local3 > 20 then
            if f2_arg1:GetStringIndexedNumber("MoonPosibleFlg") == 1 then
                f2_local0[1] = 30
                f2_local0[2] = 20
                f2_local0[3] = 20
                f2_local0[4] = 20
                f2_local0[16] = 10
            else
                f2_local0[1] = 30
                f2_local0[2] = 20
                f2_local0[3] = 20
                f2_local0[4] = 20
                f2_local0[16] = 10
            end
            f2_local0[26] = 80
            f2_local0[28] = 80
            f2_local0[25] = 30
            f2_local0[27] = 30
        elseif f2_local3 > 10 then
            if f2_arg1:GetStringIndexedNumber("MoonPosibleFlg") == 1 then
                f2_local0[1] = 20
                f2_local0[2] = 15
                f2_local0[3] = 15
                f2_local0[4] = 20
                f2_local0[5] = 40
                f2_local0[9] = 15
                f2_local0[16] = 10
            else
                f2_local0[1] = 25
                f2_local0[2] = 20
                f2_local0[3] = 20
                f2_local0[4] = 20
                f2_local0[9] = 15
                f2_local0[16] = 10
            end
            f2_local0[26] = 80
            f2_local0[28] = 80
            f2_local0[25] = 30
            f2_local0[27] = 30
        elseif f2_local3 > 5 then
            if f2_arg1:HasSpecialEffectId(TARGET_SELF, 5032) and f2_arg1:GetTimer(0) <= 0 and f2_local4 < 80 then
                f2_arg1:SetTimer(0, 10)
                f2_local0[12] = 70
                f2_local0[15] = 30
            else
                if f2_arg1:GetStringIndexedNumber("MoonPosibleFlg") == 1 then
                    f2_local0[5] = 50
                end
                f2_local0[4] = 10
                f2_local0[8] = 45
                f2_local0[9] = 30
                f2_local0[26] = 30
                f2_local0[28] = 30
            end
        elseif f2_arg1:HasSpecialEffectId(TARGET_SELF, 5031) and f2_local4 < 50 then
            f2_local0[12] = 15
            f2_local0[13] = 80
            f2_local0[20] = 5
        elseif f2_arg1:HasSpecialEffectId(TARGET_SELF, 5032) and f2_local4 < 50 then
            f2_local0[12] = 50
            f2_local0[13] = 30
            f2_local0[20] = 5
        else
            f2_local0[12] = 20
            f2_local0[13] = 50
            f2_local0[20] = 30
            f2_local0[25] = 160
            f2_local0[26] = 200
            f2_local0[27] = 200
            f2_local0[28] = 200
            if f2_arg1:GetHpRate(TARGET_SELF) > 0.6 and f2_arg1:GetStringIndexedNumber("MoonPosibleFlg") == 1 then
                f2_local0[5] = 100
            end
        end
    else
        f2_local0[42] = 100
    end
    f2_local0[21] = 0
    if f2_arg1:IsEventFlag(14003970) then
        f2_local0[25] = 0
    end
    if f2_arg1:IsEventFlag(14003920) then
        f2_local0[26] = 0
    end
    if f2_arg1:IsEventFlag(14003960) then
        f2_local0[27] = 0
    end
    if f2_arg1:IsEventFlag(14003935) then
        f2_local0[28] = 0
    end
    if f2_arg1:GetTimer(2) > 0 then
        f2_local0[25] = 0
        f2_local0[26] = 0
        f2_local0[27] = 0
        f2_local0[28] = 0
    end
    if f2_arg1:GetHpRate(TARGET_SELF) > 0.6 then
        f2_local0[25] = 0
        f2_local0[26] = 0
        f2_local0[27] = 0
        f2_local0[28] = 0
    end
    if f2_arg1:GetNumber(1) == 0 then
        f2_local0[41] = 1000000
        f2_arg1:SetNumber(1, 1)
    end
    f2_local0[1] = SetCoolTime(f2_arg1, f2_arg2, 3000, 16, f2_local0[1], 1)
    f2_local0[2] = SetCoolTime(f2_arg1, f2_arg2, 3001, 16, f2_local0[2], 1)
    f2_local0[3] = SetCoolTime(f2_arg1, f2_arg2, 3002, 16, f2_local0[3], 1)
    f2_local0[4] = SetCoolTime(f2_arg1, f2_arg2, 3003, 15, f2_local0[4], 0)
    f2_local0[5] = SetCoolTime(f2_arg1, f2_arg2, 3005, 40, f2_local0[5], 0)
    f2_local0[8] = SetCoolTime(f2_arg1, f2_arg2, 3008, 10, f2_local0[8], 10)
    f2_local0[9] = SetCoolTime(f2_arg1, f2_arg2, 3009, 10, f2_local0[9], 5)
    f2_local0[12] = SetCoolTime(f2_arg1, f2_arg2, 3018, 15, f2_local0[12], 5)
    f2_local0[13] = SetCoolTime(f2_arg1, f2_arg2, 3013, 15, f2_local0[13], 5)
    f2_local0[15] = SetCoolTime(f2_arg1, f2_arg2, 3014, 15, f2_local0[15], 5)
    f2_local0[15] = SetCoolTime(f2_arg1, f2_arg2, 3019, 15, f2_local0[15], 5)
    f2_local0[16] = SetCoolTime(f2_arg1, f2_arg2, 3007, 20, f2_local0[16], 0)
    f2_local0[20] = SetCoolTime(f2_arg1, f2_arg2, 3015, 10, f2_local0[20], 0)
    f2_local0[21] = SetCoolTime(f2_arg1, f2_arg2, 3016, 45, f2_local0[21], 1)
    f2_local0[25] = SetCoolTime(f2_arg1, f2_arg2, 3030, 90, f2_local0[25], 0)
    f2_local0[26] = SetCoolTime(f2_arg1, f2_arg2, 3031, 60, f2_local0[26], 0)
    f2_local0[27] = SetCoolTime(f2_arg1, f2_arg2, 3032, 70, f2_local0[27], 0)
    f2_local0[28] = SetCoolTime(f2_arg1, f2_arg2, 3033, 60, f2_local0[28], 0)
    f2_local1[1] = REGIST_FUNC(f2_arg1, f2_arg2, ProlificRenala203100_Act01)
    f2_local1[2] = REGIST_FUNC(f2_arg1, f2_arg2, ProlificRenala203100_Act02)
    f2_local1[3] = REGIST_FUNC(f2_arg1, f2_arg2, ProlificRenala203100_Act03)
    f2_local1[4] = REGIST_FUNC(f2_arg1, f2_arg2, ProlificRenala203100_Act04)
    f2_local1[5] = REGIST_FUNC(f2_arg1, f2_arg2, ProlificRenala203100_Act05)
    f2_local1[8] = REGIST_FUNC(f2_arg1, f2_arg2, ProlificRenala203100_Act08)
    f2_local1[9] = REGIST_FUNC(f2_arg1, f2_arg2, ProlificRenala203100_Act09)
    f2_local1[12] = REGIST_FUNC(f2_arg1, f2_arg2, ProlificRenala203100_Act12)
    f2_local1[13] = REGIST_FUNC(f2_arg1, f2_arg2, ProlificRenala203100_Act13)
    f2_local1[14] = REGIST_FUNC(f2_arg1, f2_arg2, ProlificRenala203100_Act14)
    f2_local1[15] = REGIST_FUNC(f2_arg1, f2_arg2, ProlificRenala203100_Act15)
    f2_local1[16] = REGIST_FUNC(f2_arg1, f2_arg2, ProlificRenala203100_Act16)
    f2_local1[20] = REGIST_FUNC(f2_arg1, f2_arg2, ProlificRenala203100_Act20)
    f2_local1[21] = REGIST_FUNC(f2_arg1, f2_arg2, ProlificRenala203100_Act21)
    f2_local1[22] = REGIST_FUNC(f2_arg1, f2_arg2, ProlificRenala203100_Act22)
    f2_local1[25] = REGIST_FUNC(f2_arg1, f2_arg2, ProlificRenala203100_Act25)
    f2_local1[26] = REGIST_FUNC(f2_arg1, f2_arg2, ProlificRenala203100_Act26)
    f2_local1[27] = REGIST_FUNC(f2_arg1, f2_arg2, ProlificRenala203100_Act27)
    f2_local1[28] = REGIST_FUNC(f2_arg1, f2_arg2, ProlificRenala203100_Act28)
    f2_local1[30] = REGIST_FUNC(f2_arg1, f2_arg2, ProlificRenala203100_Act30)
    f2_local1[31] = REGIST_FUNC(f2_arg1, f2_arg2, ProlificRenala203100_Act31)
    f2_local1[40] = REGIST_FUNC(f2_arg1, f2_arg2, ProlificRenala203100_Act40)
    f2_local1[41] = REGIST_FUNC(f2_arg1, f2_arg2, ProlificRenala203100_Act41)
    f2_local1[42] = REGIST_FUNC(f2_arg1, f2_arg2, ProlificRenala203100_Act42)
    f2_local1[43] = REGIST_FUNC(f2_arg1, f2_arg2, ProlificRenala203100_Act43)
    f2_local1[44] = REGIST_FUNC(f2_arg1, f2_arg2, ProlificRenala203100_Act44)
    f2_local1[45] = REGIST_FUNC(f2_arg1, f2_arg2, ProlificRenala203100_Act45)
    f2_local1[46] = REGIST_FUNC(f2_arg1, f2_arg2, ProlificRenala203100_Act46)
    f2_local1[47] = REGIST_FUNC(f2_arg1, f2_arg2, ProlificRenala203100_Act47)
    local f2_local7 = REGIST_FUNC(f2_arg1, f2_arg2, ProlificRenala203100_ActAfter_AdjustSpace)
    Common_Battle_Activate(f2_arg1, f2_arg2, f2_local0, f2_local1, f2_local7, f2_local2)
    
end

function ProlificRenala203100_Act01(f3_arg0, f3_arg1, f3_arg2)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    local f3_local0 = 4
    local f3_local1 = 3000
    local f3_local2 = 5 - f3_arg0:GetMapHitRadius(TARGET_SELF)
    local f3_local3 = 0
    local f3_local4 = 0
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f3_local0, f3_local1, TARGET_ENE_0, f3_local2, f3_local3, f3_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function ProlificRenala203100_Act02(f4_arg0, f4_arg1, f4_arg2)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    local f4_local0 = 4
    local f4_local1 = 3001
    local f4_local2 = 5 - f4_arg0:GetMapHitRadius(TARGET_SELF)
    local f4_local3 = 0
    local f4_local4 = 0
    f4_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f4_local0, f4_local1, TARGET_ENE_0, f4_local2, f4_local3, f4_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function ProlificRenala203100_Act03(f5_arg0, f5_arg1, f5_arg2)
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    local f5_local0 = 4
    local f5_local1 = 3002
    local f5_local2 = 5 - f5_arg0:GetMapHitRadius(TARGET_SELF)
    local f5_local3 = 0
    local f5_local4 = 0
    f5_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f5_local0, f5_local1, TARGET_ENE_0, f5_local2, f5_local3, f5_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function ProlificRenala203100_Act04(f6_arg0, f6_arg1, f6_arg2)
    f6_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f6_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    local f6_local0 = 4
    local f6_local1 = 3003
    local f6_local2 = 5 - f6_arg0:GetMapHitRadius(TARGET_SELF)
    local f6_local3 = 0
    local f6_local4 = 0
    f6_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f6_local0, f6_local1, TARGET_ENE_0, f6_local2, f6_local3, f6_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function ProlificRenala203100_Act05(f7_arg0, f7_arg1, f7_arg2)
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    local f7_local0 = 4
    local f7_local1 = 3005
    local f7_local2 = 5 - f7_arg0:GetMapHitRadius(TARGET_SELF)
    local f7_local3 = 0
    local f7_local4 = 0
    f7_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f7_local0, f7_local1, TARGET_ENE_0, f7_local2, f7_local3, f7_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function ProlificRenala203100_Act08(f8_arg0, f8_arg1, f8_arg2)
    f8_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    local f8_local0 = 4
    local f8_local1 = 3008
    local f8_local2 = 5 - f8_arg0:GetMapHitRadius(TARGET_SELF)
    local f8_local3 = 0
    local f8_local4 = 0
    f8_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f8_local0, f8_local1, TARGET_ENE_0, f8_local2, f8_local3, f8_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function ProlificRenala203100_Act09(f9_arg0, f9_arg1, f9_arg2)
    f9_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    local f9_local0 = 4
    local f9_local1 = 3009
    local f9_local2 = 5 - f9_arg0:GetMapHitRadius(TARGET_SELF)
    local f9_local3 = 0
    local f9_local4 = 0
    f9_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f9_local0, f9_local1, TARGET_ENE_0, f9_local2, f9_local3, f9_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function ProlificRenala203100_Act12(f10_arg0, f10_arg1, f10_arg2)
    local f10_local0 = 10
    local f10_local1 = 0
    local f10_local2 = 999
    local f10_local3 = 0
    local f10_local4 = 0
    local f10_local5 = 2
    local f10_local6 = 2
    Approach_Act_Flex(f10_arg0, f10_arg1, f10_local0, f10_local1, f10_local2, f10_local3, f10_local4, f10_local5, f10_local6)
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5028)
    local f10_local7 = 4
    local f10_local8 = 3018
    local f10_local9 = 5 - f10_arg0:GetMapHitRadius(TARGET_SELF)
    local f10_local10 = 0
    local f10_local11 = 0
    f10_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f10_local7, f10_local8, TARGET_ENE_0, f10_local9, f10_local10, f10_local11, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function ProlificRenala203100_Act13(f11_arg0, f11_arg1, f11_arg2)
    local f11_local0 = 6
    local f11_local1 = 0
    local f11_local2 = 999
    local f11_local3 = 0
    local f11_local4 = 0
    local f11_local5 = 2
    local f11_local6 = 2
    Approach_Act_Flex(f11_arg0, f11_arg1, f11_local0, f11_local1, f11_local2, f11_local3, f11_local4, f11_local5, f11_local6)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5028)
    local f11_local7 = 4
    local f11_local8 = 3013
    local f11_local9 = 5 - f11_arg0:GetMapHitRadius(TARGET_SELF)
    local f11_local10 = 0
    local f11_local11 = 0
    f11_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f11_local7, f11_local8, TARGET_ENE_0, f11_local9, f11_local10, f11_local11, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function ProlificRenala203100_Act14(f12_arg0, f12_arg1, f12_arg2)
    local f12_local0 = 5
    local f12_local1 = 0
    local f12_local2 = 999
    local f12_local3 = 0
    local f12_local4 = 0
    local f12_local5 = 2
    local f12_local6 = 2
    Approach_Act_Flex(f12_arg0, f12_arg1, f12_local0, f12_local1, f12_local2, f12_local3, f12_local4, f12_local5, f12_local6)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5028)
    local f12_local7 = 4
    local f12_local8 = 3010
    local f12_local9 = 5 - f12_arg0:GetMapHitRadius(TARGET_SELF)
    local f12_local10 = 0
    local f12_local11 = 0
    f12_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f12_local7, f12_local8, TARGET_ENE_0, f12_local9, f12_local10, f12_local11, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function ProlificRenala203100_Act15(f13_arg0, f13_arg1, f13_arg2)
    local f13_local0 = 10
    local f13_local1 = 0
    local f13_local2 = 999
    local f13_local3 = 0
    local f13_local4 = 0
    local f13_local5 = 2
    local f13_local6 = 2
    Approach_Act_Flex(f13_arg0, f13_arg1, f13_local0, f13_local1, f13_local2, f13_local3, f13_local4, f13_local5, f13_local6)
    if f13_arg0:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_L, 180, -1, 999) then
        f13_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
        local f13_local7 = 4
        local f13_local8 = 3014
        local f13_local9 = 5 - f13_arg0:GetMapHitRadius(TARGET_SELF)
        local f13_local10 = 0
        local f13_local11 = 0
        f13_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f13_local7, f13_local8, TARGET_ENE_0, f13_local9, f13_local10, f13_local11, 0, 0)
        GetWellSpace_Odds = 0
        return GetWellSpace_Odds
    else
        f13_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
        local f13_local7 = 4
        local f13_local8 = 3019
        local f13_local9 = 5 - f13_arg0:GetMapHitRadius(TARGET_SELF)
        local f13_local10 = 0
        local f13_local11 = 0
        f13_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f13_local7, f13_local8, TARGET_ENE_0, f13_local9, f13_local10, f13_local11, 0, 0)
        GetWellSpace_Odds = 0
        return GetWellSpace_Odds
    end
    
end

function ProlificRenala203100_Act16(f14_arg0, f14_arg1, f14_arg2)
    f14_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    local f14_local0 = 15
    local f14_local1 = 3007
    local f14_local2 = 5 - f14_arg0:GetMapHitRadius(TARGET_SELF)
    local f14_local3 = 0
    local f14_local4 = 0
    f14_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f14_local0, f14_local1, TARGET_ENE_0, f14_local2, f14_local3, f14_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function ProlificRenala203100_Act20(f15_arg0, f15_arg1, f15_arg2)
    if f15_arg0:CheckDoesExistPath(TARGET_SELF, AI_DIR_TYPE_B, 4) then
        f15_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
        local f15_local0 = 10
        local f15_local1 = 3015
        local f15_local2 = 5 - f15_arg0:GetMapHitRadius(TARGET_SELF)
        local f15_local3 = 0
        local f15_local4 = 0
        f15_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f15_local0, f15_local1, TARGET_ENE_0, f15_local2, f15_local3, f15_local4, 0, 0)
        GetWellSpace_Odds = 0
        return GetWellSpace_Odds
    else
        f15_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
        f15_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
        local f15_local0 = 10
        local f15_local1 = 3016
        local f15_local2 = 5 - f15_arg0:GetMapHitRadius(TARGET_SELF)
        local f15_local3 = 0
        local f15_local4 = 0
        f15_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f15_local0, f15_local1, TARGET_ENE_0, f15_local2, f15_local3, f15_local4, 0, 0)
        GetWellSpace_Odds = 0
        return GetWellSpace_Odds
    end
    
end

function ProlificRenala203100_Act21(f16_arg0, f16_arg1, f16_arg2)
    f16_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f16_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    local f16_local0 = 10
    local f16_local1 = 3016
    local f16_local2 = 5 - f16_arg0:GetMapHitRadius(TARGET_SELF)
    local f16_local3 = 0
    local f16_local4 = 0
    f16_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f16_local0, f16_local1, TARGET_ENE_0, f16_local2, f16_local3, f16_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function ProlificRenala203100_Act22(f17_arg0, f17_arg1, f17_arg2)
    f17_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    local f17_local0 = 10
    local f17_local1 = 3029
    local f17_local2 = 5 - f17_arg0:GetMapHitRadius(TARGET_SELF)
    local f17_local3 = 0
    local f17_local4 = 0
    f17_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f17_local0, f17_local1, TARGET_ENE_0, f17_local2, f17_local3, f17_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function ProlificRenala203100_Act25(f18_arg0, f18_arg1, f18_arg2)
    f18_arg0:SetTimer(2, 15)
    f18_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    local f18_local0 = 20
    local f18_local1 = 3030
    local f18_local2 = 5 - f18_arg0:GetMapHitRadius(TARGET_SELF)
    local f18_local3 = 0
    local f18_local4 = 0
    f18_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f18_local0, f18_local1, TARGET_ENE_0, f18_local2, f18_local3, f18_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function ProlificRenala203100_Act26(f19_arg0, f19_arg1, f19_arg2)
    f19_arg0:SetTimer(2, 15)
    f19_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    local f19_local0 = 20
    local f19_local1 = 3031
    local f19_local2 = 5 - f19_arg0:GetMapHitRadius(TARGET_SELF)
    local f19_local3 = 0
    local f19_local4 = 0
    f19_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f19_local0, f19_local1, TARGET_ENE_0, f19_local2, f19_local3, f19_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function ProlificRenala203100_Act27(f20_arg0, f20_arg1, f20_arg2)
    f20_arg0:SetTimer(2, 15)
    f20_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f20_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 14586)
    local f20_local0 = 20
    local f20_local1 = 3032
    local f20_local2 = 5 - f20_arg0:GetMapHitRadius(TARGET_SELF)
    local f20_local3 = 0
    local f20_local4 = 0
    f20_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f20_local0, f20_local1, TARGET_ENE_0, f20_local2, f20_local3, f20_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function ProlificRenala203100_Act28(f21_arg0, f21_arg1, f21_arg2)
    f21_arg0:SetTimer(2, 15)
    f21_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    local f21_local0 = 20
    local f21_local1 = 3033
    local f21_local2 = 5 - f21_arg0:GetMapHitRadius(TARGET_SELF)
    local f21_local3 = 0
    local f21_local4 = 0
    f21_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f21_local0, f21_local1, TARGET_ENE_0, f21_local2, f21_local3, f21_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function ProlificRenala203100_Act30(f22_arg0, f22_arg1, f22_arg2)
    f22_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    local f22_local0 = 4
    local f22_local1 = 3031
    local f22_local2 = 5 - f22_arg0:GetMapHitRadius(TARGET_SELF)
    local f22_local3 = 0
    local f22_local4 = 0
    f22_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f22_local0, f22_local1, TARGET_ENE_0, f22_local2, f22_local3, f22_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function ProlificRenala203100_Act31(f23_arg0, f23_arg1, f23_arg2)
    f23_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    local f23_local0 = 4
    local f23_local1 = 3026
    local f23_local2 = 5 - f23_arg0:GetMapHitRadius(TARGET_SELF)
    local f23_local3 = 0
    local f23_local4 = 0
    f23_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f23_local0, f23_local1, TARGET_ENE_0, f23_local2, f23_local3, f23_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function ProlificRenala203100_Act40(f24_arg0, f24_arg1, f24_arg2)
    local f24_local0 = 2
    local f24_local1 = 2
    local f24_local2 = true
    local f24_local3 = -1
    f24_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, f24_local0, TARGET_ENE_0, f24_local1, TARGET_SELF, f24_local2, f24_local3)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function ProlificRenala203100_Act41(f25_arg0, f25_arg1, f25_arg2)
    local f25_local0 = 3
    local f25_local1 = 20
    local f25_local2 = true
    local f25_local3 = -1
    f25_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, f25_local0, TARGET_ENE_0, f25_local1, TARGET_SELF, f25_local2, f25_local3)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function ProlificRenala203100_Act42(f26_arg0, f26_arg1, f26_arg2)
    f26_arg1:AddSubGoal(GOAL_COMMON_Turn, 2, TARGET_ENE_0, f26_arg0:GetRandam_Int(15, 20), 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function ProlificRenala203100_Act43(f27_arg0, f27_arg1, f27_arg2)
    f27_arg0:SetStringIndexedNumber("BackStepFlg", 1)
    local f27_local0 = 20
    local f27_local1 = 6001
    local f27_local2 = TARGET_ENE_0
    local f27_local3 = 0
    local f27_local4 = AI_DIR_TYPE_R
    local f27_local5 = 0
    f27_arg1:AddSubGoal(GOAL_COMMON_SpinStep, f27_local0, f27_local1, f27_local2, f27_local3, f27_local4, f27_local5)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function ProlificRenala203100_Act44(f28_arg0, f28_arg1, f28_arg2)
    local f28_local0 = f28_arg0:GetRandam_Int(0, 1)
    local f28_local1 = 3.5
    local f28_local2 = TARGET_ENE_0
    local f28_local3 = f28_local0
    local f28_local4 = 15
    local f28_local5 = true
    local f28_local6 = -1
    local f28_local7 = GUARD_GOAL_DESIRE_RET_Failed
    local f28_local8 = true
    f28_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, f28_local1, f28_local2, f28_local3, f28_local4, f28_local5, isLifeSuccess, f28_local6, f28_local7)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function ProlificRenala203100_Act45(f29_arg0, f29_arg1, f29_arg2)
    local f29_local0 = 6
    local f29_local1 = 15
    local f29_local2 = true
    local f29_local3 = -1
    f29_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, f29_local0, TARGET_ENE_0, f29_local1, TARGET_SELF, f29_local2, f29_local3)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function ProlificRenala203100_Act46(f30_arg0, f30_arg1, f30_arg2)
    local f30_local0 = 3
    local f30_local1 = TARGET_ENE_0
    local f30_local2 = 8
    local f30_local3 = TARGET_ENE_0
    local f30_local4 = true
    local f30_local5 = -1
    local f30_local6 = GUARD_GOAL_DESIRE_RET_Failed
    local f30_local7 = false
    local f30_local8 = 1
    f30_arg1:AddSubGoal(GOAL_COMMON_LeaveTargetToPathEnd, f30_local0, f30_local1, f30_local2, f30_local3, f30_local4, f30_local5, f30_local6, f30_local7, f30_local8)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function ProlificRenala203100_Act47(f31_arg0, f31_arg1, f31_arg2)
    if f31_arg0:IsExistMeshOnLine(TARGET_SELF, AI_DIR_TYPE_B, 1.5) and f31_arg0:GetDist(TARGET_ENE_0) <= 8 then
        local f31_local0 = 3
        local f31_local1 = TARGET_ENE_0
        local f31_local2 = 8
        local f31_local3 = TARGET_ENE_0
        local f31_local4 = true
        local f31_local5 = -1
        local f31_local6 = GUARD_GOAL_DESIRE_RET_Failed
        local f31_local7 = false
        local f31_local8 = 1
        f31_arg1:AddSubGoal(GOAL_COMMON_LeaveTargetToPathEnd, f31_local0, f31_local1, f31_local2, f31_local3, f31_local4, f31_local5, f31_local6, f31_local7, f31_local8)
    else
        local f31_local0 = f31_arg0:GetRandam_Int(0, 1)
        local f31_local1 = 3.5
        local f31_local2 = TARGET_ENE_0
        local f31_local3 = f31_local0
        local f31_local4 = 100
        local f31_local5 = true
        local f31_local6 = -1
        local f31_local7 = GUARD_GOAL_DESIRE_RET_Failed
        local f31_local8 = true
        f31_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, f31_local1, f31_local2, f31_local3, f31_local4, f31_local5, isLifeSuccess, f31_local6, f31_local7)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function ProlificRenala203100_ActAfter_AdjustSpace(f32_arg0, f32_arg1, f32_arg2)
    f32_arg1:AddSubGoal(GOAL_ProlificRenala203100_AfterAttackAct, 10)
    
end

Goal.Update = function (f33_arg0, f33_arg1, f33_arg2)
    return Update_Default_NoSubGoal(f33_arg0, f33_arg1, f33_arg2)
    
end

Goal.Terminate = function (f34_arg0, f34_arg1, f34_arg2)
    
end

Goal.Interrupt = function (f35_arg0, f35_arg1, f35_arg2)
    if f35_arg1:IsLadderAct(TARGET_SELF) then
        return false
    end
    local f35_local0 = 5 - f35_arg1:GetMapHitRadius(TARGET_SELF)
    local f35_local1 = 0
    local f35_local2 = 20
    local f35_local3 = f35_arg1:GetDist(TARGET_ENE_0)
    local f35_local4 = f35_arg1:GetRandam_Int(1, 100)
    if f35_arg1:IsInterupt(INTERUPT_Damaged) and f35_arg1:HasSpecialEffectId(TARGET_SELF, 5034) == false and f35_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 300, -1, 999) and f35_arg1:GetTimer(1) <= 0 and f35_local4 < 30 and f35_local3 < 5 then
        f35_arg1:SetTimer(1, 10)
        f35_arg2:ClearSubGoal()
        f35_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
        f35_arg2:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 4, 3015, TARGET_ENE_0, 0, 0, 0, 0, 0)
        return true
    end
    if f35_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) then
        if f35_arg1:HasSpecialEffectId(TARGET_SELF, 5026) then
            if f35_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 90, -1, 50) and f35_local3 > 15 then
                f35_arg2:ClearSubGoal()
                f35_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 6, 3004, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            end
        elseif f35_arg1:HasSpecialEffectId(TARGET_SELF, 5027) then
            f35_arg1:SetStringIndexedNumber("Warp_Cnt", f35_arg1:GetStringIndexedNumber("Warp_Cnt") + 1)
            f35_arg2:ClearSubGoal()
            f35_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 6, 3017, TARGET_ENE_0, 0, 0, 0, 0, 0)
            return true
        elseif f35_arg1:HasSpecialEffectId(TARGET_SELF, 5028) then
            if f35_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 90, -1, 20) then
                f35_arg2:ClearSubGoal()
                f35_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 6, 3011, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            end
        elseif f35_arg1:HasSpecialEffectId(TARGET_SELF, 5033) then
            if f35_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 90, -1, 999) and f35_arg1:GetRemainingAttackCoolTime(3007) <= 0 and f35_local3 > 15 then
                f35_arg2:ClearSubGoal()
                f35_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 6, 3007, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            end
        elseif f35_arg1:HasSpecialEffectId(TARGET_SELF, 14586) then
            local f35_local5 = 7
            local f35_local6 = 0
            local f35_local7 = 1.5
            f35_arg2:ClearSubGoal()
            f35_arg1:SetStringIndexedNumber("ExistMeshOnLine_SELF_F", f35_arg1:GetExistMeshOnLineDistEx(TARGET_SELF, AI_DIR_TYPE_F, 70 + f35_local7, f35_local7, 0))
            f35_arg1:SetStringIndexedNumber("ExistMeshOnLine_SELF_FL", f35_arg1:GetExistMeshOnLineDistEx(TARGET_SELF, AI_DIR_TYPE_FL, 70 + f35_local7, f35_local7, 0))
            f35_arg1:SetStringIndexedNumber("ExistMeshOnLine_SELF_FR", f35_arg1:GetExistMeshOnLineDistEx(TARGET_SELF, AI_DIR_TYPE_FR, 70 + f35_local7, f35_local7, 0))
            f35_arg1:SetStringIndexedNumber("ExistMeshOnLine_SELF_L", f35_arg1:GetExistMeshOnLineDistEx(TARGET_SELF, AI_DIR_TYPE_L, 70 + f35_local7, f35_local7, 0))
            f35_arg1:SetStringIndexedNumber("ExistMeshOnLine_SELF_R", f35_arg1:GetExistMeshOnLineDistEx(TARGET_SELF, AI_DIR_TYPE_R, 70 + f35_local7, f35_local7, 0))
            f35_arg1:SetStringIndexedNumber("ExistMeshOnLine_SELF_B", f35_arg1:GetExistMeshOnLineDistEx(TARGET_SELF, AI_DIR_TYPE_B, 70 + f35_local7, f35_local7, 0))
            f35_arg1:SetStringIndexedNumber("ExistMeshOnLine_SELF_BL", f35_arg1:GetExistMeshOnLineDistEx(TARGET_SELF, AI_DIR_TYPE_BL, 70 + f35_local7, f35_local7, 0))
            f35_arg1:SetStringIndexedNumber("ExistMeshOnLine_SELF_BR", f35_arg1:GetExistMeshOnLineDistEx(TARGET_SELF, AI_DIR_TYPE_BR, 70 + f35_local7, f35_local7, 0))
            if f35_arg1:GetStringIndexedNumber("ExistMeshOnLine_SELF_BL") >= 8 or f35_arg1:GetStringIndexedNumber("ExistMeshOnLine_SELF_BR") >= 8 then
                if f35_arg1:GetStringIndexedNumber("ExistMeshOnLine_SELF_BL") < 8 then
                    f35_local6 = AI_DIR_TYPE_BR
                elseif f35_arg1:GetStringIndexedNumber("ExistMeshOnLine_SELF_BR") < 8 then
                    f35_local6 = AI_DIR_TYPE_BL
                elseif f35_local4 > 50 then
                    f35_local6 = AI_DIR_TYPE_BL
                else
                    f35_local6 = AI_DIR_TYPE_BR
                end
            elseif f35_arg1:GetStringIndexedNumber("ExistMeshOnLine_SELF_BL") >= 8 then
                f35_local6 = AI_DIR_TYPE_B
            elseif f35_arg1:GetStringIndexedNumber("ExistMeshOnLine_SELF_L") >= 8 or f35_arg1:GetStringIndexedNumber("ExistMeshOnLine_SELF_R") >= 8 then
                if f35_arg1:GetStringIndexedNumber("ExistMeshOnLine_SELF_L") < 8 then
                    f35_local6 = AI_DIR_TYPE_R
                elseif f35_arg1:GetStringIndexedNumber("ExistMeshOnLine_SELF_R") < 8 then
                    f35_local6 = AI_DIR_TYPE_L
                elseif f35_local4 > 50 then
                    f35_local6 = AI_DIR_TYPE_L
                else
                    f35_local6 = AI_DIR_TYPE_R
                end
            elseif f35_arg1:GetStringIndexedNumber("ExistMeshOnLine_SELF_FL") >= 8 or f35_arg1:GetStringIndexedNumber("ExistMeshOnLine_SELF_FR") >= 8 then
                if f35_arg1:GetStringIndexedNumber("ExistMeshOnLine_SELF_FL") < 8 then
                    f35_local6 = AI_DIR_TYPE_FR
                elseif f35_arg1:GetStringIndexedNumber("ExistMeshOnLine_SELF_FR") < 8 then
                    f35_local6 = AI_DIR_TYPE_FL
                elseif f35_local4 > 50 then
                    f35_local6 = AI_DIR_TYPE_FL
                else
                    f35_local6 = AI_DIR_TYPE_FR
                end
            elseif f35_arg1:GetStringIndexedNumber("ExistMeshOnLine_SELF_F") < 8 then
                f35_local6 = AI_DIR_TYPE_F
            else
                f35_local6 = AI_DIR_TYPE_F
                f35_local5 = 0
            end
            f35_arg2:AddSubGoal(GOAL_COMMON_ToTargetWarp, 5, TARGET_SELF, f35_local6, f35_local5, TARGET_ENE_0)
            return true
        end
    end
    return false
    
end

RegisterTableGoal(GOAL_ProlificRenala203100_AfterAttackAct, "ProlificRenala203100_AfterAttackAct")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_ProlificRenala203100_AfterAttackAct, true)

Goal.Update = function (f36_arg0, f36_arg1, f36_arg2)
    return Update_Default_NoSubGoal(f36_arg0, f36_arg1, f36_arg2)
    
end


