﻿function DemiHumanBerserk412020_Logic(f1_arg0)
    COMMON_Initialize(f1_arg0)
    if COMMON_EasySetup_Initial(f1_arg0) == false then
        local f1_local0 = f1_arg0:GetEventRequest()
        local f1_local1 = f1_arg0:IsSearchTarget(TARGET_ENE_0)
        local f1_local2 = f1_arg0:GetDist(POINT_INITIAL)
        local f1_local3 = GetCurrentTimeType(f1_arg0)
        local f1_local4 = f1_arg0:GetPrevTargetState()
        local f1_local5 = f1_arg0:IsBattleState()
        if f1_arg0:HasSpecialEffectId(TARGET_SELF, 10545) == true then
            f1_arg0:AddTopGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, 3038, TARGET_ENE_0, 999, 0, 0, 0, 0)
        elseif f1_arg0:HasSpecialEffectId(TARGET_SELF, 10544) == true then
            f1_arg0:AddTopGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, 3037, TARGET_ENE_0, 999, 0, 0, 0, 0)
        else
            COMMON_EasySetup3(f1_arg0)
        end
    end
    
end

function DemiHumanBerserk412020_Interupt(f2_arg0, f2_arg1)
    
end

function DemiHumanBerserk412020_NoneBattleCheck(f3_arg0)
    if f3_arg0:IsBattleState() == false and f3_arg0:IsCautionState() == false and f3_arg0:IsFindState() == false and f3_arg0:IsSearchLowState() == false and f3_arg0:IsSearchHighState() == false then
        return true
    else
        return false
    end
    
end


