﻿function UncoverTombNobleMan430000_Logic(f1_arg0)
    COMMON_Initialize(f1_arg0)
    if COMMON_EasySetup_Initial(f1_arg0) == false then
        local f1_local0 = f1_arg0:GetDist(TARGET_ENE_0)
        local f1_local1 = f1_arg0:GetEventRequest()
        local f1_local2 = f1_arg0:IsSearchTarget(TARGET_ENE_0)
        local f1_local3 = f1_arg0:GetCurrTargetType()
        local f1_local4 = f1_arg0:GetPrevTargetState()
        local f1_local5 = f1_arg0:GetPlatoonCommand()
        local f1_local6 = f1_local5:GetCommandNo()
        local f1_local7 = 9
        if f1_arg0:IsBattleState() == false and f1_arg0:IsCautionState() == false and f1_arg0:IsSearchLowState() == false and f1_arg0:IsSearchHighState() == false then
            f1_arg0:SetNumber(f1_local7, 0)
        end
        if f1_local1 == 100 then
            f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 5, POINT_INITIAL, 0.5, TARGET_SELF, true, -1)
        elseif f1_local1 == 110 then
            f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 5, POINT_INITIAL, 0.5, TARGET_SELF, false, -1)
        elseif f1_arg0:HasSpecialEffectId(TARGET_SELF, 10293) == true then
            f1_arg0:AddTopGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, 3026, TARGET_ENE_0, 999, 0, 0, 0, 0)
        elseif f1_arg0:HasSpecialEffectId(TARGET_SELF, 10111) == true then
            if f1_arg0:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 4) then
                f1_arg0:AddTopGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 15, 3002, TARGET_ENE_0, 999, 0, 0, 0, 0)
            elseif f1_arg0:IsBattleState() == false and f1_arg0:IsMemoryState() == false and f1_arg0:IsCautionState() == false and f1_arg0:IsFindState() == false and f1_arg0:IsSearchLowState() == false and f1_arg0:IsSearchHighState() == false then
                f1_arg0:AddTopGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 15, 3002, TARGET_ENE_0, 999, 0, 0, 0, 0)
            else
                f1_arg0:AddTopGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 15, 3001, TARGET_ENE_0, 999, 0, 0, 0, 0)
            end
        else
            if f1_arg0:IsChangeState() and f1_arg0:IsCautionState() then
                if f1_arg0:GetNumber(8) == 0 then
                    local f1_local8 = 10
                    local f1_local9 = 3031
                    if f1_arg0:GetTimer(11) <= 0 and (f1_local0 >= 10 or f1_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_B, 200)) then
                        f1_arg0:SetTimer(11, f1_local8)
                        f1_arg0:AddTopGoal(GOAL_COMMON_Wait, f1_arg0:GetRandam_Float(0, 3), TARGET_ENE_0, 0, 0, 0)
                        f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, f1_local9, TARGET_ENE_0, 9999, 0, 0, 0, 0)
                    end
                else
                    local f1_local8 = 10
                    local f1_local9 = 3031
                    f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, f1_arg0:GetRandam_Float(4, 5.5), TARGET_ENE_0, 0, TARGET_SELF, true, -1):SetLifeEndSuccess(true)
                    f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 5, TARGET_ENE_0, f1_local0, TARGET_SELF, true, -1)
                    f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, f1_local9, TARGET_SELF, 9999, 0, 0, 0, 0)
                    f1_arg0:AddTopGoal(GOAL_COMMON_Wait, 3, TARGET_NONE, 0, 0, 0)
                    f1_arg0:SetNumber(8, 0)
                end
            else
            end
            COMMON_EasySetup3(f1_arg0)
        end
    end
    
end

function UncoverTombNobleMan430000_Interupt(f2_arg0, f2_arg1)
    local f2_local0 = f2_arg0:GetPlatoonCommand()
    local f2_local1 = f2_local0:GetCommandNo()
    local f2_local2 = 14
    isChangedOrder = f2_arg0:IsInterupt(INTERUPT_PlatoonAiOrder)
    if isChangedOrder and f2_local1 == f2_local2 then
        f2_arg1:ClearSubGoal()
        f2_arg0:Replaning()
    end
    
end


