﻿RegisterTableGoal(GOAL_Deer601000_Battle, "Deer601000_Battle")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_Deer601000_Battle, true)

Goal.Initialize = function (f1_arg0, f1_arg1, f1_arg2, f1_arg3)
    Init_Pseudo_Global(f1_arg1, f1_arg2)
    f1_arg1:GetStringIndexedNumber("WalkBefore")
    f1_arg1:GetStringIndexedNumber("Alert_mode")
    f1_arg1:GetStringIndexedNumber("TURNING_RANGE")
    f1_arg1:GetStringIndexedNumber("Warp_Late")
    Warp_Late = f1_arg1:GetRandam_Int(1, 100)
    
end

Goal.Activate = function (f2_arg0, f2_arg1, f2_arg2)
    if FearOfFire(f2_arg1, f2_arg2, PLAN_SIDEWAYTYPE__NONE) == true then
        return
    end
    local f2_local0 = {}
    local f2_local1 = {}
    local f2_local2 = {}
    Common_Clear_Param(f2_local0, f2_local1, f2_local2)
    local f2_local3 = f2_arg1:GetDist(TARGET_ENE_0)
    local f2_local4 = f2_arg1:GetDist(TARGET_FRI_0)
    local f2_local5 = f2_arg1:GetRandam_Int(1, 100)
    local f2_local6 = f2_arg1:GetPrevTargetState()
    local f2_local7 = f2_arg1:HasSpecialEffectId(TARGET_SELF, 8500)
    local f2_local8 = f2_arg1:HasSpecialEffectId(TARGET_ENE_0, 8110)
    local f2_local9 = f2_arg1:HasSpecialEffectId(TARGET_FRI_0, 8110)
    local f2_local10 = f2_arg1:GetRandam_Int(22, 22)
    local f2_local11 = f2_arg1:GetRandam_Int(25, 25)
    local f2_local12 = f2_arg1:GetRandam_Int(1, 100)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 13161)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 13156)
    if f2_arg1:HasSpecialEffectId(TARGET_SELF, 13156) == true then
        f2_local0[15] = 95
    elseif f2_local9 == false and f2_local4 > 0 and f2_local4 <= f2_local10 then
        f2_local0[17] = 100
    elseif f2_local8 == false and f2_local3 > 0 and f2_local3 <= f2_local10 then
        f2_local0[17] = 100
    elseif f2_local4 > 0 and f2_local4 <= f2_local11 then
        f2_local0[3] = 100
    elseif f2_local3 > 0 and f2_local3 <= f2_local11 then
        f2_local0[3] = 100
    elseif f2_local3 < 0 or f2_local4 < 0 then
        f2_local0[1] = 35
        f2_local0[2] = 25
        f2_local0[10] = 40
    end
    f2_local0[15] = SetCoolTime(f2_arg1, f2_arg2, 3000, 10, f2_local0[15], 1)
    f2_local1[1] = REGIST_FUNC(f2_arg1, f2_arg2, Deer601000_Act01)
    f2_local1[2] = REGIST_FUNC(f2_arg1, f2_arg2, Deer601000_Act02)
    f2_local1[3] = REGIST_FUNC(f2_arg1, f2_arg2, Deer601000_Act03)
    f2_local1[10] = REGIST_FUNC(f2_arg1, f2_arg2, Deer601000_Act10)
    f2_local1[11] = REGIST_FUNC(f2_arg1, f2_arg2, Deer601000_Act11)
    f2_local1[12] = REGIST_FUNC(f2_arg1, f2_arg2, Deer601000_Act12)
    f2_local1[13] = REGIST_FUNC(f2_arg1, f2_arg2, Deer601000_Act13)
    f2_local1[14] = REGIST_FUNC(f2_arg1, f2_arg2, Deer601000_Act14)
    f2_local1[15] = REGIST_FUNC(f2_arg1, f2_arg2, Deer601000_Act15)
    f2_local1[17] = REGIST_FUNC(f2_arg1, f2_arg2, Deer601000_Act17)
    local f2_local13 = REGIST_FUNC(f2_arg1, f2_arg2, Deer601000_ActAfter_AdjustSpace)
    Common_Battle_Activate(f2_arg1, f2_arg2, f2_local0, f2_local1, f2_local13, f2_local2)
    
end

function Deer601000_Act01(f3_arg0, f3_arg1, f3_arg2)
    local f3_local0 = f3_arg0:GetRandam_Int(1, 100)
    f3_arg0:SetStringIndexedNumber("WalkBefore", 0)
    if f3_local0 <= 30 then
        f3_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 5, 3021, TARGET_SELF, DIST_None, 0, 90)
    elseif f3_local0 <= 60 then
        f3_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 5, 3021, TARGET_SELF, DIST_None, 0, 180, 0, 0)
        f3_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 5, 3022, TARGET_SELF, DIST_None, 0, 0)
        f3_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 5, 3022, TARGET_SELF, DIST_None, 0, 0)
    else
        f3_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 5, 3021, TARGET_SELF, DIST_None, 0, 180, 0, 0)
        f3_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 5, 3022, TARGET_SELF, DIST_None, 0, 0)
        f3_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 5, 3022, TARGET_SELF, DIST_None, 0, 0)
        f3_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 5, 3022, TARGET_SELF, DIST_None, 0, 0)
        f3_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 5, 3022, TARGET_SELF, DIST_None, 0, 0)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Deer601000_Act02(f4_arg0, f4_arg1, f4_arg2)
    f4_arg0:SetStringIndexedNumber("WalkBefore", 0)
    f4_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3020, TARGET_SELF, DIST_None, 0, 90)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Deer601000_Act03(f5_arg0, f5_arg1, f5_arg2)
    local f5_local0 = TARGET_ENE_0
    if f5_arg0:GetDist(TARGET_ENE_0) < 0 then
        f5_local0 = TARGET_FRI_0
    end
    f5_arg0:SetStringIndexedNumber("WalkBefore", 0)
    f5_arg0:AddObserveArea(0, TARGET_SELF, f5_local0, AI_DIR_TYPE_F, 360, 22)
    f5_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 2.5, 3023, f5_local0, DIST_None, 0, 90)
    f5_arg0:SetStringIndexedNumber("Alert_mode", 1)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Deer601000_Act10(f6_arg0, f6_arg1, f6_arg2)
    local f6_local0 = 1
    f6_arg0:SetStringIndexedNumber("WalkBefore", 1)
    f6_arg1:AddSubGoal(GOAL_COMMON_WalkAround_Anywhere, -1, 1, 10, true, -1, 0, 1, false, false)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Deer601000_Act11(f7_arg0, f7_arg1, f7_arg2)
    local f7_local0 = 3 - f7_arg0:GetMapHitRadius(TARGET_SELF)
    local f7_local1 = f7_arg0:GetRelativeAngleFromTarget(TARGET_ENE_0)
    local f7_local2 = -1
    local f7_local3 = 360
    local f7_local4 = f7_arg0:GetRandam_Int(1, 100)
    local f7_local5 = TARGET_ENE_0
    f7_arg1:ClearSubGoal()
    if f7_arg0:GetDist(TARGET_ENE_0) < 0 then
        f7_local5 = TARGET_FRI_0
    end
    f7_arg0:SetStringIndexedNumber("TURNING_RANGE", f7_arg0:GetRandam_Int(15, 20))
    if f7_local4 <= 60 then
        f7_arg0:AddObserveArea(0, TARGET_SELF, f7_local5, AI_DIR_TYPE_F, 360, f7_arg0:GetStringIndexedNumber("TURNING_RANGE"))
    end
    if f7_arg0:GetStringIndexedNumber("WalkBefore") == 1 then
        if f7_arg0:IsInsideTarget(f7_local5, AI_DIR_TYPE_F, 40) then
            f7_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 10, f7_arg0:GetRandam_Int(6000, 6001), f7_local5, 0, AI_DIR_TYPE_B, 0)
        elseif f7_local1 >= 20 then
            f7_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 10, 6002, f7_local5, 0, AI_DIR_TYPE_B, 0)
        elseif f7_local1 <= -20 then
            f7_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 10, 6003, f7_local5, 0, AI_DIR_TYPE_B, 0)
        else
            f7_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 10, f7_arg0:GetRandam_Int(6000, 6001), f7_local5, 0, AI_DIR_TYPE_B, 0)
        end
        f7_arg0:SetStringIndexedNumber("WalkBefore", 0)
        f7_arg0:SetStringIndexedNumber("Alert_mode", 0)
    end
    f7_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 10, f7_local5, 50, TARGET_SELF, false, -1)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Deer601000_Act12(f8_arg0, f8_arg1, f8_arg2)
    local f8_local0 = 3 - f8_arg0:GetMapHitRadius(TARGET_SELF)
    local f8_local1 = f8_arg0:GetRelativeAngleFromTarget(TARGET_ENE_0)
    local f8_local2 = 0
    local f8_local3 = 0
    local f8_local4 = f8_arg0:GetRandam_Int(1, 100)
    local f8_local5 = TARGET_ENE_0
    f8_arg0:SetStringIndexedNumber("TURNING_RANGE", f8_arg0:GetRandam_Int(15, 20))
    if f8_arg0:GetDist(TARGET_ENE_0) < 0 then
        f8_local5 = TARGET_FRI_0
    end
    if f8_arg0:GetStringIndexedNumber("WalkBefore") == 1 then
        f8_arg0:SetStringIndexedNumber("WalkBefore", 0)
    end
    local f8_local6 = f8_arg0:GetRandam_Int(1, 3.5)
    local f8_local7 = f8_arg0:GetRandam_Int(15, 20)
    local f8_local8 = f8_arg0:GetRandam_Int(5, 10)
    local f8_local9 = f8_arg0:GetRandam_Int(3, 8)
    f8_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, f8_local6, f8_local5, f8_local7, TARGET_SELF, false, -1):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
    if f8_arg0:GetDist(f8_local5) < f8_local7 then
        if f8_local4 <= 25 then
            local f8_local10 = f8_arg0:GetRandam_Int(3005, 3006)
            for f8_local11 = 1, f8_local8, 1 do
                f8_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f8_local10, TARGET_NONE, DIST_None, 0, 90)
            end
        else
            local f8_local10 = f8_arg0:GetRandam_Int(3007, 3008)
            for f8_local11 = 1, f8_local9, 1 do
                f8_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f8_local10, TARGET_NONE, DIST_None, 0, 90)
            end
        end
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Deer601000_Act13(f9_arg0, f9_arg1, f9_arg2)
    local f9_local0 = 3 - f9_arg0:GetMapHitRadius(TARGET_SELF)
    local f9_local1 = f9_arg0:GetRelativeAngleFromTarget(TARGET_ENE_0)
    local f9_local2 = -1
    local f9_local3 = 360
    local f9_local4 = f9_arg0:GetRandam_Int(1, 100)
    local f9_local5 = TARGET_ENE_0
    if f9_arg0:GetDist(TARGET_ENE_0) < 0 then
        f9_local5 = TARGET_FRI_0
    end
    local f9_local6 = f9_arg0:GetDist(f9_local5)
    local f9_local7 = f9_arg0:GetMapHitRadius(TARGET_SELF)
    local f9_local8 = 15
    local f9_local9 = f9_arg0:GetExistMeshOnLineDistEx(TARGET_SELF, AI_DIR_TYPE_F, f9_local8 + f9_local7, f9_local7, 0)
    local f9_local10 = f9_arg0:GetRandam_Int(AI_DIR_TYPE_L, AI_DIR_TYPE_R)
    f9_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget_Continuous, 10, f9_local5, 30, TARGET_SELF, false, -1, GUARD_GOAL_DESIRE_RET_Continue, false, 2)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Deer601000_Act14(f10_arg0, f10_arg1, f10_arg2)
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 13161)
    f10_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 2, TARGET_SOUND, f10_arg0:GetRandam_Float(1, 6), TARGET_SELF, false, -1)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Deer601000_Act15(f11_arg0, f11_arg1, f11_arg2)
    local f11_local0 = 2
    local f11_local1 = 0
    local f11_local2 = 0
    local f11_local3 = 100
    local f11_local4 = 0
    local f11_local5 = 2
    local f11_local6 = 2
    Approach_Act_Flex(f11_arg0, f11_arg1, f11_local0, f11_local1, f11_local2, f11_local3, f11_local4, f11_local5, f11_local6)
    local f11_local7 = 3
    local f11_local8 = 3000
    local f11_local9 = 3 - f11_arg0:GetMapHitRadius(TARGET_SELF)
    local f11_local10 = -1
    local f11_local11 = 60
    f11_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f11_local7, f11_local8, TARGET_ENE_0, f11_local9, f11_local10, f11_local11, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Deer601000_Act17(f12_arg0, f12_arg1, f12_arg2)
    if f12_arg0:HasSpecialEffectId(TARGET_SELF, 5160) then
        f12_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget_Continuous, 10, TARGET_ENE_0, 30, TARGET_SELF, false, -1, GUARD_GOAL_DESIRE_RET_Continue, false, 2)
    else
        f12_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget_Escape, 10, TARGET_ENE_0, 30, TARGET_SELF, false, 1.5)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Deer601000_ActAfter_AdjustSpace(f13_arg0, f13_arg1, f13_arg2)
    f13_arg1:AddSubGoal(GOAL_Deer601000_AfterAttackAct, 10)
    
end

Goal.Update = function (f14_arg0, f14_arg1, f14_arg2)
    return Update_Default_NoSubGoal(f14_arg0, f14_arg1, f14_arg2)
    
end

Goal.Terminate = function (f15_arg0, f15_arg1, f15_arg2)
    
end

Goal.Interrupt = function (f16_arg0, f16_arg1, f16_arg2)
    local f16_local0 = f16_arg1:GetRandam_Int(1, 100)
    local f16_local1 = f16_arg1:GetDist(TARGET_ENE_0)
    if f16_arg1:IsLadderAct(TARGET_SELF) then
        return false
    end
    local f16_local2 = 25 + 10
    local f16_local3 = 100
    if Damaged_Act(f16_arg1, f16_arg2, f16_local2, f16_local3) then
        f16_arg2:ClearSubGoal()
        f16_arg1:SetStringIndexedNumber("TURNING_RANGE", f16_arg1:GetRandam_Int(15, 20))
        f16_arg1:AddObserveArea(0, TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 360, f16_arg1:GetStringIndexedNumber("TURNING_RANGE"))
        f16_arg2:AddSubGoal(GOAL_COMMON_LeaveTarget, 10, TARGET_ENE_0, 50, TARGET_SELF, false, -1)
        return true
    end
    if f16_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) then
        if f16_arg1:HasSpecialEffectId(TARGET_SELF, 13161) then
            local f16_local4 = f16_arg1:GetRandam_Int(1, 8)
            local f16_local5 = f16_arg1:GetRandam_Int(0, 3)
            local f16_local6 = TARGET_ENE_0
            f16_arg2:ClearSubGoal()
            f16_arg2:AddSubGoal(GOAL_COMMON_ToTargetWarp, 5, TARGET_SOUND, f16_local4, f16_local5, f16_local6)
            return true
        elseif f16_arg1:HasSpecialEffectId(TARGET_SELF, 13156) then
            f16_arg1:Replaning()
            return true
        end
    end
    return false
    
end

RegisterTableGoal(GOAL_Deer601000_AfterAttackAct, "Deer601000_AfterAttackAct")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_Deer601000_AfterAttackAct, true)

Goal.Activate = function (f17_arg0, f17_arg1, f17_arg2)
    local f17_local0 = f17_arg1:GetDist(TARGET_ENE_0)
    local f17_local1 = f17_arg1:GetToTargetAngle(TARGET_ENE_0)
    f17_arg1:SetStringIndexedNumber("DistMin_AAA", -999)
    f17_arg1:SetStringIndexedNumber("DistMax_AAA", 7)
    f17_arg1:SetStringIndexedNumber("BaseDir_AAA", AI_DIR_TYPE_F)
    f17_arg1:SetStringIndexedNumber("Angle_AAA", 180)
    f17_arg1:SetStringIndexedNumber("DistMin_Inter_AAA", 1)
    f17_arg1:SetStringIndexedNumber("DistMax_Inter_AAA", 10)
    f17_arg1:SetStringIndexedNumber("BaseAng_Inter_AAA", 0)
    f17_arg1:SetStringIndexedNumber("Ang_Inter_AAA", 180)
    f17_arg2:AddSubGoal(GOAL_COMMON_AfterAttackAct, 10)
    
end

Goal.Update = function (f18_arg0, f18_arg1, f18_arg2)
    return Update_Default_NoSubGoal(f18_arg0, f18_arg1, f18_arg2)
    
end


