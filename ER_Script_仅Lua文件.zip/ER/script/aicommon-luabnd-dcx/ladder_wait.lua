﻿function LadderWait_Activate(f1_arg0, f1_arg1)
    LadderWait_AddInnerGoal(f1_arg0, f1_arg1)
    f1_arg1:SetNumber(0, 0)
    
end

function LadderWait_Update(f2_arg0, f2_arg1)
    if f2_arg1:GetNumber(0) == 1 then
        if f2_arg0:GetTimer(0) <= 0 then
            if f2_arg0:IsChrAroundLadderEdge(2.5, dmyStartId) == false then
                return GOAL_RESULT_Success
            else
                f2_arg1:SetTimer(0, f2_arg0:GetRandam_Float(0, 2))
            end
        end
    else
        local f2_local0 = f2_arg0:CalcGetNearestLadderActDmyIdByLadder()
        if f2_arg0:IsChrAroundLadderEdge(2.5, f2_local0) == false then
            local f2_local1 = f2_arg0:GetRandam_Float(0, 2)
            f2_arg1:SetTimer(0, f2_local1)
            f2_arg1:SetNumber(0, 1)
        end
    end
    if f2_arg1:GetSubGoalNum() <= 0 then
        LadderWait_AddInnerGoal(f2_arg0, f2_arg1)
    end
    return GOAL_RESULT_Continue
    
end

function LadderWait_Terminate(f3_arg0, f3_arg1)
    
end

REGISTER_GOAL_NO_INTERUPT(GOAL_COMMON_LadderAct, true)

function LadderWait_Interupt(f4_arg0, f4_arg1)
    if f4_arg0:IsInterupt(INTERUPT_Damaged) then
        return false
    end
    return false
    
end

function LadderWait_AddInnerGoal(f5_arg0, f5_arg1)
    local f5_local0 = f5_arg0:GetDistXZ(TARGET_ENE_0)
    if f5_local0 <= 1 then
    elseif f5_local0 <= 3 then
        f5_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 2, TARGET_ENE_0, 999, TARGET_ENE_0, true, -1):SetLifeEndSuccess(true)
    end
    f5_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, f5_arg0:GetRandam_Float(2, 4), TARGET_ENE_0, f5_arg0:GetRandam_Int(0, 1), f5_arg0:GetRandam_Int(30, 45), true, true, -1):SetLifeEndSuccess(true)
    f5_arg1:AddSubGoal(GOAL_COMMON_Wait, f5_arg0:GetRandam_Float(0.5, 1), TARGET_ENE_0)
    
end


