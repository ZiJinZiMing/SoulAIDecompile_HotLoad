﻿function Platoon010200_Initialize(f1_arg0)
    f1_arg0:SetEnablePlatoonMove(true)
    f1_arg0:SetFormationType(0, 2)
    f1_arg0:SetFormationParam(0, 0, 0)
    f1_arg0:SetFormationParam(1, 1, -2)
    f1_arg0:SetFormationParam(2, -1, -2)
    f1_arg0:SetFormationParam(3, 0.8, -4)
    f1_arg0:SetFormationParam(4, -0.8, -4)
    f1_arg0:SetBaseMoveRate(0, 2.5)
    
end

function Platoon010200_Activate(f2_arg0)
    
end

function Platoon010200_Deactivate(f3_arg0)
    
end

function Platoon010200_Update(f4_arg0)
    Platoon_Common_Act(f4_arg0, 1)
    
end


