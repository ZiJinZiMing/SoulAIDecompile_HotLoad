﻿function Platoon000900_Initialize(f1_arg0)
    f1_arg0:SetEnablePlatoonMove(true)
    f1_arg0:SetFormationType(0, 2)
    f1_arg0:SetFormationParam(0, 0, 0)
    f1_arg0:SetFormationParam(1, 4, 13)
    f1_arg0:SetFormationParam(2, -4, 13)
    f1_arg0:SetFormationParam(3, 0, -1)
    f1_arg0:SetFormationParam(4, 0, -15)
    f1_arg0:SetFormationParam(5, -7, -10)
    f1_arg0:SetFormationParam(6, 7, -10)
    f1_arg0:SetFormationParam(30, 4.5, -13)
    f1_arg0:SetFormationParam(31, -4.5, -13)
    f1_arg0:SetFormationParam(28, -7, -10)
    f1_arg0:SetFormationParam(29, 7, -10)
    f1_arg0:SetFormationParam(7, 5, -1)
    f1_arg0:SetFormationParam(8, -5, -1)
    f1_arg0:SetFormationParam(9, 5, -5)
    f1_arg0:SetFormationParam(10, -5, -5)
    f1_arg0:SetFormationParam(11, 5, -9)
    f1_arg0:SetFormationParam(12, -5, -9)
    f1_arg0:SetFormationParam(13, 1, -18)
    f1_arg0:SetFormationParam(14, -2, -19)
    f1_arg0:SetFormationParam(15, 5, -20)
    f1_arg0:SetFormationParam(16, -1, -21)
    f1_arg0:SetFormationParam(17, 1, -21)
    f1_arg0:SetFormationParam(18, -2, -23)
    f1_arg0:SetFormationParam(19, 2, -24)
    f1_arg0:SetFormationParam(20, 1, -25)
    f1_arg0:SetFormationParam(21, 0, -26)
    f1_arg0:SetFormationParam(22, -5, -30)
    f1_arg0:SetFormationParam(23, 0, -30)
    f1_arg0:SetFormationParam(24, 5, 3)
    f1_arg0:SetFormationParam(25, -5, 3)
    f1_arg0:SetFormationParam(26, 6.5, -2)
    f1_arg0:SetFormationParam(27, -6.5, -2)
    f1_arg0:SetBaseMoveRate(0, 16)
    
end

function Platoon000900_Activate(f2_arg0)
    
end

function Platoon000900_Deactivate(f3_arg0)
    
end

function Platoon000900_Update(f4_arg0)
    Platoon_Common_Act(f4_arg0, 1)
    
end


