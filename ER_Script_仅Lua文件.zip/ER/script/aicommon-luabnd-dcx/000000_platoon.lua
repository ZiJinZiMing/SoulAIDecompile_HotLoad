﻿function Platoon000000_Initialize(f1_arg0)
    
end

function Platoon000000_Activate(f2_arg0)
    
end

function Platoon000000_Deactivate(f3_arg0)
    
end

function Platoon000000_Update(f4_arg0)
    
end


