﻿function Platoon003450_Initialize(f1_arg0)
    f1_arg0:SetEnablePlatoonMove(true)
    f1_arg0:SetFormationType(0, 2)
    f1_arg0:SetFormationParam(0, 0, 0)
    f1_arg0:SetFormationParam(1, 0, -2.5)
    f1_arg0:SetFormationParam(2, 1.5, -4.5)
    f1_arg0:SetFormationParam(3, -1.5, -4.5)
    f1_arg0:SetFormationParam(4, 1.5, -6.5)
    f1_arg0:SetFormationParam(5, -1.5, -6.5)
    f1_arg0:SetFormationParam(6, 2.5, -10)
    f1_arg0:SetFormationParam(7, -2.5, -10)
    f1_arg0:SetBaseMoveRate(0, 1)
    f1_arg0:SetBaseMoveRate(1, 2.5)
    f1_arg0:SetBaseMoveRate(2, 1.7)
    f1_arg0:SetBaseMoveRate(3, 1.7)
    f1_arg0:SetBaseMoveRate(4, 1.7)
    f1_arg0:SetBaseMoveRate(5, 1.7)
    f1_arg0:SetBaseMoveRate(6, 0.5)
    f1_arg0:SetBaseMoveRate(7, 0.5)
    
end

function Platoon003450_Activate(f2_arg0)
    
end

function Platoon003450_Deactivate(f3_arg0)
    
end

function Platoon003450_Update(f4_arg0)
    Platoon_Common_Act(f4_arg0, 1)
    
end


