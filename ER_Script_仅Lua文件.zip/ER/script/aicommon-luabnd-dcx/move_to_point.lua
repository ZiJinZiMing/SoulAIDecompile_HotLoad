﻿RegisterTableGoal(GOAL_COMMON_MoveToMultiPoint, "GOAL_COMMON_MoveToMultiPoint")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_COMMON_MoveToMultiPoint, true)
REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_MoveToMultiPoint, 0, "到達判定距離", 0)
REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_MoveToMultiPoint, 1, "旋回対象", 0)
REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_MoveToMultiPoint, 2, "歩くか", 0)
REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_MoveToMultiPoint, 3, "ガード番号", 0)
REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_MoveToMultiPoint, 4, "ポイント1", 0)
REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_MoveToMultiPoint, 5, "ポイント2", 0)
REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_MoveToMultiPoint, 6, "ポイント3", 0)
REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_MoveToMultiPoint, 7, "ポイント4", 0)
REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_MoveToMultiPoint, 8, "ポイント5", 0)
REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_MoveToMultiPoint, 9, "ポイント6", 0)
REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_MoveToMultiPoint, 10, "ポイント7", 0)
REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_MoveToMultiPoint, 11, "ポイント8", 0)
REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_MoveToMultiPoint, 12, "ポイント9", 0)
REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_MoveToMultiPoint, 13, "ポイント10", 0)

Goal.Activate = function (f1_arg0, f1_arg1, f1_arg2)
    local f1_local0 = true
    for f1_local1 = 5, 13, 1 do
        if f1_arg2:GetParam(f1_local1) == nil or f1_arg2:GetParam(f1_local1) <= 0 then
            f1_arg2:SetNumber(0, f1_local1 - 1)
            f1_local0 = false
            break
        end
    end
    if f1_local0 == true then
        f1_arg2:SetNumber(0, 13)
    end
    local f1_local1 = 9999
    local f1_local2 = -1
    for f1_local3 = 4, f1_arg2:GetNumber(0) - 1, 1 do
        f1_arg1:SetEventMoveTarget(f1_arg2:GetParam(f1_local3))
        local f1_local6 = f1_arg1:GetDist(POINT_EVENT)
        if f1_local6 < f1_local1 then
            f1_local1 = f1_local6
            f1_local2 = f1_local3
        end
    end
    for f1_local3 = f1_local2, f1_arg2:GetNumber(0), 1 do
        f1_arg2:AddSubGoal(GOAL_COMMON_MoveToPoint, f1_arg2:GetLife(), f1_arg2:GetParam(f1_local3), f1_arg2:GetParam(0), f1_arg2:GetParam(1), f1_arg2:GetParam(2), f1_arg2:GetParam(3))
    end
    



end

Goal.Update = function (f2_arg0, f2_arg1, f2_arg2)
    if f2_arg2:GetSubGoalNum() <= 0 then
        if f2_arg1:GetDist(f2_arg2:GetParam(f2_arg2:GetNumber(0))) <= f2_arg2:GetParam(0) then
            return GOAL_RESULT_Success
        else
            local f2_local0 = 9999
            local f2_local1 = -1
            for f2_local2 = 4, f2_arg2:GetNumber(0), 1 do
                f2_arg1:SetEventMoveTarget(f2_arg2:GetParam(f2_local2))
                local f2_local5 = f2_arg1:GetDist(POINT_EVENT)
                if f2_local5 < f2_local0 then
                    f2_local0 = f2_local5
                    f2_local1 = f2_local2
                end
            end
            for f2_local2 = f2_local1, f2_arg2:GetNumber(0), 1 do
                f2_arg2:AddSubGoal(GOAL_COMMON_MoveToPoint, f2_arg2:GetLife(), f2_arg2:GetParam(f2_local2), f2_arg2:GetParam(0), f2_arg2:GetParam(1), f2_arg2:GetParam(2), f2_arg2:GetParam(3))
            end

        end
    end
    return GOAL_RESULT_Continue
    
end


