﻿function Platoon000730_Initialize(f1_arg0)
    f1_arg0:SetEnablePlatoonMove(true)
    f1_arg0:SetFormationType(0, 2)
    f1_arg0:SetFormationParam(0, 0, 0)
    f1_arg0:SetFormationParam(1, 0, -1)
    f1_arg0:SetFormationParam(2, 0, -1)
    f1_arg0:SetFormationParam(3, -1, -4.5)
    f1_arg0:SetFormationParam(4, 1, -5.5)
    f1_arg0:SetFormationParam(5, 0, -8)
    f1_arg0:SetBaseMoveRate(0, 3)
    f1_arg0:SetBaseMoveRate(1, 0.7)
    f1_arg0:SetBaseMoveRate(2, 0.7)
    f1_arg0:SetBaseMoveRate(3, 0.8)
    f1_arg0:SetBaseMoveRate(4, 0.7)
    
end

function Platoon000730_Activate(f2_arg0)
    
end

function Platoon000730_Deactivate(f3_arg0)
    
end

function Platoon000730_Update(f4_arg0)
    local f4_local0 = 1
    local f4_local1 = 0.9
    Platoon_Common_Act(f4_arg0, 1)
    
end


