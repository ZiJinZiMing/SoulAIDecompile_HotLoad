﻿function COMMON_PatrolBehavior_FlagInitialize(f1_arg0, f1_arg1)
    local f1_local0 = f1_arg0:GetMovePointNumber()
    if f1_arg0:GetStringIndexedNumber("COMMON_PatrolBehavior_MovePointIdx") ~= f1_local0 or f1_arg1 then
        f1_arg0:SetStringIndexedNumber("COMMON_PatrolBehavior_DoneAct", 0)
    end
    if f1_arg0:IsSearchLowState() or f1_arg0:IsSearchHighState() or f1_arg0:IsCautionState() or f1_arg0:IsBattleState() then
        f1_arg0:SetStringIndexedNumber("COMMON_PatrolBehavior_DoneAct", 1)
    end
    f1_arg0:SetStringIndexedNumber("COMMON_PatrolBehavior_MovePointIdx", f1_local0)
    
end

function COMMON_PatrolBehavior(f2_arg0, f2_arg1, f2_arg2)
    local f2_local0 = f2_arg0:GetPrevMovePointNumber()
    local f2_local1 = f2_arg0:GetMovePointActionId(f2_local0)
    if f2_arg2 ~= nil and f2_arg2 ~= -1 then
        f2_local1 = f2_arg2
    end
    if f2_local1 == 402000 then
        f2_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, -1, 3037, TARGET_SELF)
        return true
    end
    if f2_local1 == 405099 then
        f2_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, -1, 3031, TARGET_SELF)
        return true
    end
    if f2_local1 == 449100 then
        f2_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, -1, 20020, TARGET_SELF)
        return true
    end
    if f2_local1 == 455001 then
        f2_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, -1, 20002, TARGET_SELF)
        return true
    end
    if f2_local1 == 460000 then
        f2_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, -1, 3033, TARGET_SELF)
        return true
    end
    if f2_local1 >= 900001 and f2_local1 <= 900099 then
        local f2_local2 = f2_local1 - 900000
        f2_arg1:AddSubGoal(GOAL_COMMON_Wait, f2_local2, TARGET_SELF)
        return true
    end
    if f2_local1 >= 910001 and f2_local1 <= 919999 then
        local f2_local2 = (f2_local1 - 910000) / 100
        f2_arg1:AddSubGoal(GOAL_COMMON_Wait, f2_local2, TARGET_SELF)
        return true
    end
    if f2_local1 >= 1000000 and f2_local1 <= 1099999 then
        local f2_local2 = f2_local1 - 1000000
        if f2_local2 >= 3000 and f2_local2 <= 3039 then
        elseif f2_local2 >= 3100 and f2_local2 <= 3104 then
        elseif f2_local2 >= 3200 and f2_local2 <= 3204 then
        elseif f2_local2 >= 20000 and f2_local2 <= 20029 then
        else
            return false
        end
        f2_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, -1, f2_local2, TARGET_SELF)
        return true
    end
    return false
    
end


