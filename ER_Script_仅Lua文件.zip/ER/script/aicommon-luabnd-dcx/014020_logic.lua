﻿function common14020_Logic(f1_arg0)
    COMMON_Initialize(f1_arg0)
    if COMMON_EasySetup_Initial(f1_arg0) == false then
        local f1_local0 = f1_arg0:GetRandam_Int(1, 100)
        local f1_local1 = f1_arg0:GetEventRequest()
        local f1_local2 = f1_arg0:IsSearchTarget(TARGET_ENE_0)
        f1_arg0:GetStringIndexedNumber("TimerStart_a")
        if f1_arg0:GetStringIndexedNumber("TimerStart_a") == 0 then
            f1_arg0:SetTimer(0, 100)
            f1_arg0:SetTimer(1, 30)
            f1_arg0:SetTimer(2, 30)
            f1_arg0:SetTimer(2, 30)
            f1_arg0:SetStringIndexedNumber("TimerStart_a", 1)
        end
        if f1_arg0:IsChangeState() and f1_arg0:IsCautionState() then
            f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, 3031, TARGET_ENE_0, 9999, 0, 0, 0, 0)
        end
        if f1_arg0:IsChangeState() and f1_arg0:IsSearchLowState() == false and f1_arg0:IsSearchHighState() == false and f1_arg0:IsCautionState() == false and f1_arg0:IsBattleState() == false and f1_arg0:GetNumber(6) == 1 then
            f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, 3033, TARGET_ENE_0, 9999, 0, 0, 0, 0)
            f1_arg0:SetNumber(6, 0)
        end
        if f1_arg0:IsFinishTimer(1) == true then
            if f1_arg0:IsBattleState() then
                f1_arg0:SetTimer(1, 30)
            else
                local f1_local3 = f1_arg0:GetDist(TARGET_ENE_0)
                local f1_local4 = f1_arg0:GetRandam_Int(1, 100)
                if f1_local4 <= 40 and f1_local3 <= 20 then
                    f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, 3030, TARGET_SELF, 9999, 0, 0, 0, 0)
                    f1_arg0:SetTimer(1, 45)
                end
            end
        end
        if f1_arg0:IsFinishTimer(0) == true then
            f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, 3022, TARGET_SELF, DIST_Middle, 0, -1)
            f1_arg0:SetStringIndexedNumber("TimerStart_a", 0)
        end
        if f1_arg0:IsBattleState() then
            f1_arg0:SetTimer(0, 100)
            f1_arg0:SetTimer(2, 30)
        end
        if f1_arg0:IsFinishTimer(2) == true then
            f1_arg0:SetAIFixedMoveTargetSpecifyAngle(TARGET_LOCALPLAYER, 30, 1, AI_SPA_DIR_TYPE_TargetF)
            local f1_local3 = f1_arg0:GetDist(TARGET_LOCALPLAYER) - 10
            if f1_local0 <= 50 then
                f1_arg0:AddTopGoal(GOAL_COMMON_MoveToSomewhere, 10, POINT_AI_FIXED_POS, AI_DIR_TYPE_CENTER, 15, POINT_AI_FIXED_POS, false)
            else
            end
            f1_arg0:SetTimer(2, 10)
        end
        if f1_local1 == 100 then
            f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 5, POINT_INITIAL, 0.5, TARGET_SELF, true, -1)
        elseif f1_local1 == 110 then
            f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 5, POINT_INITIAL, 0.5, TARGET_SELF, false, -1)
        elseif RideRequest(f1_arg0, 10, -1) then
            f1_arg0:AddTopGoal(GOAL_COMMON_Mount, 10, 1.2)
        else
            COMMON_EasySetup3(f1_arg0)
        end
    end
    
end

function common14020_Interupt(f2_arg0, f2_arg1)
    
end


