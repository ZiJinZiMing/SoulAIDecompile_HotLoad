﻿function Platoon000451_Initialize(f1_arg0)
    f1_arg0:SetEnablePlatoonMove(true)
    f1_arg0:SetFormationType(0, 2)
    f1_arg0:SetFormationParam(0, 0, 0)
    f1_arg0:SetFormationParam(1, 0, -1)
    f1_arg0:SetFormationParam(2, -3, -6.1)
    f1_arg0:SetFormationParam(3, 0, -5.8)
    f1_arg0:SetFormationParam(4, 3, -6.1)
    f1_arg0:SetFormationParam(5, 0, -11)
    f1_arg0:SetBaseMoveRate(0, 1.5)
    
end

function Platoon000451_Activate(f2_arg0)
    
end

function Platoon000451_Deactivate(f3_arg0)
    
end

function Platoon000451_Update(f4_arg0)
    Platoon_Common_Act(f4_arg0, 1)
    
end


