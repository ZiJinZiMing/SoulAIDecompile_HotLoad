﻿function CommonAttack_Activate(f1_arg0, f1_arg1)
    
end

function CommonAttack_Update(f2_arg0, f2_arg1)
    return GOAL_RESULT_Continue
    
end

function CommonAttack_Terminate(f3_arg0, f3_arg1)
    
end

function CommonAttack_Interupt(f4_arg0, f4_arg1)
    return false
    
end


