﻿RegisterTableGoal(GOAL_Wyvern450010_Battle, "Wyvern450010_Battle")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_Wyvern450010_Battle, true)

Goal.Initialize = function (f1_arg0, f1_arg1, f1_arg2, f1_arg3)
    
end

Goal.Activate = function (f2_arg0, f2_arg1, f2_arg2)
    Init_Pseudo_Global(f2_arg1, f2_arg2)
    local f2_local0 = {}
    local f2_local1 = {}
    local f2_local2 = {}
    Common_Clear_Param(f2_local0, f2_local1, f2_local2)
    local f2_local3 = f2_arg1:GetDist(TARGET_ENE_0)
    local f2_local4 = f2_arg1:GetEventRequest()
    if f2_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_B, 180) then
        f2_local0[2] = 30
    elseif f2_local4 == 10 then
        f2_local0[12] = 50
    elseif f2_local4 == 20 then
        f2_local0[11] = 50
    elseif f2_local3 <= 5 then
        f2_local0[6] = 50
    else
        f2_local0[10] = 50
    end
    f2_local1[1] = REGIST_FUNC(f2_arg1, f2_arg2, Wyvern450010_Act01)
    f2_local1[2] = REGIST_FUNC(f2_arg1, f2_arg2, Wyvern450010_Act02)
    f2_local1[3] = REGIST_FUNC(f2_arg1, f2_arg2, Wyvern450010_Act03)
    f2_local1[4] = REGIST_FUNC(f2_arg1, f2_arg2, Wyvern450010_Act04)
    f2_local1[5] = REGIST_FUNC(f2_arg1, f2_arg2, Wyvern450010_Act05)
    f2_local1[6] = REGIST_FUNC(f2_arg1, f2_arg2, Wyvern450010_Act06)
    f2_local1[7] = REGIST_FUNC(f2_arg1, f2_arg2, Wyvern450010_Act07)
    f2_local1[8] = REGIST_FUNC(f2_arg1, f2_arg2, Wyvern450010_Act08)
    f2_local1[9] = REGIST_FUNC(f2_arg1, f2_arg2, Wyvern450010_Act09)
    f2_local1[10] = REGIST_FUNC(f2_arg1, f2_arg2, Wyvern450010_Act10)
    f2_local1[11] = REGIST_FUNC(f2_arg1, f2_arg2, Wyvern450010_Act11)
    f2_local1[12] = REGIST_FUNC(f2_arg1, f2_arg2, Wyvern450010_Act12)
    f2_local1[20] = REGIST_FUNC(f2_arg1, f2_arg2, Wyvern450010_Act20)
    f2_local1[21] = REGIST_FUNC(f2_arg1, f2_arg2, Wyvern450010_Act21)
    local f2_local5 = REGIST_FUNC(f2_arg1, f2_arg2, Wyvern450010_ActAfter_AdjustSpace)
    Common_Battle_Activate(f2_arg1, f2_arg2, f2_local0, f2_local1, f2_local5, f2_local2)
    
end

function Wyvern450010_Act01(f3_arg0, f3_arg1, f3_arg2)
    local f3_local0 = 3002
    local f3_local1 = 3003
    local f3_local2 = 15 - f3_arg0:GetMapHitRadius(TARGET_SELF)
    local f3_local3 = 20 - f3_arg0:GetMapHitRadius(TARGET_SELF)
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 5, f3_local0, TARGET_ENE_0, f3_local2, 0, 0, 0, 0)
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 5, f3_local1, TARGET_ENE_0, f3_local3, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wyvern450010_Act02(f4_arg0, f4_arg1, f4_arg2)
    local f4_local0 = 3004
    local f4_local1 = 20 - f4_arg0:GetMapHitRadius(TARGET_SELF)
    local f4_local2 = 0
    local f4_local3 = 0
    f4_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f4_local0, TARGET_ENE_0, f4_local1, f4_local2, f4_local3, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wyvern450010_Act03(f5_arg0, f5_arg1, f5_arg2)
    local f5_local0 = 3005
    local f5_local1 = 3006
    local f5_local2 = 20 - f5_arg0:GetMapHitRadius(TARGET_SELF)
    local f5_local3 = f5_arg0:GetRelativeAngleFromTarget(TARGET_ENE_0)
    if f5_local3 >= 5 then
        f5_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f5_local1, TARGET_ENE_0, f5_local2, 0, 0, 0, 0)
    else
        f5_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f5_local0, TARGET_ENE_0, f5_local2, 0, 0, 0, 0)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wyvern450010_Act04(f6_arg0, f6_arg1, f6_arg2)
    local f6_local0 = 3007
    local f6_local1 = 3008
    local f6_local2 = 20 - f6_arg0:GetMapHitRadius(TARGET_SELF)
    local f6_local3 = f6_arg0:GetRelativeAngleFromTarget(TARGET_ENE_0)
    if f6_local3 <= -5 then
        f6_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f6_local1, TARGET_ENE_0, f6_local2, 0, 0, 0, 0)
    else
        f6_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f6_local0, TARGET_ENE_0, f6_local2, 0, 0, 0, 0)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wyvern450010_Act05(f7_arg0, f7_arg1, f7_arg2)
    local f7_local0 = 3009
    local f7_local1 = 20 - f7_arg0:GetMapHitRadius(TARGET_SELF)
    f7_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 15, f7_local0, TARGET_ENE_0, f7_local1, 0, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wyvern450010_Act06(f8_arg0, f8_arg1, f8_arg2)
    local f8_local0 = 3010
    local f8_local1 = 3011
    local f8_local2 = 20 - f8_arg0:GetMapHitRadius(TARGET_SELF)
    local f8_local3 = f8_arg0:GetRelativeAngleFromTarget(TARGET_ENE_0)
    if f8_local3 <= -5 then
        f8_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f8_local1, TARGET_ENE_0, f8_local2, 0, 0, 0, 0)
    else
        f8_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f8_local0, TARGET_ENE_0, f8_local2, 0, 0, 0, 0)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wyvern450010_Act07(f9_arg0, f9_arg1, f9_arg2)
    local f9_local0 = 3012
    local f9_local1 = 20 - f9_arg0:GetMapHitRadius(TARGET_SELF)
    f9_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f9_local0, TARGET_ENE_0, f9_local1, 0, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wyvern450010_Act08(f10_arg0, f10_arg1, f10_arg2)
    local f10_local0 = 3004
    local f10_local1 = 3001
    local f10_local2 = 20 - f10_arg0:GetMapHitRadius(TARGET_SELF)
    f10_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f10_local0, TARGET_ENE_0, f10_local2, 0, 0, 0, 0)
    f10_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f10_local1, TARGET_ENE_0, f10_local2, 0, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wyvern450010_Act09(f11_arg0, f11_arg1, f11_arg2)
    f11_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 15, 3000, TARGET_ENE_0, DIST_None, 0, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wyvern450010_Act10(f12_arg0, f12_arg1, f12_arg2)
    f12_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3001, TARGET_ENE_0, DIST_None, 0, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wyvern450010_Act11(f13_arg0, f13_arg1, f13_arg2)
    f13_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3015, TARGET_ENE_0, DIST_None, 0, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wyvern450010_Act12(f14_arg0, f14_arg1, f14_arg2)
    local f14_local0 = 3012
    local f14_local1 = 20 - f14_arg0:GetMapHitRadius(TARGET_SELF)
    f14_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3012, TARGET_ENE_0, f14_local1, 0, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wyvern450010_Act20(f15_arg0, f15_arg1, f15_arg2)
    local f15_local0 = f15_arg0:GetDist(TARGET_ENE_0)
    local f15_local1 = 8
    local f15_local2 = 8
    local f15_local3 = 0
    local f15_local4 = f15_arg0:GetRandam_Int(1, 100)
    local f15_local5 = -1
    if f15_local4 <= f15_local3 then
        f15_local5 = 9910
    end
    if f15_local1 <= f15_local0 then
        Approach_Act(f15_arg0, f15_arg1, f15_local1, f15_local2, f15_local3, 3)
    end
    
end

function Wyvern450010_Act21(f16_arg0, f16_arg1, f16_arg2)
    f16_arg1:AddSubGoal(GOAL_COMMON_Turn, 2, TARGET_ENE_0, 90, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wyvern450010_ActAfter_AdjustSpace(f17_arg0, f17_arg1, f17_arg2)
    f17_arg1:AddSubGoal(GOAL_Wyvern450010_AfterAttackAct, 10)
    
end

Goal.Update = function (f18_arg0, f18_arg1, f18_arg2)
    return Update_Default_NoSubGoal(f18_arg0, f18_arg1, f18_arg2)
    
end

Goal.Terminate = function (f19_arg0, f19_arg1, f19_arg2)
    
end

Goal.Interrupt = function (f20_arg0, f20_arg1, f20_arg2)
    if f20_arg1:IsInterupt(INTERUPT_ForgetTarget) and f20_arg1:GetAttackPassedTime(3023) >= 12 then
        f20_arg2:ClearSubGoal()
        f20_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3023, TARGET_ENE_0, DIST_None, 0, 90)
        return true
    end
    return false
    
end

RegisterTableGoal(GOAL_Wyvern450010_AfterAttackAct, "Wyvern450010_AfterAttackAct")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_Wyvern450010_AfterAttackAct, true)

Goal.Activate = function (f21_arg0, f21_arg1, f21_arg2)
    
end

Goal.Update = function (f22_arg0, f22_arg1, f22_arg2)
    return Update_Default_NoSubGoal(f22_arg0, f22_arg1, f22_arg2)
    
end


