﻿function Platoon000140_Initialize(f1_arg0)
    f1_arg0:SetEnablePlatoonMove(true)
    f1_arg0:SetFormationType(0, 2)
    f1_arg0:SetFormationParam(0, 0, 0)
    f1_arg0:SetBaseMoveRate(0, 1)
    
end

function Platoon000140_Activate(f2_arg0)
    
end

function Platoon000140_Deactivate(f3_arg0)
    
end

function Platoon000140_Update(f4_arg0)
    
end


