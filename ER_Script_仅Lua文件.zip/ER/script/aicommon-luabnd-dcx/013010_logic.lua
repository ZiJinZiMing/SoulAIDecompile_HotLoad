﻿function common13010_Logic(f1_arg0)
    local f1_local0 = f1_arg0:GetEventRequest()
    local f1_local1 = f1_arg0:IsSearchTarget(TARGET_ENE_0)
    local f1_local2 = f1_arg0:GetCurrTargetType()
    local f1_local3 = f1_arg0:GetPrevTargetState()
    if f1_local0 == 100 then
        f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 5, POINT_INITIAL, 0.5, TARGET_SELF, true, -1)
    elseif f1_local0 == 110 then
        f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 5, POINT_INITIAL, 0.5, TARGET_SELF, false, -1)
    elseif RideRequest(f1_arg0, 10, -1) then
        f1_arg0:AddTopGoal(GOAL_COMMON_Mount, 10, 1.2)
    else
        COMMON_EasySetup3(f1_arg0)
    end
    
end

function common13010_Interupt(f2_arg0, f2_arg1)
    
end


