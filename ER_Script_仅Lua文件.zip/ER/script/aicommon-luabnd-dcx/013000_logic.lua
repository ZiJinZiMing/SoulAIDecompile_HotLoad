﻿function common13000_Logic(f1_arg0)
    COMMON_Initialize(f1_arg0)
    if COMMON_EasySetup_Initial(f1_arg0) == false then
        local f1_local0 = f1_arg0:GetEventRequest()
        local f1_local1 = f1_arg0:IsSearchTarget(TARGET_ENE_0)
        local f1_local2 = f1_arg0:GetCurrTargetType()
        local f1_local3 = f1_arg0:GetPrevTargetState()
        if f1_local0 == 100 then
            f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 5, POINT_INITIAL, 0.5, TARGET_SELF, true, -1)
        elseif f1_local0 == 110 then
            f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 5, POINT_INITIAL, 0.5, TARGET_SELF, false, -1)
        elseif RideRequest(f1_arg0, 10, -1) then
            f1_arg0:AddTopGoal(GOAL_COMMON_Mount, 10, 1.2)
        else
            if f1_arg0:IsChangeState() then
                if f1_arg0:IsFindState() or f1_arg0:IsBattleState() then
                    local f1_local4 = f1_arg0:GetDist(TARGET_ENE_0)
                    local f1_local5 = 8
                    local f1_local6 = 30
                    local f1_local7 = 3030
                    if f1_local4 <= f1_local5 and f1_arg0:GetTimer(10) <= 0 then
                        f1_arg0:SetTimer(10, f1_local6)
                        f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, f1_local7, TARGET_ENE_0, 9999, 0, 180, 0, 0)
                    end
                elseif f1_arg0:IsCautionState() or f1_local3 == AI_TARGET_STATE__CAUTION then
                    local f1_local4 = 10
                    local f1_local5 = 3031
                    if f1_arg0:GetTimer(11) <= 0 then
                        f1_arg0:SetTimer(11, f1_local4)
                        f1_arg0:AddTopGoal(GOAL_COMMON_Wait, f1_arg0:GetRandam_Float(0, 3), TARGET_ENE_0, 0, 0, 0)
                        f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, f1_local5, TARGET_ENE_0, 9999, 0, 0, 0, 0)
                    else
                    end
                end
            end
            COMMON_EasySetup3(f1_arg0)
        end
    end
    
end

function common13000_Interupt(f2_arg0, f2_arg1)
    
end


