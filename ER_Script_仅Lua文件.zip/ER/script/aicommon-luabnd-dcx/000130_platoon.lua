﻿function Platoon000130_Initialize(f1_arg0)
    f1_arg0:SetEnablePlatoonMove(true)
    f1_arg0:SetNumber(0, 0)
    f1_arg0:SetFormationType(0, 2)
    f1_arg0:SetFormationParam(0, 0, 0)
    f1_arg0:SetFormationParam(1, 0, 0)
    f1_arg0:SetBaseMoveRate(2, 0.7)
    f1_arg0:SetBaseMoveRate(3, 0.7)
    f1_arg0:SetBaseMoveRate(4, 0.7)
    f1_arg0:SetBaseMoveRate(5, 0.7)
    f1_arg0:SetBaseMoveRate(6, 0.7)
    
end

function Platoon000130_Activate(f2_arg0)
    
end

function Platoon000130_Deactivate(f3_arg0)
    
end

function Platoon000130_Update(f4_arg0)
    local f4_local0 = 100
    local f4_local1 = 101
    local f4_local2 = 102
    local f4_local3 = 5
    local f4_local4 = 10
    local f4_local5 = 5
    local f4_local6 = 5
    local f4_local7 = 1.7
    local f4_local8 = 0.5
    local f4_local9 = 4
    local f4_local10 = 0.5
    local f4_local11 = 0
    local f4_local12 = 0
    local f4_local13 = false
    local f4_local14 = 0
    local f4_local15 = 0
    local f4_local16 = {}
    local f4_local17 = 0
    local f4_local18 = 0
    local f4_local19 = 0
    local f4_local20 = {}
    local f4_local21 = {}
    local f4_local22 = 0
    local f4_local23 = 0
    local f4_local24 = 0
    local f4_local25 = 0
    local f4_local26 = 0
    local f4_local27 = 0
    local f4_local28 = 0
    for f4_local29 = f4_arg0:GetMemberNum() - 1, 0, -1 do
        local f4_local32 = f4_arg0:GetMemberAI(f4_local29)
        if f4_local32 == nill or f4_local29 == 0 then
        else
            if f4_local32:IsBattleState() then
                f4_local13 = true
            end
            local f4_local33 = f4_local32:GetDist(TARGET_TEAM_FORMATION)
            local f4_local34 = f4_local32:GetDist(TARGET_ENE_0)
            if f4_local29 == 1 then
                f4_local17 = f4_local17 + 1
                if f4_local9 < f4_local33 then
                    f4_local18 = f4_local18 + 1
                end
                f4_local14 = f4_local32:GetToTargetAngle(TARGET_LOCALPLAYER)
                f4_local15 = f4_local32:GetDist(TARGET_LOCALPLAYER)
                if f4_local15 < 12 then
                    f4_arg0:SetNumber(0, 2)
                elseif f4_local15 < 16 then
                end
            end
        end
    end
    Platoon000130_ChangeFormation(f4_arg0, f4_local13, f4_local14, f4_local15)
    for f4_local29 = f4_arg0:GetMemberNum() - 1, 0, -1 do
        local f4_local32 = f4_arg0:GetMemberAI(f4_local29)
        if f4_local32 ~= nill then
            if f4_local29 == 0 then
                if f4_local18 == f4_local17 then
                    f4_arg0:SendCommand(f4_local29, PLAN_PLATOON_COMMAND__WAIT)
                elseif f4_local17 == 0 then
                    f4_arg0:SendCommand(f4_local29, PLAN_PLATOON_COMMAND__WAIT)
                else
                    f4_arg0:SetMoveRate(f4_local29, 1)
                    f4_arg0:SendCommand(f4_local29, f4_local3)
                end
            else
                local f4_local33 = f4_local32:GetDist(TARGET_TEAM_FORMATION)
                local f4_local34 = 0
                if f4_local32:HasSpecialEffectId(TARGET_SELF, 5002) then
                    f4_arg0:SetMoveRate(f4_local29, 1)
                elseif f4_local4 < f4_local33 then
                    f4_arg0:SetMoveRate(f4_local29, f4_local7)
                elseif f4_local5 < f4_local33 then
                    f4_local34 = 1 + (f4_local33 - f4_local5) / (f4_local4 - f4_local5) * (f4_local7 - 1)
                    f4_arg0:SetMoveRate(f4_local29, f4_local34)
                elseif f4_local33 < f4_local6 then
                    f4_local34 = 1 + (f4_local6 - f4_local33) / f4_local6 * (f4_local8 - 1)
                    f4_arg0:SetMoveRate(f4_local29, f4_local34)
                else
                    f4_arg0:SetMoveRate(f4_local29, 1)
                end
                if f4_local32:IsBattleState() == false then
                    f4_arg0:SendCommand(f4_local29, f4_local3)
                elseif f4_arg0:GetNumber(0) == 2 then
                    f4_arg0:SendCommand(f4_local29, f4_local1)
                elseif f4_arg0:GetNumber(0) == 1 then
                    if f4_local29 == 1 or f4_local29 == 4 or f4_local29 == 5 then
                        f4_arg0:SendCommand(f4_local29, f4_local0)
                    else
                        f4_arg0:SendCommand(f4_local29, f4_local1)
                    end
                else
                    f4_arg0:SendCommand(f4_local29, f4_local0)
                end
            end
        end
    end
    


end

function Platoon000130_ChangeFormation(f5_arg0, f5_arg1, f5_arg2, f5_arg3)
    local f5_local0 = 15
    local f5_local1 = 20
    if f5_arg1 then
        for f5_local2 = 1, f5_arg0:GetMemberNum() - 1, 1 do
            local f5_local5 = 0
            local f5_local6 = f5_local2 - 1
            if f5_local6 <= 1 then
                f5_local5 = 0
            elseif math.mod(f5_local6, 2) == 1 then
                f5_local5 = math.ceil(f5_local6 / 2 * f5_local1)
            else
                f5_local5 = -f5_local6 / 2 * f5_local1
            end
            local f5_local7 = (f5_arg2 + f5_local5) * math.pi / 180
            if f5_local2 ~= 1 then
                f5_arg0:SetFormationParam(f5_local2, f5_local0 * math.sin(f5_local7), f5_local0 * math.cos(f5_local7))
            end
        end
    else
        f5_arg0:SetFormationParam(2, 8, -2)
        f5_arg0:SetFormationParam(3, -8, -3)
        f5_arg0:SetFormationParam(4, 7, -8)
        f5_arg0:SetFormationParam(5, -7, -9)
        f5_arg0:SetFormationParam(6, 0, -18)
    end
    
end


