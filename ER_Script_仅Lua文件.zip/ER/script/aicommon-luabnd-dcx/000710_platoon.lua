﻿function Platoon000710_Initialize(f1_arg0)
    f1_arg0:SetEnablePlatoonMove(true)
    f1_arg0:SetFormationType(0, 2)
    f1_arg0:SetFormationParam(0, 0, 0)
    f1_arg0:SetFormationParam(1, 0, -7)
    f1_arg0:SetFormationParam(2, 3, -11)
    f1_arg0:SetFormationParam(3, -2, -13)
    f1_arg0:SetFormationParam(4, 1, -16)
    f1_arg0:SetFormationParam(5, -4, -20)
    f1_arg0:SetFormationParam(6, 3.5, -22)
    f1_arg0:SetFormationParam(7, -0.5, -25)
    f1_arg0:SetBaseMoveRate(0, 10)
    f1_arg0:SetBaseMoveRate(1, 0.6)
    f1_arg0:SetBaseMoveRate(2, 1.2)
    f1_arg0:SetBaseMoveRate(3, 1.2)
    f1_arg0:SetBaseMoveRate(4, 1.2)
    f1_arg0:SetBaseMoveRate(5, 1.2)
    f1_arg0:SetBaseMoveRate(6, 1.2)
    f1_arg0:SetBaseMoveRate(7, 1.2)
    
end

function Platoon000710_Activate(f2_arg0)
    
end

function Platoon000710_Deactivate(f3_arg0)
    
end

function Platoon000710_Update(f4_arg0)
    Platoon_Common_Act(f4_arg0, 1, 2)
    
end


