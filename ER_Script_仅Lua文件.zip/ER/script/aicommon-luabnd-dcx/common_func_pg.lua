﻿function _COMMON_GetEzStateAnimId(f1_arg0, f1_arg1)
    ret = {}
    local f1_local0 = 1
    for f1_local1 = 1, 30, 1 do
        ret[f1_local1] = f1_arg0:GetEzStateAnimId(f1_arg1, f1_local1 - 1)
    end
    return ret
    

end

function _COMMON_GetMinDist(f2_arg0, f2_arg1)
    ret = {}
    local f2_local0 = 1
    for f2_local1 = 1, 30, 1 do
        ret[f2_local1] = f2_arg0:GetMinDist(f2_arg1, f2_local1 - 1)
    end
    return ret
    

end

function _COMMON_GetMaxDist(f3_arg0, f3_arg1)
    ret = {}
    local f3_local0 = 0
    for f3_local1 = 0, 29, 1 do
        ret[f3_local1] = f3_arg0:GetMaxDist(f3_arg1, f3_local1 - 1)
    end
    return ret
    

end

function _COMMON_GetAtkDistType(f4_arg0, f4_arg1)
    ret = {}
    local f4_local0 = 1
    for f4_local1 = 1, 30, 1 do
        ret[f4_local1] = f4_arg0:GetAtkDistType(f4_arg1, f4_local1 - 1)
        if ret[f4_local1] == 0 then
            ret[f4_local1] = DIST_Near
        elseif ret[f4_local1] == 1 then
            ret[f4_local1] = DIST_Middle
        elseif ret[f4_local1] == 2 then
            ret[f4_local1] = DIST_Far
        elseif ret[f4_local1] == 3 then
            ret[f4_local1] = DIST_Out
        elseif ret[f4_local1] == 4 then
            ret[f4_local1] = DIST_None
        end
    end
    return ret
    

end

function _COMMON_GetOddsParam(f5_arg0, f5_arg1)
    ret = {}
    local f5_local0 = f5_arg0:GetOddsParamIdOffset(100)
    local f5_local1 = 0
    for f5_local2 = 0, 99, 1 do
        ret[f5_local2] = f5_arg0:GetOddsParam(f5_local0 + f5_arg1, f5_local2)
    end
    return ret
    

end

function _COMMON_MulOddsXWeight(f6_arg0, f6_arg1)
    local f6_local0 = 0
    local f6_local1 = true
    if table.getn(f6_arg1) == 0 then
        f6_local1 = false
    end
    local f6_local2 = 0
    local f6_local3 = 0
    for f6_local4 = 0, 99, 1 do
        if f6_local1 == false then
            f6_arg1[f6_local4] = 1
        end
        f6_arg0[f6_local4] = f6_arg0[f6_local4] * f6_arg1[f6_local4]
        if f6_arg0[f6_local4] < 0 then
            f6_arg0[f6_local4] = 0
        end
        f6_arg0[f6_local4] = f6_arg0[f6_local4] + f6_local2
        f6_local2 = f6_arg0[f6_local4]
        if f6_local3 < f6_arg0[f6_local4] then
            f6_local3 = f6_arg0[f6_local4]
        end
    end
    return f6_local3
    

end

function _COMMON_MulWeightParam(f7_arg0, f7_arg1, f7_arg2)
    local f7_local0 = false
    if table.getn(f7_arg1) == 0 then
        f7_local0 = true
    end
    local f7_local1 = f7_arg0:GetOddsParamIdOffset(100)
    local f7_local2 = 0
    for f7_local3 = 0, 99, 1 do
        if f7_local0 then
            f7_arg1[f7_local3] = 1
        end
        f7_arg1[f7_local3] = f7_arg1[f7_local3] * f7_arg0:GetOddsParam(f7_local1 + f7_arg2, f7_local3)
    end
    

end

function _COMMON_SetEnemyActRate(f8_arg0, f8_arg1, f8_arg2, f8_arg3)
    f8_arg1:SetStringIndexedNumber("ActRate01", f8_arg3)
    f8_arg1:SetStringIndexedNumber("ActRate02", f8_arg3)
    f8_arg1:SetStringIndexedNumber("ActRate03", f8_arg3)
    f8_arg1:SetStringIndexedNumber("ActRate04", f8_arg3)
    f8_arg1:SetStringIndexedNumber("ActRate05", f8_arg3)
    f8_arg1:SetStringIndexedNumber("ActRate06", f8_arg3)
    f8_arg1:SetStringIndexedNumber("ActRate07", f8_arg3)
    f8_arg1:SetStringIndexedNumber("ActRate08", f8_arg3)
    f8_arg1:SetStringIndexedNumber("ActRate09", f8_arg3)
    f8_arg1:SetStringIndexedNumber("ActRate10", f8_arg3)
    f8_arg1:SetStringIndexedNumber("ActRate11", f8_arg3)
    f8_arg1:SetStringIndexedNumber("ActRate12", f8_arg3)
    f8_arg1:SetStringIndexedNumber("ActRate13", f8_arg3)
    f8_arg1:SetStringIndexedNumber("ActRate14", f8_arg3)
    f8_arg1:SetStringIndexedNumber("ActRate15", f8_arg3)
    f8_arg1:SetStringIndexedNumber("ActRate16", f8_arg3)
    f8_arg1:SetStringIndexedNumber("ActRate17", f8_arg3)
    f8_arg1:SetStringIndexedNumber("ActRate18", f8_arg3)
    f8_arg1:SetStringIndexedNumber("ActRate19", f8_arg3)
    f8_arg1:SetStringIndexedNumber("ActRate20", f8_arg3)
    
end


