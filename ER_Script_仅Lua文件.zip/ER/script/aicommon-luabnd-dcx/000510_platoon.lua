﻿function Platoon000510_Initialize(f1_arg0)
    
end

function Platoon000510_Activate(f2_arg0)
    
end

function Platoon000510_Deactivate(f3_arg0)
    
end

function Platoon000510_Update(f4_arg0)
    Platoon_Common_Act(f4_arg0, 1)
    
end


