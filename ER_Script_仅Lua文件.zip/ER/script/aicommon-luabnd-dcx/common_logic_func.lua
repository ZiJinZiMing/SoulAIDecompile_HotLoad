﻿function COMMON_Initialize(f1_arg0)
    local f1_local0 = true
    if f1_arg0:IsBattleState() or f1_arg0:IsCautionState() or f1_arg0:IsSearchHighState() or f1_arg0:IsSearchLowState() or f1_arg0:IsMemoryState() then
        f1_local0 = false
    end
    COMMON_SoundBehavior_FlagInitialize(f1_arg0)
    COMMON_PatrolBehavior_FlagInitialize(f1_arg0)
    if f1_arg0:IsChangeState() and f1_local0 == true then
        f1_arg0:SetStringIndexedNumber("COMMON_WAA__isPointCreated", 0)
    end
    f1_arg0:SetStringIndexedNumber("NeglectTarget", 0)
    f1_arg0:SetStringIndexedNumber("IsEnableFadeWarp_OnFailedPath", 0)
    if f1_arg0:GetTimer(15) <= 0 then
        f1_arg0:SetNumber(15, 0)
    end
    if f1_local0 == true then
        f1_arg0:SetStringIndexedNumber("DisableFearOfFire", 0)
    end
    if f1_arg0:GetStringIndexedNumber("IsIgnore_Sideway_onFailedPath") == 1 then
        if f1_arg0:IsBattleState() then
            if f1_arg0:GetDist(TARGET_ENE_0) >= 8 then
                f1_arg0:SetStringIndexedNumber("IsIgnore_Sideway_onFailedPath", 0)
            end
        else
            f1_arg0:SetStringIndexedNumber("IsIgnore_Sideway_onFailedPath", 0)
        end
    end
    if f1_arg0:GetStringIndexedNumber("RepCount_Disable_FailedPath") >= 1 then
        f1_arg0:SetStringIndexedNumber("RepCount_Disable_FailedPath", f1_arg0:GetStringIndexedNumber("RepCount_Disable_FailedPath") - 1)
    else
        f1_arg0:SetStringIndexedNumber("RepCount_Disable_FailedPath", 0)
    end
    if f1_arg0:IsOmissionLevel30() or f1_local0 == false then
        f1_arg0:ClearMoveToSomewhereSmoothMemory()
    end
    return false
    
end

function COMMON_EasySetup_Initial(f2_arg0)
    if f2_arg0:IsLadderAct(TARGET_SELF) then
        f2_arg0:AddTopGoal(GOAL_COMMON_LadderMove, -1, 3000, TARGET_SELF, f2_arg0:GetLadderDirMove(TARGET_SELF))
        return true
    elseif f2_arg0:HasSpecialEffectId(TARGET_SELF, 5019) then
        f2_arg0:SetAIFixedMoveTargetSpecifyAngle(TARGET_SELF, 180, 3, AI_SPA_DIR_TYPE_TargetF)
        f2_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, f2_arg0:GetRandam_Float(0.5, 4), POINT_AI_FIXED_POS, 0, TARGET_SELF, true, -1)
        return true
    end
    if f2_arg0:IsAiJumping() then
        f2_arg0:AddTopGoal(GOAL_COMMON_JumpEndWait, 10)
        return true
    end
    if f2_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_ANIME_COLLECTSLEEPING) then
        f2_arg0:AddTopGoal(GOAL_COMMON_Wait, 2, TARGET_SELF, 0, 0, 0)
        return true
    end
    if f2_arg0:IsRiding(TARGET_SELF) == false then
        if f2_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_ANIME_SLEEPING) == false then
            if f2_arg0:HasSpecialEffectAttribute(TARGET_SELF, SP_EFFECT_TYPE_SLEEP) and f2_arg0:HasSpecialEffectId(TARGET_SELF, 5851) == false and f2_arg0:HasSpecialEffectId(TARGET_SELF, 5852) == false and f2_arg0:HasSpecialEffectId(TARGET_SELF, 5853) == false then
                f2_arg0:AddTopGoal(GOAL_COMMON_Fall_Asleep, 10, true)
                return true
            end
        elseif f2_arg0:HasSpecialEffectAttribute(TARGET_SELF, SP_EFFECT_TYPE_SLEEP) == true then
            f2_arg0:AddTopGoal(GOAL_COMMON_Fall_Asleep, 10, true)
            return true
        end
    elseif f2_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_FACILITY_RIDE) == true and f2_arg0:HasSpecialEffectAttribute(TARGET_SELF, SP_EFFECT_TYPE_SLEEP) == true then
        f2_arg0:AddTopGoal(GOAL_COMMON_Dismount, 10)
        return true
    end
    if f2_arg0:IsRiding(TARGET_SELF) == false and f2_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_ANIME_SLEEPING) == true then
        if f2_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_NATURAL_SLEEP) and (IsTargetTimeZone(f2_arg0, PLAN_TIME_TYPE_NIGHT) or IsTargetTimeZone(f2_arg0, PLAN_TIME_TYPE_MIDNIGHT)) and (f2_arg0:GetCurrTargetState() == AI_TARGET_STATE__NONE or f2_arg0:GetCurrTargetState() == AI_TARGET_STATE__AWARE) and f2_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_NATURAL_SLEEP_GUARD) == false then
            f2_arg0:AddTopGoal(GOAL_COMMON_Fall_Asleep, 10, false)
            return true
        elseif f2_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_NATURAL_SLEEP_MORNING) and (IsTargetTimeZone(f2_arg0, PLAN_TIME_TYPE_MORNING) or IsTargetTimeZone(f2_arg0, PLAN_TIME_TYPE_DAYTIME)) and (f2_arg0:GetCurrTargetState() == AI_TARGET_STATE__NONE or f2_arg0:GetCurrTargetState() == AI_TARGET_STATE__AWARE) and f2_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_NATURAL_SLEEP_GUARD) == false then
            f2_arg0:AddTopGoal(GOAL_COMMON_Fall_Asleep, 10, false)
            return true
        elseif f2_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_NATURAL_SLEEP_DAYTIME) and (IsTargetTimeZone(f2_arg0, PLAN_TIME_TYPE_MORNING) or IsTargetTimeZone(f2_arg0, PLAN_TIME_TYPE_DAYTIME) or IsTargetTimeZone(f2_arg0, PLAN_TIME_TYPE_EVENING)) and (f2_arg0:GetCurrTargetState() == AI_TARGET_STATE__NONE or f2_arg0:GetCurrTargetState() == AI_TARGET_STATE__AWARE) and f2_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_NATURAL_SLEEP_GUARD) == false then
            f2_arg0:AddTopGoal(GOAL_COMMON_Fall_Asleep, 10, false)
            return true
        else
            local f2_local0 = PLAN_ANIMEID_SLEEP_END
            f2_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, f2_local0, TARGET_ENE_0, 9999, 0, 0, 0, 0)
            return true
        end
    end
    if f2_arg0:IsRiding(TARGET_SELF) == false then
        local f2_local0 = f2_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__surpriseAnimId)
        if f2_local0 > 0 and f2_arg0:IsChangeState() == true and f2_arg0:GetPrevTargetState() == AI_TARGET_STATE__NONE and f2_arg0:GetCurrTargetState() == AI_TARGET_STATE__BATTLE then
            f2_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 1, f2_local0, TARGET_ENE_0, 9999, 0, 0, 0, 0)
            return true
        end
    end
    if f2_arg0:IsRiding(TARGET_SELF) == false then
        local f2_local0 = f2_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__enableWeaponOnOff)
        local f2_local1 = f2_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__weaponOffSpecialEffectId)
        local f2_local2 = f2_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__weaponOnSpecialEffectId)
        local f2_local3 = f2_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__weaponOffAnimId)
        local f2_local4 = f2_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__weaponOnAnimId)
        if f2_local0 > 0 then
            if f2_arg0:HasSpecialEffectId(TARGET_SELF, f2_local2) == true then
                if f2_arg0:IsBattleState() == false and f2_arg0:IsCautionState() == false and f2_arg0:IsSearchHighState() == false and f2_arg0:IsSearchLowState() == false and f2_arg0:IsMemoryState() == false then
                    f2_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, f2_local3, TARGET_SELF, 9999, 0, 0, 0, 0)
                    return true
                end
            elseif f2_arg0:HasSpecialEffectId(TARGET_SELF, f2_local1) == true and (f2_arg0:IsBattleState() == true or f2_arg0:IsCautionState() == true or f2_arg0:IsSearchHighState() == true or f2_arg0:IsSearchLowState() == true or f2_arg0:IsMemoryState() == true) then
                f2_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, f2_local4, TARGET_SELF, 9999, 0, 0, 0, 0)
                return true
            end
        end
    end
    if f2_arg0:IsRiding(TARGET_SELF) == false and f2_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_ANIME_SLEEPING) == false then
        if f2_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_NATURAL_SLEEP) and (IsTargetTimeZone(f2_arg0, PLAN_TIME_TYPE_NIGHT) or IsTargetTimeZone(f2_arg0, PLAN_TIME_TYPE_MIDNIGHT)) and (f2_arg0:GetCurrTargetState() == AI_TARGET_STATE__NONE or f2_arg0:GetCurrTargetState() == AI_TARGET_STATE__AWARE) and f2_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_NATURAL_SLEEP_GUARD) == false then
            f2_arg0:AddTopGoal(GOAL_COMMON_Fall_Asleep, 10, false)
            return true
        elseif f2_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_NATURAL_SLEEP_MORNING) and (IsTargetTimeZone(f2_arg0, PLAN_TIME_TYPE_MORNING) or IsTargetTimeZone(f2_arg0, PLAN_TIME_TYPE_DAYTIME)) and (f2_arg0:GetCurrTargetState() == AI_TARGET_STATE__NONE or f2_arg0:GetCurrTargetState() == AI_TARGET_STATE__AWARE) and f2_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_NATURAL_SLEEP_GUARD) == false then
            f2_arg0:AddTopGoal(GOAL_COMMON_Fall_Asleep, 10, false)
            return true
        elseif f2_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_NATURAL_SLEEP_DAYTIME) and (IsTargetTimeZone(f2_arg0, PLAN_TIME_TYPE_MORNING) or IsTargetTimeZone(f2_arg0, PLAN_TIME_TYPE_DAYTIME) or IsTargetTimeZone(f2_arg0, PLAN_TIME_TYPE_EVENING)) and (f2_arg0:GetCurrTargetState() == AI_TARGET_STATE__NONE or f2_arg0:GetCurrTargetState() == AI_TARGET_STATE__AWARE) and f2_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_NATURAL_SLEEP_GUARD) == false then
            f2_arg0:AddTopGoal(GOAL_COMMON_Fall_Asleep, 10, false)
            return true
        end
    end
    if f2_arg0:IsRiding(TARGET_SELF) == true and f2_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_FACILITY_RIDE) and f2_arg0:GetTimer(12) <= 0 then
        if f2_arg0:IsBattleState() == true then
            local f2_local0 = f2_arg0:GetDist(TARGET_ENE_0)
            if f2_arg0:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_B, 180, 180, 999) then
                f2_arg0:AddTopGoal(GOAL_COMMON_Dismount, 10)
                return true
            end
            if f2_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_FLAMETHROWER_RIDE) then
                if f2_local0 <= 1.5 and f2_arg0:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 20, 180, 99) == false then
                    f2_arg0:AddTopGoal(GOAL_COMMON_Dismount, 10)
                    return true
                end
            elseif f2_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_L_BARISTA_RIDE) then
                if f2_local0 <= 3 then
                    f2_arg0:AddTopGoal(GOAL_COMMON_Dismount, 10)
                    return true
                end
            elseif f2_local0 <= 3 and f2_arg0:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 20, 180, 99) == false then
                f2_arg0:AddTopGoal(GOAL_COMMON_Dismount, 10)
                return true
            end
        elseif (f2_arg0:IsCautionState() == true or f2_arg0:IsSearchHighState() == true or f2_arg0:IsSearchLowState() == true) and f2_arg0:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_B, 180, 180, 6) then
            f2_arg0:AddTopGoal(GOAL_COMMON_Dismount, 10)
            return true
        end
    end
    return false
    
end

function COMMON_EasySetup3(f3_arg0)
    COMMON_EzSetup(f3_arg0)
    
end

function COMMON_EzSetup(f4_arg0)
    local f4_local0 = f4_arg0:GetLatestSoundBehaviorID()
    if f4_arg0:GetLatestSoundTargetRank() == AI_SOUND_RANK__BEHAVIOR and COMMON_SoundBehavior(f4_arg0, f4_local0) ~= false then
        return true
    end
    if f4_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_BUDDY_DECLARE) == true then
        _COMMON_SetBuddyBattleActLogic(f4_arg0)
    else
        _COMMON_SetBattleActLogic(f4_arg0)
    end
    
end

function _COMMON_SetBattleActLogic(f5_arg0)
    local f5_local0 = f5_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__maxBackhomeDist)
    local f5_local1 = f5_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__backhomeDist)
    local f5_local2 = f5_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__backhomeBattleDist)
    local f5_local3 = f5_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__nonBattleActLife)
    local f5_local4 = f5_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__callHelp_ForgetTimeByArrival)
    local f5_local5 = f5_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__backToHomeStuckAct)
    local f5_local6 = 1
    local f5_local7 = f5_arg0:IsSearchTarget(TARGET_ENE_0)
    local f5_local8 = f5_arg0:GetMovePointEffectRange()
    local f5_local9 = TARGET_ENE_0
    local f5_local10 = f5_arg0:GetDist(TARGET_ENE_0)
    if f5_arg0:IsSearchHighState() or f5_arg0:IsSearchLowState() then
        f5_local9 = TARGET_SEARCH
        f5_local10 = f5_arg0:GetDist(TARGET_SEARCH)
    end
    if f5_local7 == true and f5_arg0:HasSpecialEffectId(TARGET_ENE_0, 13945) == true then
        f5_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 2, TARGET_HOSTPLAYER, 10, TARGET_SELF, false, -1)
        return true
    end
    if f5_arg0:GetFlyRouteState() ~= AI_FLY_ROUTE_STATE_NOT_USE_FLY_ROUTE then
        if f5_arg0:IsBattleState() and f5_arg0:GetFlyRouteState() == AI_FLY_ROUTE_STATE_ON_GROUND then
            _COMMON_AddBattleGoal(f5_arg0)
        else
            _COMMON_AddNonBattleGoal(f5_arg0, 30, 0, false)
        end
    elseif f5_arg0:TeamHelp_IsValidReply() then
        f5_arg0:AddTopGoal(GOAL_COMMON_TeamReplyHelp, f5_local4)
        return true
    elseif f5_arg0:IsForceBattleGoal() then
        f5_arg0:ClearForceBattleGoal()
        f5_arg0:ReqPlatoonState(PLATOON_STATE_Battle)
        _COMMON_AddBattleGoal(f5_arg0)
    elseif f5_local7 == true or f5_arg0:IsSearchLowState() or f5_arg0:IsSearchHighState() then
        if f5_local0 < f5_local8 then
            if f5_local5 == f5_local6 then
                f5_arg0:AddTopGoal(GOAL_COMMON_MoveToSomewhereSmooth, 1.5, POINT_INITIAL, AI_DIR_TYPE_CENTER, 0, TARGET_SELF, true):SetLifeEndSuccess(true)
                f5_arg0:AddTopGoal(GOAL_COMMON_FadeWarpToInitPos, 10, 2, 4)
                f5_arg0:SetStringIndexedNumber("RepCount_Disable_FailedPath", 1)
                return true
            else
                local f5_local11 = 2
                if f5_local10 < f5_local11 then
                    _COMMON_AddBattleGoal(f5_arg0)
                    return true
                else
                    _COMMON_AddNonBattleGoal(f5_arg0, f5_local3, 2, false)
                    return true
                end
            end
        elseif f5_local1 < f5_local8 then
            if f5_local10 < f5_local2 then
                f5_arg0:ReqPlatoonState(PLATOON_STATE_Battle)
                _COMMON_AddBattleGoal(f5_arg0)
                return true
            else
                local f5_local11 = f5_arg0:GetActTypeOnFailedPathEnd()
                local f5_local12 = f5_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__failedPath_AttackId)
                local f5_local13 = f5_arg0:GetMovePointNumber()
                local f5_local14 = 0
                local f5_local15 = false
                if f5_arg0:IsValidPlatoon() == true and f5_arg0:IsPlatoonLeader() == false then
                    local f5_local16 = f5_arg0:GetPlatoonCommand()
                    local f5_local17 = f5_local16:GetCommandNo()
                    if f5_local17 == PLAN_PLATOON_COMMAND__MOVE or f5_local17 == PLAN_PLATOON_COMMAND__PATROL_BEHAVIOR or f5_local17 == PLAN_PLATOON_COMMAND__PATROL_BEHAVIOR_RESET or f5_local17 == PLAN_PLATOON_COMMAND__DEF or f5_local17 == PLAN_PLATOON_COMMAND__SCOUT_MOVE then
                        f5_local15 = true
                    end
                end
                if f5_local15 == true then
                    f5_local14 = f5_arg0:GetDistAtoB(f5_local9, TARGET_TEAM_FORMATION)
                elseif f5_local13 >= 0 then
                    f5_local14 = f5_arg0:GetDistAtoB(f5_local9, POINT_MOVE_POINT)
                else
                    f5_local14 = f5_arg0:GetDistAtoB(f5_local9, POINT_INITIAL)
                end
                if f5_arg0:GetMovePointEffectRange() < f5_local14 then
                    _COMMON_AddReturnLimitGoal(f5_arg0)
                    return true
                else
                    _COMMON_AddBattleGoal(f5_arg0)
                    return true
                end
            end
        else
            _COMMON_AddBattleGoal(f5_arg0)
            return true
        end
    else
        if f5_local5 == f5_local6 then
            f5_arg0:SetStringIndexedNumber("IsEnableFadeWarp_OnFailedPath", 1)
        end
        _COMMON_AddNonBattleGoal(f5_arg0, 30, -1, true)
        return true
    end
    return false
    
end

function _COMMON_SetBuddyBattleActLogic(f6_arg0)
    local f6_local0 = f6_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__maxBackhomeDist)
    local f6_local1 = f6_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__backhomeDist)
    local f6_local2 = f6_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__backhomeBattleDist)
    local f6_local3 = f6_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__nonBattleActLife)
    local f6_local4 = f6_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__callHelp_ForgetTimeByArrival)
    local f6_local5 = f6_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__IsGuard_Act)
    local f6_local6 = f6_arg0:IsSearchTarget(TARGET_ENE_0)
    local f6_local7 = f6_arg0:GetMovePointEffectRange()
    local f6_local8 = f6_arg0:GetDist(TARGET_ENE_0)
    local f6_local9 = f6_arg0:GetDist(TARGET_HOSTPLAYER)
    local f6_local10 = 23
    local f6_local11 = false
    local f6_local12 = f6_arg0:GetBuddyFollowType()
    local f6_local13 = false
    local f6_local14 = -1
    if f6_local5 > 0 then
        f6_local14 = 9910
    end
    if f6_local6 == true or f6_arg0:IsSearchHighState() or f6_arg0:IsSearchLowState() then
        f6_local11 = true
    end
    if f6_local11 == true and (f6_arg0:HasSpecialEffectId(TARGET_ENE_0, 297800) == true or f6_arg0:HasSpecialEffectId(TARGET_ENE_0, 297810) == true) then
        f6_local11 = false
    end
    if f6_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_BUDDY_DECLARE) == true and f6_arg0:GetBuddyActiveRange() >= 0 then
        f6_local1 = f6_arg0:GetBuddyActiveRange() + 10
        f6_local0 = f6_arg0:GetBuddyActiveRange() + 30
    end
    if f6_local12 == PLAN_BUDDYFOLLOWTYPE_FOLLOW and f6_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_BUDDY_AGGRESSIVE) == false and f6_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_BUDDY_AGGRESSIVE_DEMIHUMAN) == false then
        f6_local13 = true
    end
    if f6_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_BUDDY_NO_FOLLOW) then
        if f6_local11 == true then
            _COMMON_AddBattleGoal(f6_arg0)
        else
            _COMMON_AddNonBattleGoal(f6_arg0, 30, -1, true)
            return true
        end
    elseif f6_local0 < f6_local7 then
        f6_arg0:AddTopGoal(GOAL_COMMON_BackToHome, 2, 0, false, 0, 0, TARGET_SELF)
        return true
    elseif f6_local1 < f6_local7 then
        local f6_local15 = f6_arg0:GetDistAtoB(TARGET_HOSTPLAYER, POINT_INITIAL)
        if f6_local10 <= f6_local9 and f6_local15 < f6_arg0:GetMovePointEffectRange() and f6_local13 == true then
            f6_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 10, TARGET_HOSTPLAYER, f6_local10 - 3, TARGET_SELF, false, -1)
            return true
        elseif f6_local11 == true then
            if f6_local8 < f6_local2 then
                _COMMON_AddBattleGoal(f6_arg0)
                return true
            else
                local f6_local16 = f6_arg0:GetDistAtoB(TARGET_ENE_0, POINT_INITIAL)
                if f6_local16 < f6_arg0:GetMovePointEffectRange() then
                    _COMMON_AddBattleGoal(f6_arg0)
                    return true
                else
                    _COMMON_AddReturnLimitGoal(f6_arg0)
                    return true
                end
            end
        elseif f6_local15 < f6_arg0:GetMovePointEffectRange() then
            _COMMON_AddNonBattleGoal(f6_arg0, 30, -1, true)
            return true
        else
            f6_arg0:AddTopGoal(GOAL_COMMON_Wait, 2, TARGET_HOSTPLAYER)
            return true
        end
    elseif f6_local11 == true then
        if f6_local13 == false then
            _COMMON_AddBattleGoal(f6_arg0)
            return true
        elseif f6_local10 <= f6_local9 then
            f6_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 10, TARGET_HOSTPLAYER, f6_local10 - 3, TARGET_SELF, false, -1)
            return true
        else
            local f6_local15 = true
            local f6_local16 = 5
            if f6_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_BUDDY_INTERCEPT_LONGRANGE) == true then
            elseif f6_arg0:GetDistAtoB(TARGET_HOSTPLAYER, TARGET_ENE_0) > f6_local10 + f6_local16 then
                f6_local15 = false
            end
            if f6_local15 == true then
                _COMMON_AddBattleGoal(f6_arg0)
                return true
            else
                local f6_local17 = 3
                local f6_local18 = f6_arg0:IsExistMeshOnLine(TARGET_SELF, AI_DIR_TYPE_R, f6_local17)
                local f6_local19 = f6_arg0:IsExistMeshOnLine(TARGET_SELF, AI_DIR_TYPE_L, f6_local17)
                local f6_local20 = 0
                if f6_local18 == false and f6_local19 == false then
                    f6_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, f6_arg0:GetRandam_Float(2, 4), TARGET_HOSTPLAYER, 2, TARGET_ENE_0, true, f6_local14)
                else
                    if f6_local18 == true and f6_local19 == true then
                        f6_local20 = f6_arg0:GetRandam_Int(0, 1)
                    elseif f6_local18 == true then
                        f6_local20 = 1
                    else
                        f6_local20 = 0
                    end
                    f6_arg0:AddTopGoal(GOAL_COMMON_SidewayMove, f6_arg0:GetRandam_Float(2, 3), TARGET_ENE_0, f6_local20, f6_arg0:GetRandam_Int(30, 45), true, true, f6_local14, GUARD_GOAL_DESIRE_RET_Failed, true)
                    if f6_local5 > 0 then
                        f6_arg0:AddTopGoal(GOAL_COMMON_Guard, f6_arg0:GetRandam_Float(0.7, 1.5), f6_local14, TARGET_ENE_0, GUARD_GOAL_DESIRE_RET_Failed, false)
                    else
                        f6_arg0:AddTopGoal(GOAL_COMMON_Stay, f6_arg0:GetRandam_Float(0.7, 1.5), f6_local16, TARGET_ENE_0)
                    end
                    return true
                end
            end
        end
    else
        _COMMON_AddNonBattleGoal(f6_arg0, 30, -1, true)
        return true
    end
    return true
    
end

function _COMMON_AddReturnLimitGoal(f7_arg0)
    local f7_local0 = f7_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__backToHomeStuckAct)
    local f7_local1 = 1
    if f7_local0 == f7_local1 then
        f7_arg0:SetStringIndexedNumber("IsEnableFadeWarp_OnFailedPath", 1)
    end
    local f7_local2 = f7_arg0:GetActTypeOnFailedPathEnd()
    local f7_local3 = f7_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__rangedAttackId)
    local f7_local4 = f7_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__IsGuard_Act)
    local f7_local5 = -1
    if f7_local4 > 0 then
        f7_local5 = 9910
    end
    if f7_arg0:HasSpecialEffectId(TARGET_SELF, 13799) then
        local f7_local6 = POINT_INITIAL
        local f7_local7 = f7_arg0:GetMovePointNumber()
        local f7_local8 = false
        if f7_arg0:IsValidPlatoon() == true and f7_arg0:IsPlatoonLeader() == false then
            local f7_local9 = f7_arg0:GetPlatoonCommand()
            local f7_local10 = f7_local9:GetCommandNo()
            if f7_local10 == PLAN_PLATOON_COMMAND__MOVE or f7_local10 == PLAN_PLATOON_COMMAND__PATROL_BEHAVIOR or f7_local10 == PLAN_PLATOON_COMMAND__PATROL_BEHAVIOR_RESET or f7_local10 == PLAN_PLATOON_COMMAND__DEF or f7_local10 == PLAN_PLATOON_COMMAND__SCOUT_MOVE then
                f7_local8 = true
            end
        end
        if f7_local8 == true then
            f7_local6 = TARGET_TEAM_FORMATION
        elseif f7_local7 >= 0 then
            f7_local6 = POINT_MOVE_POINT
        end
        f7_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 45, f7_local6, 10, TARGET_SELF, false, -1, 0, 0)
        f7_arg0:AddTopGoal(GOAL_COMMON_Wait, 2, TARGET_ENE_0)
        return true
    end
    if 0 == f7_local2 then
        f7_arg0:AddTopGoal(GOAL_COMMON_BackToHome, 10, 0, false, 0, 0, TARGET_ENE_0)
    elseif 1 == f7_local2 then
        f7_arg0:AddTopGoal(GOAL_COMMON_BackToHome, 10, 0, false, 0, 0, TARGET_ENE_0)
    elseif 2 == f7_local2 then
        f7_arg0:AddTopGoal(GOAL_COMMON_SideWay_On_FailedPath, 30, 1, f7_local3, 10, 8, 8, f7_local5, true)
    elseif 3 == f7_local2 then
        f7_arg0:AddTopGoal(GOAL_COMMON_SideWay_On_FailedPath, 30, 1, -1, 3, 8, 8, f7_local5, true)
    end
    return true
    
end

function _COMMON_AddBattleGoal(f8_arg0)
    local f8_local0 = f8_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__battleGoalID)
    local f8_local1 = f8_arg0:GetPrevTargetState()
    local f8_local2 = 0
    if f8_arg0:HasSpecialEffectId(TARGET_SELF, 5015) then
        f8_arg0:AddTopGoal(f8_local0, -1)
    elseif f8_arg0:IsBattleState() then
        f8_arg0:ReqPlatoonState(PLATOON_STATE_Battle)
        local f8_local3 = nil
        if f8_arg0:HasSpecialEffectId(TARGET_SELF, 5060) == true and f8_arg0:HasSpecialEffectId(TARGET_SELF, 5061) == false then
            f8_arg0:Replaning()
        elseif f8_arg0:IsValidPlatoon() == true then
            local f8_local4 = f8_arg0:GetPlatoonCommand()
            local f8_local5 = f8_local4:GetCommandNo()
            local f8_local6 = f8_arg0:GetDist(TARGET_TEAM_FORMATION)
            if f8_local5 == PLAN_PLATOON_COMMAND__ATK then
                f8_local3 = f8_arg0:AddTopGoal(f8_local0, -1)
            elseif f8_local5 == PLAN_PLATOON_COMMAND__DEF then
                _COMMON_AddNonBattleGoal(f8_arg0, -1, -1, true)
            elseif f8_local5 == PLAN_PLATOON_COMMAND__RUN then
                if f8_arg0:GetDist(TARGET_ENE_0) <= 4 then
                    f8_local3 = f8_arg0:AddTopGoal(f8_local0, -1)
                else
                    f8_arg0:AddTopGoal(GOAL_COMMON_LeaveTargetToPathEnd, -1, TARGET_TEAM_LEADER, 80, TARGET_SELF, false, -1, GOAL_RESULT_Continue, false, 2)
                end
            elseif f8_local5 == PLAN_PLATOON_COMMAND__STOP then
                f8_local3 = f8_arg0:AddTopGoal(f8_local0, -1)
            else
                f8_local3 = f8_arg0:AddTopGoal(f8_local0, -1)
            end
        else
            f8_local3 = f8_arg0:AddTopGoal(f8_local0, -1)
        end
        if f8_local3 then
            f8_local3:SetManagementGoal()
        end
    elseif f8_arg0:IsCautionState() then
        f8_arg0:ReqPlatoonState(PLATOON_STATE_Caution)
        f8_local2 = 1
        _COMMON_AddCautionAndFindGoal(f8_arg0, f8_local2)
    elseif f8_arg0:IsSearchHighState() then
        f8_local2 = 4
        _COMMON_AddCautionAndFindGoal(f8_arg0, f8_local2)
    elseif f8_arg0:IsSearchLowState() then
        f8_local2 = 3
        _COMMON_AddCautionAndFindGoal(f8_arg0, f8_local2)
    elseif f8_arg0:IsMemoryState() then
        f8_local2 = 0
        _COMMON_AddCautionAndFindGoal(f8_arg0, f8_local2)
    else
        _COMMON_AddNonBattleGoal(f8_arg0, -1, -1, true)
    end
    
end

function _COMMON_AddChangeStateActionGoal(f9_arg0, f9_arg1)
    local f9_local0 = f9_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__changeStateAction_ToNormal)
    local f9_local1 = 0
    local f9_local2 = 1
    local f9_local3 = 2
    local f9_local4 = 0
    local f9_local5 = TARGET_NONE
    local f9_local6 = 1810
    local f9_local7 = f9_arg0:GetRandam_Int(1, 100)
    local f9_local8 = f9_arg0:GetDist(TARGET_ENE_0)
    if f9_arg1 == 0 then
        f9_local4 = f9_local0
        f9_local5 = POINT_INITIAL
    else
        f9_local4 = 0
        f9_local5 = TARGET_ENE_0
    end
    if f9_local4 == f9_local2 then
        if f9_local8 >= 10 or f9_local8 == -1 then
            f9_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, f9_local6, f9_local5, DIST_NONE, 0, -1)
        else
            f9_arg0:AddTopGoal(GOAL_COMMON_Stay, 1, 0, f9_local5)
        end
    elseif f9_local4 == f9_local3 then
        if f9_local8 >= 10 or f9_local8 == -1 then
            f9_arg0:AddTopGoal(GOAL_COMMON_Turn, 3, f9_local5)
            f9_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, f9_local6, f9_local5, DIST_NONE, 0, -1)
        else
            f9_arg0:AddTopGoal(GOAL_COMMON_Stay, 1, 0, f9_local5)
        end
    else
    end
    
end

function _COMMON_AddCautionAndFindGoal(f10_arg0, f10_arg1)
    local f10_local0 = f10_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__goalAction_ToCaution)
    local f10_local1 = f10_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__goalAction_ToCautionImportant)
    local f10_local2 = f10_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__goalAction_ToDisappear)
    local f10_local3 = f10_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__goalAction_ToSearchLv1)
    local f10_local4 = f10_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__goalAction_ToSearchLv2)
    local f10_local5 = 0
    local f10_local6 = 1
    local f10_local7 = 2
    local f10_local8 = 3
    local f10_local9 = 4
    local f10_local10 = 5
    local f10_local11 = 6
    local f10_local12 = 7
    local f10_local13 = 8
    local f10_local14 = 9
    local f10_local15 = 10
    local f10_local16 = 11
    local f10_local17 = 12
    local f10_local18 = 13
    local f10_local19 = 14
    local f10_local20 = 15
    local f10_local21 = 16
    local f10_local22 = 0
    local f10_local23 = 10
    local f10_local24 = f10_arg0:GetLatestSoundTargetRank()
    local f10_local25 = 1.2
    local f10_local26 = 1.2
    local f10_local27 = 20
    local f10_local28 = 3500
    local f10_local29 = 3501
    local f10_local30 = 3502
    local f10_local31 = TARGET_ENE_0
    local f10_local32 = false
    if f10_arg1 == 0 then
        f10_local22 = f10_local2
        f10_local32 = f10_arg0:IsForgettingMemoryTarget()
    elseif f10_arg1 == 1 and f10_local24 == AI_SOUND_RANK__IMPORTANT then
        f10_local22 = f10_local1
        f10_local32 = f10_arg0:IsForgettingSoundTarget()
    elseif f10_arg1 == 1 then
        f10_local22 = f10_local0
        f10_local32 = f10_arg0:IsForgettingSoundTarget()
    elseif f10_arg1 == 3 then
        f10_local22 = f10_local3
        f10_local32 = f10_arg0:IsForgettingTopSearchTarget()
        f10_local31 = TARGET_SEARCH
    elseif f10_arg1 == 4 then
        f10_local22 = f10_local4
        f10_local32 = f10_arg0:IsForgettingTopSearchTarget()
        f10_local31 = TARGET_SEARCH
    end
    local f10_local33 = f10_arg0:GetDist(f10_local31)
    if f10_local22 == f10_local6 then
        f10_arg0:AddTopGoal(GOAL_COMMON_Stay, 1, 0, f10_local31)
    elseif f10_local22 == f10_local7 then
        if f10_local32 == true then
            f10_arg0:AddTopGoal(GOAL_COMMON_Stay, 1, 0, f10_local31)
        else
            f10_arg0:AddTopGoal(GOAL_COMMON_MoveToSomewhere, f10_local23, f10_local31, AI_DIR_TYPE_CENTER, f10_local25, TARGET_SELF, true)
        end
    elseif f10_local22 == f10_local8 then
        if f10_local32 == true then
            f10_arg0:AddTopGoal(GOAL_COMMON_Stay, 1, 0, f10_local31)
        else
            f10_arg0:AddTopGoal(GOAL_COMMON_MoveToSomewhere, f10_local23, f10_local31, AI_DIR_TYPE_CENTER, f10_local25, TARGET_SELF, false)
        end
    elseif f10_local22 == f10_local9 then
        f10_arg0:AddTopGoal(GOAL_COMMON_Stay, 1, 0, f10_local31)
    elseif f10_local22 == f10_local10 then
        f10_arg0:AddTopGoal(GOAL_COMMON_LeaveTarget_Continuous, 10, f10_local31, 15, TARGET_SELF, false, -1, GUARD_GOAL_DESIRE_RET_Continue, false, 2)
    elseif f10_local22 == f10_local11 then
        f10_arg0:AddTopGoal(GOAL_COMMON_MoveToSomewhere, f10_local23, f10_local31, AI_DIR_TYPE_CENTER, f10_local25, TARGET_SELF, false)
        f10_arg0:AddTopGoal(GOAL_COMMON_WalkAround_On_FailedPath, 1000)
    elseif f10_local22 == f10_local12 then
        if f10_local32 == true then
            f10_arg0:AddTopGoal(GOAL_COMMON_Stay, 1, 0, f10_local31)
        else
            f10_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, f10_local23, f10_local31, f10_local25, f10_local31, true, 9910)
        end
    elseif f10_local22 == 99 then
        f10_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 5, 3008, TARGET_ENE_0, DIST_NONE, 0, 90)
    elseif f10_local22 == 98 then
        f10_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 5, 3006, TARGET_ENE_0, DIST_NONE, 0, 90)
    elseif f10_local22 == f10_local13 then
        f10_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, -1, 3503, TARGET_SELF, 9999, 0, 90)
    elseif f10_local22 == f10_local14 then
        f10_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, -1, f10_local28, f10_local31, 9999, 0, 90)
        f10_arg0:AddTopGoal(GOAL_COMMON_Wait, f10_arg0:GetRandam_Int(2, 5), f10_local31, 0, 0, 0)
    elseif f10_local22 == f10_local15 then
        f10_arg0:AddTopGoal(GOAL_COMMON_Turn, 3, f10_local31)
        f10_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, -1, f10_local28, f10_local31, 9999, 0, 90)
        f10_arg0:AddTopGoal(GOAL_COMMON_Wait, f10_arg0:GetRandam_Int(2, 5), f10_local31, 0, 0, 0)
    elseif f10_local22 == f10_local16 then
        if f10_local32 == true then
            f10_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, -1, f10_local28, f10_local31, 9999, 0, 90)
            f10_arg0:AddTopGoal(GOAL_COMMON_Wait, f10_arg0:GetRandam_Int(2, 5), f10_local31, 0, 0, 0)
        else
            f10_arg0:AddTopGoal(GOAL_COMMON_MoveToSomewhere, f10_local23, f10_local31, AI_DIR_TYPE_CENTER, f10_local26, TARGET_SELF, true)
        end
    elseif f10_local22 == f10_local17 then
        if f10_local32 == true then
            f10_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, -1, f10_local28, f10_local31, 9999, 0, 90)
            f10_arg0:AddTopGoal(GOAL_COMMON_Wait, f10_arg0:GetRandam_Int(2, 5), f10_local31, 0, 0, 0)
        else
            f10_arg0:AddTopGoal(GOAL_COMMON_MoveToSomewhere, f10_local23, f10_local31, AI_DIR_TYPE_CENTER, f10_local26, TARGET_SELF, false)
        end
    elseif f10_local22 == f10_local18 then
        f10_arg0:AddTopGoal(GOAL_COMMON_LeaveTarget, f10_local23, f10_local31, f10_local27, f10_local31, true, -1)
        f10_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, -1, f10_local28, f10_local31, 9999, 0, 90)
        f10_arg0:AddTopGoal(GOAL_COMMON_Wait, f10_arg0:GetRandam_Int(2, 5), f10_local31, 0, 0, 0)
    elseif f10_local22 == f10_local19 then
        f10_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, f10_local29, f10_local31, 9999, 0, 90)
    elseif f10_local22 == f10_local20 then
        if f10_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_DETECT_ANIM_COOLTIME) == false then
            f10_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, f10_local30, f10_local31, 9999, 0, 90)
        else
            f10_arg0:AddTopGoal(GOAL_COMMON_Turn, 3, f10_local31)
        end
    elseif f10_local22 == f10_local21 then
        if f10_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_DETECT_ANIM_COOLTIME) == false then
            f10_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, f10_local30, f10_local31, 9999, 0, 90)
        elseif f10_local32 == true then
            f10_arg0:AddTopGoal(GOAL_COMMON_Stay, 1, 0, f10_local31)
        else
            f10_arg0:AddTopGoal(GOAL_COMMON_MoveToSomewhere, f10_local23, f10_local31, AI_DIR_TYPE_CENTER, f10_local25, TARGET_SELF, true)
        end
    else
        f10_arg0:SetStringIndexedNumber("NeglectTarget", 1)
        _COMMON_AddNonBattleGoal(f10_arg0, 5, -1, false)
    end
    
end

function _COMMON_AddNonBattleGoal(f11_arg0, f11_arg1, f11_arg2, f11_arg3)
    f11_arg0:TeamHelp_ValidateCall()
    f11_arg0:TeamHelp_ValidateReply()
    if f11_arg0:IsChangeState() and not f11_arg0:IsBattleState() and not f11_arg0:IsCautionState() then
        local f11_local0 = 0
        f11_local0 = 0
        _COMMON_AddChangeStateActionGoal(f11_arg0, f11_local0)
    end
    f11_arg0:AddTopGoal(GOAL_COMMON_NonBattleAct, f11_arg1, f11_arg2, f11_arg3, false, POINT_INIT_POSE, 0, 0)
    
end

function COMMON_Interrupt(f12_arg0, f12_arg1)
    if f12_arg0:IsLadderAct(TARGET_SELF) then
        return false
    end
    if f12_arg0:IsInterupt(INTERUPT_FindUnfavorableFailedPoint) and f12_arg0:GetStringIndexedNumber("RepCount_Disable_FailedPath") == 0 and (f12_arg0:IsBattleState() == true or f12_arg0:IsSearchHighState() == true or f12_arg0:IsSearchLowState() == true or f12_arg0:IsCautionState() == true) then
        local f12_local0 = f12_arg0:GetActTypeOnFailedPathEnd()
        if f12_arg0:GetStringIndexedNumber("IsIgnore_Sideway_onFailedPath") == 1 then
            f12_local0 = 0
        end
        if f12_local0 ~= 0 then
            if f12_arg0:CheckDoesExistPath(TARGET_ENE_0, AI_DIR_TYPE_CENTER, 0) then
                f12_arg0:SetStringIndexedNumber("RepCount_Disable_FailedPath", 2)
                f12_arg1:ClearSubGoal()
                f12_arg0:Replaning()
            elseif f12_arg0:CalcSetPointWaitAndSee() then
                local f12_local1 = true
                if f12_arg0:IsRiding(TARGET_SELF) == true then
                    f12_local1 = false
                end
                f12_arg1:ClearSubGoal()
                f12_arg1:AddSubGoal(GOAL_COMMON_MoveToWaitandSee, 30, 2, TARGET_SELF, f12_local1, 1, -1)
                _COMMON_Add_On_FailedPathGoal(f12_arg0, f12_arg1)
            else
                f12_arg1:ClearSubGoal()
                _COMMON_Add_On_FailedPathGoal(f12_arg0, f12_arg1)
            end
            return true
        end
    end
    if f12_arg0:IsInterupt(INTERUPT_MovedEnd_OnFailedPath) and f12_arg0:GetStringIndexedNumber("RepCount_Disable_FailedPath") == 0 then
        if f12_arg0:IsBattleState() == true and f12_arg0:CheckDoesExistPath(TARGET_ENE_0, AI_DIR_TYPE_CENTER, 0) == true then
            f12_arg0:SetStringIndexedNumber("RepCount_Disable_FailedPath", 2)
            f12_arg1:ClearSubGoal()
            return true
        else
            local f12_local0 = f12_arg0:GetActTypeOnFailedPathEnd()
            if f12_arg0:GetStringIndexedNumber("IsEnableFadeWarp_OnFailedPath") == 1 then
                f12_arg1:ClearSubGoal()
                f12_arg0:SetStringIndexedNumber("RepCount_Disable_FailedPath", 1)
                f12_arg1:AddSubGoal(GOAL_COMMON_FadeWarpToInitPos, 10, 2, 4)
                return true
            end
            if f12_arg0:GetStringIndexedNumber("IsIgnore_Sideway_onFailedPath") == 1 then
                f12_local0 = 0
            end
            if f12_local0 ~= 0 then
                f12_arg1:ClearSubGoal()
                _COMMON_Add_On_FailedPathGoal(f12_arg0, f12_arg1)
                return true
            end
        end
    end
    return false
    
end

function _COMMON_Add_On_FailedPathGoal(f13_arg0, f13_arg1)
    f13_arg0:DecideWalkAroundPos()
    local f13_local0 = f13_arg0:GetActTypeOnFailedPathEnd()
    local f13_local1 = f13_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__rangedAttackId)
    local f13_local2 = f13_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__IsGuard_Act)
    local f13_local3 = -1
    if f13_local2 > 0 then
        f13_local3 = 9910
    end
    if f13_arg0:HasSpecialEffectId(TARGET_SELF, 13799) then
        f13_arg1:AddSubGoal(GOAL_COMMON_Guard_On_FailedPath, 30, 1, 15)
        return true
    end
    if 0 == f13_local0 then
    elseif 1 == f13_local0 then
        f13_arg1:AddSubGoal(GOAL_COMMON_BackToHome_On_FailedPath, 100, 1)
    elseif 2 == f13_local0 then
        f13_arg1:AddSubGoal(GOAL_COMMON_SideWay_On_FailedPath, 30, 1, f13_local1, 10, 8, 8, f13_local3, false)
    elseif 3 == f13_local0 then
        f13_arg1:AddSubGoal(GOAL_COMMON_SideWay_On_FailedPath, 30, 1, -1, 3, 8, 8, f13_local3, false)
    end
    
end


