﻿function RideRequest(f1_arg0, f1_arg1, f1_arg2)
    if f1_arg0:IsRiding(TARGET_SELF) == true then
        return false
    end
    if f1_arg0:GetTimer(13) > 0 then
        return false
    end
    local f1_local0 = f1_arg0:IsSearchTarget(TARGET_ENE_0)
    if f1_arg2 > 0 and f1_local0 == true and f1_arg0:GetDist(TARGET_ENE_0) <= f1_arg2 then
        return false
    end
    if f1_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_HORSE_RIDE) == true then
        if f1_arg0:IsBattleState() == false and f1_arg0:IsSearchHighState() == false and f1_arg0:IsSearchLowState() == false and f1_arg0:IsCautionState() == false and f1_arg0:IsMemoryState() == false then
            return false
        end
    elseif f1_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_FACILITY_RIDE) == true then
        if f1_arg0:IsBattleState() == true or f1_arg0:IsSearchHighState() == true or f1_arg0:IsSearchLowState() == true or f1_arg0:IsCautionState() == true or f1_arg0:IsMemoryState() == true then
            return false
        end
    else
        return false
    end
    if f1_arg0:ReserveRide(f1_arg1) == true then
        return true
    end
    return false
    
end

function FearOfFire(f2_arg0, f2_arg1, f2_arg2)
    if f2_arg0:HasSpecialEffectAttribute(TARGET_ENE_0, SP_EFFECT_TYPE_BEAST_REPELLENT) and f2_arg0:HasSpecialEffectAttribute(TARGET_SELF, SP_EFFECT_TYPE_ENABLE_BEAST_REPELLENT) and f2_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_BEAST_REPELLENT_UNDAMAGED) and f2_arg0:GetStringIndexedNumber("DisableFearOfFire") == 0 then
        if f2_arg2 == nil then
            f2_arg2 = PLAN_SIDEWAYTYPE__NONE
        end
        if f2_arg2 == PLAN_SIDEWAYTYPE__NONE then
            f2_arg1:AddSubGoal(GOAL_COMMON_SideWay_For_Fear_Of_Fire, -1, 10, -1, false)
        elseif f2_arg2 == PLAN_SIDEWAYTYPE__DEFAULT then
            f2_arg1:AddSubGoal(GOAL_COMMON_SideWay_For_Fear_Of_Fire, -1, 7, -1, true)
        elseif f2_arg2 == PLAN_SIDEWAYTYPE__GUARD then
            f2_arg1:AddSubGoal(GOAL_COMMON_SideWay_For_Fear_Of_Fire, -1, 7, 9910, true)
        elseif f2_arg2 == PLAN_SIDEWAYTYPE__PARRY then
            f2_arg1:AddSubGoal(GOAL_COMMON_SideWay_For_Fear_Of_Fire, -1, 7, 9920, true)
        end
        return true
    end
    return false
    
end

function CommonNPC_ChangeWepL1(f3_arg0, f3_arg1)
    local f3_local0 = f3_arg0:GetEquipWeaponIndex(ARM_L)
    if WEP_Primary ~= f3_local0 then
        f3_arg1:AddSubGoal(GOAL_COMMON_Attack, 10, NPC_ATK_ChangeWep_L1, TARGET_NONE, DIST_None)
    end
    
end

function CommonNPC_ChangeWepR1(f4_arg0, f4_arg1)
    local f4_local0 = f4_arg0:GetEquipWeaponIndex(ARM_R)
    if WEP_Primary ~= f4_local0 then
        f4_arg1:AddSubGoal(GOAL_COMMON_Attack, 10, NPC_ATK_ChangeWep_R1, TARGET_NONE, DIST_None)
    end
    
end

function CommonNPC_ChangeWepL2(f5_arg0, f5_arg1)
    local f5_local0 = f5_arg0:GetEquipWeaponIndex(ARM_L)
    if WEP_Secondary ~= f5_local0 then
        f5_arg1:AddSubGoal(GOAL_COMMON_Attack, 10, NPC_ATK_ChangeWep_L2, TARGET_NONE, DIST_None)
    end
    
end

function CommonNPC_ChangeWepR2(f6_arg0, f6_arg1)
    local f6_local0 = f6_arg0:GetEquipWeaponIndex(ARM_R)
    if WEP_Secondary ~= f6_local0 then
        f6_arg1:AddSubGoal(GOAL_COMMON_Attack, 10, NPC_ATK_ChangeWep_R2, TARGET_NONE, DIST_None)
    end
    
end

function CommonNPC_SwitchBothHandMode(f7_arg0, f7_arg1)
    if not f7_arg0:IsBothHandMode(TARGET_SELF) then
        f7_arg1:AddSubGoal(GOAL_COMMON_Attack, 10, NPC_ATK_ChangeStyleR, TARGET_NONE, DIST_None)
    end
    
end

function CommonNPC_SwitchOneHandMode(f8_arg0, f8_arg1)
    if f8_arg0:IsBothHandMode(TARGET_SELF) then
        f8_arg1:AddSubGoal(GOAL_COMMON_Attack, 10, NPC_ATK_ChangeStyleR, TARGET_NONE, DIST_None)
    end
    
end

function NPC_Approach_Act_Flex(f9_arg0, f9_arg1, f9_arg2, f9_arg3, f9_arg4, f9_arg5, f9_arg6, f9_arg7, f9_arg8)
    if f9_arg7 == nil then
        f9_arg7 = 3
    end
    if f9_arg8 == nil then
        f9_arg8 = 8
    end
    local f9_local0 = f9_arg0:GetDist(TARGET_ENE_0)
    local f9_local1 = f9_arg0:GetRandam_Int(1, 100)
    local f9_local2 = true
    if f9_arg4 <= f9_local0 then
        f9_local2 = false
    elseif f9_arg3 <= f9_local0 and f9_local1 <= f9_arg5 then
        f9_local2 = false
    end
    local f9_local3 = -1
    local f9_local4 = f9_arg0:GetRandam_Int(1, 100)
    if f9_local4 <= f9_arg6 then
        f9_local3 = 4
    end
    if f9_local2 == true then
        life = f9_arg7
    else
        life = f9_arg8
    end
    local f9_local5 = 0
    if f9_arg2 <= f9_local0 then
        if f9_local2 == true then
            f9_arg2 = f9_arg2 + f9_arg0:GetStringIndexedNumber("AddDistWalk") + f9_local5
        else
            f9_arg2 = f9_arg2 + f9_arg0:GetStringIndexedNumber("AddDistRun") + f9_local5
        end
        f9_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, life, TARGET_ENE_0, f9_arg2, TARGET_SELF, f9_local2, f9_local3)
    end
    
end

function NPC_KATATE_Switch(f10_arg0, f10_arg1)
    if f10_arg0:IsBothHandMode(TARGET_SELF) then
        f10_arg1:AddSubGoal(GOAL_COMMON_NonspinningComboAttack, 10, NPC_ATK_ChangeStyleR, TARGET_ENE_0, DIST_None, 0)
    end
    
end

function NPC_RYOUTE_Switch(f11_arg0, f11_arg1)
    if not f11_arg0:IsBothHandMode(TARGET_SELF) then
        f11_arg1:AddSubGoal(GOAL_COMMON_NonspinningComboAttack, 10, NPC_ATK_ChangeStyleR, TARGET_ENE_0, DIST_None, 0)
    end
    
end

function Damaged_StepCount_NPCPlayer(f12_arg0, f12_arg1, f12_arg2, f12_arg3, f12_arg4, f12_arg5, f12_arg6, f12_arg7, f12_arg8)
    local f12_local0 = f12_arg0:GetDist(TARGET_ENE_0)
    local f12_local1 = f12_arg0:GetRandam_Int(1, 100)
    local f12_local2 = f12_arg0:GetRandam_Int(1, 100)
    local f12_local3 = f12_arg0:GetRandam_Int(1, 100)
    if f12_arg0:IsInterupt(INTERUPT_Damaged) and f12_local0 < f12_arg2 and f12_local1 <= f12_arg3 then
        f12_arg1:ClearSubGoal()
        if f12_local2 <= f12_arg6 then
            f12_arg1:AddSubGoal(GOAL_COMMON_Attack, 10, NPC_ATK_StepB, TARGET_ENE_0, DIST_None, 0)
        elseif f12_local2 <= f12_arg6 + f12_arg7 then
            f12_arg1:AddSubGoal(GOAL_COMMON_Attack, 10, NPC_ATK_StepL, TARGET_ENE_0, DIST_None, 0)
        else
            f12_arg1:AddSubGoal(GOAL_COMMON_Attack, 10, NPC_ATK_StepR, TARGET_ENE_0, DIST_None, 0)
        end
        if f12_local3 <= f12_arg4 then
            f12_arg1:AddSubGoal(GOAL_COMMON_ComboAttack, 10, f12_arg5, TARGET_ENE_0, DIST_Middle, 0)
        end
        return true
    end
    
end

function FindAttack_Step_NPCPlayer(f13_arg0, f13_arg1, f13_arg2, f13_arg3, f13_arg4, f13_arg5, f13_arg6)
    local f13_local0 = f13_arg0:GetDist(TARGET_ENE_0)
    local f13_local1 = f13_arg0:GetRandam_Int(1, 100)
    local f13_local2 = f13_arg0:GetRandam_Int(1, 100)
    if f13_arg0:IsInterupt(INTERUPT_FindAttack) and f13_local0 <= f13_arg2 and f13_local1 <= f13_arg3 then
        f13_arg1:ClearSubGoal()
        if f13_local2 <= f13_arg4 then
            f13_arg1:AddSubGoal(GOAL_COMMON_Attack, 10, NPC_ATK_StepB, TARGET_ENE_0, DIST_None, 0)
        elseif f13_local2 <= f13_arg4 + f13_arg5 then
            f13_arg1:AddSubGoal(GOAL_COMMON_Attack, 10, NPC_ATK_StepL, TARGET_ENE_0, DIST_None, 0)
        else
            f13_arg1:AddSubGoal(GOAL_COMMON_Attack, 10, NPC_ATK_StepR, TARGET_ENE_0, DIST_None, 0)
        end
        return true
    end
    
end

function FindAttack_Act(f14_arg0, f14_arg1, f14_arg2, f14_arg3)
    local f14_local0 = f14_arg0:GetDist(TARGET_ENE_0)
    local f14_local1 = f14_arg0:GetRandam_Int(1, 100)
    if f14_arg0:IsInterupt(INTERUPT_FindAttack) and f14_local0 <= f14_arg2 and f14_local1 <= f14_arg3 then
        f14_arg1:ClearSubGoal()
        return true
    end
    return false
    
end

function FindAttack_Step(f15_arg0, f15_arg1, f15_arg2, f15_arg3, f15_arg4, f15_arg5, f15_arg6, f15_arg7)
    local f15_local0 = f15_arg0:GetDist(TARGET_ENE_0)
    local f15_local1 = f15_arg0:GetRandam_Int(1, 100)
    local f15_local2 = f15_arg0:GetRandam_Int(1, 100)
    local f15_local3 = GET_PARAM_IF_NIL_DEF(f15_arg4, 50)
    local f15_local4 = GET_PARAM_IF_NIL_DEF(f15_arg5, 25)
    local f15_local5 = GET_PARAM_IF_NIL_DEF(f15_arg6, 25)
    local f15_local6 = GET_PARAM_IF_NIL_DEF(f15_arg7, 3)
    if f15_arg0:IsInterupt(INTERUPT_FindAttack) and f15_local0 <= f15_arg2 and f15_local1 <= f15_arg3 then
        f15_arg1:ClearSubGoal()
        if f15_local2 <= f15_local3 then
            f15_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 701, TARGET_ENE_0, 0, AI_DIR_TYPE_B, f15_local6)
        elseif f15_local2 <= f15_local3 + f15_local4 then
            f15_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 702, TARGET_ENE_0, 0, AI_DIR_TYPE_L, f15_local6)
        else
            f15_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 703, TARGET_ENE_0, 0, AI_DIR_TYPE_R, f15_local6)
        end
        return true
    end
    
end

function FindAttack_Guard(f16_arg0, f16_arg1, f16_arg2, f16_arg3, f16_arg4, f16_arg5, f16_arg6)
    local f16_local0 = f16_arg0:GetDist(TARGET_ENE_0)
    local f16_local1 = f16_arg0:GetRandam_Int(1, 100)
    local f16_local2 = f16_arg0:GetRandam_Int(1, 100)
    local f16_local3 = GET_PARAM_IF_NIL_DEF(f16_arg4, 40)
    local f16_local4 = GET_PARAM_IF_NIL_DEF(f16_arg5, 4)
    local f16_local5 = GET_PARAM_IF_NIL_DEF(f16_arg6, 3)
    if f16_arg0:IsInterupt(INTERUPT_FindAttack) and f16_local0 <= f16_arg2 and f16_local1 <= f16_arg3 then
        f16_arg1:ClearSubGoal()
        if f16_local2 <= f16_local3 then
            f16_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 4, TARGET_ENE_0, f16_local5, TARGET_ENE_0, true, 9910)
        else
            f16_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 4, TARGET_ENE_0, f16_local5, TARGET_ENE_0, true, 9910)
            f16_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, f16_local4, TARGET_ENE_0, f16_arg0:GetRandam_Int(0, 1), f16_arg0:GetRandam_Int(30, 45), true, true, 9910)
        end
        return true
    end
    
end

function FindAttack_Step_or_Guard(f17_arg0, f17_arg1, f17_arg2, f17_arg3, f17_arg4, f17_arg5, f17_arg6, f17_arg7, f17_arg8, f17_arg9, f17_arg10, f17_arg11)
    local f17_local0 = f17_arg0:GetDist(TARGET_ENE_0)
    local f17_local1 = f17_arg0:GetRandam_Int(1, 100)
    local f17_local2 = f17_arg0:GetRandam_Int(1, 100)
    local f17_local3 = f17_arg0:GetRandam_Int(1, 100)
    local f17_local4 = GET_PARAM_IF_NIL_DEF(f17_arg5, 50)
    local f17_local5 = GET_PARAM_IF_NIL_DEF(f17_arg6, 25)
    local f17_local6 = GET_PARAM_IF_NIL_DEF(f17_arg7, 25)
    local f17_local7 = GET_PARAM_IF_NIL_DEF(f17_arg8, 3)
    local f17_local8 = GET_PARAM_IF_NIL_DEF(f17_arg9, 40)
    local f17_local9 = GET_PARAM_IF_NIL_DEF(f17_arg10, 4)
    local f17_local10 = GET_PARAM_IF_NIL_DEF(f17_arg11, 3)
    if f17_arg0:IsInterupt(INTERUPT_FindAttack) and f17_local0 <= f17_arg2 and f17_local1 <= f17_arg3 then
        if f17_local2 <= f17_arg4 then
            f17_arg1:ClearSubGoal()
            if f17_local3 <= f17_local4 then
                f17_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 701, TARGET_ENE_0, 0, AI_DIR_TYPE_B, f17_local7)
            elseif f17_local3 <= f17_local4 + f17_local5 then
                f17_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 702, TARGET_ENE_0, 0, AI_DIR_TYPE_L, f17_local7)
            else
                f17_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 703, TARGET_ENE_0, 0, AI_DIR_TYPE_R, f17_local7)
            end
            return true
        else
            f17_arg1:ClearSubGoal()
            if f17_local3 <= f17_local8 then
                f17_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 4, TARGET_ENE_0, f17_local10, TARGET_ENE_0, true, 9910)
            else
                f17_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 4, TARGET_ENE_0, f17_local10, TARGET_ENE_0, true, 9910)
                f17_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, f17_local9, TARGET_ENE_0, f17_arg0:GetRandam_Int(0, 1), f17_arg0:GetRandam_Int(30, 45), true, true, 9910)
            end
            return true
        end
    end
    
end

function Damaged_Act(f18_arg0, f18_arg1, f18_arg2, f18_arg3)
    local f18_local0 = f18_arg0:GetDist(TARGET_ENE_0)
    local f18_local1 = f18_arg0:GetRandam_Int(1, 100)
    if f18_arg0:IsInterupt(INTERUPT_Damaged) and f18_local0 < f18_arg2 and f18_local1 <= f18_arg3 then
        f18_arg1:ClearSubGoal()
        return true
    end
    return false
    
end

function Damaged_Guard(f19_arg0, f19_arg1, f19_arg2, f19_arg3, f19_arg4, f19_arg5, f19_arg6)
    local f19_local0 = f19_arg0:GetDist(TARGET_ENE_0)
    local f19_local1 = f19_arg0:GetRandam_Int(1, 100)
    local f19_local2 = f19_arg0:GetRandam_Int(1, 100)
    local f19_local3 = GET_PARAM_IF_NIL_DEF(f19_arg4, 40)
    local f19_local4 = GET_PARAM_IF_NIL_DEF(f19_arg5, 4)
    local f19_local5 = GET_PARAM_IF_NIL_DEF(f19_arg6, 3)
    if f19_arg0:IsInterupt(INTERUPT_Damaged) and f19_local0 <= f19_arg2 and f19_local1 <= f19_arg3 then
        f19_arg1:ClearSubGoal()
        if f19_local2 <= f19_local3 then
            f19_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 4, TARGET_ENE_0, f19_local5, TARGET_ENE_0, true, 9910)
        else
            f19_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 4, TARGET_ENE_0, f19_local5, TARGET_ENE_0, true, 9910)
            f19_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, f19_local4, TARGET_ENE_0, f19_arg0:GetRandam_Int(0, 1), f19_arg0:GetRandam_Int(30, 45), true, true, 9910)
        end
        return true
    end
    
end

function Damaged_Step(f20_arg0, f20_arg1, f20_arg2, f20_arg3, f20_arg4, f20_arg5, f20_arg6, f20_arg7)
    local f20_local0 = f20_arg0:GetDist(TARGET_ENE_0)
    local f20_local1 = f20_arg0:GetRandam_Int(1, 100)
    local f20_local2 = f20_arg0:GetRandam_Int(1, 100)
    local f20_local3 = GET_PARAM_IF_NIL_DEF(f20_arg4, 50)
    local f20_local4 = GET_PARAM_IF_NIL_DEF(f20_arg5, 25)
    local f20_local5 = GET_PARAM_IF_NIL_DEF(f20_arg6, 25)
    local f20_local6 = GET_PARAM_IF_NIL_DEF(f20_arg7, 3)
    if f20_arg0:IsInterupt(INTERUPT_Damaged) and f20_local0 <= f20_arg2 and f20_local1 <= f20_arg3 then
        f20_arg1:ClearSubGoal()
        if f20_local2 <= f20_local3 then
            f20_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 701, TARGET_ENE_0, 0, AI_DIR_TYPE_B, f20_local6)
        elseif f20_local2 <= f20_local3 + f20_local4 then
            f20_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 702, TARGET_ENE_0, 0, AI_DIR_TYPE_L, f20_local6)
        else
            f20_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 703, TARGET_ENE_0, 0, AI_DIR_TYPE_R, f20_local6)
        end
        return true
    end
    
end

function Damaged_Step_or_Guard(f21_arg0, f21_arg1, f21_arg2, f21_arg3, f21_arg4, f21_arg5, f21_arg6, f21_arg7, f21_arg8, f21_arg9, f21_arg10, f21_arg11)
    local f21_local0 = f21_arg0:GetDist(TARGET_ENE_0)
    local f21_local1 = f21_arg0:GetRandam_Int(1, 100)
    local f21_local2 = f21_arg0:GetRandam_Int(1, 100)
    local f21_local3 = f21_arg0:GetRandam_Int(1, 100)
    local f21_local4 = GET_PARAM_IF_NIL_DEF(f21_arg5, 50)
    local f21_local5 = GET_PARAM_IF_NIL_DEF(f21_arg6, 25)
    local f21_local6 = GET_PARAM_IF_NIL_DEF(f21_arg7, 25)
    local f21_local7 = GET_PARAM_IF_NIL_DEF(f21_arg8, 3)
    local f21_local8 = GET_PARAM_IF_NIL_DEF(f21_arg9, 40)
    local f21_local9 = GET_PARAM_IF_NIL_DEF(f21_arg10, 4)
    local f21_local10 = GET_PARAM_IF_NIL_DEF(f21_arg11, 3)
    if f21_arg0:IsInterupt(INTERUPT_Damaged) and f21_local0 <= f21_arg2 and f21_local1 <= f21_arg3 then
        if f21_local2 <= f21_arg4 then
            f21_arg1:ClearSubGoal()
            if f21_local3 <= f21_local4 then
                f21_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 701, TARGET_ENE_0, 0, AI_DIR_TYPE_B, f21_local7)
            elseif f21_local3 <= f21_local4 + f21_local5 then
                f21_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 702, TARGET_ENE_0, 0, AI_DIR_TYPE_L, f21_local7)
            else
                f21_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 703, TARGET_ENE_0, 0, AI_DIR_TYPE_R, f21_local7)
            end
            return true
        else
            f21_arg1:ClearSubGoal()
            if f21_local3 <= f21_local8 then
                f21_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 4, TARGET_ENE_0, f21_local10, TARGET_ENE_0, true, 9910)
            else
                f21_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 4, TARGET_ENE_0, f21_local10, TARGET_ENE_0, true, 9910)
                f21_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, f21_local9, TARGET_ENE_0, f21_arg0:GetRandam_Int(0, 1), f21_arg0:GetRandam_Int(30, 45), true, true, 9910)
            end
            return true
        end
    end
    
end

function GuardBreak_Act(f22_arg0, f22_arg1, f22_arg2, f22_arg3)
    local f22_local0 = f22_arg0:GetDist(TARGET_ENE_0)
    local f22_local1 = f22_arg0:GetRandam_Int(1, 100)
    if f22_arg0:IsInterupt(INTERUPT_GuardBreak) and f22_local0 <= f22_arg2 and f22_local1 <= f22_arg3 then
        f22_arg1:ClearSubGoal()
        return true
    end
    return false
    
end

function GuardBreak_Attack(f23_arg0, f23_arg1, f23_arg2, f23_arg3, f23_arg4)
    local f23_local0 = f23_arg0:GetDist(TARGET_ENE_0)
    local f23_local1 = f23_arg0:GetRandam_Int(1, 100)
    if f23_arg0:IsInterupt(INTERUPT_GuardBreak) and f23_local0 <= f23_arg2 and f23_local1 <= f23_arg3 then
        f23_arg1:ClearSubGoal()
        f23_arg1:AddSubGoal(GOAL_COMMON_Attack, 10, f23_arg4, TARGET_ENE_0, DIST_Middle, 0)
        return true
    end
    return false
    
end

function MissSwing_Int(f24_arg0, f24_arg1, f24_arg2, f24_arg3)
    local f24_local0 = f24_arg0:GetDist(TARGET_ENE_0)
    local f24_local1 = f24_arg0:GetRandam_Int(1, 100)
    if f24_arg0:IsInterupt(INTERUPT_MissSwing) and f24_local0 <= f24_arg2 and f24_local1 <= f24_arg3 then
        f24_arg1:ClearSubGoal()
        return true
    end
    return false
    
end

function MissSwing_Attack(f25_arg0, f25_arg1, f25_arg2, f25_arg3, f25_arg4)
    local f25_local0 = f25_arg0:GetDist(TARGET_ENE_0)
    local f25_local1 = f25_arg0:GetRandam_Int(1, 100)
    if f25_arg0:IsInterupt(INTERUPT_MissSwing) and f25_local0 <= f25_arg2 and f25_local1 <= f25_arg3 then
        f25_arg1:ClearSubGoal()
        f25_arg1:AddSubGoal(GOAL_COMMON_Attack, 10, f25_arg4, TARGET_ENE_0, DIST_Middle, 0)
        return true
    end
    return false
    
end

function UseItem_Act(f26_arg0, f26_arg1, f26_arg2, f26_arg3)
    local f26_local0 = f26_arg0:GetDist(TARGET_ENE_0)
    local f26_local1 = f26_arg0:GetRandam_Int(1, 100)
    if f26_arg0:IsInterupt(INTERUPT_UseItem) and f26_local0 <= f26_arg2 and f26_local1 <= f26_arg3 then
        f26_arg1:ClearSubGoal()
        return true
    end
    return false
    
end

function Shoot_1kind(f27_arg0, f27_arg1, f27_arg2, f27_arg3)
    local f27_local0 = f27_arg0:GetDist(TARGET_ENE_0)
    local f27_local1 = f27_arg0:GetRandam_Int(1, 100)
    local f27_local2 = GET_PARAM_IF_NIL_DEF(bkStepPer, 50)
    local f27_local3 = GET_PARAM_IF_NIL_DEF(leftStepPer, 25)
    local f27_local4 = GET_PARAM_IF_NIL_DEF(rightStepPer, 25)
    local f27_local5 = GET_PARAM_IF_NIL_DEF(safetyDist, 3)
    if f27_arg0:IsInterupt(INTERUPT_Shoot) and f27_local0 <= f27_arg2 and f27_local1 <= f27_arg3 then
        f27_arg1:ClearSubGoal()
        return true
    end
    return false
    
end

function Shoot_2dist(f28_arg0, f28_arg1, f28_arg2, f28_arg3, f28_arg4, f28_arg5)
    local f28_local0 = f28_arg0:GetDist(TARGET_ENE_0)
    local f28_local1 = f28_arg0:GetRandam_Int(1, 100)
    local f28_local2 = f28_arg0:GetRandam_Int(1, 100)
    if f28_arg0:IsInterupt(INTERUPT_Shoot) then
        if f28_local0 <= f28_arg2 then
            if f28_local1 <= f28_arg4 then
                f28_arg1:ClearSubGoal()
                return 1
            end
        elseif f28_local0 <= f28_arg3 then
            if f28_local1 <= f28_arg5 then
                f28_arg1:ClearSubGoal()
                return 2
            end
        else
            return 0
        end
    end
    return 0
    
end

function MissSwingSelf_Step(f29_arg0, f29_arg1, f29_arg2, f29_arg3, f29_arg4, f29_arg5, f29_arg6)
    local f29_local0 = f29_arg0:GetDist(TARGET_ENE_0)
    local f29_local1 = f29_arg0:GetRandam_Int(1, 100)
    local f29_local2 = f29_arg0:GetRandam_Int(1, 100)
    local f29_local3 = GET_PARAM_IF_NIL_DEF(f29_arg3, 50)
    local f29_local4 = GET_PARAM_IF_NIL_DEF(f29_arg4, 25)
    local f29_local5 = GET_PARAM_IF_NIL_DEF(f29_arg5, 25)
    local f29_local6 = GET_PARAM_IF_NIL_DEF(f29_arg6, 3)
    if f29_arg0:IsInterupt(INTERUPT_MissSwingSelf) and f29_local1 <= f29_arg2 then
        f29_arg1:ClearSubGoal()
        if f29_local2 <= f29_local3 then
            f29_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 701, TARGET_ENE_0, 0, AI_DIR_TYPE_B, f29_local6)
        elseif f29_local2 <= f29_local3 + f29_local4 then
            f29_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 702, TARGET_ENE_0, 0, AI_DIR_TYPE_L, f29_local6)
        else
            f29_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 703, TARGET_ENE_0, 0, AI_DIR_TYPE_R, f29_local6)
        end
        return true
    end
    
end

function RebByOpGuard_Step(f30_arg0, f30_arg1, f30_arg2, f30_arg3, f30_arg4, f30_arg5, f30_arg6)
    local f30_local0 = f30_arg0:GetDist(TARGET_ENE_0)
    local f30_local1 = f30_arg0:GetRandam_Int(1, 100)
    local f30_local2 = f30_arg0:GetRandam_Int(1, 100)
    local f30_local3 = GET_PARAM_IF_NIL_DEF(f30_arg3, 50)
    local f30_local4 = GET_PARAM_IF_NIL_DEF(f30_arg4, 25)
    local f30_local5 = GET_PARAM_IF_NIL_DEF(f30_arg5, 25)
    local f30_local6 = GET_PARAM_IF_NIL_DEF(f30_arg6, 3)
    if f30_arg0:IsInterupt(INTERUPT_ReboundByOpponentGuard) and f30_local1 <= f30_arg2 then
        f30_arg1:ClearSubGoal()
        if f30_local2 <= f30_local3 then
            f30_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 701, TARGET_ENE_0, 0, AI_DIR_TYPE_B, f30_local6)
        elseif f30_local2 <= f30_local3 + f30_local4 then
            f30_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 702, TARGET_ENE_0, 0, AI_DIR_TYPE_L, f30_local6)
        else
            f30_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 703, TARGET_ENE_0, 0, AI_DIR_TYPE_R, f30_local6)
        end
        return true
    end
    
end

function SuccessGuard_Act(f31_arg0, f31_arg1, f31_arg2, f31_arg3)
    local f31_local0 = f31_arg0:GetDist(TARGET_ENE_0)
    local f31_local1 = f31_arg0:GetRandam_Int(1, 100)
    local f31_local2 = f31_arg0:GetRandam_Int(1, 100)
    if f31_arg0:IsInterupt(INTERUPT_SuccessGuard) and f31_local0 <= f31_arg2 and f31_local1 <= f31_arg3 then
        f31_arg1:ClearSubGoal()
        return true
    end
    return false
    
end

function SuccessGuard_Attack(f32_arg0, f32_arg1, f32_arg2, f32_arg3, f32_arg4)
    local f32_local0 = f32_arg0:GetDist(TARGET_ENE_0)
    local f32_local1 = f32_arg0:GetRandam_Int(1, 100)
    if f32_arg0:IsInterupt(INTERUPT_SuccessGuard) and f32_local0 <= f32_arg2 and f32_local1 <= f32_arg3 then
        f32_arg1:ClearSubGoal()
        f32_arg1:AddSubGoal(GOAL_COMMON_Attack, 10, f32_arg4, TARGET_ENE_0, DIST_Middle, 0)
        return true
    end
    return false
    
end

function FarDamaged_Act(f33_arg0, f33_arg1, f33_arg2, f33_arg3)
    local f33_local0 = f33_arg0:GetDist(TARGET_ENE_0)
    local f33_local1 = f33_arg0:GetRandam_Int(1, 100)
    if f33_arg0:IsInterupt(INTERUPT_Damaged) and f33_arg2 <= f33_local0 and f33_local1 <= f33_arg3 then
        f33_arg1:ClearSubGoal()
        return true
    end
    return false
    
end

function MissSwing_Act(f34_arg0, f34_arg1, f34_arg2, f34_arg3)
    local f34_local0 = f34_arg0:GetDist(TARGET_ENE_0)
    local f34_local1 = f34_arg0:GetRandam_Int(1, 100)
    if f34_arg0:IsInterupt(INTERUPT_MissSwing) and f34_local0 <= f34_arg2 and f34_local1 <= f34_arg3 then
        f34_arg1:ClearSubGoal()
        return true
    end
    return false
    
end

function FindGuardBreak_Act(f35_arg0, f35_arg1, f35_arg2, f35_arg3)
    local f35_local0 = f35_arg0:GetDist(TARGET_ENE_0)
    local f35_local1 = f35_arg0:GetRandam_Int(1, 100)
    if f35_arg0:IsInterupt(INTERUPT_GuardBreak) and f35_local0 <= f35_arg2 and f35_local1 <= f35_arg3 then
        f35_arg1:ClearSubGoal()
        return true
    end
    return false
    
end

function FindGuardFinish_Act(f36_arg0, f36_arg1, f36_arg2, f36_arg3)
    local f36_local0 = f36_arg0:GetDist(TARGET_ENE_0)
    local f36_local1 = f36_arg0:GetRandam_Int(1, 100)
    if f36_arg0:IsInterupt(INTERUPT_GuardFinish) and f36_local0 <= f36_arg2 and f36_local1 <= f36_arg3 then
        f36_arg1:ClearSubGoal()
        return true
    end
    return false
    
end

function FindShoot_Act(f37_arg0, f37_arg1, f37_arg2, f37_arg3, f37_arg4, f37_arg5, f37_arg6, f37_arg7)
    local f37_local0 = f37_arg0:GetDist(TARGET_ENE_0)
    local f37_local1 = f37_arg0:GetRandam_Int(1, 100)
    if f37_arg0:IsInterupt(INTERUPT_Shoot) then
        if f37_local0 <= f37_arg5 and f37_local1 <= f37_arg2 then
            f37_arg1:ClearSubGoal()
            return 1
        elseif f37_local0 <= f37_arg6 and f37_local1 <= f37_arg3 then
            f37_arg1:ClearSubGoal()
            return 2
        elseif f37_local0 <= f37_arg7 and f37_local1 <= f37_arg4 then
            f37_arg1:ClearSubGoal()
            return 3
        else
            f37_arg1:ClearSubGoal()
            return 0
        end
    end
    return 0
    
end

function BusyApproach_Act(f38_arg0, f38_arg1, f38_arg2, f38_arg3, f38_arg4)
    local f38_local0 = -1
    local f38_local1 = f38_arg0:GetRandam_Int(1, 100)
    if f38_local1 <= f38_arg4 then
        f38_local0 = 9910
    end
    local f38_local2 = f38_arg0:GetDist(TARGET_ENE_0)
    if f38_arg3 <= f38_local2 then
        f38_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 10, TARGET_ENE_0, f38_arg2, TARGET_SELF, false, f38_local0)
    else
        f38_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 2, TARGET_ENE_0, f38_arg2, TARGET_SELF, true, f38_local0)
    end
    
end

function Approach_and_Attack_Act(f39_arg0, f39_arg1, f39_arg2, f39_arg3, f39_arg4, f39_arg5, f39_arg6, f39_arg7, f39_arg8)
    local f39_local0 = f39_arg0:GetDist(TARGET_ENE_0)
    local f39_local1 = true
    if f39_arg3 <= f39_local0 then
        f39_local1 = false
    end
    local f39_local2 = -1
    local f39_local3 = f39_arg0:GetRandam_Int(1, 100)
    if f39_local3 <= f39_arg4 then
        f39_local2 = 9910
    end
    local f39_local4 = GET_PARAM_IF_NIL_DEF(f39_arg7, 1.5)
    local f39_local5 = GET_PARAM_IF_NIL_DEF(f39_arg8, 20)
    f39_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 10, TARGET_ENE_0, f39_arg2, TARGET_SELF, f39_local1, f39_local2)
    f39_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f39_arg5, TARGET_ENE_0, f39_arg6, f39_local4, f39_local5)
    
end

function KeepDist_and_Attack_Act(f40_arg0, f40_arg1, f40_arg2, f40_arg3, f40_arg4, f40_arg5, f40_arg6, f40_arg7)
    local f40_local0 = f40_arg0:GetDist(TARGET_ENE_0)
    local f40_local1 = true
    if f40_arg4 <= f40_local0 then
        f40_local1 = false
    end
    local f40_local2 = -1
    local f40_local3 = f40_arg0:GetRandam_Int(1, 100)
    if f40_local3 <= f40_arg5 then
        f40_local2 = 9910
    end
    f40_arg1:AddSubGoal(GOAL_COMMON_KeepDist, 10, TARGET_ENE_0, f40_arg2, f40_arg3, TARGET_ENE_0, f40_local1, f40_local2)
    f40_arg1:AddSubGoal(GOAL_COMMON_Attack, 10, f40_arg6, TARGET_ENE_0, f40_arg7, 0)
    
end

function Approach_and_GuardBreak_Act(f41_arg0, f41_arg1, f41_arg2, f41_arg3, f41_arg4, f41_arg5, f41_arg6, f41_arg7, f41_arg8)
    local f41_local0 = f41_arg0:GetDist(TARGET_ENE_0)
    local f41_local1 = true
    if f41_arg3 <= f41_local0 then
        f41_local1 = false
    end
    local f41_local2 = -1
    local f41_local3 = f41_arg0:GetRandam_Int(1, 100)
    if f41_local3 <= f41_arg4 then
        f41_local2 = 9910
    end
    f41_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 10, TARGET_ENE_0, f41_arg2, TARGET_SELF, f41_local1, f41_local2)
    f41_arg1:AddSubGoal(GOAL_COMMON_GuardBreakAttack, 10, f41_arg5, TARGET_ENE_0, f41_arg6, 0)
    f41_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 10, f41_arg7, TARGET_ENE_0, f41_arg8, 0)
    
end

function GetWellSpace_Act(f42_arg0, f42_arg1, f42_arg2, f42_arg3, f42_arg4, f42_arg5, f42_arg6, f42_arg7)
    local f42_local0 = -1
    local f42_local1 = f42_arg0:GetRandam_Int(1, 100)
    if f42_local1 <= f42_arg2 then
        f42_local0 = 9910
    end
    local f42_local2 = f42_arg0:GetRandam_Int(1, 100)
    local f42_local3 = f42_arg0:GetRandam_Int(0, 1)
    local f42_local4 = f42_arg0:GetTeamRecordCount(COORDINATE_TYPE_SideWalk_L + f42_local3, TARGET_ENE_0, 2)
    if f42_local2 <= f42_arg3 then
    elseif f42_local2 <= f42_arg3 + f42_arg4 and f42_local4 < 2 then
        f42_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 2.5, TARGET_ENE_0, 2, TARGET_ENE_0, true, f42_local0)
        f42_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, 3, TARGET_ENE_0, f42_local3, f42_arg0:GetRandam_Int(30, 45), true, true, f42_local0)
    elseif f42_local2 <= f42_arg3 + f42_arg4 + f42_arg5 then
        f42_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 2.5, TARGET_ENE_0, 3, TARGET_ENE_0, true, f42_local0)
    elseif f42_local2 <= f42_arg3 + f42_arg4 + f42_arg5 + f42_arg6 then
        f42_arg1:AddSubGoal(GOAL_COMMON_Wait, f42_arg0:GetRandam_Float(0.5, 1), 0, 0, 0, 0)
    else
        f42_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 701, TARGET_ENE_0, 0, AI_DIR_TYPE_B, 4)
    end
    
end

function GetWellSpace_Act_IncludeSidestep(f43_arg0, f43_arg1, f43_arg2, f43_arg3, f43_arg4, f43_arg5, f43_arg6, f43_arg7, f43_arg8)
    local f43_local0 = -1
    local f43_local1 = f43_arg0:GetRandam_Int(1, 100)
    if f43_local1 <= f43_arg2 then
        f43_local0 = 9910
    end
    local f43_local2 = f43_arg0:GetRandam_Int(1, 100)
    local f43_local3 = f43_arg0:GetRandam_Int(0, 1)
    local f43_local4 = f43_arg0:GetTeamRecordCount(COORDINATE_TYPE_SideWalk_L + f43_local3, TARGET_ENE_0, 2)
    if f43_local2 <= f43_arg3 then
    elseif f43_local2 <= f43_arg3 + f43_arg4 and f43_local4 < 2 then
        f43_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 2.5, TARGET_ENE_0, 2, TARGET_ENE_0, true, f43_local0)
        f43_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, 3, TARGET_ENE_0, f43_local3, f43_arg0:GetRandam_Int(30, 45), true, true, f43_local0)
    elseif f43_local2 <= f43_arg3 + f43_arg4 + f43_arg5 then
        f43_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 2.5, TARGET_ENE_0, 3, TARGET_ENE_0, true, f43_local0)
    elseif f43_local2 <= f43_arg3 + f43_arg4 + f43_arg5 + f43_arg6 then
        f43_arg1:AddSubGoal(GOAL_COMMON_Wait, f43_arg0:GetRandam_Float(0.5, 1), 0, 0, 0, 0)
    elseif f43_local2 <= f43_arg3 + f43_arg4 + f43_arg5 + f43_arg6 + f43_arg7 then
        f43_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6001, TARGET_ENE_0, 0, AI_DIR_TYPE_B, 4)
    else
        local f43_local5 = f43_arg0:GetRandam_Int(1, 100)
        if f43_local5 <= 50 then
            f43_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6002, TARGET_ENE_0, 0, AI_DIR_TYPE_L, 4)
        else
            f43_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6003, TARGET_ENE_0, 0, AI_DIR_TYPE_R, 4)
        end
    end
    
end

function Shoot_Act(f44_arg0, f44_arg1, f44_arg2, f44_arg3, f44_arg4)
    if f44_arg4 == 1 then
        f44_arg1:AddSubGoal(GOAL_COMMON_Attack, 10, f44_arg2, TARGET_ENE_0, DIST_None, 0)
    elseif f44_arg4 >= 2 then
        f44_arg1:AddSubGoal(GOAL_COMMON_ComboAttack, 10, f44_arg2, TARGET_ENE_0, DIST_None, 0)
        if f44_arg4 >= 3 then
            f44_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, f44_arg3, TARGET_ENE_0, DIST_None, 0)
            if f44_arg4 >= 4 then
                f44_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, f44_arg3, TARGET_ENE_0, DIST_None, 0)
                if f44_arg4 >= 5 then
                    f44_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, f44_arg3, TARGET_ENE_0, DIST_None, 0)
                end
            end
        end
        f44_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 10, f44_arg3, TARGET_ENE_0, DIST_None, 0)
    end
    
end

function Approach_Act(f45_arg0, f45_arg1, f45_arg2, f45_arg3, f45_arg4, f45_arg5)
    if f45_arg5 == nil then
        f45_arg5 = 10
    end
    local f45_local0 = f45_arg0:GetDist(TARGET_ENE_0)
    local f45_local1 = true
    if f45_arg3 <= f45_local0 then
        f45_local1 = false
    end
    local f45_local2 = -1
    local f45_local3 = f45_arg0:GetRandam_Int(1, 100)
    if f45_local3 <= f45_arg4 then
        f45_local2 = 9910
    end
    f45_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, f45_arg5, TARGET_ENE_0, f45_arg2, TARGET_SELF, f45_local1, f45_local2)
    
end

function Approach_or_Leave_Act(f46_arg0, f46_arg1, f46_arg2, f46_arg3, f46_arg4, f46_arg5)
    local f46_local0 = f46_arg0:GetDist(TARGET_ENE_0)
    local f46_local1 = true
    if f46_arg4 ~= -1 and f46_arg4 <= f46_local0 then
        f46_local1 = false
    end
    local f46_local2 = -1
    local f46_local3 = f46_arg0:GetRandam_Int(1, 100)
    if f46_local3 <= f46_arg5 then
        f46_local2 = 9910
    end
    if f46_arg2 <= f46_local0 then
        f46_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 5, TARGET_ENE_0, f46_arg3, TARGET_SELF, f46_local1, f46_local2)
    else
        f46_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 5, TARGET_ENE_0, f46_arg2, TARGET_ENE_0, true, f46_local2)
    end
    
end

function Watching_Parry_Chance_Act(f47_arg0, f47_arg1)
    FirstDist = f47_arg0:GetRandam_Float(2, 4)
    SecondDist = f47_arg0:GetRandam_Float(2, 4)
    f47_arg1:AddSubGoal(GOAL_COMMON_KeepDist, 5, TARGET_ENE_0, FirstDist, FirstDist + 0.5, TARGET_ENE_0, true, 9920)
    f47_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, f47_arg0:GetRandam_Float(3, 5), TARGET_ENE_0, f47_arg0:GetRandam_Int(0, 1), 180, true, true, 9920)
    f47_arg1:AddSubGoal(GOAL_COMMON_KeepDist, 5, TARGET_ENE_0, SecondDist, SecondDist + 0.5, TARGET_ENE_0, true, 9920)
    f47_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, f47_arg0:GetRandam_Float(3, 5), TARGET_ENE_0, f47_arg0:GetRandam_Int(0, 1), 180, true, true, 9920)
    
end

function Parry_Act(f48_arg0, f48_arg1, f48_arg2, f48_arg3, f48_arg4, f48_arg5)
    local f48_local0 = f48_arg0:GetDist(TARGET_ENE_0)
    if f48_arg0:IsInterupt(INTERUPT_ParryTiming) then
        if f48_local0 <= f48_arg2 and f48_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_F, f48_arg3) and not f48_arg0:IsActiveGoal(GOAL_COMMON_Parry) then
            f48_arg1:ClearSubGoal()
            f48_arg1:AddSubGoal(GOAL_COMMON_Parry, 1.25, 4000, TARGET_SELF, 0)
            return true
        end
    elseif f48_arg0:IsInterupt(INTERUPT_SuccessParry) and f48_local0 <= f48_arg4 and f48_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_F, f48_arg5) then
        f48_arg1:ClearSubGoal()
        if f48_local0 > 1 then
            f48_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 3, TARGET_ENE_0, 1, TARGET_SELF, false, -1)
        else
            local f48_local1 = 1
            f48_arg1:AddSubGoal(GOAL_COMMON_Wait, f48_local1, TARGET_ENE_0)
        end
        f48_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 2, 3110, TARGET_ENE_0, 3, 0, -1)
        return true
    end
    
end

function ObserveAreaForBackstab(f49_arg0, f49_arg1, f49_arg2, f49_arg3, f49_arg4)
    f49_arg0:AddObserveArea(f49_arg2, TARGET_ENE_0, TARGET_SELF, AI_DIR_TYPE_B, f49_arg4, f49_arg3)
    
end

function Backstab_Act(f50_arg0, f50_arg1, f50_arg2, f50_arg3, f50_arg4, f50_arg5)
    if f50_arg0:IsInterupt(INTERUPT_Inside_ObserveArea) and f50_arg0:IsThrowing() == false and f50_arg0:IsFinishTimer(f50_arg4) == true and f50_arg0:IsInsideObserve(f50_arg2) then
        f50_arg0:SetTimer(f50_arg4, f50_arg5)
        f50_arg1:ClearSubGoal()
        f50_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 5, TARGET_ENE_0, f50_arg3, TARGET_SELF, false, -1)
        f50_arg1:AddSubGoal(GOAL_COMMON_Attack, 10, 3110, TARGET_ENE_0, 3, 0)
        return true
    end
    
end

function Torimaki_Act(f51_arg0, f51_arg1, f51_arg2)
    local f51_local0 = -1
    local f51_local1 = f51_arg0:GetRandam_Int(1, 100)
    if f51_local1 <= f51_arg2 then
        f51_local0 = 9910
    end
    local f51_local2 = f51_arg0:GetDist(TARGET_ENE_0)
    if f51_local2 >= 15 then
        f51_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 5, TARGET_ENE_0, 4.5, TARGET_SELF, true, -1)
    elseif f51_local2 >= 6 then
        f51_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 5, TARGET_ENE_0, 4.5, TARGET_SELF, true, -1)
    elseif f51_local2 >= 3 then
        f51_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, 3, TARGET_ENE_0, f51_arg0:GetRandam_Int(0, 1), f51_arg0:GetRandam_Int(30, 45), true, true, f51_local0)
    else
        f51_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 5, TARGET_ENE_0, 4, TARGET_ENE_0, true, f51_local0)
    end
    f51_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, 3, TARGET_ENE_0, f51_arg0:GetRandam_Int(0, 1), f51_arg0:GetRandam_Int(30, 45), true, true, f51_local0)
    
end

function Kankyaku_Act(f52_arg0, f52_arg1, f52_arg2)
    local f52_local0 = -1
    local f52_local1 = f52_arg0:GetRandam_Int(1, 100)
    if f52_local1 <= f52_arg2 then
        f52_local0 = 9910
    end
    local f52_local2 = f52_arg0:GetDist(TARGET_ENE_0)
    if f52_local2 >= 15 then
        f52_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 5, TARGET_ENE_0, 6.5, TARGET_SELF, true, -1)
    elseif f52_local2 >= 8 then
        f52_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 5, TARGET_ENE_0, 6.5, TARGET_SELF, true, -1)
    elseif f52_local2 >= 4 then
        f52_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, 3, TARGET_ENE_0, f52_arg0:GetRandam_Int(0, 1), f52_arg0:GetRandam_Int(30, 45), true, true, f52_local0)
    else
        f52_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 5, TARGET_ENE_0, 6, TARGET_ENE_0, true, f52_local0)
    end
    f52_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, 3, TARGET_ENE_0, f52_arg0:GetRandam_Int(0, 1), f52_arg0:GetRandam_Int(30, 45), true, true, f52_local0)
    
end

function ClearTableParam(f53_arg0, f53_arg1)
    local f53_local0 = 50
    local f53_local1 = 1
    for f53_local2 = 1, f53_local0, 1 do
        f53_arg0[f53_local2] = 0
        f53_arg1[f53_local2] = {}
    end
    

end

function SelectOddsIndex(f54_arg0, f54_arg1)
    local f54_local0 = table.getn(f54_arg1)
    local f54_local1 = 0
    for f54_local2 = 1, f54_local0, 1 do
        f54_local1 = f54_local1 + f54_arg1[f54_local2]
    end
    local f54_local2 = f54_arg0:GetRandam_Int(0, f54_local1 - 1)
    for f54_local3 = 1, f54_local0, 1 do
        local f54_local6 = f54_arg1[f54_local3]
        if f54_local2 < f54_local6 then
            return f54_local3
        end
        f54_local2 = f54_local2 - f54_local6
    end
    return -1
    


end

function SelectFunc(f55_arg0, f55_arg1, f55_arg2)
    local f55_local0 = SelectOddsIndex(f55_arg0, f55_arg1)
    if f55_local0 < 1 then
        return nil
    end
    return f55_arg2[f55_local0]
    
end

function SelectGoalFunc(f56_arg0, f56_arg1, f56_arg2)
    local f56_local0 = _GetGoalActFuncTable(f56_arg0)
    return SelectFunc(f56_arg1, f56_arg2, f56_local0)
    
end

function CallAttackAndAfterFunc(f57_arg0, f57_arg1, f57_arg2, f57_arg3, f57_arg4, f57_arg5)
    local f57_local0 = SelectOddsIndex(f57_arg1, f57_arg3)
    local f57_local1 = 0
    if f57_local0 >= 1 then
        local f57_local2 = _GetGoalActFuncTable(f57_arg0)
        local f57_local3 = nil
        if f57_arg4 ~= nil then
            f57_local3 = f57_arg4[f57_local0]
        end
        f57_local1 = f57_local2[f57_local0](f57_arg0, f57_arg1, f57_arg2, f57_local3)
    end
    local f57_local2 = f57_arg1:GetRandam_Int(1, 100)
    if f57_local2 <= f57_local1 then
        if f57_arg0.ActAfter ~= nil then
            f57_arg0.ActAfter(f57_arg0, f57_arg1, f57_arg2, f57_arg5)
        else
            HumanCommon_ActAfter_AdjustSpace(f57_arg1, f57_arg2, f57_arg5)
        end
    end
    
end

function _GetGoalActFuncTable(f58_arg0)
    return {f58_arg0.Act01, f58_arg0.Act02, f58_arg0.Act03, f58_arg0.Act04, f58_arg0.Act05, f58_arg0.Act06, f58_arg0.Act07, f58_arg0.Act08, f58_arg0.Act09, f58_arg0.Act10, f58_arg0.Act11, f58_arg0.Act12, f58_arg0.Act13, f58_arg0.Act14, f58_arg0.Act15, f58_arg0.Act16, f58_arg0.Act17, f58_arg0.Act18, f58_arg0.Act19, f58_arg0.Act20}
    
end

function GetTargetAngle(f59_arg0, f59_arg1)
    if f59_arg0:IsInsideTarget(f59_arg1, AI_DIR_TYPE_F, 90) then
        if f59_arg0:IsInsideTarget(f59_arg1, AI_DIR_TYPE_F, 90) then
            return TARGET_ANGLE_FRONT
        elseif f59_arg0:IsInsideTarget(f59_arg1, AI_DIR_TYPE_L, 180) then
            return TARGET_ANGLE_LEFT
        else
            return TARGET_ANGLE_RIGHT
        end
    end
    if f59_arg0:IsInsideTarget(f59_arg1, AI_DIR_TYPE_L, 90) then
        return TARGET_ANGLE_LEFT
    elseif f59_arg0:IsInsideTarget(f59_arg1, AI_DIR_TYPE_R, 90) then
        return TARGET_ANGLE_RIGHT
    else
        return TARGET_ANGLE_BACK
    end
    
end

function GetCurrentTimeType(f60_arg0)
    local f60_local0 = 360
    local f60_local1 = 600
    local f60_local2 = 1080
    local f60_local3 = 1200
    local f60_local4 = 180
    local f60_local5 = f60_arg0:GetAreaMinute() + f60_arg0:GetAreaHour() * 60
    if f60_local0 <= f60_local5 and f60_local5 < f60_local1 then
        return PLAN_TIME_TYPE_MORNING
    elseif f60_local1 <= f60_local5 and f60_local5 < f60_local2 then
        return PLAN_TIME_TYPE_DAYTIME
    elseif f60_local2 <= f60_local5 and f60_local5 < f60_local3 then
        return PLAN_TIME_TYPE_EVENING
    elseif f60_local3 <= f60_local5 and f60_local5 < 1440 or f60_local5 >= 0 and f60_local5 < f60_local4 then
        return PLAN_TIME_TYPE_NIGHT
    elseif f60_local4 <= f60_local5 and f60_local5 < f60_local0 then
        return PLAN_TIME_TYPE_MIDNIGHT
    else
        return nil
    end
    
end

function IsTargetTimeZone(f61_arg0, f61_arg1)
    local f61_local0 = 360
    local f61_local1 = 600
    local f61_local2 = 1080
    local f61_local3 = 1200
    local f61_local4 = 180
    local f61_local5 = f61_arg0:GetAreaMinute() + f61_arg0:GetAreaHour() * 60
    if f61_arg1 == PLAN_TIME_TYPE_MORNING then
        if f61_local0 <= f61_local5 and f61_local5 < f61_local1 then
            return true
        else
            return false
        end
    elseif f61_arg1 == PLAN_TIME_TYPE_DAYTIME then
        if f61_local1 <= f61_local5 and f61_local5 < f61_local2 then
            return true
        else
            return false
        end
    elseif f61_arg1 == PLAN_TIME_TYPE_EVENING then
        if f61_local2 <= f61_local5 and f61_local5 < f61_local3 then
            return true
        else
            return false
        end
    elseif f61_arg1 == PLAN_TIME_TYPE_NIGHT then
        if f61_local3 <= f61_local5 and f61_local5 < 1440 or f61_local5 >= 0 and f61_local5 < f61_local4 then
            return true
        else
            return false
        end
    elseif f61_arg1 == PLAN_TIME_TYPE_MIDNIGHT then
        if f61_local4 <= f61_local5 and f61_local5 < f61_local0 then
            return true
        else
            return false
        end
    else
        return false
    end
    
end

function IsInsideTargetTimeZone(f62_arg0, f62_arg1, f62_arg2)
    local f62_local0 = false
    local f62_local1 = false
    local f62_local2 = {}
    local f62_local3 = 5
    f62_local2[PLAN_TIME_TYPE_MORNING] = false
    f62_local2[PLAN_TIME_TYPE_DAYTIME] = false
    f62_local2[PLAN_TIME_TYPE_EVENING] = false
    f62_local2[PLAN_TIME_TYPE_NIGHT] = false
    f62_local2[PLAN_TIME_TYPE_MIDNIGHT] = false
    local f62_local4 = 0
    repeat
        if f62_local4 == f62_arg1 then
            f62_local0 = true
        end
        if f62_local0 then
            f62_local2[f62_local4] = true
            if f62_local4 == f62_arg2 then
                f62_local1 = true
            end
        end
        if f62_local4 == f62_local3 - 1 then
            f62_local4 = 0
        else
            f62_local4 = f62_local4 + 1
        end
    until f62_local1
    return f62_local2[GetCurrentTimeType(f62_arg0)]
    

end

function GET_PARAM_IF_NIL_DEF(f63_arg0, f63_arg1)
    if f63_arg0 ~= nil then
        return f63_arg0
    end
    return f63_arg1
    
end

function REGIST_FUNC(f64_arg0, f64_arg1, f64_arg2, f64_arg3)
    return function ()
        return f64_arg2(f64_arg0, f64_arg1, f64_arg3)
        
    end

    
end

function Approach_Act_Flex(f66_arg0, f66_arg1, f66_arg2, f66_arg3, f66_arg4, f66_arg5, f66_arg6, f66_arg7, f66_arg8)
    if f66_arg7 == nil then
        f66_arg7 = 3
    end
    if f66_arg8 == nil then
        f66_arg8 = 8
    end
    local f66_local0 = f66_arg0:GetDist(TARGET_ENE_0)
    local f66_local1 = f66_arg0:GetRandam_Int(1, 100)
    local f66_local2 = true
    if f66_arg4 <= f66_local0 then
        f66_local2 = false
    elseif f66_arg3 <= f66_local0 and f66_local1 <= f66_arg5 then
        f66_local2 = false
    end
    local f66_local3 = -1
    local f66_local4 = f66_arg0:GetRandam_Int(1, 100)
    if f66_local4 <= f66_arg6 then
        f66_local3 = 9910
    end
    if f66_local2 == true then
        life = f66_arg7
    else
        life = f66_arg8
    end
    local f66_local5 = 0
    if f66_arg2 <= f66_local0 then
        if f66_local2 == true then
            f66_arg2 = f66_arg2 + f66_arg0:GetStringIndexedNumber("AddDistWalk") + f66_local5
        else
            f66_arg2 = f66_arg2 + f66_arg0:GetStringIndexedNumber("AddDistRun") + f66_local5
        end
        f66_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, life, TARGET_ENE_0, f66_arg2, TARGET_SELF, f66_local2, f66_local3)
    end
    
end

function SpaceCheck(f67_arg0, f67_arg1, f67_arg2, f67_arg3)
    local f67_local0 = f67_arg0:GetMapHitRadius(TARGET_SELF)
    local f67_local1 = f67_arg0:GetExistMeshOnLineDistSpecifyAngleEx(TARGET_SELF, f67_arg2, f67_arg3 + f67_local0, AI_SPA_DIR_TYPE_TargetF, f67_local0, 0)
    if f67_arg3 * 0.95 <= f67_local1 then
        return true
    else
        return false
    end
    
end

function InsideRange(f68_arg0, f68_arg1, f68_arg2, f68_arg3, f68_arg4, f68_arg5)
    return YSD_InsideRangeEx(f68_arg0, f68_arg1, f68_arg2, f68_arg3, f68_arg4, f68_arg5)
    
end

function InsideDir(f69_arg0, f69_arg1, f69_arg2, f69_arg3)
    return YSD_InsideRangeEx(f69_arg0, f69_arg1, f69_arg2, f69_arg3, -999, 999)
    
end

function YSD_InsideRangeEx(f70_arg0, f70_arg1, f70_arg2, f70_arg3, f70_arg4, f70_arg5)
    local f70_local0 = f70_arg0:GetDist(TARGET_ENE_0)
    if f70_arg4 <= f70_local0 and f70_local0 <= f70_arg5 then
        local f70_local1 = f70_arg0:GetToTargetAngle(TARGET_ENE_0)
        local f70_local2 = 0
        if f70_arg2 < 0 then
            f70_local2 = -1
        else
            f70_local2 = 1
        end
        if f70_arg2 + f70_arg3 / -2 <= f70_local1 and f70_local1 <= f70_arg2 + f70_arg3 / 2 or f70_arg2 + f70_arg3 / -2 <= f70_local1 + 360 * f70_local2 and f70_local1 + 360 * f70_local2 <= f70_arg2 + f70_arg3 / 2 then
            return true
        else
            return false
        end
    else
        return false
    end
    
end

function SetCoolTime(f71_arg0, f71_arg1, f71_arg2, f71_arg3, f71_arg4, f71_arg5)
    f71_arg3 = f71_arg0:RegistAttackTimeInterval(f71_arg2, f71_arg3)
    if f71_arg4 <= 0 then
        return 0
    elseif f71_arg0:GetAttackPassedTime(f71_arg2) <= f71_arg3 then
        return f71_arg5
    end
    return f71_arg4
    
end

function Counter_Act(f72_arg0, f72_arg1, f72_arg2, f72_arg3)
    local f72_local0 = 0.5
    if f72_arg2 == nil then
        f72_arg2 = 4
    end
    local f72_local1 = f72_arg0:GetRandam_Int(1, 100)
    local f72_local2 = f72_arg0:GetNumber(15)
    if f72_arg0:IsInterupt(INTERUPT_Damaged) then
        f72_arg0:SetTimer(15, 5)
        if f72_local2 == 0 then
            f72_local2 = f72_arg2
        end
        f72_arg0:SetNumber(15, f72_local2 * 2)
    end
    if f72_local2 >= 100 then
        f72_arg0:SetNumber(15, 100)
    end
    if f72_arg0:IsInterupt(INTERUPT_Damaged) and f72_local1 <= f72_arg0:GetNumber(15) and f72_arg0:GetTimer(14) <= 0 then
        f72_arg0:SetTimer(14, 3)
        f72_arg0:SetNumber(15, 0)
        f72_arg1:ClearSubGoal()
        f72_arg1:AddSubGoal(GOAL_COMMON_EndureAttack, f72_local0, f72_arg3, TARGET_ENE_0, DIST_None, 0, 180, 0, 0)
        return true
    end
    return false
    
end

function ReactBackstab_Act(f73_arg0, f73_arg1, f73_arg2, f73_arg3, f73_arg4)
    local f73_local0 = f73_arg0:GetRandam_Int(1, 100)
    local f73_local1 = f73_arg0:GetRandam_Int(1, 100)
    local f73_local2 = 3
    local f73_local3 = 6000
    local f73_local4 = 6002
    local f73_local5 = 6003
    if f73_arg3 == nil then
        f73_arg4 = 0
    end
    if f73_arg0:IsInterupt(INTERUPT_BackstabRisk) then
        if f73_local0 <= f73_arg4 then
            f73_arg1:ClearSubGoal()
            f73_arg1:AddSubGoal(GOAL_COMMON_StabCounterAttack, f73_local2, f73_arg3, TARGET_ENE_0, DIST_None, 0, 180, 0, 0)
        elseif f73_arg2 == 1 then
            f73_arg1:ClearSubGoal()
            f73_arg1:AddSubGoal(GOAL_COMMON_SpinStep, f73_local2, f73_local3, TARGET_SELF, 0, AI_DIR_TYPE_F, 0)
        elseif f73_arg2 == 2 then
            f73_arg1:ClearSubGoal()
            if f73_local1 <= 50 then
                f73_arg1:AddSubGoal(GOAL_COMMON_SpinStep, f73_local2, f73_local4, TARGET_SELF, 0, AI_DIR_TYPE_L, 0)
            else
                f73_arg1:AddSubGoal(GOAL_COMMON_SpinStep, f73_local2, f73_local5, TARGET_SELF, 0, AI_DIR_TYPE_R, 0)
            end
        elseif f73_arg2 == 3 then
            f73_arg1:ClearSubGoal()
            if f73_local1 <= 33 then
                f73_arg1:AddSubGoal(GOAL_COMMON_SpinStep, f73_local2, f73_local3, TARGET_SELF, 0, AI_DIR_TYPE_F, 0)
            elseif f73_local1 <= 66 then
                f73_arg1:AddSubGoal(GOAL_COMMON_SpinStep, f73_local2, f73_local4, TARGET_SELF, 0, AI_DIR_TYPE_L, 0)
            else
                f73_arg1:AddSubGoal(GOAL_COMMON_SpinStep, f73_local2, f73_local5, TARGET_SELF, 0, AI_DIR_TYPE_R, 0)
            end
        end
        return false
    end
    
end

function Init_Pseudo_Global(f74_arg0, f74_arg1)
    f74_arg0:SetStringIndexedNumber("Dist_SideStep", 5)
    f74_arg0:SetStringIndexedNumber("Dist_BackStep", 5)
    f74_arg0:SetStringIndexedNumber("AddDistWalk", 0)
    f74_arg0:SetStringIndexedNumber("AddDistRun", 0)
    Init_AfterAttackAct(f74_arg0, f74_arg1)
    
end

function Init_AfterAttackAct(f75_arg0, f75_arg1)
    f75_arg0:SetStringIndexedNumber("DistMin_AAA", -999)
    f75_arg0:SetStringIndexedNumber("DistMax_AAA", 999)
    f75_arg0:SetStringIndexedNumber("BaseDir_AAA", AI_DIR_TYPE_F)
    f75_arg0:SetStringIndexedNumber("Angle_AAA", 360)
    f75_arg0:SetStringIndexedNumber("Odds_Guard_AAA", 0)
    f75_arg0:SetStringIndexedNumber("Odds_NoAct_AAA", 0)
    f75_arg0:SetStringIndexedNumber("Odds_BackAndSide_AAA", 0)
    f75_arg0:SetStringIndexedNumber("Odds_Back_AAA", 0)
    f75_arg0:SetStringIndexedNumber("Odds_Backstep_AAA", 0)
    f75_arg0:SetStringIndexedNumber("Odds_Sidestep_AAA", 0)
    f75_arg0:SetStringIndexedNumber("Odds_BitWait_AAA", 0)
    f75_arg0:SetStringIndexedNumber("Odds_BsAndSide_AAA", 0)
    f75_arg0:SetStringIndexedNumber("Odds_BsAndSs_AAA", 0)
    f75_arg0:SetStringIndexedNumber("DistMin_Inter_AAA", -999)
    f75_arg0:SetStringIndexedNumber("DistMax_Inter_AAA", 999)
    f75_arg0:SetStringIndexedNumber("BaseAng_Inter_AAA", 0)
    f75_arg0:SetStringIndexedNumber("Ang_Inter_AAA", 360)
    f75_arg0:SetStringIndexedNumber("BackAndSide_BackLife_AAA", 2)
    f75_arg0:SetStringIndexedNumber("BackAndSide_SideLife_AAA", f75_arg0:GetRandam_Float(2.5, 3.5))
    f75_arg0:SetStringIndexedNumber("BackLife_AAA", f75_arg0:GetRandam_Float(2, 3))
    f75_arg0:SetStringIndexedNumber("BsAndSide_SideLife_AAA", f75_arg0:GetRandam_Float(2.5, 3.5))
    f75_arg0:SetStringIndexedNumber("BackAndSide_BackDist_AAA", 1.5)
    f75_arg0:SetStringIndexedNumber("BackDist_AAA", f75_arg0:GetRandam_Float(2.5, 3.5))
    f75_arg0:SetStringIndexedNumber("BackAndSide_SideDir_AAA", f75_arg0:GetRandam_Int(45, 60))
    f75_arg0:SetStringIndexedNumber("BsAndSide_SideDir_AAA", f75_arg0:GetRandam_Int(45, 60))
    
end

function Update_Default_NoSubGoal(f76_arg0, f76_arg1, f76_arg2)
    if f76_arg2:GetSubGoalNum() <= 0 then
        return GOAL_RESULT_Success
    end
    return GOAL_RESULT_Continue
    
end

function GuardGoalSubFunc_Activate(f77_arg0, f77_arg1, f77_arg2)
    if 0 < f77_arg2 then
        f77_arg0:DoEzAction(f77_arg1, f77_arg2)
    end
    
end

function GuardGoalSubFunc_Update(f78_arg0, f78_arg1, f78_arg2, f78_arg3, f78_arg4)
    if 0 < f78_arg2 then
        if f78_arg1:GetNumber(0) ~= 0 then
            return GOAL_RESULT_Failed
        elseif f78_arg1:GetNumber(1) ~= 0 then
            return f78_arg3
        end
    end
    if f78_arg1:GetLife() <= 0 then
        if f78_arg4 then
            return GOAL_RESULT_Success
        else
            return GOAL_RESULT_Failed
        end
    end
    return GOAL_RESULT_Continue
    
end

function GuardGoalSubFunc_Interrupt(f79_arg0, f79_arg1, f79_arg2, f79_arg3)
    if 0 < f79_arg2 then
        if f79_arg0:IsInterupt(INTERUPT_Damaged) then
            f79_arg1:SetNumber(0, 1)
        elseif f79_arg0:IsInterupt(INTERUPT_SuccessGuard) and f79_arg3 ~= GOAL_RESULT_Continue then
            f79_arg1:SetNumber(1, 1)
        end
    end
    return false
    
end


