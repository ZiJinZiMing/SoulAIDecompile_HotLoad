﻿REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_LeaveTarget_Continuous, 0, "移動対象", 0)
REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_LeaveTarget_Continuous, 1, "到達判定距離", 0)
REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_LeaveTarget_Continuous, 2, "旋回対象", 0)
REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_LeaveTarget_Continuous, 3, "歩くか", 0)
REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_LeaveTarget_Continuous, 4, "ガード番号", 0)
REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_LeaveTarget_Continuous, 5, "ガード終了時の終了結果", 0)
REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_LeaveTarget_Continuous, 6, "ガード寿命が尽きたら成功か", 0)
REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_LeaveTarget_Continuous, 7, "パスチェックを行う距離", 0)

function LeaveTargetContinuous_Activate(f1_arg0, f1_arg1)
    local f1_local0 = f1_arg1:GetParam(0)
    local f1_local1 = f1_arg1:GetParam(1)
    local f1_local2 = f1_arg1:GetParam(2)
    local f1_local3 = f1_arg1:GetParam(3)
    local f1_local4 = f1_arg1:GetParam(4)
    local f1_local5 = f1_arg1:GetParam(5)
    local f1_local6 = f1_arg1:GetParam(6)
    local f1_local7 = f1_arg1:GetParam(7)
    f1_arg1:SetNumber(0, 0)
    f1_arg1:AddSubGoal(GOAL_COMMON_LeaveTargetToPathEnd, -1, f1_local0, 9999, f1_local2, f1_local3, f1_local4, f1_local5, f1_local6, f1_local7)
    
end

function LeaveTargetContinuous_Update(f2_arg0, f2_arg1)
    local f2_local0 = f2_arg1:GetParam(0)
    local f2_local1 = f2_arg1:GetParam(1)
    local f2_local2 = f2_arg1:GetParam(2)
    local f2_local3 = f2_arg1:GetParam(3)
    local f2_local4 = f2_arg1:GetParam(4)
    local f2_local5 = f2_arg1:GetParam(5)
    local f2_local6 = f2_arg1:GetParam(6)
    local f2_local7 = f2_arg1:GetParam(7)
    local f2_local8 = GOAL_RESULT_Continue
    if f2_local1 < f2_arg0:GetDist(f2_local0) then
        return GOAL_RESULT_Success
    end
    if f2_arg1:GetSubGoalNum() <= 0 then
        if f2_arg1:GetNumber(0) == 0 then
            local f2_local9 = {AI_DIR_TYPE_BL, AI_DIR_TYPE_BR, AI_DIR_TYPE_L, AI_DIR_TYPE_R}
            local f2_local10 = {225, 135, 270, 90}
            local f2_local11 = false
            for f2_local12 = 1, 4, 1 do
                local f2_local15 = f2_arg0:GetRandam_Int(1, table.getn(f2_local9))
                f2_local11 = SpaceCheck(f2_arg0, f2_arg1, f2_local10[f2_local15], f2_local7)
                f2_arg0:SetAIFixedMoveTarget(TARGET_SELF, f2_local9[f2_local15], 5)
                table.remove(f2_local9, f2_local15)
                table.remove(f2_local10, f2_local15)
                if f2_local11 == true then
                    break
                end
            end
            if f2_local11 == true then
                f2_arg1:AddSubGoal(GOAL_COMMON_Turn, 3, POINT_AI_FIXED_POS)
            else
                f2_arg0:SetAIFixedMoveTarget(TARGET_SELF, AI_DIR_TYPE_B, 5)
                f2_arg1:AddSubGoal(GOAL_COMMON_Turn, 3, POINT_AI_FIXED_POS)
            end
            f2_arg1:SetNumber(0, 1)

        elseif f2_arg1:GetTimer(0) <= 0 then
            f2_arg0:SetAIFixedMoveTarget(TARGET_SELF, AI_DIR_TYPE_B, 1)
            f2_arg1:AddSubGoal(GOAL_COMMON_LeaveTargetToPathEnd, -1, POINT_AI_FIXED_POS, 9999, f2_local2, f2_local3, f2_local4, f2_local5, f2_local6, f2_local7)
            f2_arg1:SetTimer(0, 1)
            f2_arg1:SetNumber(0, 0)
        else
            f2_arg1:AddSubGoal(GOAL_COMMON_Wait, 1, TARGET_NONE, 0, 0, 0)
        end
    end
    return f2_local8
    
end

function LeaveTargetContinuous_Terminate(f3_arg0, f3_arg1)
    
end

REGISTER_GOAL_NO_INTERUPT(GOAL_COMMON_LeaveTarget_Continuous, true)

function LeaveTargetContinuous_Interupt(f4_arg0, f4_arg1)
    return false
    
end


