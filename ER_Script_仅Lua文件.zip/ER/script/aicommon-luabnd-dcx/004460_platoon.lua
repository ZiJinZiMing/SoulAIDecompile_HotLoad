﻿function Platoon004460_Initialize(f1_arg0)
    f1_arg0:SetEnablePlatoonMove(true)
    f1_arg0:SetFormationType(0, 2)
    f1_arg0:SetFormationParam(0, 0, 0)
    f1_arg0:SetFormationParam(1, 0, -2.5)
    f1_arg0:SetFormationParam(2, -5, -1)
    f1_arg0:SetFormationParam(3, 5, -1)
    f1_arg0:SetFormationParam(4, -5, -8)
    f1_arg0:SetFormationParam(5, 5, -8)
    f1_arg0:SetFormationParam(6, 0, -11)
    f1_arg0:SetBaseMoveRate(0, 1.5)
    
end

function Platoon004460_Activate(f2_arg0)
    
end

function Platoon004460_Deactivate(f3_arg0)
    
end

function Platoon004460_Update(f4_arg0)
    Platoon_Common_Act(f4_arg0, 1)
    
end


