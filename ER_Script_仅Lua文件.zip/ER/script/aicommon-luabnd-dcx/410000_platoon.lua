﻿function Platoon410000_Initialize(f1_arg0)
    f1_arg0:SetEnablePlatoonMove(false)
    
end

function Platoon410000_Activate(f2_arg0)
    
end

function Platoon410000_Deactivate(f3_arg0)
    
end

function Platoon410000_Update(f4_arg0)
    local f4_local0 = 100
    local f4_local1 = 101
    local f4_local2 = 0
    for f4_local3 = f4_arg0:GetMemberNum() - 1, 0, -1 do
        local f4_local6 = f4_arg0:GetMemberAI(f4_local3)
        if f4_local6 ~= nill and f4_local6:GetHpRate(TARGET_SELF) <= 0 then
            f4_local2 = f4_local2 + 1
        end
    end
    local f4_local3 = f4_arg0:GetMemberNum() / 2
    if math.floor(f4_arg0:GetMemberNum() / 2) <= f4_local2 then
        f4_arg0:SendCommandAll(f4_local1)
    else
        f4_arg0:SendCommandAll(f4_local0)
    end
    

end


