﻿function Platoon000500_Initialize(f1_arg0)
    f1_arg0:SetEnablePlatoonMove(true)
    f1_arg0:SetFormationType(0, 2)
    f1_arg0:SetFormationParam(0, 0, 0)
    local f1_local0 = 0
    for f1_local1 = 1, f1_arg0:GetMemberNum() - 1, 1 do
        f1_local0 = f1_local1
        f1_arg0:SetFormationParam(f1_local1, 0, -(f1_local0 * 3))
    end
    f1_arg0:SetBaseMoveRate(0, 1.5)
    for f1_local1 = 1, f1_arg0:GetMemberNum() - 1, 1 do
        f1_arg0:SetBaseMoveRate(f1_local1, 1)
    end
    if f1_arg0:GetMemberNum() > 7 then
        for f1_local1 = f1_arg0:GetMemberNum() - 2, f1_arg0:GetMemberNum() - 1, 1 do
            f1_arg0:SetBaseMoveRate(f1_local1, 3)
        end
    end
    


end

function Platoon000500_Activate(f2_arg0)
    
end

function Platoon000500_Deactivate(f3_arg0)
    
end

function Platoon000500_Update(f4_arg0)
    local f4_local0 = f4_arg0:GetMemberAI(0)
    local f4_local1 = f4_local0:GetEventRequest()
    if f4_local1 == 4599 then
        for f4_local2 = 0, f4_arg0:GetMemberNum() - 1, 1 do
            f4_arg0:SetBaseMoveRate(f4_local2, 5)
        end
    end
    Platoon_Common_Act(f4_arg0, 1)
    
end


