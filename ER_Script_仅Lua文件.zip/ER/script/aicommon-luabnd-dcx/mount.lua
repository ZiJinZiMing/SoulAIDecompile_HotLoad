﻿REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_Mount, 0, "到達判定距離", 0)
REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_Mount, 1, "乗れなかった場合のクールタイム秒数", 0)
REGISTER_GOAL_NO_SUB_GOAL(GOAL_COMMON_Mount, true)
REGISTER_GOAL_UPDATE_TIME(GOAL_COMMON_Mount, 0, 0)
local f0_local0 = 90000

function _GetRequestId_forMount(f1_arg0, f1_arg1)
    local f1_local0 = f1_arg0
    if f1_arg1:IsNpcPlayer() == true and f1_arg0 == f0_local0 then
        f1_local0 = NPC_ATK_RideMount
    end
    return f1_local0
    
end

function _GetCoolTime_forMount(f2_arg0, f2_arg1)
    local f2_local0 = 300
    if f2_arg1:GetParam(1) ~= nil and f2_arg1:GetParam(1) > 0 then
        f2_local0 = f2_arg1:GetParam(1)
    end
    return f2_local0
    
end

function Mount_Activate(f3_arg0, f3_arg1)
    if f3_arg0:IsRiding(TARGET_SELF) then
        f3_arg1:SetNumber(0, -1)
        return
    end
    local f3_local0 = f3_arg0:IsSearchTarget(TARGET_RIDE_0)
    if f3_local0 == false and f3_arg0:ReserveRide(10) == true then
        f3_local0 = f3_arg0:IsSearchTarget(TARGET_RIDE_0)
    end
    if f3_local0 == true then
        local f3_local1 = f3_arg1:GetLife()
        local f3_local2 = TARGET_RIDE_0
        local f3_local3 = f3_arg1:GetParam(0)
        local f3_local4 = TARGET_SELF
        local f3_local5 = 0
        local f3_local6 = AI_DIR_TYPE_CENTER
        if f3_arg0:HasSpecialEffectId(f3_local2, 5210) then
            f3_local5 = 2
            f3_local6 = AI_DIR_TYPE_B
            f3_local3 = 0.5
        elseif f3_arg0:HasSpecialEffectId(f3_local2, 5211) then
            f3_local5 = 1.5
            f3_local6 = AI_DIR_TYPE_B
            f3_local3 = 0.5
        elseif f3_arg0:HasSpecialEffectId(f3_local2, 5212) then
            f3_local5 = 3
            f3_local6 = AI_DIR_TYPE_B
            f3_local3 = 0.5
        elseif f3_arg0:HasSpecialEffectId(f3_local2, 5213) then
            f3_local5 = 1
            f3_local6 = AI_DIR_TYPE_B
            f3_local3 = 0.5
        end
        if f3_arg0:HasSpecialEffectId(TARGET_SELF, 5225) then
            f3_local5 = 1.5
            f3_local6 = AI_DIR_TYPE_B
            f3_local3 = 0.5
        elseif f3_arg0:HasSpecialEffectId(TARGET_SELF, 5226) then
            f3_local5 = 1.5
            f3_local6 = AI_DIR_TYPE_R
            f3_local3 = 0.5
        elseif f3_arg0:HasSpecialEffectId(TARGET_SELF, 5227) then
            f3_local5 = 1.5
            f3_local6 = AI_DIR_TYPE_L
            f3_local3 = 0.5
        end
        local f3_local7 = f3_arg0:GetExistMeshOnLineDistEx(f3_local2, f3_local6, f3_local5, 1, 0)
        if f3_local7 < f3_local5 then
            f3_arg0:SetTimer(13, _GetCoolTime_forMount(f3_arg0, f3_arg1))
            f3_arg1:SetNumber(0, -1)
        else
            f3_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f3_local1, f3_local2, f3_local3, f3_local4, false, -1, f3_local6, f3_local5)
            f3_arg1:AddSubGoal(GOAL_COMMON_MountSub, 4)
            f3_arg1:SetNumber(0, 0)
        end
    else
        f3_arg1:SetNumber(0, -1)
    end
    
end

function Mount_Update(f4_arg0, f4_arg1)
    local f4_local0 = f4_arg1:GetNumber(0)
    if f4_arg1:GetLife() <= 0 and f4_arg0:IsRiding(TARGET_SELF) == false then
        f4_arg0:SetTimer(13, _GetCoolTime_forMount(f4_arg0, f4_arg1))
        return GOAL_RESULT_Failed
    end
    if f4_local0 == 0 then
        if f4_arg1:GetSubGoalNum() <= 0 then
            local f4_local1 = f4_arg1:GetLastSubGoalResult()
            if f4_local1 == GOAL_RESULT_Success then
                return GOAL_RESULT_Success
            else
                return GOAL_RESULT_Failed
            end
        end
    else
        return GOAL_RESULT_Failed
    end
    return GOAL_RESULT_Continue
    
end

function Mount_Terminate(f5_arg0, f5_arg1)
    
end

function Mount_Interupt(f6_arg0, f6_arg1)
    if f6_arg0:IsInterupt(INTERUPT_MovedEnd_OnFailedPath) then
        f6_arg1:ClearSubGoal()
        f6_arg0:SetTimer(13, _GetCoolTime_forMount(f6_arg0, f6_arg1))
        return true
    end
    return false
    
end

REGISTER_GOAL_NO_SUB_GOAL(GOAL_COMMON_MountSub, true)
REGISTER_GOAL_UPDATE_TIME(GOAL_COMMON_MountSub, 0, 0)

function MountSub_Activate(f7_arg0, f7_arg1)
    local f7_local0 = f7_arg1:GetLife()
    f7_arg0:ClearMoveRequest()
    f7_arg0:TurnTo(TARGET_RIDE_0)
    f7_arg0:SetAttackRequest(_GetRequestId_forMount(f0_local0, f7_arg0))
    
end

function MountSub_Update(f8_arg0, f8_arg1)
    if f8_arg1:GetLife() <= 0 and f8_arg0:IsRiding(TARGET_SELF) == false then
        f8_arg0:SetTimer(13, _GetCoolTime_forMount(f8_arg0, f8_arg1))
        return GOAL_RESULT_Failed
    end
    if f8_arg0:IsEnableComboAttack() then
        return GOAL_RESULT_Success
    elseif f8_arg0:IsEnableCancelMove() then
        return GOAL_RESULT_Success
    elseif f8_arg0:IsEnableCancelAttack() then
        return GOAL_RESULT_Success
    elseif f8_arg0:IsFinishAttack_CheckAttackNo(_GetRequestId_forMount(f0_local0, f8_arg0)) then
        return GOAL_RESULT_Success
    end
    if f8_arg0:IsStartAttack_CheckAttackNo(_GetRequestId_forMount(f0_local0, f8_arg0)) == false then
        f8_arg0:SetAttackRequest(_GetRequestId_forMount(f0_local0, f8_arg0))
    end
    return GOAL_RESULT_Continue
    
end

function MountSub_Terminate(f9_arg0, f9_arg1)
    
end

function MountSub_Interupt(f10_arg0, f10_arg1)
    return false
    
end


