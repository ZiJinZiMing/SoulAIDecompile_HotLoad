﻿function Platoon003661_Initialize(f1_arg0)
    f1_arg0:SetEnablePlatoonMove(true)
    f1_arg0:SetFormationType(0, 2)
    f1_arg0:SetFormationParam(1, 1, -3)
    f1_arg0:SetFormationParam(2, -2, -4)
    f1_arg0:SetFormationParam(3, 5, -5)
    f1_arg0:SetFormationParam(4, -1, -6)
    f1_arg0:SetFormationParam(5, 1, -6)
    f1_arg0:SetFormationParam(6, -2, -7)
    f1_arg0:SetFormationParam(7, 3, -8)
    f1_arg0:SetFormationParam(8, 1, -8)
    f1_arg0:SetFormationParam(9, -1, -9)
    f1_arg0:SetFormationParam(10, -5, -10)
    f1_arg0:SetFormationParam(11, 0, -10)
    f1_arg0:SetFormationParam(12, 1, -12)
    f1_arg0:SetFormationParam(13, -2, -13)
    f1_arg0:SetFormationParam(14, 5, -14)
    f1_arg0:SetFormationParam(15, -1, -15)
    f1_arg0:SetFormationParam(16, 1, -16)
    f1_arg0:SetFormationParam(17, -2, -18)
    f1_arg0:SetFormationParam(18, 2, -19)
    f1_arg0:SetFormationParam(19, 1, -20)
    f1_arg0:SetFormationParam(20, -5, -22)
    f1_arg0:SetBaseMoveRate(0, 1.5)
    
end

function Platoon003661_Activate(f2_arg0)
    
end

function Platoon003661_Deactivate(f3_arg0)
    
end

function Platoon003661_Update(f4_arg0)
    Platoon_Common_Act(f4_arg0, 1)
    
end


