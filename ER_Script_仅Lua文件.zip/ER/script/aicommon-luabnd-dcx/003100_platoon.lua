﻿function Platoon003100_Initialize(f1_arg0)
    f1_arg0:SetEnablePlatoonMove(true)
    f1_arg0:SetFormationType(0, 2)
    f1_arg0:SetFormationParam(0, 0, 0)
    f1_arg0:SetFormationParam(1, 0, -1)
    f1_arg0:SetFormationParam(2, 0, -3)
    f1_arg0:SetFormationParam(3, 0, -5)
    f1_arg0:SetFormationParam(4, 0, -7)
    f1_arg0:SetFormationParam(5, 0, -9)
    f1_arg0:SetFormationParam(6, 0, -11)
    f1_arg0:SetFormationParam(7, 0, -13)
    f1_arg0:SetFormationParam(8, 0, -15)
    f1_arg0:SetFormationParam(9, 0, -17)
    f1_arg0:SetFormationParam(10, 0, -19)
    f1_arg0:SetFormationParam(11, 0, -21)
    f1_arg0:SetFormationParam(12, 0, -23)
    f1_arg0:SetFormationParam(13, 0, -25)
    f1_arg0:SetFormationParam(14, 0, -27)
    f1_arg0:SetFormationParam(15, 0, -29)
    f1_arg0:SetFormationParam(16, 0, -31)
    f1_arg0:SetFormationParam(17, 0, -33)
    f1_arg0:SetFormationParam(18, 0, -35)
    f1_arg0:SetFormationParam(19, 0, -37)
    f1_arg0:SetBaseMoveRate(0, 1.5)
    
end

function Platoon003100_Activate(f2_arg0)
    
end

function Platoon003100_Deactivate(f3_arg0)
    
end

function Platoon003100_Update(f4_arg0)
    Platoon_Common_Act(f4_arg0, 1)
    
end


