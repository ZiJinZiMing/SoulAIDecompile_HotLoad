﻿function Wyvern450010_Logic(f1_arg0)
    COMMON_Initialize(f1_arg0)
    local f1_local0 = GetCurrentTimeType(f1_arg0)
    if f1_arg0:IsChangeState() and f1_arg0:GetCurrTargetState() == AI_TARGET_STATE__NONE then
        f1_arg0:GetStringIndexedNumber("Wyvern450010_FistActDone")
    end
    if not f1_arg0:IsUseFlyRoute() and f1_arg0:IsChangeState() then
        local f1_local1 = f1_arg0:GetPrevTargetState()
        if f1_arg0:IsBattleState() then
            f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, 3022, TARGET_ENE_0, DIST_NONE, 0, 90)
        elseif f1_arg0:IsSearchLowState() and f1_local1 == AI_TARGET_STATE__NONE then
            f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, 3024, TARGET_SEARCH, DIST_NONE, 0, 90)
        elseif f1_arg0:IsCautionState() and f1_local1 == AI_TARGET_STATE__NONE then
            if f1_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_L, 180) then
                f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, 3028, TARGET_ENE_0, DIST_None, 0, 90)
            elseif f1_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_R, 180) then
                f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, 3029, TARGET_ENE_0, DIST_None, 0, 90)
            end
        elseif (f1_local1 == AI_TARGET_STATE__SEARCH or f1_local1 == AI_TARGET_STATE__SEARCH2) and f1_arg0:IsSearchLowState() == false and f1_arg0:IsSearchHighState() == false and f1_arg0:IsCautionState() == false and f1_arg0:IsBattleState() == false then
            f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, 3023, TARGET_ENE_0, DIST_NONE, 0, 90)
        end
    end
    if f1_arg0:IsBattleState() then
        f1_arg0:AddTopGoal(f1_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__battleGoalID), -1)
    elseif f1_arg0:IsSearchLowState() then
        f1_arg0:AddTopGoal(GOAL_COMMON_Stay, 1, 0, TARGET_ENE_0)
    elseif f1_arg0:IsCautionState() then
        f1_arg0:AddTopGoal(GOAL_COMMON_Stay, 1, 0, TARGET_ENE_0)
    elseif f1_arg0:GetStringIndexedNumber("Wyvern450010_FistActDone") ~= 1 then
        f1_arg0:AddTopGoal(GOAL_COMMON_WaitWithAnime, -1, 3021, TARGET_SELF)
        f1_arg0:SetStringIndexedNumber("Wyvern450010_FistActDone", 1)
    else
        local f1_local1 = 2
        local f1_local2 = 10
        local f1_local3 = true
        local f1_local4 = 3020
        local f1_local5 = 18
        local f1_local6 = -1
        local f1_local7 = false
        local f1_local8 = true
        f1_arg0:AddTopGoal(GOAL_COMMON_WalkAround_Anywhere, -1, f1_local1, f1_local2, f1_local3, f1_local4, f1_local5, f1_local6, f1_local7, f1_local8)
    end
    
end

function Wyvern450010_Interupt(f2_arg0, f2_arg1)
    return false
    
end


