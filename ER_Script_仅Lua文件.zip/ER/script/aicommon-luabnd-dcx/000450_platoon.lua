﻿function Platoon000450_Initialize(f1_arg0)
    f1_arg0:SetEnablePlatoonMove(true)
    f1_arg0:SetFormationType(0, 2)
    f1_arg0:SetFormationParam(0, 0, 0)
    f1_arg0:SetFormationParam(1, -2, -2)
    f1_arg0:SetFormationParam(2, 2, -2)
    f1_arg0:SetFormationParam(3, 0, -5.5)
    f1_arg0:SetFormationParam(4, -2.5, -9.5)
    f1_arg0:SetFormationParam(5, 2.5, -9.5)
    f1_arg0:SetBaseMoveRate(0, 1.5)
    
end

function Platoon000450_Activate(f2_arg0)
    
end

function Platoon000450_Deactivate(f3_arg0)
    
end

function Platoon000450_Update(f4_arg0)
    Platoon_Common_Act(f4_arg0, 1)
    
end


