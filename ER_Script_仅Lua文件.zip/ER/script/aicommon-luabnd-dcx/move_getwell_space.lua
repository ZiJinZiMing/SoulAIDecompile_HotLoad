﻿RegisterTableGoal(GOAL_COMMON_MoveGetwellSpace, "MoveGetwellSpace")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_COMMON_MoveGetwellSpace, true)
REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_MoveGetwellSpace, 0, "後退優先度", 0)
REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_MoveGetwellSpace, 1, "左移動優先度", 0)
REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_MoveGetwellSpace, 2, "右移動優先度", 0)
REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_MoveGetwellSpace, 3, "旋回対象", 0)
REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_MoveGetwellSpace, 4, "安全チェック距離", 0)
REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_MoveGetwellSpace, 5, "移動不可時成功とみなすか", 0)

Goal.Activate = function (f1_arg0, f1_arg1, f1_arg2)
    local f1_local0 = {}
    local f1_local1 = {}
    local f1_local2 = {AI_DIR_TYPE_B, AI_DIR_TYPE_L, AI_DIR_TYPE_R}
    local f1_local3 = {180, -90, 90}
    local f1_local4 = f1_arg2:GetParam(3)
    local f1_local5 = f1_arg2:GetParam(4)
    local f1_local6 = f1_arg2:GetParam(5)
    local f1_local7 = f1_arg2:GetParam(6)
    for f1_local8 = 0, 2, 1 do
        if f1_arg2:GetParam(f1_local8) >= 0 then
            local f1_local11 = table.getn(f1_local0) + 1
            for f1_local12 = 1, f1_local11 - 1, 1 do
                if f1_local0[f1_local12] < f1_arg2:GetParam(f1_local8) then
                    f1_local11 = f1_local12
                    break
                end
            end
            table.insert(f1_local0, f1_local11, f1_arg2:GetParam(f1_local8))
            table.insert(f1_local1, f1_local11, f1_local8 + 1)

        end
    end
    for f1_local8 = 1, 2, 1 do
        for f1_local11 = 1, table.getn(f1_local0), 1 do
            local f1_local14 = f1_local2[f1_local1[f1_local11]]
            if f1_arg1:IsExistMeshOnLine(TARGET_SELF, f1_local14, f1_local5) and (not f1_arg1:IsExistChrOnLineSpecifyAngle(TARGET_SELF, f1_local3[f1_local1[f1_local11]], f1_local5, AI_SPA_DIR_TYPE_TargetF) or f1_local8 == 2) then
                if f1_local14 == AI_DIR_TYPE_B then
                    f1_arg2:AddSubGoal(GOAL_COMMON_LeaveTarget, f1_arg2:GetLife(), TARGET_ENE_0, f1_local6, TARGET_ENE_0, true, -1)
                elseif f1_local14 == AI_DIR_TYPE_L then
                    f1_arg2:AddSubGoal(GOAL_COMMON_SidewayMove, f1_arg2:GetLife(), TARGET_ENE_0, 0, f1_arg1:GetRandam_Int(30, 45), true, true, -1)
                elseif f1_local14 == AI_DIR_TYPE_R then
                    f1_arg2:AddSubGoal(GOAL_COMMON_SidewayMove, f1_arg2:GetLife(), TARGET_ENE_0, 1, f1_arg1:GetRandam_Int(30, 45), true, true, -1)
                end
                return
            end
        end
    end
    


end

Goal.Update = function (f2_arg0, f2_arg1, f2_arg2)
    if f2_arg2:GetSubGoalNum() <= 0 then
        if f2_arg2:GetParam(5) then
            return GOAL_RESULT_Success
        else
            return GOAL_RESULT_Failed
        end
    end
    return GOAL_RESULT_Continue
    
end


