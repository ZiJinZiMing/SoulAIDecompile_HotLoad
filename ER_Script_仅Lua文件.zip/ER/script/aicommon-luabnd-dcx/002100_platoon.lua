﻿function Platoon002100_Initialize(f1_arg0)
    f1_arg0:SetEnablePlatoonMove(false)
    
end

function Platoon002100_Activate(f2_arg0)
    
end

function Platoon002100_Deactivate(f3_arg0)
    
end

function Platoon002100_Update(f4_arg0)
    
end


