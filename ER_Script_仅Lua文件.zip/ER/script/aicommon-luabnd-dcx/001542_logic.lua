﻿function AutoTest1542_Logic(f1_arg0)
    f1_arg0:StartDash()
    f1_arg0:AddTopGoal(GOAL_COMMON_MoveToSomewhere, 5, POINT_AutoWalkAroundTest, AI_DIR_TYPE_CENTER, 1, TARGET_SELF, true)
    
end

function AutoTest1542_Interupt(f2_arg0, f2_arg1)
    if f2_arg0:DbgAutoRemo_IsWaitCommand() then
        f2_arg1:ClearSubGoal()
        local f2_local0 = f2_arg0:DbgAutoRemo_GetWaitCommandTime()
        f2_arg0:AddTopGoal(GOAL_COMMON_Wait, f2_local0, TARGET_NONE, 0, 0, 0)
        f2_arg0:DbgAutoRemo_ResetWaitCommand()
        return true
    end
    return false
    
end


