﻿function Platoon000110_Initialize(f1_arg0)
    f1_arg0:SetEnablePlatoonMove(false)
    f1_arg0:SetFormationType(0, 2)
    f1_arg0:SetFormationParam(0, 0, 0)
    f1_arg0:SetFormationParam(1, 0, 0)
    f1_arg0:SetFormationParam(2, 2, -2)
    f1_arg0:SetFormationParam(3, -2, -3)
    f1_arg0:SetFormationParam(4, 1, -5)
    f1_arg0:SetFormationParam(5, -1, -6)
    f1_arg0:SetBaseMoveRate(0, 1.5)
    
end

function Platoon000110_Activate(f2_arg0)
    
end

function Platoon000110_Deactivate(f3_arg0)
    
end

function Platoon000110_Update(f4_arg0)
    
end


