﻿REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_ApproachAround, 0, "移動対象", 0)
REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_ApproachAround, 1, "到達判定距離", 0)
REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_ApproachAround, 2, "旋回対象", 0)
REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_ApproachAround, 3, "歩く?", 0)
REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_ApproachAround, 4, "ガードEzState番号", 0)
REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_ApproachAround, 5, "移動方向", 0)
REGISTER_DBG_GOAL_PARAM(GOAL_COMMON_ApproachAround, 6, "指定方向への距離", 0)
REGISTER_GOAL_NO_INTERUPT(GOAL_COMMON_ApproachAround, true)
REGISTER_GOAL_NO_SUB_GOAL(GOAL_COMMON_ApproachAround, true)

function ApproachAround_Activate(f1_arg0, f1_arg1)
    local f1_local0 = f1_arg1:GetLife()
    local f1_local1 = f1_arg1:GetParam(0)
    local f1_local2 = f1_arg1:GetParam(1)
    local f1_local3 = f1_arg1:GetParam(2)
    local f1_local4 = f1_arg1:GetParam(3)
    local f1_local5 = f1_arg1:GetParam(4)
    local f1_local6 = f1_arg1:GetParam(5)
    local f1_local7 = f1_arg1:GetParam(6)
    local f1_local8 = nil
    local f1_local9 = false
    local f1_local10 = true
    f1_arg1:AddSubGoal(GOAL_COMMON_MoveToSomewhere, -1, f1_local1, f1_local6, f1_local2, f1_local3, f1_local4, f1_local7, f1_local8, f1_local9, f1_local10)
    if f1_local5 > 0 then
        local f1_local11 = f1_arg0:GetDist(f1_local1)
        if f1_local2 < f1_local11 then
            f1_arg0:DoEzAction(f1_local0, f1_local5)
        end
    end
    
end

function ApproachAround_Update(f2_arg0, f2_arg1, f2_arg2)
    if f2_arg1:GetSubGoalNum() <= 0 then
        return GOAL_RESULT_Success
    end
    return GOAL_RESULT_Continue
    
end

function ApproachAround_Terminate(f3_arg0, f3_arg1)
    
end

function ApproachAround_Interupt(f4_arg0, f4_arg1)
    return false
    
end


