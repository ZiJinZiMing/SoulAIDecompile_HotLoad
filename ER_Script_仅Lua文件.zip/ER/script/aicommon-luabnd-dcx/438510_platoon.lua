﻿function Platoon000100_Initialize(f1_arg0)
    f1_arg0:SetEnablePlatoonMove(true)
    f1_arg0:SetFormationType(0, 2)
    f1_arg0:SetFormationType(0, 2)
    f1_arg0:SetFormationParam(0, 0, 0)
    f1_arg0:SetFormationParam(1, 0, 0)
    f1_arg0:SetFormationParam(2, 0.5, -1)
    f1_arg0:SetFormationParam(3, -0.5, -2)
    f1_arg0:SetBaseMoveRate(0, 1.5)
    f1_arg0:SetBaseMoveRate(1, 1)
    f1_arg0:SetBaseMoveRate(2, 0.7)
    f1_arg0:SetBaseMoveRate(3, 0.7)
    
end

function Platoon000100_Activate(f2_arg0)
    
end

function Platoon000100_Deactivate(f3_arg0)
    
end

function Platoon000100_Update(f4_arg0)
    Platoon_Common_Act(f4_arg0, 1)
    
end


