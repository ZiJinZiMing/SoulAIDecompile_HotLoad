﻿function Platoon002000_Initialize(f1_arg0)
    f1_arg0:SetEnablePlatoonMove(false)
    f1_arg0:SetTimer(0, 2)
    
end

function Platoon002000_Activate(f2_arg0)
    
end

function Platoon002000_Deactivate(f3_arg0)
    
end

function Platoon002000_Update(f4_arg0)
    f4_arg0:SetEnablePlatoonMove(false)
    if f4_arg0:GetTeamDefeatEntityId() > 0 and f4_arg0:IsExistTargetTeamDefeat() == false then
        f4_arg0:SendCommandAll(PLAN_PLATOON_COMMAND__BUDDY_RETURN)
    else
        f4_arg0:SendCommandAll(PLAN_PLATOON_COMMAND__BUDDY_BATTLE)
    end
    
end


