﻿function common14500_Logic(f1_arg0)
    COMMON_Initialize(f1_arg0)
    if not f1_arg0:IsUseFlyRoute() and f1_arg0:IsChangeState() then
        local f1_local0 = f1_arg0:GetPrevTargetState()
        if f1_arg0:IsBattleState() then
            f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, 3022, TARGET_ENE_0, DIST_NONE, 0, 90)
        elseif f1_arg0:IsSearchLowState() and f1_local0 == AI_TARGET_STATE__NONE then
            f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, 3024, TARGET_SEARCH, DIST_NONE, 0, 90)
        elseif f1_arg0:IsSearchHighState() and f1_local0 == AI_TARGET_STATE__SEARCH then
            f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 4, 3025, TARGET_SEARCH, DIST_NONE, 0, 90)
            f1_arg0:SetTimer(2, 6)
        elseif f1_arg0:IsCautionState() and f1_local0 == AI_TARGET_STATE__NONE then
            if f1_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_L, 180) then
                f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, 3028, TARGET_ENE_0, DIST_None, 0, 90)
            elseif f1_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_R, 180) then
                f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, 3029, TARGET_ENE_0, DIST_None, 0, 90)
            end
        elseif (f1_local0 == AI_TARGET_STATE__SEARCH or f1_local0 == AI_TARGET_STATE__SEARCH2) and f1_arg0:IsSearchLowState() == false and f1_arg0:IsSearchHighState() == false and f1_arg0:IsCautionState() == false and f1_arg0:IsBattleState() == false then
            f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, 3023, TARGET_ENE_0, DIST_NONE, 0, 90)
        end
    end
    if not f1_arg0:IsUseFlyRoute() then
        if f1_arg0:IsBattleState() then
            f1_arg0:AddTopGoal(f1_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__battleGoalID), -1)
            f1_arg0:SetNumber(5, 0)
        elseif f1_arg0:IsSearchLowState() then
            f1_arg0:AddTopGoal(GOAL_COMMON_Stay, 1, 0, TARGET_ENE_0)
            f1_arg0:SetNumber(5, 0)
        elseif f1_arg0:IsSearchHighState() then
            if f1_arg0:IsFinishTimer(2) and f1_arg0:GetRandam_Int(1, 100) < 20 and f1_arg0:GetAttackPassedTime(3027) >= 20 then
                f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 9, 3027, TARGET_SEARCH, DIST_NONE, 0, -1)
            else
                f1_arg0:AddTopGoal(GOAL_COMMON_MoveToSomewhere, 1, TARGET_SEARCH, AI_DIR_TYPE_CENTER, 1, TARGET_SELF, true)
            end
            f1_arg0:SetNumber(5, 0)
        elseif f1_arg0:IsCautionState() then
            f1_arg0:AddTopGoal(GOAL_COMMON_Stay, 1, 0, TARGET_ENE_0)
            f1_arg0:SetNumber(5, 0)
        elseif f1_arg0:GetNumber(5) == 0 and f1_arg0:GetAttackPassedTime(3023) >= 12 then
            f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, 3021, TARGET_ENE_0, DIST_NONE, 0, 90)
            f1_arg0:SetNumber(5, 1)
            f1_arg0:SetTimer(1, 10)
        elseif f1_arg0:IsFinishTimer(1) then
            f1_arg0:AddTopGoal(GOAL_COMMON_WalkAround_Anywhere, -1)
        else
            f1_arg0:AddTopGoal(GOAL_COMMON_Stay, 1, 0, TARGET_ENE_0)
        end
    end
    
end

function common14500_Interupt(f2_arg0, f2_arg1)
    
end


