﻿function Platoon000720_Initialize(f1_arg0)
    f1_arg0:SetEnablePlatoonMove(true)
    f1_arg0:SetFormationType(0, 2)
    f1_arg0:SetFormationParam(0, 0, 0)
    f1_arg0:SetFormationParam(1, -2.5, -7)
    f1_arg0:SetFormationParam(2, 2.5, -8.5)
    f1_arg0:SetFormationParam(3, 1, -17)
    f1_arg0:SetFormationParam(4, -4, -21)
    f1_arg0:SetFormationParam(5, 4, -22)
    f1_arg0:SetFormationParam(6, -1, -25)
    f1_arg0:SetFormationParam(7, 1, -27)
    f1_arg0:SetBaseMoveRate(0, 40)
    f1_arg0:SetBaseMoveRate(1, 0.7)
    f1_arg0:SetBaseMoveRate(2, 0.7)
    f1_arg0:SetBaseMoveRate(3, 1.5)
    f1_arg0:SetBaseMoveRate(4, 1.5)
    f1_arg0:SetBaseMoveRate(5, 1.5)
    f1_arg0:SetBaseMoveRate(6, 1.5)
    f1_arg0:SetBaseMoveRate(7, 1.5)
    
end

function Platoon000720_Activate(f2_arg0)
    
end

function Platoon000720_Deactivate(f3_arg0)
    
end

function Platoon000720_Update(f4_arg0)
    Platoon_Common_Act(f4_arg0, 0)
    
end


