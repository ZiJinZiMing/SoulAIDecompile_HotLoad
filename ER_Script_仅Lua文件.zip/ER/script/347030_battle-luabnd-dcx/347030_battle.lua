﻿RegisterTableGoal(GOAL_FrogHuman_347030_Battle, "GOAL_FrogHuman_347030_Battle")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_FrogHuman_347030_Battle, true)

Goal.Initialize = function (f1_arg0, f1_arg1, f1_arg2, f1_arg3)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3000)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3001)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3002)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3005)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3006)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3007)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3008)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3009)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3011)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3012)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3013)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3014)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3015)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3016)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3017)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3018)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3023)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3024)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3025)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3026)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3027)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3028)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3029)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3030)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3031)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3032)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3033)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3034)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3035)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3036)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3037)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3038)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3039)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3000)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3001)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3002)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3005)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3016)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3010)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3011)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3012)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3020)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3021)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3022)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3024)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3025)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3026)
    
end

Goal.Activate = function (f2_arg0, f2_arg1, f2_arg2)
    Init_Pseudo_Global(f2_arg1, f2_arg2)
    local f2_local0 = {}
    local f2_local1 = {}
    local f2_local2 = {}
    Common_Clear_Param(f2_local0, f2_local1, f2_local2)
    local f2_local3 = f2_arg1:GetDist(TARGET_ENE_0)
    local f2_local4 = f2_arg1:GetRandam_Int(1, 100)
    local f2_local5 = f2_arg1:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__thinkAttr_doAdmirer)
    if f2_local5 == 1 and f2_arg1:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Kankyaku then
        if f2_arg1:HasSpecialEffectId(TARGET_SELF, 15610) then
            f2_local0[3] = 100
        elseif f2_local3 >= 4 then
            f2_local0[15] = 20
            f2_local0[30] = 60
            f2_local0[17] = 50
        else
            f2_local0[15] = 20
            f2_local0[30] = 80
        end
    elseif f2_local5 == 1 and f2_arg1:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Torimaki then
        local f2_local6 = 0
        if f2_arg1:HasSpecialEffectId(TARGET_SELF, 15608) then
            f2_local6 = 1
        end
        local f2_local7 = 0
        if f2_arg1:HasSpecialEffectId(TARGET_SELF, 15609) then
            f2_local7 = 1
        end
        if f2_arg1:HasSpecialEffectId(TARGET_SELF, 15610) then
            f2_local0[3] = 100
        elseif f2_local3 >= 4 then
            f2_local0[3] = 1
            f2_local0[30] = 69
            f2_local0[15] = 10
            f2_local0[17] = 50
            f2_local0[19] = 20 * f2_local6
            f2_local0[20] = 20 * f2_local7
        else
            f2_local0[3] = 1
            f2_local0[30] = 89
            f2_local0[15] = 10
        end
    else
        local f2_local6 = 0
        if f2_arg1:HasSpecialEffectId(TARGET_SELF, 15608) then
            f2_local6 = 1
        end
        local f2_local7 = 0
        if f2_arg1:HasSpecialEffectId(TARGET_SELF, 15609) then
            f2_local7 = 1
        end
        if f2_local3 >= 5 then
            if f2_arg1:HasSpecialEffectId(TARGET_SELF, 15610) then
                f2_local0[3] = 100
            else
                f2_local0[17] = 100
            end
        elseif f2_local3 >= 3 then
            f2_local0[1] = 45
            f2_local0[2] = 25
            f2_local0[3] = 10
            f2_local0[17] = 20
            f2_local0[18] = 0 * f2_local6
            f2_local0[19] = 20 * f2_local6
            f2_local0[20] = 60 * f2_local7
        else
            f2_local0[1] = 35
            f2_local0[2] = 65
        end
    end
    f2_local0[1] = SetCoolTime(f2_arg1, f2_arg2, 3033, 3, f2_local0[1], 1)
    f2_local0[2] = SetCoolTime(f2_arg1, f2_arg2, 3016, 3, f2_local0[2], 0)
    if f2_arg1:HasSpecialEffectId(TARGET_SELF, 15610) then
        f2_local0[3] = SetCoolTime(f2_arg1, f2_arg2, 3020, 0, f2_local0[3], 0)
    else
        f2_local0[3] = SetCoolTime(f2_arg1, f2_arg2, 3020, 20, f2_local0[3], 0)
    end
    if f2_arg1:GetTimer(0) > 0 then
        f2_local0[15] = 0
    end
    f2_local0[18] = SetCoolTime(f2_arg1, f2_arg2, 20011, 15, f2_local0[18], 0)
    f2_local0[19] = SetCoolTime(f2_arg1, f2_arg2, 20012, 15, f2_local0[19], 0)
    f2_local0[20] = SetCoolTime(f2_arg1, f2_arg2, 20013, 10, f2_local0[20], 0)
    f2_local1[1] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347030_Act01)
    f2_local1[2] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347030_Act02)
    f2_local1[3] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347030_Act03)
    f2_local1[15] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347030_Act15)
    f2_local1[16] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347030_Act16)
    f2_local1[17] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347030_Act17)
    f2_local1[18] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347030_Act18)
    f2_local1[19] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347030_Act19)
    f2_local1[20] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347030_Act20)
    f2_local1[30] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347030_Act30)
    f2_local1[31] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347030_Act31)
    local f2_local6 = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347030_ActAfter_AdjustSpace)
    Common_Battle_Activate(f2_arg1, f2_arg2, f2_local0, f2_local1, f2_local6, f2_local2)
    
end

function FrogHuman_347030_Act01(f3_arg0, f3_arg1, f3_arg2)
    local f3_local0 = 2.5 - f3_arg0:GetMapHitRadius(TARGET_SELF)
    local f3_local1 = 0
    local f3_local2 = 999
    local f3_local3 = 100
    local f3_local4 = 0
    local f3_local5 = 4
    local f3_local6 = 8
    Approach_Act_Flex(f3_arg0, f3_arg1, f3_local0, f3_local1, f3_local2, f3_local3, f3_local4, f3_local5, f3_local6)
    local f3_local7 = 3033
    local f3_local8 = 3034
    local f3_local9 = 3035
    local f3_local10 = 2
    local f3_local11 = 3
    local f3_local12 = 5 - f3_arg0:GetMapHitRadius(TARGET_SELF)
    local f3_local13 = 0
    local f3_local14 = 0
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f3_local7, TARGET_ENE_0, f3_local10, 0, 0, 0, 0)
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, f3_local8, TARGET_ENE_0, f3_local11, 0, 0, 0, 0)
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 10, f3_local9, TARGET_ENE_0, f3_local12, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347030_Act02(f4_arg0, f4_arg1, f4_arg2)
    local f4_local0 = 3 - f4_arg0:GetMapHitRadius(TARGET_SELF)
    local f4_local1 = 0
    local f4_local2 = 999
    local f4_local3 = 100
    local f4_local4 = 0
    local f4_local5 = 4
    local f4_local6 = 8
    Approach_Act_Flex(f4_arg0, f4_arg1, f4_local0, f4_local1, f4_local2, f4_local3, f4_local4, f4_local5, f4_local6)
    local f4_local7 = 3016
    local f4_local8 = 4.4
    local f4_local9 = 0
    local f4_local10 = 0
    f4_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 2, f4_local7, TARGET_ENE_0, f4_local8, f4_local9, f4_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347030_Act03(f5_arg0, f5_arg1, f5_arg2)
    local f5_local0 = 3020
    local f5_local1 = 5 - f5_arg0:GetMapHitRadius(TARGET_SELF)
    local f5_local2 = 0
    local f5_local3 = 0
    f5_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f5_local0, TARGET_ENE_0, f5_local1, f5_local2, f5_local3, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347030_Act15(f6_arg0, f6_arg1, f6_arg2)
    local f6_local0 = 5
    local f6_local1 = TARGET_ENE_0
    local f6_local2 = 5
    local f6_local3 = TARGET_ENE_0
    local f6_local4 = true
    local f6_local5 = f6_arg0:GetDist(TARGET_ENE_0)
    local f6_local6 = 0
    local f6_local7 = f6_arg0:GetRandam_Int(1, 100)
    local f6_local8 = -1
    if f6_local7 <= f6_local6 then
        f6_local8 = -1
    end
    f6_arg0:SetTimer(0, 4)
    f6_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, f6_local0, f6_local1, f6_local2, f6_local3, f6_local4, f6_local8)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347030_Act16(f7_arg0, f7_arg1, f7_arg2)
    f7_arg1:AddSubGoal(GOAL_COMMON_Turn, 1, TARGET_ENE_0, 90, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347030_Act17(f8_arg0, f8_arg1, f8_arg2)
    local f8_local0 = f8_arg0:GetDist(TARGET_ENE_0)
    local f8_local1 = 2
    local f8_local2 = 30
    local f8_local3 = f8_arg0:GetRandam_Int(1, 100)
    local f8_local4 = false
    local f8_local5 = -1
    f8_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 4, TARGET_ENE_0, f8_local1, TARGET_ENE_0, f8_local4, f8_local5)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347030_Act18(f9_arg0, f9_arg1, f9_arg2)
    local f9_local0 = 5
    local f9_local1 = 20011
    local f9_local2 = TARGET_ENE_0
    local f9_local3 = 10
    local f9_local4 = 0
    local f9_local5 = 0
    local f9_local6 = 0
    f9_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, f9_local0, f9_local1, f9_local2, f9_local3, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347030_Act19(f10_arg0, f10_arg1, f10_arg2)
    local f10_local0 = 5
    local f10_local1 = 20012
    local f10_local2 = TARGET_ENE_0
    local f10_local3 = 10
    local f10_local4 = 0
    local f10_local5 = 0
    local f10_local6 = 0
    f10_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, f10_local0, f10_local1, f10_local2, f10_local3, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347030_Act20(f11_arg0, f11_arg1, f11_arg2)
    local f11_local0 = 5
    local f11_local1 = 20013
    local f11_local2 = TARGET_ENE_0
    local f11_local3 = 10
    local f11_local4 = 0
    local f11_local5 = 0
    local f11_local6 = 0
    f11_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, f11_local0, f11_local1, f11_local2, f11_local3, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347030_Act30(f12_arg0, f12_arg1, f12_arg2)
    local f12_local0 = f12_arg0:GetDist(TARGET_ENE_0)
    local f12_local1 = f12_arg0:GetRandam_Int(6, 7)
    local f12_local2 = 999
    local f12_local3 = 0
    local f12_local4 = f12_arg0:GetStringIndexedNumber("c3470_DashRate")
    local f12_local5 = 90
    local f12_local6 = f12_arg0:GetRandam_Int(2, 10)
    local f12_local7 = 0
    Approach_Act_Flex(f12_arg0, f12_arg1, f12_local1, f12_local2, f12_local3, f12_local4, f12_local5, f12_local6, f12_local7)
    local f12_local8 = f12_arg0:GetRandam_Int(5, 20)
    local f12_local9 = TARGET_ENE_0
    local f12_local10 = f12_arg0:GetRandam_Int(0, 1)
    local f12_local11 = f12_arg0:GetRandam_Int(90, 360)
    local f12_local12 = 2
    local f12_local13 = TARGET_SELF
    local f12_local14 = true
    local f12_local15 = true
    local f12_local16 = f12_arg0:GetDist(TARGET_ENE_0)
    local f12_local17 = 0
    local f12_local18 = f12_arg0:GetRandam_Int(1, 100)
    if f12_local18 <= f12_local17 then
        guardActionId = -1
    end
    f12_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, f12_local8, f12_local9, f12_local10, f12_local11, f12_local14, -1, f12_local15, guardActionId)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347030_Act31(f13_arg0, f13_arg1, f13_arg2)
    local f13_local0 = 10
    local f13_local1 = TARGET_ENE_0
    local f13_local2 = 7
    local f13_local3 = TARGET_ENE_0
    local f13_local4 = true
    local f13_local5 = f13_arg0:GetDist(TARGET_ENE_0)
    local f13_local6 = 0
    local f13_local7 = f13_arg0:GetRandam_Int(1, 100)
    local f13_local8 = -1
    if f13_local7 <= f13_local6 then
        f13_local8 = -1
    end
    f13_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, f13_local0, f13_local1, f13_local2, f13_local3, f13_local4, f13_local8)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347030_ActAfter_AdjustSpace(f14_arg0, f14_arg1, f14_arg2)
    f14_arg1:AddSubGoal(GOAL_FrogHuman_347030_AfterAttackAct, 10)
    
end

Goal.Update = function (f15_arg0, f15_arg1, f15_arg2)
    return Update_Default_NoSubGoal(f15_arg0, f15_arg1, f15_arg2)
    
end

Goal.Terminate = function (f16_arg0, f16_arg1, f16_arg2)
    
end

Goal.Interrupt = function (f17_arg0, f17_arg1, f17_arg2)
    return false
    
end

RegisterTableGoal(GOAL_FrogHuman_347030_AfterAttackAct, "GOAL_FrogHuman_347030_AfterAttackAct")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_FrogHuman_347030_AfterAttackAct, true)

Goal.Activate = function (f18_arg0, f18_arg1, f18_arg2)
    
end

Goal.Update = function (f19_arg0, f19_arg1, f19_arg2)
    return Update_Default_NoSubGoal(f19_arg0, f19_arg1, f19_arg2)
    
end


