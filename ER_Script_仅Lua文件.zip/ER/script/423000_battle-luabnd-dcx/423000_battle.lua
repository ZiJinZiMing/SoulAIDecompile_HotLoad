﻿RegisterTableGoal(GOAL_GroundTacoJr423000_Battle, "GroundTacoJr423000_Battle")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_GroundTacoJr423000_Battle, true)

Goal.Initialize = function (f1_arg0, f1_arg1, f1_arg2, f1_arg3)
    
end

Goal.Activate = function (f2_arg0, f2_arg1, f2_arg2)
    local f2_local0 = {}
    local f2_local1 = {}
    local f2_local2 = {}
    Common_Clear_Param(f2_local0, f2_local1, f2_local2)
    local f2_local3 = f2_arg1:GetDist(TARGET_ENE_0)
    local f2_local4 = f2_arg1:GetRandam_Int(1, 100)
    local f2_local5 = f2_arg1:GetEventRequest()
    local f2_local6 = f2_arg1:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__thinkAttr_doAdmirer)
    if f2_local6 == 1 and f2_arg1:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Kankyaku then
        f2_local0[22] = 20
        f2_local0[24] = 80
    elseif f2_local6 == 1 and f2_arg1:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Torimaki then
        f2_local0[3] = 40
        f2_local0[24] = 60
    elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_B, 180, 90, 10 - f2_arg1:GetMapHitRadius(TARGET_SELF)) then
        f2_local0[21] = 100
    elseif f2_local3 >= 8 then
        f2_local0[22] = 100
    elseif f2_local3 >= 4 then
        f2_local0[1] = 50
        f2_local0[2] = 20
        f2_local0[3] = 20
        f2_local0[22] = 10
    else
        f2_local0[1] = 20
        f2_local0[2] = 60
        f2_local0[3] = 20
    end
    f2_local0[1] = SetCoolTime(f2_arg1, f2_arg2, 3000, 10, f2_local0[1], 1)
    f2_local1[1] = REGIST_FUNC(f2_arg1, f2_arg2, GroundTacoJr423000_Act01)
    f2_local1[2] = REGIST_FUNC(f2_arg1, f2_arg2, GroundTacoJr423000_Act02)
    f2_local1[3] = REGIST_FUNC(f2_arg1, f2_arg2, GroundTacoJr423000_Act03)
    f2_local1[21] = REGIST_FUNC(f2_arg1, f2_arg2, GroundTacoJr423000_Act21)
    f2_local1[22] = REGIST_FUNC(f2_arg1, f2_arg2, GroundTacoJr423000_Act22)
    f2_local1[23] = REGIST_FUNC(f2_arg1, f2_arg2, GroundTacoJr423000_Act23)
    f2_local1[24] = REGIST_FUNC(f2_arg1, f2_arg2, GroundTacoJr423000_Act24)
    f2_local1[31] = REGIST_FUNC(f2_arg1, f2_arg2, GroundTacoJr423000_Act31)
    f2_local1[45] = REGIST_FUNC(f2_arg1, f2_arg2, GroundTacoJr423000_Act45)
    f2_local1[46] = REGIST_FUNC(f2_arg1, f2_arg2, GroundTacoJr423000_Act46)
    f2_local1[47] = REGIST_FUNC(f2_arg1, f2_arg2, GroundTacoJr423000_Act47)
    local f2_local7 = REGIST_FUNC(f2_arg1, f2_arg2, GroundTacoJr423000_ActAfter_AdjustSpace)
    Common_Battle_Activate(f2_arg1, f2_arg2, f2_local0, f2_local1, f2_local7, f2_local2)
    
end

function GroundTacoJr423000_Act01(f3_arg0, f3_arg1, f3_arg2)
    local f3_local0 = 1.8 - f3_arg0:GetMapHitRadius(TARGET_SELF)
    local f3_local1 = 1.8 - f3_arg0:GetMapHitRadius(TARGET_SELF)
    local f3_local2 = 1.8 - f3_arg0:GetMapHitRadius(TARGET_SELF) + (10 - f3_arg0:GetMapHitRadius(TARGET_SELF))
    local f3_local3 = 0
    local f3_local4 = 0
    local f3_local5 = 8
    local f3_local6 = 0
    Approach_Act_Flex(f3_arg0, f3_arg1, f3_local0, f3_local1, f3_local2, f3_local3, f3_local4, f3_local5, f3_local6)
    local f3_local7 = 3001
    local f3_local8 = 3 - f3_arg0:GetMapHitRadius(TARGET_SELF)
    local f3_local9 = 0
    local f3_local10 = 180
    f3_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 5, f3_local7, TARGET_ENE_0, f3_local8, f3_local9, f3_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function GroundTacoJr423000_Act02(f4_arg0, f4_arg1, f4_arg2)
    local f4_local0 = f4_arg0:GetRandam_Int(1, 100)
    local f4_local1 = 1.2 - f4_arg0:GetMapHitRadius(TARGET_SELF)
    local f4_local2 = 1.2 - f4_arg0:GetMapHitRadius(TARGET_SELF)
    local f4_local3 = 1.2 - f4_arg0:GetMapHitRadius(TARGET_SELF) + (10 - f4_arg0:GetMapHitRadius(TARGET_SELF))
    local f4_local4 = 0
    local f4_local5 = 0
    local f4_local6 = 8
    local f4_local7 = 0
    Approach_Act_Flex(f4_arg0, f4_arg1, f4_local1, f4_local2, f4_local3, f4_local4, f4_local5, f4_local6, f4_local7)
    local f4_local8 = 3002
    local f4_local9 = 3003
    local f4_local10 = 1.5 - f4_arg0:GetMapHitRadius(TARGET_SELF) + 1.5
    local f4_local11 = 3 - f4_arg0:GetMapHitRadius(TARGET_SELF)
    local f4_local12 = 0
    local f4_local13 = 180
    f4_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 5, f4_local8, TARGET_ENE_0, f4_local10, f4_local12, f4_local13, 0, 0)
    f4_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 5, f4_local9, TARGET_ENE_0, f4_local11, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function GroundTacoJr423000_Act03(f5_arg0, f5_arg1, f5_arg2)
    local f5_local0 = 2
    local f5_local1 = 3 - f5_arg0:GetMapHitRadius(TARGET_SELF)
    local f5_local2 = 3 - f5_arg0:GetMapHitRadius(TARGET_SELF) + 3
    local f5_local3 = 0
    local f5_local4 = 0
    local f5_local5 = 8
    local f5_local6 = 0
    Approach_Act_Flex(f5_arg0, f5_arg1, f5_local0, f5_local1, f5_local2, f5_local3, f5_local4, f5_local5, f5_local6)
    local f5_local7 = 3000
    local f5_local8 = 3 - f5_arg0:GetMapHitRadius(TARGET_SELF)
    local f5_local9 = 0
    local f5_local10 = 180
    f5_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 5, f5_local7, TARGET_ENE_0, f5_local8, f5_local9, f5_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function GroundTacoJr423000_ActCP2(f6_arg0, f6_arg1, f6_arg2)
    local f6_local0 = f6_arg0:GetRandam_Int(1, 100)
    local f6_local1 = 3 - f6_arg0:GetMapHitRadius(TARGET_SELF)
    local f6_local2 = 3 - f6_arg0:GetMapHitRadius(TARGET_SELF)
    local f6_local3 = 3 - f6_arg0:GetMapHitRadius(TARGET_SELF) + 3
    local f6_local4 = 100
    local f6_local5 = 0
    local f6_local6 = 4
    local f6_local7 = 8
    Approach_Act_Flex(f6_arg0, f6_arg1, f6_local1, f6_local2, f6_local3, f6_local4, f6_local5, f6_local6, f6_local7)
    local f6_local8 = 3001
    local f6_local9 = 3002
    local f6_local10 = 3003
    local f6_local11 = 1.2 - f6_arg0:GetMapHitRadius(TARGET_SELF)
    local f6_local12 = 1.5 - f6_arg0:GetMapHitRadius(TARGET_SELF)
    local f6_local13 = 3 - f6_arg0:GetMapHitRadius(TARGET_SELF)
    local f6_local14 = 0
    local f6_local15 = 180
    f6_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 5, f6_local8, TARGET_ENE_0, f6_local11, f6_local14, f6_local15, 0, 0)
    f6_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 5, f6_local9, TARGET_ENE_0, f6_local12, 0, 0)
    f6_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 5, f6_local10, TARGET_ENE_0, f6_local13, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function GroundTacoJr423000_Act21(f7_arg0, f7_arg1, f7_arg2)
    f7_arg1:AddSubGoal(GOAL_COMMON_Turn, 2, TARGET_ENE_0, 90, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function GroundTacoJr423000_Act22(f8_arg0, f8_arg1, f8_arg2)
    local f8_local0 = f8_arg0:GetDist(TARGET_ENE_0)
    local f8_local1 = (10 - f8_arg0:GetMapHitRadius(TARGET_SELF)) / 2
    local f8_local2 = true
    local f8_local3 = f8_arg0:GetRandam_Int(1, 100)
    local f8_local4 = -1
    f8_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 4, TARGET_ENE_0, f8_local1, TARGET_ENE_0, f8_local2, f8_local4)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function GroundTacoJr423000_Act23(f9_arg0, f9_arg1, f9_arg2)
    local f9_local0 = f9_arg0:GetDist(TARGET_ENE_0)
    local f9_local1 = (10 - f9_arg0:GetMapHitRadius(TARGET_SELF)) * 2
    local f9_local2 = true
    local f9_local3 = f9_arg0:GetRandam_Int(1, 100)
    local f9_local4 = -1
    if f9_local0 <= (10 - f9_arg0:GetMapHitRadius(TARGET_SELF)) / 1.5 then
        f9_arg1:ClearSubGoal()
    else
        f9_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 4, TARGET_ENE_0, f9_local1, TARGET_ENE_0, false, f9_local4)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function GroundTacoJr423000_Act24(f10_arg0, f10_arg1, f10_arg2)
    local f10_local0 = f10_arg0:GetRandam_Int(1, 100)
    local f10_local1 = -1
    f10_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, 2, TARGET_ENE_0, f10_arg0:GetRandam_Int(0, 1), f10_arg0:GetRandam_Int(30, 45), true, true, f10_local1)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function GroundTacoJr423000_ActCP3(f11_arg0, f11_arg1, f11_arg2)
    f11_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3021, TARGET_ENE_0, DIST_None, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function GroundTacoJr423000_Act45(f12_arg0, f12_arg1, f12_arg2)
    f12_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3021, TARGET_ENE_0, DIST_None, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function GroundTacoJr423000_Act46(f13_arg0, f13_arg1, f13_arg2)
    f13_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3021, TARGET_ENE_0, DIST_None, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function GroundTacoJr423000_Act47(f14_arg0, f14_arg1, f14_arg2)
    f14_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3021, TARGET_ENE_0, DIST_None, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function GroundTacoJr423000_Approach_Act_Flex(f15_arg0, f15_arg1, f15_arg2, f15_arg3, f15_arg4, f15_arg5, f15_arg6, f15_arg7, f15_arg8)
    local f15_local0 = f15_arg0:GetDist(TARGET_ENE_0)
    local f15_local1 = f15_arg0:GetRandam_Int(1, 100)
    local f15_local2 = false
    if f15_arg3 <= f15_local0 then
        f15_local2 = true
    elseif f15_arg4 <= f15_local0 and f15_local1 <= f15_arg5 then
        f15_local2 = false
    end
    local f15_local3 = -1
    local f15_local4 = f15_arg0:GetRandam_Int(1, 100)
    if f15_local4 <= f15_arg6 then
        f15_local3 = 9910
    end
    if f15_local2 == true then
        life = f15_arg7
    else
        life = f15_arg8
    end
    if f15_arg2 <= f15_local0 then
        f15_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, life, TARGET_ENE_0, f15_arg2, TARGET_SELF, f15_local2, f15_local3)
    end
    
end

function GroundTacoJr423000_ActAfter_AdjustSpace(f16_arg0, f16_arg1, f16_arg2)
    f16_arg1:AddSubGoal(GOAL_GroundTacoJr423000_AfterAttackAct, 10)
    
end

Goal.Update = function (f17_arg0, f17_arg1, f17_arg2)
    return Update_Default_NoSubGoal(f17_arg0, f17_arg1, f17_arg2)
    
end

Goal.Terminate = function (f18_arg0, f18_arg1, f18_arg2)
    
end

Goal.Interrupt = function (f19_arg0, f19_arg1, f19_arg2)
    local f19_local0 = f19_arg1:GetDist(TARGET_ENE_0)
    local f19_local1 = f19_arg1:GetDist(TARGET_FRI_0)
    local f19_local2 = f19_arg1:GetRandam_Int(1, 100)
    local f19_local3 = f19_arg1:GetPrevTargetState()
    local f19_local4 = f19_arg1:AddObserveSpecialEffectAttribute(TARGET_ENE_0, PLAN_SP_EFFECT_FALL_FROM_HORSE)
    if f19_arg1:IsLadderAct(TARGET_SELF) then
        return false
    end
    if f19_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f19_arg1:GetSpecialEffectActivateInterruptType(0) == PLAN_SP_EFFECT_FALL_FROM_HORSE then
        f19_arg2:ClearSubGoal()
        return true
    end
    if f19_arg1:IsInterupt(INTERUPT_Damaged) then
    end
    return false
    
end

RegisterTableGoal(GOAL_GroundTacoJr423000_AfterAttackAct, "GroundTacoJr423000_AfterAttackAct")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_GroundTacoJr423000_AfterAttackAct, true)

Goal.Activate = function (f20_arg0, f20_arg1, f20_arg2)
    
end

Goal.Update = function (f21_arg0, f21_arg1, f21_arg2)
    return Update_Default_NoSubGoal(f21_arg0, f21_arg1, f21_arg2)
    
end


