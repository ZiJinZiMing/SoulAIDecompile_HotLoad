﻿function Tortoises609000_Logic(f1_arg0)
    COMMON_Initialize(f1_arg0)
    local f1_local0 = f1_arg0:GetPrevTargetState()
    if COMMON_EasySetup_Initial(f1_arg0) == false then
        local f1_local1 = f1_arg0:GetMovePointNumber()
        local f1_local2 = f1_arg0:GetEventRequest()
        local f1_local3 = f1_arg0:IsSearchTarget(TARGET_ENE_0)
        local f1_local4 = f1_arg0:GetRandam_Int(1, 100)
        f1_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
        if f1_local2 == 100 then
            f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 5, POINT_INITIAL, 0.5, TARGET_SELF, true, -1)
        elseif f1_local2 == 110 then
            f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 5, POINT_INITIAL, 0.5, TARGET_SELF, false, -1)
        elseif f1_arg0:IsBattleState() == false and f1_arg0:IsSearchLowState() == false and f1_arg0:IsSearchHighState() == false and f1_arg0:IsCautionState() == false and f1_arg0:IsMemoryState() == false and f1_local1 == -1 and f1_arg0:IsValidPlatoon() == false then
            local f1_local5 = 2
            local f1_local6 = 10
            local f1_local7 = true
            local f1_local8 = 3020
            local f1_local9 = 7
            local f1_local10 = 1
            local f1_local11 = false
            local f1_local12 = true
            local f1_local13 = false
            f1_arg0:AddTopGoal(GOAL_COMMON_WalkAround_Anywhere, -1, f1_local5, f1_local6, f1_local7, f1_local8, f1_local9, f1_local10, f1_local11, f1_local12, f1_local13)
            local f1_local14 = f1_arg0:GetRandam_Int(1, 100)
            local f1_local15 = 5
            local f1_local16 = 3021
            local f1_local17 = TARGET_SELF
            local f1_local18 = 10
            f1_arg0:AddTopGoal(GOAL_COMMON_ComboRepeat_SuccessAngle180, f1_local15, f1_local16, f1_local17, f1_local18)
            if f1_local14 >= 70 then
                f1_arg0:AddTopGoal(GOAL_COMMON_ComboRepeat_SuccessAngle180, f1_local15, f1_local16, f1_local17, f1_local18)
            end
        else
            COMMON_EasySetup3(f1_arg0)
        end
    end
    
end

function Tortoises609000_Interupt(f2_arg0, f2_arg1)
    
end


