﻿RegisterTableGoal(GOAL_KnightofNoblerot_Sc380010_Battle, "KnightofNoblerot_Sc380010_Battle")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_KnightofNoblerot_Sc380010_Battle, true)

Goal.Initialize = function (f1_arg0, f1_arg1, f1_arg2, f1_arg3)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3000)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3001)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3002)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3003)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3004)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3010)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3011)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3012)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3014)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3015)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3029)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3100)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3101)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3102)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3000)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3001)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3003)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3004)
    
end

Goal.Activate = function (f2_arg0, f2_arg1, f2_arg2)
    Init_Pseudo_Global(f2_arg1, f2_arg2)
    f2_arg1:SetStringIndexedNumber("Dist_SideStep", 5)
    f2_arg1:SetStringIndexedNumber("Dist_BackStep", 5)
    local f2_local0 = {}
    local f2_local1 = {}
    local f2_local2 = {}
    Common_Clear_Param(f2_local0, f2_local1, f2_local2)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5028)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5029)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5034)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5035)
    f2_arg1:DeleteObserve(1)
    local f2_local3 = f2_arg1:GetDist(TARGET_ENE_0)
    local f2_local4 = f2_arg1:GetRandam_Int(1, 100)
    local f2_local5 = f2_arg1:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__thinkAttr_doAdmirer)
    local f2_local6 = f2_arg1:GetDist(TARGET_FRI_0)
    local f2_local7 = 1
    local f2_local8 = 1
    local f2_local9 = f2_arg1:GetEventRequest()
    if f2_arg1:GetNumber(0) >= 5 then
        f2_arg1:SetTimer(0, f2_arg1:GetRandam_Float(3, 6))
        f2_arg1:SetNumber(0, 0)
    end
    if f2_local6 <= 7 then
        local f2_local10 = 5
    end
    if f2_local5 == 1 and f2_arg1:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Kankyaku then
        if f2_local3 >= 10 then
            f2_local0[29] = 100
        elseif f2_local3 >= 7.5 then
            f2_local0[21] = 100
            f2_local0[29] = 100
        elseif f2_local3 >= 5.5 then
            f2_local0[21] = 100
        elseif f2_local3 >= 3.5 then
            f2_local0[21] = 100
            f2_local0[22] = 100
            f2_local0[30] = 300
        else
            f2_local0[21] = 10
            f2_local0[22] = 300
            f2_local0[30] = 200
        end
    elseif f2_local5 == 1 and f2_arg1:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Torimaki then
        if f2_local3 >= 10 then
            f2_local0[9] = 150
            f2_local0[10] = 150
            f2_local0[29] = 700
        elseif f2_local3 >= 7.5 then
            f2_local0[9] = 150
            f2_local0[10] = 150
            f2_local0[21] = 300
            f2_local0[29] = 400
        elseif f2_local3 >= 5.5 then
            f2_local0[3] = 100
            f2_local0[9] = 100
            f2_local0[10] = 100
            f2_local0[21] = 700
        elseif f2_local3 >= 3.5 then
            f2_local0[1] = 40
            f2_local0[4] = 30
            f2_local0[6] = 100
            f2_local0[7] = 100
            f2_local0[8] = 30
            f2_local0[21] = 300
            f2_local0[22] = 100
            f2_local0[30] = 300
        else
            f2_local0[1] = 50
            f2_local0[7] = 150
            f2_local0[22] = 500
            f2_local0[30] = 300
        end
    elseif InsideRange(f2_arg1, f2_arg2, 180, 240, 0, 3) then
        if InsideRange(f2_arg1, f2_arg2, 90, 180, 0, 3) then
            f2_local0[23] = 500
        else
            f2_local0[24] = 500
        end
        f2_local0[20] = 50
    elseif InsideRange(f2_arg1, f2_arg2, 180, 200, 3, 10) then
        f2_local0[20] = 100
        f2_local0[21] = 100
    elseif f2_local3 >= 10 then
        if f2_arg1:IsFinishTimer(0) then
            f2_local0[9] = 400
            f2_local0[10] = 500
            f2_local0[21] = 100
            if f2_arg1:HasSpecialEffectAttribute(TARGET_SELF, 307) then
                f2_local0[13] = 200
                f2_local0[14] = 100
            end
        else
            f2_local0[9] = 100
            f2_local0[10] = 200
            f2_local0[21] = 700
            if f2_arg1:HasSpecialEffectAttribute(TARGET_SELF, 307) then
                f2_local0[13] = 200
                f2_local0[14] = 100
            end
        end
    elseif f2_local3 >= 7 then
        if f2_arg1:IsFinishTimer(0) then
            f2_local0[9] = 600
            f2_local0[10] = 300
            f2_local0[21] = 100
            if f2_arg1:HasSpecialEffectAttribute(TARGET_SELF, 307) then
                f2_local0[13] = 200
                f2_local0[14] = 100
            end
        else
            f2_local0[9] = 200
            f2_local0[10] = 100
            f2_local0[21] = 700
            if f2_arg1:HasSpecialEffectAttribute(TARGET_SELF, 307) then
                f2_local0[13] = 200
                f2_local0[14] = 100
            end
        end
    elseif f2_local3 >= 5 then
        if not f2_arg1:IsFinishTimer(1) then
            f2_local0[1] = 0
            f2_local0[2] = 0
            f2_local0[3] = 550
            f2_local0[4] = 0
            f2_local0[8] = 0
            f2_local0[9] = 250
            f2_local0[10] = 0
            f2_local0[21] = 200 * f2_local7
            if f2_arg1:HasSpecialEffectAttribute(TARGET_SELF, 307) then
                f2_local0[13] = 0
                f2_local0[14] = 200
            end
        else
            f2_local0[1] = 50
            f2_local0[2] = 200
            f2_local0[3] = 300
            f2_local0[4] = 150
            f2_local0[8] = 0
            f2_local0[9] = 0
            f2_local0[10] = 0
            f2_local0[21] = 50 * f2_local7
            if f2_arg1:HasSpecialEffectAttribute(TARGET_SELF, 307) then
                f2_local0[13] = 0
                f2_local0[14] = 200
            end
        end
    elseif f2_local3 >= 3 then
        if not f2_arg1:IsFinishTimer(1) then
            f2_local0[1] = 0
            f2_local0[2] = 200
            f2_local0[3] = 300
            f2_local0[4] = 0
            f2_local0[6] = 100
            f2_local0[7] = 0
            f2_local0[8] = 0
            f2_local0[9] = 0
            f2_local0[11] = 0
            f2_local0[21] = 50 * f2_local7
            if f2_arg1:HasSpecialEffectAttribute(TARGET_SELF, 307) then
                f2_local0[13] = 0
                f2_local0[14] = 200
            end
        else
            f2_local0[1] = 100
            f2_local0[2] = 200
            f2_local0[3] = 200
            f2_local0[4] = 0
            f2_local0[6] = 150
            f2_local0[7] = 150 * f2_local7
            f2_local0[8] = 0
            f2_local0[9] = 0
            f2_local0[11] = 200
            f2_local0[21] = 0
            f2_local0[22] = 100 * f2_local7
            if f2_arg1:HasSpecialEffectAttribute(TARGET_SELF, 307) then
                f2_local0[13] = 0
                f2_local0[14] = 200
            end
        end
    else
        f2_local0[1] = 100
        f2_local0[2] = 0
        f2_local0[3] = 0
        f2_local0[4] = 0
        f2_local0[6] = 150
        f2_local0[7] = 200 * f2_local7
        f2_local0[8] = 200
        f2_local0[11] = 150
        f2_local0[21] = 0
        f2_local0[22] = 100 * f2_local7
        if f2_arg1:HasSpecialEffectAttribute(TARGET_SELF, 307) then
            f2_local0[13] = 0
            f2_local0[14] = 200
        end
    end
    if f2_local6 <= 8 and f2_local6 >= 0 and f2_arg1:HasSpecialEffectId(TARGET_FRI_0, 13855) == false then
        if f2_local3 >= 5 then
            f2_local0[5] = 1000
        elseif f2_local3 >= 3 then
            f2_local0[5] = 600
        else
            f2_local0[5] = 200
        end
    end
    if SpaceCheck(f2_arg1, f2_arg2, 90, 1) == false and SpaceCheck(f2_arg1, f2_arg2, -90, 1) == false then
        f2_local0[21] = 0
    end
    if SpaceCheck(f2_arg1, f2_arg2, 180, 3) == false then
        f2_local0[7] = 0
        f2_local0[22] = 0
    end
    if SpaceCheck(f2_arg1, f2_arg2, 90, 3) == false then
        f2_local0[24] = 0
    end
    if SpaceCheck(f2_arg1, f2_arg2, -90, 3) == false then
        f2_local0[23] = 0
    end
    f2_local0[1] = SetCoolTime(f2_arg1, f2_arg2, 3000, 5, f2_local0[1], 1)
    f2_local0[2] = SetCoolTime(f2_arg1, f2_arg2, 3010, 8, f2_local0[2], 1)
    f2_local0[3] = SetCoolTime(f2_arg1, f2_arg2, 3011, 8, f2_local0[3], 1)
    f2_local0[4] = SetCoolTime(f2_arg1, f2_arg2, 3013, 10, f2_local0[4], 1)
    f2_local0[5] = SetCoolTime(f2_arg1, f2_arg2, 3020, 42, f2_local0[5], 0)
    f2_local0[6] = SetCoolTime(f2_arg1, f2_arg2, 3027, 15, f2_local0[6], 1)
    f2_local0[7] = SetCoolTime(f2_arg1, f2_arg2, 3001, 5, f2_local0[7], 1)
    f2_local0[7] = SetCoolTime(f2_arg1, f2_arg2, 3003, 5, f2_local0[7], 1)
    f2_local0[7] = SetCoolTime(f2_arg1, f2_arg2, 6001, 5, f2_local0[7], 1)
    f2_local0[7] = SetCoolTime(f2_arg1, f2_arg2, 6002, 5, f2_local0[7], 1)
    f2_local0[7] = SetCoolTime(f2_arg1, f2_arg2, 6003, 5, f2_local0[7], 1)
    f2_local0[8] = SetCoolTime(f2_arg1, f2_arg2, 3004, 10, f2_local0[8], 1)
    f2_local0[11] = SetCoolTime(f2_arg1, f2_arg2, 3001, 5, f2_local0[11], 1)
    f2_local0[13] = SetCoolTime(f2_arg1, f2_arg2, 3005, 7, f2_local0[13], 1)
    f2_local0[14] = SetCoolTime(f2_arg1, f2_arg2, 3007, 7, f2_local0[14], 1)
    f2_local0[14] = SetCoolTime(f2_arg1, f2_arg2, 3008, 7, f2_local0[14], 1)
    f2_local0[22] = SetCoolTime(f2_arg1, f2_arg2, 3003, 8, f2_local0[22], 1)
    f2_local0[22] = SetCoolTime(f2_arg1, f2_arg2, 6001, 8, f2_local0[22], 1)
    f2_local0[22] = SetCoolTime(f2_arg1, f2_arg2, 6002, 8, f2_local0[22], 1)
    f2_local0[22] = SetCoolTime(f2_arg1, f2_arg2, 6003, 8, f2_local0[22], 1)
    f2_local1[1] = REGIST_FUNC(f2_arg1, f2_arg2, KnightofNoblerot_Sc380010_Act01)
    f2_local1[2] = REGIST_FUNC(f2_arg1, f2_arg2, KnightofNoblerot_Sc380010_Act02)
    f2_local1[3] = REGIST_FUNC(f2_arg1, f2_arg2, KnightofNoblerot_Sc380010_Act03)
    f2_local1[4] = REGIST_FUNC(f2_arg1, f2_arg2, KnightofNoblerot_Sc380010_Act04)
    f2_local1[5] = REGIST_FUNC(f2_arg1, f2_arg2, KnightofNoblerot_Sc380010_Act05)
    f2_local1[6] = REGIST_FUNC(f2_arg1, f2_arg2, KnightofNoblerot_Sc380010_Act06)
    f2_local1[7] = REGIST_FUNC(f2_arg1, f2_arg2, KnightofNoblerot_Sc380010_Act07)
    f2_local1[8] = REGIST_FUNC(f2_arg1, f2_arg2, KnightofNoblerot_Sc380010_Act08)
    f2_local1[9] = REGIST_FUNC(f2_arg1, f2_arg2, KnightofNoblerot_Sc380010_Act09)
    f2_local1[10] = REGIST_FUNC(f2_arg1, f2_arg2, KnightofNoblerot_Sc380010_Act10)
    f2_local1[11] = REGIST_FUNC(f2_arg1, f2_arg2, KnightofNoblerot_Sc380010_Act11)
    f2_local1[13] = REGIST_FUNC(f2_arg1, f2_arg2, KnightofNoblerot_Sp380010_Act13)
    f2_local1[14] = REGIST_FUNC(f2_arg1, f2_arg2, KnightofNoblerot_Sp380010_Act14)
    f2_local1[20] = REGIST_FUNC(f2_arg1, f2_arg2, KnightofNoblerot_Sc380010_Act20)
    f2_local1[21] = REGIST_FUNC(f2_arg1, f2_arg2, KnightofNoblerot_Sc380010_Act21)
    f2_local1[22] = REGIST_FUNC(f2_arg1, f2_arg2, KnightofNoblerot_Sc380010_Act22)
    f2_local1[23] = REGIST_FUNC(f2_arg1, f2_arg2, KnightofNoblerot_Sc380010_Act23)
    f2_local1[24] = REGIST_FUNC(f2_arg1, f2_arg2, KnightofNoblerot_Sc380010_Act24)
    f2_local1[29] = REGIST_FUNC(f2_arg1, f2_arg2, KnightofNoblerot_Sc380010_Act29)
    f2_local1[30] = REGIST_FUNC(f2_arg1, f2_arg2, KnightofNoblerot_Sc380010_Act30)
    local f2_local10 = REGIST_FUNC(f2_arg1, f2_arg2, KnightofNoblerot_Sc380010_ActAfter_AdjustSpace)
    Common_Battle_Activate(f2_arg1, f2_arg2, f2_local0, f2_local1, f2_local10, f2_local2)
    
end

function KnightofNoblerot_Sc380010_Act01(f3_arg0, f3_arg1, f3_arg2)
    local f3_local0 = 4 - f3_arg0:GetMapHitRadius(TARGET_SELF)
    local f3_local1 = 4 - f3_arg0:GetMapHitRadius(TARGET_SELF) + 0.9
    local f3_local2 = 4 - f3_arg0:GetMapHitRadius(TARGET_SELF) + 2
    local f3_local3 = 100
    local f3_local4 = 0
    local f3_local5 = 0.5
    local f3_local6 = 0.8
    Approach_Act_Flex(f3_arg0, f3_arg1, f3_local0, f3_local1, f3_local2, f3_local3, f3_local4, f3_local5, f3_local6)
    local f3_local7 = 3000
    local f3_local8 = 4 - f3_arg0:GetMapHitRadius(TARGET_SELF) + 1
    local f3_local9 = 5 - f3_arg0:GetMapHitRadius(TARGET_SELF)
    local f3_local10 = 0
    local f3_local11 = 0
    local f3_local12 = f3_arg0:GetRandam_Int(1, 100)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f3_local7, TARGET_ENE_0, f3_local8, f3_local10, f3_local11, 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function KnightofNoblerot_Sc380010_Act02(f4_arg0, f4_arg1, f4_arg2)
    local f4_local0 = 4.5 - f4_arg0:GetMapHitRadius(TARGET_SELF)
    local f4_local1 = 4.5 - f4_arg0:GetMapHitRadius(TARGET_SELF)
    local f4_local2 = 4.5 - f4_arg0:GetMapHitRadius(TARGET_SELF)
    local f4_local3 = 50
    local f4_local4 = 0
    local f4_local5 = 0.5
    local f4_local6 = 0.8
    Approach_Act_Flex(f4_arg0, f4_arg1, f4_local0, f4_local1, f4_local2, f4_local3, f4_local4, f4_local5, f4_local6)
    local f4_local7 = 3010
    local f4_local8 = 5 - f4_arg0:GetMapHitRadius(TARGET_SELF)
    local f4_local9 = 0
    local f4_local10 = 0
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5028)
    f4_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f4_local7, TARGET_ENE_0, f4_local8, f4_local9, f4_local10, 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function KnightofNoblerot_Sc380010_Act03(f5_arg0, f5_arg1, f5_arg2)
    local f5_local0 = 5.6 - f5_arg0:GetMapHitRadius(TARGET_SELF)
    local f5_local1 = 5.6 - f5_arg0:GetMapHitRadius(TARGET_SELF) + 0.9
    local f5_local2 = 5.6 - f5_arg0:GetMapHitRadius(TARGET_SELF) + 2
    local f5_local3 = 100
    local f5_local4 = 0
    local f5_local5 = 0.5
    local f5_local6 = 0.8
    Approach_Act_Flex(f5_arg0, f5_arg1, f5_local0, f5_local1, f5_local2, f5_local3, f5_local4, f5_local5, f5_local6)
    local f5_local7 = 3011
    local f5_local8 = 5 - f5_arg0:GetMapHitRadius(TARGET_SELF)
    local f5_local9 = 0
    local f5_local10 = 0
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5028)
    f5_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f5_local7, TARGET_ENE_0, f5_local8, f5_local9, f5_local10, 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function KnightofNoblerot_Sc380010_Act04(f6_arg0, f6_arg1, f6_arg2)
    local f6_local0 = 4 - f6_arg0:GetMapHitRadius(TARGET_SELF)
    local f6_local1 = 4 - f6_arg0:GetMapHitRadius(TARGET_SELF)
    local f6_local2 = 4 - f6_arg0:GetMapHitRadius(TARGET_SELF) + 0.9
    local f6_local3 = 100
    local f6_local4 = 0
    local f6_local5 = 0.5
    local f6_local6 = 0.8
    Approach_Act_Flex(f6_arg0, f6_arg1, f6_local0, f6_local1, f6_local2, f6_local3, f6_local4, f6_local5, f6_local6)
    local f6_local7 = 3013
    local f6_local8 = 5 - f6_arg0:GetMapHitRadius(TARGET_SELF)
    local f6_local9 = 0
    local f6_local10 = 0
    f6_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f6_local7, TARGET_ENE_0, f6_local8, f6_local9, f6_local10, 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function KnightofNoblerot_Sc380010_Act05(f7_arg0, f7_arg1, f7_arg2)
    local f7_local0 = 3020
    local f7_local1 = 5 - f7_arg0:GetMapHitRadius(TARGET_SELF)
    local f7_local2 = 0
    local f7_local3 = 0
    f7_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f7_local0, TARGET_FRI_0, f7_local1, f7_local2, f7_local3, 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function KnightofNoblerot_Sc380010_Act06(f8_arg0, f8_arg1, f8_arg2)
    local f8_local0 = 3027
    local f8_local1 = 5 - f8_arg0:GetMapHitRadius(TARGET_SELF)
    local f8_local2 = 0
    local f8_local3 = 0
    f8_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5035)
    f8_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f8_local0, TARGET_ENE_0, f8_local1, f8_local2, f8_local3, 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function KnightofNoblerot_Sc380010_Act07(f9_arg0, f9_arg1, f9_arg2)
    local f9_local0 = 4 - f9_arg0:GetMapHitRadius(TARGET_SELF)
    local f9_local1 = 4 - f9_arg0:GetMapHitRadius(TARGET_SELF)
    local f9_local2 = 4 - f9_arg0:GetMapHitRadius(TARGET_SELF) + 1
    local f9_local3 = 100
    local f9_local4 = 0
    local f9_local5 = 0.5
    local f9_local6 = 0.8
    Approach_Act_Flex(f9_arg0, f9_arg1, f9_local0, f9_local1, f9_local2, f9_local3, f9_local4, f9_local5, f9_local6)
    local f9_local7 = 3003
    local f9_local8 = 4 - f9_arg0:GetMapHitRadius(TARGET_SELF) + 1
    local f9_local9 = 5 - f9_arg0:GetMapHitRadius(TARGET_SELF)
    local f9_local10 = 0
    local f9_local11 = 0
    local f9_local12 = f9_arg0:GetRandam_Int(1, 100)
    f9_arg0:SetTimer(1, 5)
    f9_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f9_local7, TARGET_ENE_0, 999, f9_local10, f9_local11, 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function KnightofNoblerot_Sc380010_Act08(f10_arg0, f10_arg1, f10_arg2)
    local f10_local0 = 3 - f10_arg0:GetMapHitRadius(TARGET_SELF)
    local f10_local1 = 3 - f10_arg0:GetMapHitRadius(TARGET_SELF) + 0.9
    local f10_local2 = 3 - f10_arg0:GetMapHitRadius(TARGET_SELF) + 1
    local f10_local3 = 100
    local f10_local4 = 0
    local f10_local5 = 0.5
    local f10_local6 = 0.8
    Approach_Act_Flex(f10_arg0, f10_arg1, f10_local0, f10_local1, f10_local2, f10_local3, f10_local4, f10_local5, f10_local6)
    local f10_local7 = 3004
    local f10_local8 = 6 - f10_arg0:GetMapHitRadius(TARGET_SELF) + 1
    local f10_local9 = 5 - f10_arg0:GetMapHitRadius(TARGET_SELF)
    local f10_local10 = 0
    local f10_local11 = 0
    local f10_local12 = f10_arg0:GetRandam_Int(1, 100)
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5029)
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5035)
    f10_arg0:SetTimer(1, 5)
    f10_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f10_local7, TARGET_ENE_0, f10_local8, f10_local10, f10_local11, 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function KnightofNoblerot_Sc380010_Act09(f11_arg0, f11_arg1, f11_arg2)
    local f11_local0 = 3029
    local f11_local1 = 5.9 - f11_arg0:GetMapHitRadius(TARGET_SELF) - 1
    local f11_local2 = 5 - f11_arg0:GetMapHitRadius(TARGET_SELF)
    local f11_local3 = 0
    local f11_local4 = 0
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5034)
    f11_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f11_local0, TARGET_ENE_0, f11_local1, f11_local3, f11_local4, 0, 0):TimingSetNumber(0, f11_arg0:GetNumber(0) + 1, AI_TIMING_SET__ACTIVATE)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function KnightofNoblerot_Sc380010_Act10(f12_arg0, f12_arg1, f12_arg2)
    local f12_local0 = 3026
    local f12_local1 = 3029
    local f12_local2 = 5 - f12_arg0:GetMapHitRadius(TARGET_SELF)
    local f12_local3 = 0
    local f12_local4 = 0
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5028)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5034)
    f12_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f12_local0, TARGET_ENE_0, 999, f12_local3, f12_local4, 0, 0):TimingSetNumber(0, f12_arg0:GetNumber(0) + 1, AI_TIMING_SET__ACTIVATE)
    f12_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 10, f12_local1, TARGET_ENE_0, f12_local2, 0, 0):TimingSetNumber(0, f12_arg0:GetNumber(0) + 2, AI_TIMING_SET__ACTIVATE)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function KnightofNoblerot_Sc380010_Act11(f13_arg0, f13_arg1, f13_arg2)
    local f13_local0 = 3.7 - f13_arg0:GetMapHitRadius(TARGET_SELF)
    local f13_local1 = 3.7 - f13_arg0:GetMapHitRadius(TARGET_SELF)
    local f13_local2 = 3.7 - f13_arg0:GetMapHitRadius(TARGET_SELF) + 1
    local f13_local3 = 100
    local f13_local4 = 0
    local f13_local5 = 1
    local f13_local6 = 2
    local f13_local7 = f13_arg0:GetDist(TARGET_ENE_0)
    Approach_Act_Flex(f13_arg0, f13_arg1, f13_local0, f13_local1, f13_local2, f13_local3, f13_local4, f13_local5, f13_local6)
    local f13_local8 = 3001
    local f13_local9 = 5 - f13_arg0:GetMapHitRadius(TARGET_SELF)
    local f13_local10 = -1
    local f13_local11 = 60
    f13_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    f13_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f13_local8, TARGET_ENE_0, f13_local9, f13_local10, f13_local11, 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function KnightofNoblerot_Sp380010_Act13(f14_arg0, f14_arg1, f14_arg2)
    local f14_local0 = 5
    local f14_local1 = 3005
    local f14_local2 = TARGET_ENE_0
    local f14_local3 = 10
    local f14_local4 = 0
    local f14_local5 = 0
    local f14_local6 = 0
    f14_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f14_local0, f14_local1, f14_local2, f14_local3, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function KnightofNoblerot_Sp380010_Act14(f15_arg0, f15_arg1, f15_arg2)
    local f15_local0 = 5
    local f15_local1 = f15_arg0:GetRandam_Int(3007, 3008)
    local f15_local2 = TARGET_ENE_0
    local f15_local3 = 10
    local f15_local4 = 0
    local f15_local5 = 0
    local f15_local6 = 0
    f15_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f15_local0, f15_local1, f15_local2, f15_local3, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function KnightofNoblerot_Sc380010_Act20(f16_arg0, f16_arg1, f16_arg2)
    f16_arg1:AddSubGoal(GOAL_COMMON_Turn, 2, TARGET_ENE_0, f16_arg0:GetRandam_Int(15, 20))
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function KnightofNoblerot_Sc380010_Act21(f17_arg0, f17_arg1, f17_arg2)
    local f17_local0 = 0
    local f17_local1 = f17_arg0:GetRandam_Int(1, 100)
    local f17_local2 = f17_arg0:GetRandam_Float(1, 2)
    local f17_local3 = -1
    local f17_local4 = 0
    if f17_arg0:GetNumber(2) <= 0 then
        f17_arg0:SetNumber(2, 1)
        f17_arg0:SetTimer(1, 10)
    end
    if SpaceCheck(f17_arg0, f17_arg1, 90, 1) == true then
        if SpaceCheck(f17_arg0, f17_arg1, -90, 1) == true then
            f17_local4 = f17_arg0:GetRandam_Int(0, 1)
        else
            f17_local4 = 1
        end
    elseif SpaceCheck(f17_arg0, f17_arg1, -90, 1) == true then
        f17_local4 = 0
    else
    end
    f17_arg0:AddObserveArea(1, TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 180, 4)
    f17_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, f17_local2, TARGET_ENE_0, f17_local4, f17_arg0:GetRandam_Int(30, 45), true, true, f17_local3)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function KnightofNoblerot_Sc380010_Act22(f18_arg0, f18_arg1, f18_arg2)
    f18_arg0:SetTimer(1, 5)
    f18_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6001, TARGET_ENE_0, 0, AI_DIR_TYPE_B, 0)
    
end

function KnightofNoblerot_Sc380010_Act23(f19_arg0, f19_arg1, f19_arg2)
    local f19_local0 = AI_DIR_TYPE_L
    local f19_local1 = 6002
    f19_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, f19_local1, TARGET_ENE_0, 0, f19_local0, 3)
    
end

function KnightofNoblerot_Sc380010_Act24(f20_arg0, f20_arg1, f20_arg2)
    local f20_local0 = AI_DIR_TYPE_R
    local f20_local1 = 6003
    f20_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, f20_local1, TARGET_ENE_0, 0, f20_local0, 3)
    
end

function KnightofNoblerot_Sc380010_Act29(f21_arg0, f21_arg1, f21_arg2)
    local f21_local0 = 0
    local f21_local1 = f21_arg0:GetRandam_Int(1, 100)
    local f21_local2 = f21_arg0:GetRandam_Float(3, 5)
    local f21_local3 = f21_arg0:GetRandam_Float(5.6, 7.4)
    local f21_local4 = -1
    f21_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, f21_local2, TARGET_ENE_0, f21_local3, TARGET_SELF, true, f21_local4)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function KnightofNoblerot_Sc380010_Act30(f22_arg0, f22_arg1, f22_arg2)
    local f22_local0 = f22_arg0:GetDist(TARGET_ENE_0)
    local f22_local1 = f22_arg0:GetRandam_Float(6, 8)
    local f22_local2 = 12
    local f22_local3 = 0
    f22_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 3, TARGET_ENE_0, f22_local1, TARGET_ENE_0, true, -1)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function KnightofNoblerot_Sc380010_ActAfter_AdjustSpace(f23_arg0, f23_arg1, f23_arg2)
    f23_arg1:AddSubGoal(GOAL_KnightofNoblerot_Sc380010_AfterAttackAct, 10)
    
end

Goal.Update = function (f24_arg0, f24_arg1, f24_arg2)
    return Update_Default_NoSubGoal(f24_arg0, f24_arg1, f24_arg2)
    
end

Goal.Terminate = function (f25_arg0, f25_arg1, f25_arg2)
    
end

Goal.Interrupt = function (f26_arg0, f26_arg1, f26_arg2)
    local f26_local0 = f26_arg1:GetDist(TARGET_ENE_0)
    local f26_local1 = 5 - f26_arg1:GetMapHitRadius(TARGET_SELF)
    local f26_local2 = f26_arg1:GetRandam_Int(1, 100)
    local f26_local3 = f26_arg1:GetRandam_Int(1, 100)
    local f26_local4 = f26_arg1:GetHpRate(TARGET_SELF)
    if f26_arg1:IsLadderAct(TARGET_SELF) then
        return false
    end
    if f26_arg1:HasSpecialEffectId(TARGET_SELF, 5110) == true or f26_arg1:HasSpecialEffectAttribute(TARGET_SELF, SP_EFFECT_TYPE_SLEEP) == true then
        return false
    end
    if f26_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) then
        if f26_arg1:GetSpecialEffectActivateInterruptId(5025) then
            if f26_arg1:IsInsideTargetEx(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 270, 3.7 - f26_arg1:GetMapHitRadius(TARGET_SELF)) and f26_local2 >= 10 then
                f26_arg2:ClearSubGoal()
                f26_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 3, 3001, TARGET_ENE_0, 999, 0, 0)
                return true
            end
        elseif f26_arg1:GetSpecialEffectActivateInterruptId(5026) then
            if f26_arg1:IsInsideTargetEx(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 270, 4.7 - f26_arg1:GetMapHitRadius(TARGET_SELF) - 1.5) and f26_local3 >= 25 then
                f26_arg2:ClearSubGoal()
                f26_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 3, 3002, TARGET_ENE_0, 999, 0, 0)
                return true
            end
        elseif f26_arg1:GetSpecialEffectActivateInterruptId(5027) then
            if f26_arg1:IsInsideTargetEx(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 270, 10) and f26_local0 >= 3 then
                f26_arg2:ClearSubGoal()
                f26_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 3, 3029, TARGET_ENE_0, 999, 0, 0)
                return true
            elseif f26_arg1:IsInsideTargetEx(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 270, 5.6 - f26_arg1:GetMapHitRadius(TARGET_SELF) - 1) then
                f26_arg2:ClearSubGoal()
                f26_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 3, 3011, TARGET_ENE_0, 999, 0, 0)
                return true
            end
        elseif f26_arg1:GetSpecialEffectActivateInterruptId(5028) then
            if f26_arg1:IsInsideTargetEx(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 270, 5.9 - f26_arg1:GetMapHitRadius(TARGET_SELF) - 1) then
                f26_arg2:ClearSubGoal()
                f26_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 3, 3012, TARGET_ENE_0, 999, 0, 0)
                return true
            end
        elseif f26_arg1:GetSpecialEffectActivateInterruptId(5029) then
            if f26_arg1:IsInsideTargetEx(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_R, 270, 3.7 - f26_arg1:GetMapHitRadius(TARGET_SELF) - 0.5) and f26_local2 >= 41 then
                f26_arg2:ClearSubGoal()
                f26_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 3, 3001, TARGET_ENE_0, 999, 0, 0)
                return true
            elseif f26_arg1:IsInsideTargetEx(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_R, 270, 6 - f26_arg1:GetMapHitRadius(TARGET_SELF)) then
                f26_arg2:ClearSubGoal()
                f26_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 3, 3025, TARGET_ENE_0, 999, 0, 0)
                return true
            else
                f26_arg2:ClearSubGoal()
                f26_arg1:Replaning()
                return true
            end
        elseif f26_arg1:GetSpecialEffectActivateInterruptId(5033) then
            if f26_arg1:IsInsideTargetEx(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_R, 270, 5.6 - f26_arg1:GetMapHitRadius(TARGET_SELF) + 0.5) then
                f26_arg2:ClearSubGoal()
                f26_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 3, 3011, TARGET_ENE_0, 999, 0, 0)
                return true
            end
        elseif f26_arg1:GetSpecialEffectActivateInterruptId(5034) then
            if f26_arg1:IsInsideTargetEx(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_R, 270, 5.9 - f26_arg1:GetMapHitRadius(TARGET_SELF) + 0.5) then
                f26_arg2:ClearSubGoal()
                f26_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 3, 3012, TARGET_ENE_0, 999, 0, 0)
                return true
            end
        elseif f26_arg1:GetSpecialEffectActivateInterruptId(5035) then
            if f26_local0 >= 6 then
                f26_arg2:ClearSubGoal()
                f26_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 3, 3029, TARGET_ENE_0, 999, 0, 0)
                return true
            elseif f26_arg1:IsInsideTargetEx(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 210, 4 - f26_arg1:GetMapHitRadius(TARGET_SELF) + 0.5) then
                f26_arg2:ClearSubGoal()
                f26_arg1:SetTimer(1, 5)
                f26_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 3, 3003, TARGET_ENE_0, 999, 0, 0)
                return true
            else
                f26_arg2:ClearSubGoal()
                f26_arg1:SetTimer(1, 5)
                f26_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6001, TARGET_ENE_0, 0, AI_DIR_TYPE_B, 0)
                return true
            end
        end
    end
    if f26_arg1:IsInterupt(INTERUPT_Inside_ObserveArea) and f26_arg1:IsInsideObserve(1) then
        f26_arg2:ClearSubGoal()
        f26_arg1:Replaning()
        return true
    end
    if f26_arg1:IsInterupt(INTERUPT_Shoot) then
        if f26_local2 >= 50 then
            if SpaceCheck(f26_arg1, f26_arg2, -90, 5) == true then
                if SpaceCheck(f26_arg1, f26_arg2, 90, 5) == false then
                    f26_arg2:ClearSubGoal()
                    f26_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 1, 6002, TARGET_ENE_0, 0, AI_DIR_TYPE_L, 3)
                    return true
                elseif f26_local3 >= 51 then
                    f26_arg2:ClearSubGoal()
                    f26_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 1, 6002, TARGET_ENE_0, 0, AI_DIR_TYPE_L, 3)
                    return true
                else
                    f26_arg2:ClearSubGoal()
                    f26_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 1, 6003, TARGET_ENE_0, 0, AI_DIR_TYPE_R, 3)
                    return true
                end
            elseif SpaceCheck(f26_arg1, f26_arg2, 90, 5) == true then
                f26_arg2:ClearSubGoal()
                f26_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 1, 6003, TARGET_ENE_0, 0, AI_DIR_TYPE_R, 3)
                return true
            elseif SpaceCheck(f26_arg1, f26_arg2, 180, 5) == true then
                f26_arg2:ClearSubGoal()
                f26_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 1, 6001, TARGET_ENE_0, 0, AI_DIR_TYPE_B, 3)
                return true
            else
                f26_arg2:ClearSubGoal()
                f26_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 1, 6000, TARGET_ENE_0, 0, AI_DIR_TYPE_F, 3)
                return true
            end
        elseif f26_local2 >= 15 then
            if f26_local0 >= 8 then
                f26_arg2:ClearSubGoal()
                f26_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3026, TARGET_ENE_0, 999, 0, 0, 0, 0)
                f26_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 3, 3029, TARGET_ENE_0, 999, 0, 0)
                return true
            elseif f26_local0 >= 5 then
                f26_arg2:ClearSubGoal()
                f26_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 3, 3029, TARGET_ENE_0, 999, 0, 0)
                return true
            end
        end
    end
    if f26_arg1:IsInterupt(INTERUPT_Damaged) and f26_arg1:HasSpecialEffectAttribute(TARGET_SELF, 307) then
        f26_arg2:ClearSubGoal()
        local f26_local5 = 0.5
        local f26_local6 = TARGET_ENE_0
        local f26_local7 = 10
        local f26_local8 = 0
        local f26_local9 = 0
        local f26_local10 = 0
        local f26_local11 = 3006
        f26_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat_SuccessAngle180, f26_local5, f26_local11, f26_local6, f26_local7, 0, 0, 0)
    end
    return false
    
end

RegisterTableGoal(GOAL_KnightofNoblerot_Sc380010_AfterAttackAct, "KnightofNoblerot_Sc380010_AfterAttackAct")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_KnightofNoblerot_Sc380010_AfterAttackAct, true)

Goal.Activate = function (f27_arg0, f27_arg1, f27_arg2)
    
end

Goal.Update = function (f28_arg0, f28_arg1, f28_arg2)
    return Update_Default_NoSubGoal(f28_arg0, f28_arg1, f28_arg2)
    
end


