﻿function CWolf407100_Logic(f1_arg0)
    COMMON_Initialize(f1_arg0)
    if COMMON_EasySetup_Initial(f1_arg0) == false then
        local f1_local0 = f1_arg0:GetEventRequest()
        local f1_local1 = f1_arg0:IsSearchTarget(TARGET_ENE_0)
        f1_arg0:GetStringIndexedNumber("NonCombat_FirstSet")
        f1_arg0:GetStringIndexedNumber("MorningAction")
        f1_arg0:GetStringIndexedNumber("HowlingFlag")
        f1_arg0:GetStringIndexedNumber("BarkFlag")
        if f1_arg0:GetStringIndexedNumber("NonCombat_FirstSet") == 0 and f1_arg0:HasSpecialEffectId(TARGET_SELF, 10416) then
            local f1_local2 = f1_arg0:GetRandam_Int(7, 30)
            local f1_local3 = f1_arg0:GetRandam_Int(40, 70)
            f1_arg0:SetTimer(10, f1_local2)
            f1_arg0:SetStringIndexedNumber("HowlingFlag", 1)
            f1_arg0:SetStringIndexedNumber("NonCombat_FirstSet", 1)
        end
        if f1_arg0:IsFinishTimer(10) == true and f1_arg0:HasSpecialEffectId(TARGET_SELF, 10416) then
            local f1_local2 = f1_arg0:GetRandam_Int(120, 200)
            f1_arg0:SetTimer(10, f1_local2)
            f1_arg0:SetStringIndexedNumber("HowlingFlag", 0)
        end
        if f1_arg0:GetStringIndexedNumber("HowlingFlag") == 0 and f1_arg0:HasSpecialEffectId(TARGET_SELF, 10416) then
            f1_arg0:SetStringIndexedNumber("HowlingFlag", 1)
            f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, 3011, TARGET_ENE_0, 9999, 0, 0, 0, 0)
        end
        if f1_local0 == 100 then
            f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 5, POINT_INITIAL, 0.5, TARGET_SELF, true, -1)
        elseif f1_local0 == 110 then
            f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 5, POINT_INITIAL, 0.5, TARGET_SELF, false, -1)
        elseif RideRequest(f1_arg0, 10, -1) then
            f1_arg0:AddTopGoal(GOAL_COMMON_Mount, 10, 1.2)
        else
            COMMON_EasySetup3(f1_arg0)
        end
    end
    
end

function CWolf407100_Interupt(f2_arg0, f2_arg1)
    
end


