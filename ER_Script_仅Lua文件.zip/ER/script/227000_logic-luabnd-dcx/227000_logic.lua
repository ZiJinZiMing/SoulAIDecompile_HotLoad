﻿function CrabBig227000_Logic(f1_arg0)
    COMMON_Initialize(f1_arg0)
    if COMMON_EasySetup_Initial(f1_arg0) == false then
        local f1_local0 = f1_arg0:GetMovePointNumber()
        local f1_local1 = f1_arg0:GetEventRequest()
        local f1_local2 = f1_arg0:IsSearchTarget(TARGET_ENE_0)
        local f1_local3 = f1_arg0:GetRandam_Int(1, 100)
        if f1_local1 == 100 then
            f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 5, POINT_INITIAL, 0.5, TARGET_SELF, true, -1)
        elseif f1_local1 == 110 then
            f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 5, POINT_INITIAL, 0.5, TARGET_SELF, false, -1)
        else
            local f1_local4 = f1_arg0:GetRandam_Int(1, 100)
            local f1_local5 = f1_arg0:GetRandam_Int(1, 100)
            local f1_local6 = f1_arg0:GetEventRequest()
            local f1_local7 = f1_arg0:IsSearchTarget(TARGET_ENE_0)
            local f1_local8 = f1_arg0:GetDist(POINT_INITIAL)
            local f1_local9 = GetCurrentTimeType(f1_arg0)
            local f1_local10 = f1_arg0:GetPrevTargetState()
            local f1_local11 = f1_arg0:GetCurrTargetState()
            local f1_local12 = f1_arg0:IsBattleState()
            local f1_local13 = f1_arg0:IsCautionState()
            local f1_local14 = f1_arg0:HasSpecialEffectId(TARGET_SELF, 12048)
            if f1_arg0:IsSearchLowState() == false and f1_arg0:IsSearchHighState() == false and f1_arg0:IsCautionState() == false and f1_arg0:IsMemoryState() == false and f1_arg0:IsBattleState() == false and f1_local14 == true then
                if f1_local4 > 70 or f1_arg0:GetNumber(3) >= 2 then
                    f1_arg0:SetNumber(3, 0)
                    f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, 3022, TARGET_NONE, DIST_None, 0, 0)
                    f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, 3023, TARGET_NONE, DIST_None, 0, 0)
                    f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, 3024, TARGET_NONE, DIST_None, 0, 0)
                elseif f1_local4 > 20 then
                    f1_arg0:SetNumber(3, f1_arg0:GetNumber(3) + 1)
                    COMMON_EasySetup3(f1_arg0)
                else
                    f1_arg0:AddTopGoal(GOAL_COMMON_WalkAround_Anywhere, -1, 5, 10, true, -1, 3, 1, false, false)
                end
            else
                COMMON_EasySetup3(f1_arg0)
            end
        end
    end
    
end

function CrabBig227000_Interupt(f2_arg0, f2_arg1)
    return false
    
end


