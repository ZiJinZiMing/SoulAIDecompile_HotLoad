﻿function StormHawk421000_Logic(f1_arg0)
    COMMON_Initialize(f1_arg0)
    if COMMON_EasySetup_Initial(f1_arg0) == false then
        local f1_local0 = f1_arg0:GetEventRequest()
        local f1_local1 = f1_arg0:IsSearchTarget(TARGET_ENE_0)
        if f1_local0 == 100 then
            f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 5, POINT_INITIAL, 0.5, TARGET_SELF, true, -1)
        elseif f1_local0 == 110 then
            f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 5, POINT_INITIAL, 0.5, TARGET_SELF, false, -1)
        elseif f1_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_BUDDY_DECLARE) == true then
            if f1_arg0:HasSpecialEffectId(TARGET_SELF, 5400) == true and f1_arg0:HasSpecialEffectId(TARGET_SELF, 10920) == true then
                f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 5, 3020, TARGET_SELF, 9998, 0, 0, 0, 0)
            elseif f1_arg0:HasSpecialEffectId(TARGET_SELF, 5020) == true and f1_arg0:HasSpecialEffectId(TARGET_SELF, 10946) == false and f1_arg0:HasSpecialEffectId(TARGET_SELF, 10945) == false then
                f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, 3015, TARGET_LOCALPLAYER, 999, 0, 0, 0, 0)
            else
                COMMON_EasySetup3(f1_arg0)
            end
        elseif f1_arg0:HasSpecialEffectId(TARGET_SELF, 5400) == true and f1_arg0:IsSearchLowState() == false and f1_arg0:IsSearchHighState() == false and f1_arg0:IsCautionState() == false and f1_arg0:IsBattleState() == false then
            f1_arg0:AddTopGoal(GOAL_COMMON_Wait, 1, TARGET_NONE)
        elseif f1_arg0:HasSpecialEffectId(TARGET_SELF, 5400) == true and (f1_arg0:IsSearchLowState() == true or f1_arg0:IsSearchHighState() == true or f1_arg0:IsCautionState() == true or f1_arg0:IsBattleState() == true) then
            if f1_arg0:HasSpecialEffectId(TARGET_SELF, 10920) == true then
                f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 5, 3020, TARGET_SELF, 9998, 0, 0, 0, 0)
            else
                f1_arg0:AddTopGoal(GOAL_COMMON_Wait, 1, TARGET_NONE)
            end
        elseif f1_arg0:HasSpecialEffectId(TARGET_SELF, 5401) == true and f1_arg0:IsSearchLowState() == false and f1_arg0:IsSearchHighState() == false and f1_arg0:IsCautionState() == false and f1_arg0:IsBattleState() == false and f1_arg0:IsMemoryState() == false and f1_arg0:GetDistXZ(POINT_INITIAL) < 1 then
            f1_arg0:SetAIFixedMoveTargetSpecifyAngle(TARGET_SELF, 180, 1, AI_SPA_DIR_TYPE_TargetF)
            f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 5, 3020, POINT_AI_FIXED_POS, 9999, 5, 20, 0, 0)
        elseif f1_arg0:HasSpecialEffectId(TARGET_SELF, 5401) == true and f1_arg0:HasSpecialEffectId(TARGET_SELF, 10907) and f1_arg0:CheckDoesExistPath(POINT_INITIAL, AI_DIR_TYPE_F, 0) and f1_arg0:IsSearchLowState() == false and f1_arg0:IsSearchHighState() == false and f1_arg0:IsCautionState() == false and f1_arg0:IsBattleState() == false and f1_arg0:IsMemoryState() == false then
            f1_arg0:AddTopGoal(GOAL_COMMON_BackToHome, 0.5, nil, true, nil, nil, POINT_INITIAL)
        else
            COMMON_EasySetup3(f1_arg0)
        end
    end
    
end

function StormHawk421000_Interupt(f2_arg0, f2_arg1)
    
end


