﻿function RottenDead_366100_Logic(f1_arg0)
    COMMON_Initialize(f1_arg0)
    local f1_local0 = f1_arg0:GetPrevTargetState()
    if COMMON_EasySetup_Initial(f1_arg0) == false then
        local f1_local1 = f1_arg0:GetMovePointNumber()
        local f1_local2 = f1_arg0:GetEventRequest()
        local f1_local3 = f1_arg0:IsSearchTarget(TARGET_ENE_0)
        local f1_local4 = f1_arg0:GetRandam_Int(1, 100)
        f1_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
        if f1_local2 == 100 then
            f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 5, POINT_INITIAL, 0.5, TARGET_SELF, true, -1)
        elseif f1_local2 == 110 then
            f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 5, POINT_INITIAL, 0.5, TARGET_SELF, false, -1)
        else
            local f1_local5 = f1_arg0:HasSpecialEffectId(TARGET_SELF, 17005)
            local f1_local6 = f1_arg0:HasSpecialEffectId(TARGET_SELF, 13471)
            local f1_local7 = f1_arg0:HasSpecialEffectId(TARGET_SELF, 17048)
            if f1_arg0:IsBattleState() == false and f1_arg0:IsSearchLowState() == false and f1_arg0:IsSearchHighState() == false and f1_arg0:IsCautionState() == false and f1_arg0:IsMemoryState() == false and f1_local1 == -1 and f1_arg0:IsValidPlatoon() == false then
                if f1_local7 == true then
                    local f1_local8 = 2
                    local f1_local9 = 10
                    local f1_local10 = true
                    local f1_local11 = 3020
                    local f1_local12 = 7
                    local f1_local13 = 1
                    local f1_local14 = false
                    local f1_local15 = true
                    local f1_local16 = true
                    f1_arg0:SetStringIndexedNumber("WalkBefore", 1)
                    local f1_local17 = f1_arg0:GetRandam_Int(1, 100)
                    f1_arg0:SetNumber(0, 0)
                    local f1_local18 = f1_arg0:GetRandam_Int(3, 7)
                    if f1_local17 > 80 then
                        f1_arg0:AddTopGoal(GOAL_COMMON_WalkAround_Anywhere, -1, 1, 6, true, 3007, f1_local18, 1, false, false, true)
                    else
                        f1_arg0:AddTopGoal(GOAL_COMMON_WalkAround_Anywhere, -1, 1, 6, true, -1, 0, 1, false, false, true)
                    end
                else
                    COMMON_EasySetup3(f1_arg0)
                end
            else
                COMMON_EasySetup3(f1_arg0)
            end
        end
    end
    
end

function RottenDead_366100_Interupt(f2_arg0, f2_arg1)
    if Damaged_Act(f2_arg0, f2_arg1, distNearRes, oddsNearRes) then
        f2_arg1:ClearSubGoal()
        return true
    end
    if f2_arg0:HasSpecialEffectId(TARGET_SELF, 16489) and (f2_arg0:IsBattleState() == true or f2_arg0:IsSearchLowState() == true or f2_arg0:IsSearchHighState() == true or f2_arg0:IsCautionState() == true or f2_arg0:IsMemoryState() == true) then
        f2_arg1:ClearSubGoal()
        return true
    end
    return false
    
end


