﻿RegisterTableGoal(GOAL_LossRaceSoldierSword300010_Battle, "LossRaceSoldierSword300010_Battle")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_LossRaceSoldierSword300010_Battle, true)

Goal.Initialize = function (f1_arg0, f1_arg1, f1_arg2, f1_arg3)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3000)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3001)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3002)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3003)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3005)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3014)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3015)
    
end

Goal.Activate = function (f2_arg0, f2_arg1, f2_arg2)
    Init_Pseudo_Global(f2_arg1, f2_arg2)
    f2_arg1:SetStringIndexedNumber("Dist_SideStep", 5)
    f2_arg1:SetStringIndexedNumber("Dist_BackStep", 5)
    local f2_local0 = {}
    local f2_local1 = {}
    local f2_local2 = {}
    Common_Clear_Param(f2_local0, f2_local1, f2_local2)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 10191)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_ENE_0, 10859)
    local f2_local3 = f2_arg1:GetDist(TARGET_ENE_0)
    local f2_local4 = f2_arg1:GetRandam_Int(1, 100)
    local f2_local5 = f2_arg1:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__thinkAttr_doAdmirer)
    local f2_local6 = f2_arg1:GetEventRequest()
    local f2_local7 = 1
    if f2_arg1:GetNumber(5) == 1 then
        f2_local7 = 2
        f2_arg1:SetNumber(5, 0)
    end
    if f2_arg1:HasSpecialEffectId(TARGET_SELF, 19007) then
        if f2_local3 >= 7 then
            f2_local0[42] = 10
        else
            f2_local0[42] = 10
            f2_local0[46] = 3
            f2_local0[47] = 3
        end
    elseif f2_local5 == 1 and f2_arg1:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Kankyaku then
        if f2_local3 >= 5 then
            if f2_arg1:IsInsideTarget(TARGET_FRI_0, AI_DIR_TYPE_L, 180) then
                f2_local0[26] = 30
                f2_local0[40] = 55
            elseif f2_arg1:IsInsideTarget(TARGET_FRI_0, AI_DIR_TYPE_R, 180) then
                f2_local0[27] = 30
                f2_local0[40] = 55
            else
                f2_local0[43] = 30
                f2_local0[40] = 55
            end
        elseif f2_local3 >= 3 then
            if f2_arg1:IsInsideTarget(TARGET_FRI_0, AI_DIR_TYPE_L, 180) then
                f2_local0[6] = 5
                f2_local0[3] = 5
                f2_local0[45] = 25
                f2_local0[26] = 55
            elseif f2_arg1:IsInsideTarget(TARGET_FRI_0, AI_DIR_TYPE_R, 180) then
                f2_local0[6] = 5
                f2_local0[3] = 5
                f2_local0[45] = 25
                f2_local0[27] = 55
            else
                f2_local0[6] = 5
                f2_local0[3] = 5
                f2_local0[5] = 5
                f2_local0[45] = 20
                f2_local0[43] = 55
            end
        else
            f2_local0[45] = 90
            f2_local0[43] = 5
        end
    elseif f2_local5 == 1 and f2_arg1:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Torimaki then
        if f2_local3 >= 5 then
            if f2_arg1:IsInsideTarget(TARGET_FRI_0, AI_DIR_TYPE_L, 180) then
                f2_local0[3] = 5
                f2_local0[26] = 25
                f2_local0[40] = 60
                f2_local0[30] = 10
                f2_local0[31] = 10
            elseif f2_arg1:IsInsideTarget(TARGET_FRI_0, AI_DIR_TYPE_R, 180) then
                f2_local0[3] = 5
                f2_local0[27] = 25
                f2_local0[40] = 60
                f2_local0[30] = 10
                f2_local0[31] = 10
            else
                f2_local0[3] = 5
                f2_local0[42] = 5
                f2_local0[43] = 25
                f2_local0[40] = 60
                f2_local0[30] = 10
                f2_local0[31] = 10
            end
        elseif f2_local3 >= 3 then
            if f2_arg1:IsInsideTarget(TARGET_FRI_0, AI_DIR_TYPE_L, 180) then
                f2_local0[6] = 20
                f2_local0[3] = 5
                f2_local0[45] = 25
                f2_local0[26] = 35
                f2_local0[31] = 10
            elseif f2_arg1:IsInsideTarget(TARGET_FRI_0, AI_DIR_TYPE_R, 180) then
                f2_local0[6] = 20
                f2_local0[3] = 5
                f2_local0[45] = 25
                f2_local0[27] = 35
                f2_local0[31] = 10
            else
                f2_local0[6] = 35
                f2_local0[3] = 5
                f2_local0[45] = 20
                f2_local0[43] = 25
                f2_local0[31] = 10
            end
        else
            f2_local0[1] = 5
            f2_local0[5] = 50
            f2_local0[45] = 40
            f2_local0[43] = 5
            f2_local0[32] = 10
        end
    elseif f2_local3 >= 7 then
        f2_local0[3] = 20
        f2_local0[4] = 10
        f2_local0[6] = 15
        f2_local0[7] = 20
        f2_local0[18] = 15 * f2_local7
        f2_local0[41] = 10
        f2_local0[43] = 10
        f2_local0[30] = 10
    elseif f2_local3 >= 5 then
        f2_local0[1] = 30
        f2_local0[3] = 15
        f2_local0[4] = 10
        f2_local0[6] = 15
        f2_local0[7] = 5
        f2_local0[18] = 20 * f2_local7
        f2_local0[42] = 15
        f2_local0[30] = 10
        f2_local0[31] = 10
    elseif f2_local3 >= 3 then
        f2_local0[1] = 15
        f2_local0[2] = 30
        f2_local0[3] = 10
        f2_local0[4] = 15
        f2_local0[6] = 5
        f2_local0[18] = 15 * f2_local7
        f2_local0[42] = 10
        f2_local0[47] = 5
        f2_local0[31] = 10
        f2_local0[32] = 10
    else
        f2_local0[2] = 5
        f2_local0[5] = 30
        f2_local0[8] = 20
        f2_local0[9] = 10
        f2_local0[42] = 10
        f2_local0[46] = 5
        f2_local0[47] = 5
        f2_local0[32] = 10
    end
    f2_arg1:SetNumber(2, 0)
    f2_local0[1] = SetCoolTime(f2_arg1, f2_arg2, 3000, 10, f2_local0[1], 0)
    f2_local0[3] = SetCoolTime(f2_arg1, f2_arg2, 3000, 10, f2_local0[1], 0)
    f2_local0[2] = SetCoolTime(f2_arg1, f2_arg2, 3002, 10, f2_local0[2], 0)
    f2_local0[4] = SetCoolTime(f2_arg1, f2_arg2, 3002, 10, f2_local0[4], 0)
    f2_local0[5] = SetCoolTime(f2_arg1, f2_arg2, 3004, 5, f2_local0[5], 1)
    f2_local0[18] = SetCoolTime(f2_arg1, f2_arg2, 3017, 10, f2_local0[18], 0)
    if f2_arg1:HasSpecialEffectId(TARGET_SELF, 10880) == false then
        f2_local0[30] = 0
        f2_local0[31] = 0
        f2_local0[32] = 0
    end
    if f2_arg1:HasSpecialEffectId(TARGET_SELF, 10859) then
        f2_local0[30] = 0
        f2_local0[31] = 0
        f2_local0[32] = 0
    end
    f2_local1[1] = REGIST_FUNC(f2_arg1, f2_arg2, LossRaceSoldierSword300010_Act01)
    f2_local1[2] = REGIST_FUNC(f2_arg1, f2_arg2, LossRaceSoldierSword300010_Act02)
    f2_local1[3] = REGIST_FUNC(f2_arg1, f2_arg2, LossRaceSoldierSword300010_Act03)
    f2_local1[4] = REGIST_FUNC(f2_arg1, f2_arg2, LossRaceSoldierSword300010_Act04)
    f2_local1[5] = REGIST_FUNC(f2_arg1, f2_arg2, LossRaceSoldierSword300010_Act05)
    f2_local1[6] = REGIST_FUNC(f2_arg1, f2_arg2, LossRaceSoldierSword300010_Act06)
    f2_local1[7] = REGIST_FUNC(f2_arg1, f2_arg2, LossRaceSoldierSword300010_Act07)
    f2_local1[8] = REGIST_FUNC(f2_arg1, f2_arg2, LossRaceSoldierSword300010_Act08)
    f2_local1[9] = REGIST_FUNC(f2_arg1, f2_arg2, LossRaceSoldierSword300010_Act09)
    f2_local1[10] = REGIST_FUNC(f2_arg1, f2_arg2, LossRaceSoldierSword300010_Act10)
    f2_local1[11] = REGIST_FUNC(f2_arg1, f2_arg2, LossRaceSoldierSword300010_Act11)
    f2_local1[18] = REGIST_FUNC(f2_arg1, f2_arg2, LossRaceSoldierSword300010_Act18)
    f2_local1[20] = REGIST_FUNC(f2_arg1, f2_arg2, LossRaceSoldierSword300010_Act20)
    f2_local1[21] = REGIST_FUNC(f2_arg1, f2_arg2, LossRaceSoldierSword300010_Act21)
    f2_local1[22] = REGIST_FUNC(f2_arg1, f2_arg2, LossRaceSoldierSword300010_Act22)
    f2_local1[23] = REGIST_FUNC(f2_arg1, f2_arg2, LossRaceSoldierSword300010_Act23)
    f2_local1[24] = REGIST_FUNC(f2_arg1, f2_arg2, LossRaceSoldierSword300010_Act24)
    f2_local1[25] = REGIST_FUNC(f2_arg1, f2_arg2, LossRaceSoldierSword300010_Act25)
    f2_local1[26] = REGIST_FUNC(f2_arg1, f2_arg2, LossRaceSoldierSword300010_Act26)
    f2_local1[27] = REGIST_FUNC(f2_arg1, f2_arg2, LossRaceSoldierSword300010_Act27)
    f2_local1[30] = REGIST_FUNC(f2_arg1, f2_arg2, LossRaceSoldierSword300010_Act30)
    f2_local1[31] = REGIST_FUNC(f2_arg1, f2_arg2, LossRaceSoldierSword300010_Act31)
    f2_local1[32] = REGIST_FUNC(f2_arg1, f2_arg2, LossRaceSoldierSword300010_Act32)
    f2_local1[40] = REGIST_FUNC(f2_arg1, f2_arg2, LossRaceSoldierSword300010_Act40)
    f2_local1[41] = REGIST_FUNC(f2_arg1, f2_arg2, LossRaceSoldierSword300010_Act41)
    f2_local1[42] = REGIST_FUNC(f2_arg1, f2_arg2, LossRaceSoldierSword300010_Act42)
    f2_local1[43] = REGIST_FUNC(f2_arg1, f2_arg2, LossRaceSoldierSword300010_Act43)
    f2_local1[44] = REGIST_FUNC(f2_arg1, f2_arg2, LossRaceSoldierSword300010_Act44)
    f2_local1[45] = REGIST_FUNC(f2_arg1, f2_arg2, LossRaceSoldierSword300010_Act45)
    f2_local1[46] = REGIST_FUNC(f2_arg1, f2_arg2, LossRaceSoldierSword300010_Act46)
    f2_local1[47] = REGIST_FUNC(f2_arg1, f2_arg2, LossRaceSoldierSword300010_Act47)
    f2_local1[48] = REGIST_FUNC(f2_arg1, f2_arg2, LossRaceSoldierSword300010_Act48)
    local f2_local8 = REGIST_FUNC(f2_arg1, f2_arg2, LossRaceSoldierSword300010_ActAfter_AdjustSpace)
    Common_Battle_Activate(f2_arg1, f2_arg2, f2_local0, f2_local1, f2_local8, f2_local2)
    
end

function LossRaceSoldierSword300010_Act01(f3_arg0, f3_arg1, f3_arg2)
    local f3_local0 = 4
    local f3_local1 = 0
    local f3_local2 = 999
    local f3_local3 = 0
    local f3_local4 = 0
    local f3_local5 = 1.5
    local f3_local6 = 1.5
    Approach_Act_Flex(f3_arg0, f3_arg1, f3_local0, f3_local1, f3_local2, f3_local3, f3_local4, f3_local5, f3_local6)
    local f3_local7 = 3000
    local f3_local8 = 3001
    local f3_local9 = 3002
    local f3_local10 = 2 - f3_arg0:GetMapHitRadius(TARGET_SELF)
    local f3_local11 = 2 - f3_arg0:GetMapHitRadius(TARGET_SELF)
    local f3_local12 = 2 - f3_arg0:GetMapHitRadius(TARGET_SELF)
    local f3_local13 = 5 - f3_arg0:GetMapHitRadius(TARGET_SELF)
    local f3_local14 = 0
    local f3_local15 = 0
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f3_local7, TARGET_ENE_0, f3_local10, f3_local14, f3_local15, 0, 0)
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat_SuccessAngle180, 10, f3_local8, TARGET_ENE_0, f3_local11, 0, 0)
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 10, f3_local9, TARGET_ENE_0, 5 - f3_arg0:GetMapHitRadius(TARGET_SELF), 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function LossRaceSoldierSword300010_Act02(f4_arg0, f4_arg1, f4_arg2)
    local f4_local0 = 2.5
    local f4_local1 = 0
    local f4_local2 = 999
    local f4_local3 = 0
    local f4_local4 = 0
    local f4_local5 = 1.5
    local f4_local6 = 1.5
    Approach_Act_Flex(f4_arg0, f4_arg1, f4_local0, f4_local1, f4_local2, f4_local3, f4_local4, f4_local5, f4_local6)
    local f4_local7 = 3002
    local f4_local8 = 3005
    local f4_local9 = 3001
    local f4_local10 = 2 - f4_arg0:GetMapHitRadius(TARGET_SELF)
    local f4_local11 = 2 - f4_arg0:GetMapHitRadius(TARGET_SELF)
    local f4_local12 = 2 - f4_arg0:GetMapHitRadius(TARGET_SELF)
    local f4_local13 = 5 - f4_arg0:GetMapHitRadius(TARGET_SELF)
    local f4_local14 = 0
    local f4_local15 = 0
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f4_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f4_local7, TARGET_ENE_0, f4_local10, f4_local14, f4_local15, 0, 0)
    f4_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat_SuccessAngle180, 10, f4_local8, TARGET_ENE_0, f4_local11, 0, 0)
    f4_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 10, f4_local9, TARGET_ENE_0, 5 - f4_arg0:GetMapHitRadius(TARGET_SELF), 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function LossRaceSoldierSword300010_Act03(f5_arg0, f5_arg1, f5_arg2)
    local f5_local0 = 4
    local f5_local1 = 999
    local f5_local2 = 0
    local f5_local3 = 0
    local f5_local4 = 0
    local f5_local5 = 1.5
    local f5_local6 = 1.5
    Approach_Act_Flex(f5_arg0, f5_arg1, f5_local0, f5_local1, f5_local2, f5_local3, f5_local4, f5_local5, f5_local6)
    local f5_local7 = 3000
    local f5_local8 = 3001
    local f5_local9 = 3002
    local f5_local10 = 2 - f5_arg0:GetMapHitRadius(TARGET_SELF)
    local f5_local11 = 2 - f5_arg0:GetMapHitRadius(TARGET_SELF)
    local f5_local12 = 2 - f5_arg0:GetMapHitRadius(TARGET_SELF)
    local f5_local13 = 5 - f5_arg0:GetMapHitRadius(TARGET_SELF)
    local f5_local14 = 0
    local f5_local15 = 0
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f5_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f5_local7, TARGET_ENE_0, f5_local10, f5_local14, f5_local15, 0, 0)
    f5_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat_SuccessAngle180, 10, f5_local8, TARGET_ENE_0, f5_local11, 0, 0)
    f5_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 10, f5_local9, TARGET_ENE_0, 5 - f5_arg0:GetMapHitRadius(TARGET_SELF), 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function LossRaceSoldierSword300010_Act04(f6_arg0, f6_arg1, f6_arg2)
    local f6_local0 = 2.5
    local f6_local1 = 999
    local f6_local2 = 0
    local f6_local3 = 0
    local f6_local4 = 0
    local f6_local5 = 1.5
    local f6_local6 = 1.5
    Approach_Act_Flex(f6_arg0, f6_arg1, f6_local0, f6_local1, f6_local2, f6_local3, f6_local4, f6_local5, f6_local6)
    local f6_local7 = 3002
    local f6_local8 = 3005
    local f6_local9 = 3001
    local f6_local10 = 2 - f6_arg0:GetMapHitRadius(TARGET_SELF)
    local f6_local11 = 2 - f6_arg0:GetMapHitRadius(TARGET_SELF)
    local f6_local12 = 2 - f6_arg0:GetMapHitRadius(TARGET_SELF)
    local f6_local13 = 5 - f6_arg0:GetMapHitRadius(TARGET_SELF)
    local f6_local14 = 0
    local f6_local15 = 0
    f6_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f6_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    f6_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f6_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f6_local7, TARGET_ENE_0, f6_local10, f6_local14, f6_local15, 0, 0)
    f6_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat_SuccessAngle180, 10, f6_local8, TARGET_ENE_0, f6_local11, 0, 0)
    f6_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 10, f6_local9, TARGET_ENE_0, 5 - f6_arg0:GetMapHitRadius(TARGET_SELF), 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function LossRaceSoldierSword300010_Act05(f7_arg0, f7_arg1, f7_arg2)
    local f7_local0 = 3004
    local f7_local1 = 5 - f7_arg0:GetMapHitRadius(TARGET_SELF)
    local f7_local2 = 0
    local f7_local3 = 0
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f7_arg0:SetNumber(5, 1)
    f7_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f7_local0, TARGET_ENE_0, f7_local1, f7_local2, f7_local3, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function LossRaceSoldierSword300010_Act06(f8_arg0, f8_arg1, f8_arg2)
    local f8_local0 = 6
    local f8_local1 = 0
    local f8_local2 = 999
    local f8_local3 = 0
    local f8_local4 = 100
    local f8_local5 = 4
    local f8_local6 = 8
    Approach_Act_Flex(f8_arg0, f8_arg1, f8_local0, f8_local1, f8_local2, f8_local3, f8_local4, f8_local5, f8_local6)
    local f8_local7 = 3003
    local f8_local8 = 5 - f8_arg0:GetMapHitRadius(TARGET_SELF)
    local f8_local9 = 0
    local f8_local10 = 0
    f8_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f8_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    f8_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f8_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f8_local7, TARGET_ENE_0, f8_local8, f8_local9, f8_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function LossRaceSoldierSword300010_Act07(f9_arg0, f9_arg1, f9_arg2)
    local f9_local0 = 6.5
    local f9_local1 = 999
    local f9_local2 = 0
    local f9_local3 = 0
    local f9_local4 = 0
    local f9_local5 = 4
    local f9_local6 = 8
    Approach_Act_Flex(f9_arg0, f9_arg1, f9_local0, f9_local1, f9_local2, f9_local3, f9_local4, f9_local5, f9_local6)
    local f9_local7 = 3003
    local f9_local8 = 5 - f9_arg0:GetMapHitRadius(TARGET_SELF)
    local f9_local9 = 0
    local f9_local10 = 0
    f9_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f9_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    f9_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f9_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f9_local7, TARGET_ENE_0, f9_local8, f9_local9, f9_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function LossRaceSoldierSword300010_Act08(f10_arg0, f10_arg1, f10_arg2)
    local f10_local0 = 3
    local f10_local1 = 0
    local f10_local2 = 999
    local f10_local3 = 0
    local f10_local4 = 0
    local f10_local5 = 1.5
    local f10_local6 = 1.5
    Approach_Act_Flex(f10_arg0, f10_arg1, f10_local0, f10_local1, f10_local2, f10_local3, f10_local4, f10_local5, f10_local6)
    local f10_local7 = 3005
    local f10_local8 = 3001
    local f10_local9 = 3002
    local f10_local10 = 2 - f10_arg0:GetMapHitRadius(TARGET_SELF)
    local f10_local11 = 2 - f10_arg0:GetMapHitRadius(TARGET_SELF)
    local f10_local12 = 2 - f10_arg0:GetMapHitRadius(TARGET_SELF)
    local f10_local13 = 5 - f10_arg0:GetMapHitRadius(TARGET_SELF)
    local f10_local14 = 0
    local f10_local15 = 0
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f10_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f10_local7, TARGET_ENE_0, f10_local10, f10_local14, f10_local15, 0, 0)
    f10_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat_SuccessAngle180, 10, f10_local8, TARGET_ENE_0, f10_local11, 0, 0)
    f10_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 10, f10_local9, TARGET_ENE_0, 5 - f10_arg0:GetMapHitRadius(TARGET_SELF), 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function LossRaceSoldierSword300010_Act09(f11_arg0, f11_arg1, f11_arg2)
    local f11_local0 = 4
    local f11_local1 = 999
    local f11_local2 = 0
    local f11_local3 = 0
    local f11_local4 = 0
    local f11_local5 = 1.5
    local f11_local6 = 1.5
    Approach_Act_Flex(f11_arg0, f11_arg1, f11_local0, f11_local1, f11_local2, f11_local3, f11_local4, f11_local5, f11_local6)
    local f11_local7 = 3005
    local f11_local8 = 3001
    local f11_local9 = 3002
    local f11_local10 = 2 - f11_arg0:GetMapHitRadius(TARGET_SELF)
    local f11_local11 = 2 - f11_arg0:GetMapHitRadius(TARGET_SELF)
    local f11_local12 = 2 - f11_arg0:GetMapHitRadius(TARGET_SELF)
    local f11_local13 = 5 - f11_arg0:GetMapHitRadius(TARGET_SELF)
    local f11_local14 = 0
    local f11_local15 = 0
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f11_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f11_local7, TARGET_ENE_0, f11_local10, f11_local14, f11_local15, 0, 0)
    f11_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat_SuccessAngle180, 10, f11_local8, TARGET_ENE_0, f11_local11, 0, 0)
    f11_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 10, f11_local9, TARGET_ENE_0, 5 - f11_arg0:GetMapHitRadius(TARGET_SELF), 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function LossRaceSoldierSword300010_Act10(f12_arg0, f12_arg1, f12_arg2)
    local f12_local0 = 2 - f12_arg0:GetMapHitRadius(TARGET_SELF)
    local f12_local1 = -999
    local f12_local2 = 2 - f12_arg0:GetMapHitRadius(TARGET_SELF)
    local f12_local3 = 0
    local f12_local4 = 0
    local f12_local5 = 4
    local f12_local6 = 8
    Approach_Act_Flex(f12_arg0, f12_arg1, f12_local0, f12_local1, f12_local2, f12_local3, f12_local4, f12_local5, f12_local6)
    local f12_local7 = 3010
    local f12_local8 = 5 - f12_arg0:GetMapHitRadius(TARGET_SELF)
    local f12_local9 = 0
    local f12_local10 = 0
    f12_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f12_local7, TARGET_ENE_0, f12_local8, f12_local9, f12_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function LossRaceSoldierSword300010_Act11(f13_arg0, f13_arg1, f13_arg2)
    local f13_local0 = 3 - f13_arg0:GetMapHitRadius(TARGET_SELF)
    local f13_local1 = 3 - f13_arg0:GetMapHitRadius(TARGET_SELF)
    local f13_local2 = 3 - f13_arg0:GetMapHitRadius(TARGET_SELF)
    local f13_local3 = 50
    local f13_local4 = 0
    local f13_local5 = 4
    local f13_local6 = 8
    local f13_local7 = 3015
    local f13_local8 = 3014
    local f13_local9 = 2.5 - f13_arg0:GetMapHitRadius(TARGET_SELF)
    local f13_local10 = 2.5 - f13_arg0:GetMapHitRadius(TARGET_SELF)
    local f13_local11 = 5 - f13_arg0:GetMapHitRadius(TARGET_SELF)
    local f13_local12 = 0
    local f13_local13 = 0
    f13_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f13_local7, TARGET_ENE_0, f13_local9, f13_local12, f13_local13, 0, 0)
    f13_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 10, f13_local8, TARGET_ENE_0, 5 - f13_arg0:GetMapHitRadius(TARGET_SELF), 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function LossRaceSoldierSword300010_Act18(f14_arg0, f14_arg1, f14_arg2)
    local f14_local0 = f14_arg0:GetRandam_Int(1, 100)
    f14_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 10186)
    local f14_local1 = 7.5
    local f14_local2 = 0
    local f14_local3 = 999
    local f14_local4 = 0
    local f14_local5 = 0
    local f14_local6 = 1.5
    local f14_local7 = 1.5
    Approach_Act_Flex(f14_arg0, f14_arg1, f14_local1, f14_local2, f14_local3, f14_local4, f14_local5, f14_local6, f14_local7)
    local f14_local8 = 3017
    local f14_local9 = 5.5 - f14_arg0:GetMapHitRadius(TARGET_SELF)
    local f14_local10 = 5 - f14_arg0:GetMapHitRadius(TARGET_SELF)
    local f14_local11 = 0
    local f14_local12 = 0
    local f14_local13 = f14_arg0:GetRandam_Int(1, 100)
    f14_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f14_local8, TARGET_ENE_0, f14_local9, f14_local11, f14_local12, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function LossRaceSoldierSword300010_Act20(f15_arg0, f15_arg1, f15_arg2)
    local f15_local0 = 5.5 - f15_arg0:GetMapHitRadius(TARGET_SELF)
    local f15_local1 = 5.5 - f15_arg0:GetMapHitRadius(TARGET_SELF)
    local f15_local2 = 5.5 - f15_arg0:GetMapHitRadius(TARGET_SELF)
    local f15_local3 = 0
    local f15_local4 = 0
    local f15_local5 = 4
    local f15_local6 = 8
    local f15_local7 = 3010
    local f15_local8 = 5 - f15_arg0:GetMapHitRadius(TARGET_SELF)
    local f15_local9 = 0
    local f15_local10 = 0
    f15_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f15_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    if f15_arg0:HasSpecialEffectId(TARGET_SELF, 10193) and f15_arg0:HasSpecialEffectId(TARGET_SELF, 10190) then
        f15_arg1:AddSubGoal(GOAL_COMMON_Wait, 3, TARGET_ENE_0)
        f15_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f15_local7, TARGET_ENE_0, f15_local8, f15_local9, f15_local10, 0, 0)
    else
        f15_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f15_local7, TARGET_ENE_0, f15_local8, f15_local9, f15_local10, 0, 0)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function LossRaceSoldierSword300010_Act21(f16_arg0, f16_arg1, f16_arg2)
    local f16_local0 = 5.5 - f16_arg0:GetMapHitRadius(TARGET_SELF)
    local f16_local1 = 5.5 - f16_arg0:GetMapHitRadius(TARGET_SELF)
    local f16_local2 = 5.5 - f16_arg0:GetMapHitRadius(TARGET_SELF)
    local f16_local3 = 50
    local f16_local4 = 0
    local f16_local5 = 4
    local f16_local6 = 8
    local f16_local7 = 3011
    local f16_local8 = 5 - f16_arg0:GetMapHitRadius(TARGET_SELF)
    local f16_local9 = 0
    local f16_local10 = 0
    f16_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f16_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    f16_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f16_local7, TARGET_ENE_0, f16_local8, f16_local9, f16_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function LossRaceSoldierSword300010_Act22(f17_arg0, f17_arg1, f17_arg2)
    local f17_local0 = 5.5 - f17_arg0:GetMapHitRadius(TARGET_SELF)
    local f17_local1 = 5.5 - f17_arg0:GetMapHitRadius(TARGET_SELF)
    local f17_local2 = 5.5 - f17_arg0:GetMapHitRadius(TARGET_SELF)
    local f17_local3 = 0
    local f17_local4 = 0
    local f17_local5 = 4
    local f17_local6 = 8
    local f17_local7 = 3012
    local f17_local8 = 5 - f17_arg0:GetMapHitRadius(TARGET_SELF)
    local f17_local9 = 0
    local f17_local10 = 0
    f17_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f17_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    f17_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f17_local7, TARGET_ENE_0, f17_local8, f17_local9, f17_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function LossRaceSoldierSword300010_Act23(f18_arg0, f18_arg1, f18_arg2)
    local f18_local0 = 5.5 - f18_arg0:GetMapHitRadius(TARGET_SELF)
    local f18_local1 = 5.5 - f18_arg0:GetMapHitRadius(TARGET_SELF)
    local f18_local2 = 5.5 - f18_arg0:GetMapHitRadius(TARGET_SELF)
    local f18_local3 = 50
    local f18_local4 = 0
    local f18_local5 = 4
    local f18_local6 = 8
    local f18_local7 = 3013
    local f18_local8 = 5 - f18_arg0:GetMapHitRadius(TARGET_SELF)
    local f18_local9 = 0
    local f18_local10 = 0
    f18_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f18_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    f18_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f18_local7, TARGET_ENE_0, f18_local8, f18_local9, f18_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function LossRaceSoldierSword300010_Act24(f19_arg0, f19_arg1, f19_arg2)
    local f19_local0 = 3008
    local f19_local1 = 5 - f19_arg0:GetMapHitRadius(TARGET_SELF)
    local f19_local2 = 0
    local f19_local3 = 0
    f19_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f19_local0, TARGET_ENE_0, f19_local1, f19_local2, f19_local3, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function LossRaceSoldierSword300010_Act25(f20_arg0, f20_arg1, f20_arg2)
    local f20_local0 = 3009
    local f20_local1 = 5 - f20_arg0:GetMapHitRadius(TARGET_SELF)
    local f20_local2 = 0
    local f20_local3 = 0
    f20_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f20_local0, TARGET_ENE_0, f20_local1, f20_local2, f20_local3, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function LossRaceSoldierSword300010_Act26(f21_arg0, f21_arg1, f21_arg2)
    local f21_local0 = f21_arg0:GetRandam_Int(1, 100)
    local f21_local1 = 0
    local f21_local2 = -1
    if f21_local0 <= f21_local1 then
        f21_local2 = 9910
    end
    f21_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, 2, TARGET_ENE_0, 0, f21_arg0:GetRandam_Int(30, 45), true, true, f21_local2)
    f21_arg0:SetNumber(0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function LossRaceSoldierSword300010_Act27(f22_arg0, f22_arg1, f22_arg2)
    local f22_local0 = f22_arg0:GetRandam_Int(1, 100)
    local f22_local1 = 0
    local f22_local2 = -1
    if f22_local0 <= f22_local1 then
        f22_local2 = 9910
    end
    f22_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, 2, TARGET_ENE_0, 1, f22_arg0:GetRandam_Int(30, 45), true, true, f22_local2)
    f22_arg0:SetNumber(0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function LossRaceSoldierSword300010_Act30(f23_arg0, f23_arg1, f23_arg2)
    local f23_local0 = f23_arg0:GetRandam_Int(1, 100)
    f23_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5029)
    f23_arg0:SetNumber(1, 1)
    f23_arg0:SetNumber(15, 1)
    f23_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6010, TARGET_ENE_0, 0, AI_DIR_TYPE_F, 2)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function LossRaceSoldierSword300010_Act31(f24_arg0, f24_arg1, f24_arg2)
    local f24_local0 = f24_arg0:GetRandam_Int(1, 100)
    f24_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5029)
    f24_arg0:SetNumber(1, 1)
    f24_arg0:SetNumber(15, 1)
    if f24_local0 > 50 then
        f24_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6012, TARGET_ENE_0, 0, AI_DIR_TYPE_L, 2)
    else
        f24_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6013, TARGET_ENE_0, 0, AI_DIR_TYPE_R, 2)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function LossRaceSoldierSword300010_Act32(f25_arg0, f25_arg1, f25_arg2)
    f25_arg0:SetNumber(1, 1)
    local f25_local0 = f25_arg0:GetRandam_Int(1, 100)
    local f25_local1 = f25_arg0:GetRandam_Int(1, 100)
    f25_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5029)
    f25_arg0:SetNumber(1, 1)
    f25_arg0:SetNumber(15, 1)
    f25_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6011, TARGET_ENE_0, 0, AI_DIR_TYPE_B, 2)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function LossRaceSoldierSword300010_Act40(f26_arg0, f26_arg1, f26_arg2)
    f26_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 2, TARGET_ENE_0, 2, TARGET_SELF, true, 9910)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function LossRaceSoldierSword300010_Act41(f27_arg0, f27_arg1, f27_arg2)
    f27_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 2, TARGET_ENE_0, 4, TARGET_SELF, false, -1)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function LossRaceSoldierSword300010_Act42(f28_arg0, f28_arg1, f28_arg2)
    f28_arg0:SetNumber(5, 1)
    f28_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, 3.5, TARGET_ENE_0, f28_arg0:GetRandam_Int(0, 1), f28_arg0:GetRandam_Int(30, 45), true, true, 9910)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function LossRaceSoldierSword300010_Act43(f29_arg0, f29_arg1, f29_arg2)
    f29_arg0:SetNumber(5, 1)
    f29_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, 2, TARGET_ENE_0, f29_arg0:GetRandam_Int(0, 1), f29_arg0:GetRandam_Int(30, 45), true, true, -1)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function LossRaceSoldierSword300010_Act44(f30_arg0, f30_arg1, f30_arg2)
    f30_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f30_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    f30_arg0:SetNumber(5, 1)
    f30_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 1.5, TARGET_ENE_0, 5, TARGET_ENE_0, true, 9910)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function LossRaceSoldierSword300010_Act45(f31_arg0, f31_arg1, f31_arg2)
    f31_arg0:SetNumber(5, 1)
    f31_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 2, TARGET_ENE_0, 5, TARGET_ENE_0, true, -1)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function LossRaceSoldierSword300010_Act46(f32_arg0, f32_arg1, f32_arg2)
    f32_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f32_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    f32_arg1:AddSubGoal(GOAL_COMMON_StepSafety, 5, -1, -1, 1, 1, TARGET_ENE_0, 3, 0, false)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function LossRaceSoldierSword300010_Act47(f33_arg0, f33_arg1, f33_arg2)
    f33_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f33_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    f33_arg1:AddSubGoal(GOAL_COMMON_StepSafety, 5, -1, 1, -1, -1, TARGET_ENE_0, 3, 0, false)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function LossRaceSoldierSword300010_Act48(f34_arg0, f34_arg1, f34_arg2)
    f34_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f34_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    f34_arg1:AddSubGoal(GOAL_COMMON_Wait, 3, TARGET_ENE_0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function LossRaceSoldierSword300010_ActAfter_AdjustSpace(f35_arg0, f35_arg1, f35_arg2)
    f35_arg1:AddSubGoal(GOAL_UncoverTombNobleManRapier430011_AfterAttackAct, 10)
    
end

Goal.Update = function (f36_arg0, f36_arg1, f36_arg2)
    return Update_Default_NoSubGoal(f36_arg0, f36_arg1, f36_arg2)
    
end

Goal.Terminate = function (f37_arg0, f37_arg1, f37_arg2)
    
end

Goal.Interrupt = function (f38_arg0, f38_arg1, f38_arg2)
    local f38_local0 = f38_arg1:GetRandam_Int(1, 100)
    local f38_local1 = f38_arg1:GetRandam_Int(1, 100)
    local f38_local2 = f38_arg1:GetDist(TARGET_ENE_0)
    local f38_local3 = f38_arg1:GetHpRate(TARGET_SELF)
    local f38_local4 = f38_arg1:GetNumber(0)
    local f38_local5 = f38_arg1:GetNumber(1)
    local f38_local6 = f38_arg1:GetRandam_Int(0, 10)
    local f38_local7 = f38_arg1:GetRandam_Int(0, 5)
    if f38_arg1:IsLadderAct(TARGET_SELF) then
        return false
    end
    if f38_arg1:HasSpecialEffectId(TARGET_SELF, 5110) == true or f38_arg1:HasSpecialEffectAttribute(TARGET_SELF, SP_EFFECT_TYPE_SLEEP) == true then
        return false
    end
    if f38_arg1:IsInterupt(INTERUPT_Damaged) and f38_arg1:GetNumber(10) == 0 then
        f38_arg1:SetNumber(10, 1)
        return true
    end
    if f38_arg1:HasSpecialEffectId(TARGET_SELF, 5029) == true and f38_arg1:HasSpecialEffectId(TARGET_ENE_0, 10859) == false then
        local f38_local8 = f38_arg1:GetDist(TARGET_ENE_0)
        local f38_local9 = f38_arg1:GetRandam_Int(1, 100)
        selectFate_ToB = 1
        selectFate_ToBL = 1
        selectFate_ToBR = 1
        selectFate_ToL = 1
        selectFate_ToR = 1
        warpDist_x = f38_arg1:GetRandam_Int(3, 5)
        if f38_arg1:GetNumber(15) == 1 then
            selectFate_ToBL = 0
            selectFate_ToBR = 0
            selectFate_ToL = 0
            selectFate_ToR = 0
        elseif f38_arg1:GetNumber(15) == 2 then
            selectFate_ToB = 0
            warpDist_x = f38_arg1:GetRandam_Int(7, 10)
        elseif f38_arg1:GetNumber(15) == 3 then
            selectFate_ToB = 0
            selectFate_ToBR = 0
            selectFate_ToR = 0
        elseif f38_arg1:GetNumber(15) == 4 then
            selectFate_ToB = 0
            selectFate_ToBL = 0
            selectFate_ToL = 0
        end
        local f38_local10 = 5 - f38_arg1:GetMapHitRadius(TARGET_SELF)
        local f38_local11 = 0
        local f38_local12 = 0
        local f38_local13 = f38_arg1:GetMapHitRadius(TARGET_SELF)
        local f38_local14 = f38_arg1:GetDist(TARGET_ENE_0)
        local f38_local15 = f38_arg1:GetRelativeAngleFromTarget(TARGET_ENE_0)
        if warpDist_x >= f38_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToB, warpDist_x + f38_local13, f38_local13, 0) then
            selectFate_ToB = 0
        end
        if warpDist_x >= f38_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToBL, warpDist_x + f38_local13, f38_local13, 0) then
            selectFate_ToBL = 0
        end
        if warpDist_x >= f38_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToBR, warpDist_x + f38_local13, f38_local13, 0) then
            selectFate_ToBR = 0
        end
        if warpDist_x >= f38_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToL, warpDist_x + f38_local13, f38_local13, 0) then
            selectFate_ToL = 0
        end
        if warpDist_x >= f38_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToR, warpDist_x + f38_local13, f38_local13, 0) then
            selectFate_ToR = 0
        end
        local f38_local16 = f38_arg1:GetRandam_Int(0, selectFate_ToB + selectFate_ToBL + selectFate_ToBR + selectFate_ToL + selectFate_ToR)
        local f38_local17 = AI_DIR_TYPE_ToB
        local f38_local18 = 0
        local f38_local19 = TARGET_ENE_0
        if selectFate_ToB + selectFate_ToBL + selectFate_ToBR + selectFate_ToL + selectFate_ToR == 0 then
            f38_arg1:SetNumber(15, 5)
        elseif AI_DIR_TYPE_ToB ~= 0 and f38_local16 <= selectFate_ToB then
            f38_local17 = AI_DIR_TYPE_ToB
            f38_local18 = warpDist_x
            f38_local19 = TARGET_ENE_0
        elseif selectFate_2 ~= 0 and f38_local16 <= selectFate_ToB + selectFate_ToBL then
            f38_local17 = AI_DIR_TYPE_ToBL
            f38_local18 = warpDist_x
            f38_local19 = TARGET_ENE_0
        elseif selectFate_3 ~= 0 and f38_local16 <= selectFate_ToB + selectFate_ToBL + selectFate_ToBR then
            f38_local17 = AI_DIR_TYPE_ToBR
            f38_local18 = warpDist_x
            f38_local19 = TARGET_ENE_0
        elseif selectFate_4 ~= 0 and f38_local16 <= selectFate_ToB + selectFate_ToBL + selectFate_ToBR + selectFate_ToL then
            f38_local17 = AI_DIR_TYPE_ToL
            f38_local18 = warpDist_x
            f38_local19 = TARGET_ENE_0
        elseif selectFate_4 ~= 0 and f38_local16 <= selectFate_ToB + selectFate_ToBL + selectFate_ToBR + selectFate_ToL + selectFate_ToR then
            f38_local17 = AI_DIR_TYPE_ToR
            f38_local18 = warpDist_x
            f38_local19 = TARGET_ENE_0
        end
        if f38_arg1:GetNumber(15) == 5 then
            f38_arg1:SetNumber(15, 0)
            f38_arg2:AddSubGoal(GOAL_COMMON_ToTargetWarp, 10, TARGET_ENE_0, f38_local17, f38_local18, f38_local19, 5, -2)
            f38_arg1:AddTopGoal(GOAL_COMMON_Wait, 0.5, TARGET_ENE_0)
        else
            f38_arg1:SetNumber(15, 0)
            f38_arg2:AddSubGoal(GOAL_COMMON_ToTargetWarp, 10, TARGET_ENE_0, f38_local17, f38_local18, f38_local19, 5, -2)
            f38_arg1:AddTopGoal(GOAL_COMMON_Wait, 0.5, TARGET_ENE_0)
        end
    end
    if f38_arg1:IsInterupt(INTERUPT_SuccessGuard) and f38_arg1:HasSpecialEffectId(TARGET_SELF, 19007) then
        if f38_local2 < 1.5 then
            if f38_local0 < 20 then
                f38_arg2:ClearSubGoal()
            elseif f38_local0 < 60 then
                f38_arg2:ClearSubGoal()
                f38_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3004, TARGET_ENE_0, 3.5, 0, 0, 0, 0)
            else
                f38_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
                f38_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 5026)
                f38_arg2:AddSubGoal(GOAL_COMMON_StepSafety, 5, -1, 1, -1, -1, TARGET_ENE_0, 3, 0, false)
            end
        elseif f38_local2 < 3 then
            if f38_local0 < 40 then
                f38_arg2:ClearSubGoal()
                f38_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3003, TARGET_ENE_0, 3.5, 0, 0, 0, 0)
                return true
            elseif f38_local0 < 70 then
                f38_arg2:ClearSubGoal()
                f38_arg2:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, 3000, TARGET_ENE_0, 0, 0, 0, 0, 0)
                f38_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat_SuccessAngle180, 10, 3001, TARGET_ENE_0, 0, 0, 0)
                f38_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 10, 3003, TARGET_ENE_0, 5, 0, 0)
            else
                f38_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
                f38_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 5026)
                f38_arg2:AddSubGoal(GOAL_COMMON_StepSafety, 5, -1, 1, -1, -1, TARGET_ENE_0, 3, 0, false)
            end
        end
    end
    if f38_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f38_arg1:HasSpecialEffectId(TARGET_SELF, 10191) and f38_arg1:HasSpecialEffectId(TARGET_SELF, 5021) == false and f38_local2 < 1.5 then
        if f38_local0 < 20 then
            f38_arg2:ClearSubGoal()
        else
            f38_arg2:ClearSubGoal()
            f38_arg1:SetNumber(5, 1)
            f38_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3004, TARGET_ENE_0, 0, 0, 0)
        end
    end
    if f38_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f38_arg1:GetSpecialEffectActivateInterruptId(10186) then
        local f38_local8 = f38_arg1:GetDist(TARGET_ENE_0)
        local f38_local9 = f38_arg1:GetRandam_Int(1, 100)
        if f38_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_F, 180) and f38_local8 <= 8 then
            f38_arg2:ClearSubGoal()
            f38_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3018, TARGET_ENE_0, 0, 0, 0, 0, 0)
            return true
        end
    end
    if f38_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f38_arg1:HasSpecialEffectId(TARGET_SELF, 5027) then
        if f38_arg1:GetAttackPassedTime(6002) >= 10 + f38_local7 and f38_arg1:GetAttackPassedTime(6003) >= 10 + f38_local7 then
            if f38_local0 <= 50 then
                f38_arg2:ClearSubGoal()
                f38_arg2:AddSubGoal(GOAL_COMMON_StepSafety, 5, -1, -1, 1, -1, TARGET_ENE_0, 3, 0, false)
                return true
            else
                f38_arg2:ClearSubGoal()
                f38_arg2:AddSubGoal(GOAL_COMMON_StepSafety, 5, -1, -1, -1, 1, TARGET_ENE_0, 3, 0, false)
                return true
            end
        elseif f38_local0 <= 50 then
            f38_arg2:ClearSubGoal()
            f38_arg2:AddSubGoal(GOAL_COMMON_SidewayMove, 1.2, TARGET_ENE_0, f38_arg1:GetRandam_Int(0, 1), f38_arg1:GetRandam_Int(30, 45), true, true, 9910)
            return true
        else
            f38_arg2:ClearSubGoal()
            f38_arg2:AddSubGoal(GOAL_COMMON_LeaveTarget, 2, TARGET_ENE_0, 5, TARGET_ENE_0, true, 9910)
            return true
        end
    end
    if f38_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f38_arg1:HasSpecialEffectId(TARGET_SELF, 5026) then
        if f38_local2 < 1.5 then
            if f38_arg1:GetAttackPassedTime(6002) >= 10 + f38_local7 and f38_arg1:GetAttackPassedTime(6003) >= 10 + f38_local7 then
                if f38_local0 <= 50 then
                    f38_arg2:ClearSubGoal()
                    f38_arg2:AddSubGoal(GOAL_COMMON_StepSafety, 5, -1, -1, 1, -1, TARGET_ENE_0, 3, 0, false)
                    return true
                else
                    f38_arg2:ClearSubGoal()
                    f38_arg2:AddSubGoal(GOAL_COMMON_StepSafety, 5, -1, -1, -1, 1, TARGET_ENE_0, 3, 0, false)
                    return true
                end
            elseif f38_arg1:GetAttackPassedTime(3004) >= 5 + f38_local7 then
                f38_arg2:ClearSubGoal()
                f38_arg1:SetNumber(5, 1)
                f38_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3004, TARGET_ENE_0, 0, 0, 0)
                return true
            elseif f38_local0 <= 50 then
                f38_arg2:ClearSubGoal()
                f38_arg2:AddSubGoal(GOAL_COMMON_SidewayMove, 1.2, TARGET_ENE_0, f38_arg1:GetRandam_Int(0, 1), f38_arg1:GetRandam_Int(30, 45), true, true, -1)
                return true
            else
                f38_arg2:ClearSubGoal()
                f38_arg2:AddSubGoal(GOAL_COMMON_LeaveTarget, 2, TARGET_ENE_0, 5, TARGET_ENE_0, true, 9910)
                return true
            end
        elseif f38_local2 > 4 and f38_local2 < 6 then
            if f38_arg1:GetAttackPassedTime(3003) >= 10 + f38_local7 then
                f38_arg2:ClearSubGoal()
                f38_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3003, TARGET_ENE_0, 0, 0, 0)
                return true
            end
        elseif f38_local2 > 5 and f38_local0 <= 50 then
            if f38_local1 <= 50 then
                f38_arg2:ClearSubGoal()
                f38_arg2:AddSubGoal(GOAL_COMMON_SidewayMove, 1.2, TARGET_ENE_0, f38_arg1:GetRandam_Int(0, 1), f38_arg1:GetRandam_Int(30, 45), true, true, 9910)
                return true
            else
                f38_arg2:ClearSubGoal()
                f38_arg2:AddSubGoal(GOAL_COMMON_ApproachTarget, 2, TARGET_ENE_0, 4, TARGET_SELF, true, 9910)
                return true
            end
        end
    end
    if f38_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f38_arg1:HasSpecialEffectId(TARGET_SELF, 5025) then
        if f38_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_B, 180, 180, 6) then
            if f38_arg1:GetAttackPassedTime(6002) >= 10 + f38_local7 and f38_arg1:GetAttackPassedTime(6003) >= 10 + f38_local7 then
                if f38_local0 <= 50 then
                    f38_arg2:ClearSubGoal()
                    f38_arg2:AddSubGoal(GOAL_COMMON_StepSafety, 5, -1, -1, 1, -1, TARGET_ENE_0, 3, 0, false)
                    return true
                else
                    f38_arg2:ClearSubGoal()
                    f38_arg2:AddSubGoal(GOAL_COMMON_StepSafety, 5, -1, -1, -1, 1, TARGET_ENE_0, 3, 0, false)
                    return true
                end
            elseif f38_arg1:GetAttackPassedTime(3004) >= 5 + f38_local7 then
                f38_arg2:ClearSubGoal()
                f38_arg1:SetNumber(5, 1)
                f38_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3004, TARGET_ENE_0, 0, 0, 0)
                return true
            else
                f38_arg2:ClearSubGoal()
                f38_arg2:AddSubGoal(GOAL_COMMON_SidewayMove, 1.2, TARGET_ENE_0, f38_arg1:GetRandam_Int(0, 1), f38_arg1:GetRandam_Int(30, 45), true, true, -1)
                return true
            end
        elseif f38_local2 < 1.5 then
            if f38_arg1:GetAttackPassedTime(6002) >= 10 + f38_local7 and f38_arg1:GetAttackPassedTime(6003) >= 10 + f38_local7 then
                if f38_local0 <= 50 then
                    f38_arg2:ClearSubGoal()
                    f38_arg2:AddSubGoal(GOAL_COMMON_StepSafety, 5, -1, -1, 1, -1, TARGET_ENE_0, 3, 0, false)
                    return true
                else
                    f38_arg2:ClearSubGoal()
                    f38_arg2:AddSubGoal(GOAL_COMMON_StepSafety, 5, -1, -1, -1, 1, TARGET_ENE_0, 3, 0, false)
                    return true
                end
            elseif f38_arg1:GetAttackPassedTime(3004) >= 5 + f38_local7 then
                f38_arg2:ClearSubGoal()
                f38_arg1:SetNumber(5, 1)
                f38_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3004, TARGET_ENE_0, 0, 0, 0)
                return true
            elseif f38_local0 <= 50 then
                f38_arg2:ClearSubGoal()
                f38_arg2:AddSubGoal(GOAL_COMMON_SidewayMove, 1.2, TARGET_ENE_0, f38_arg1:GetRandam_Int(0, 1), f38_arg1:GetRandam_Int(30, 45), true, true, -1)
                return true
            else
                f38_arg2:ClearSubGoal()
                f38_arg2:AddSubGoal(GOAL_COMMON_LeaveTarget, 2, TARGET_ENE_0, 5, TARGET_ENE_0, true, 9910)
                return true
            end
        elseif f38_local2 > 4 and f38_local2 < 6 then
            if f38_arg1:GetAttackPassedTime(3003) >= 10 + f38_local7 then
                f38_arg2:ClearSubGoal()
                f38_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3003, TARGET_ENE_0, 0, 0, 0)
                return true
            end
        elseif f38_local2 > 5 and f38_local0 <= 50 then
            if f38_local1 <= 50 then
                f38_arg2:ClearSubGoal()
                f38_arg2:AddSubGoal(GOAL_COMMON_SidewayMove, 1.2, TARGET_ENE_0, f38_arg1:GetRandam_Int(0, 1), f38_arg1:GetRandam_Int(30, 45), true, true, 9910)
                return true
            else
                f38_arg2:ClearSubGoal()
                f38_arg2:AddSubGoal(GOAL_COMMON_ApproachTarget, 2, TARGET_ENE_0, 4, TARGET_SELF, true, 9910)
                return true
            end
        end
    end
    return false
    
end

RegisterTableGoal(GOAL_LossRaceSoldierSword300011_AfterAttackAct, "LossRaceSoldierSword300011_AfterAttackAct")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_LossRaceSoldierSword300011_AfterAttackAct, true)

Goal.Activate = function (f39_arg0, f39_arg1, f39_arg2)
    actPerArr[1] = 5
    actPerArr[8] = 50
    actPerArr[12] = 40
    actPerArr[13] = 5
    
end

Goal.Update = function (f40_arg0, f40_arg1, f40_arg2)
    return Update_Default_NoSubGoal(f40_arg0, f40_arg1, f40_arg2)
    
end


