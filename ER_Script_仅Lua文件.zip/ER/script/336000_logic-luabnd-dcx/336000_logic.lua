﻿function AncestorBelieverAx336000_Logic(f1_arg0)
    COMMON_Initialize(f1_arg0)
    if COMMON_EasySetup_Initial(f1_arg0) == false then
        local f1_local0 = f1_arg0:GetRandam_Int(1, 100)
        local f1_local1 = f1_arg0:GetEventRequest()
        local f1_local2 = f1_arg0:IsSearchTarget(TARGET_ENE_0)
        local f1_local3 = f1_arg0:GetDist(TARGET_SOUND)
        local f1_local4 = not (f1_arg0:GetCurrTargetState() ~= AI_TARGET_STATE__CAUTION and f1_arg0:GetCurrTargetState() ~= AI_TARGET_STATE__SEARCH and f1_arg0:GetCurrTargetState() ~= AI_TARGET_STATE__SEARCH2)
        if f1_local1 == 100 then
            f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 5, POINT_INITIAL, 0.5, TARGET_SELF, true, -1)
        elseif f1_local1 == 110 then
            f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 5, POINT_INITIAL, 0.5, TARGET_SELF, false, -1)
        elseif RideRequest(f1_arg0, 10, -1) then
            f1_arg0:AddTopGoal(GOAL_COMMON_Mount, 10, 1.2)
        elseif f1_arg0:IsRiding(TARGET_SELF) == true and f1_arg0:GetCurrTargetState() ~= AI_TARGET_STATE__BATTLE then
            f1_arg0:AddTopGoal(GOAL_COMMON_Wait, 1, TARGET_NONE)
        elseif f1_arg0:HasSpecialEffectId(TARGET_SELF, 13155) and f1_local4 == true and f1_arg0:IsInsideTargetCustom(TARGET_SELF, TARGET_SOUND, AI_DIR_TYPE_F, 360, 180, 50) == false then
            f1_arg0:AddTopGoal(GOAL_COMMON_ComboRepeat, 10, 3030, TARGET_ENE_0, 0, 0, 0, 0, 0)
        elseif f1_arg0:HasSpecialEffectId(TARGET_SELF, 13155) and f1_local4 == true and f1_arg0:IsInsideTargetCustom(TARGET_SELF, TARGET_SOUND, AI_DIR_TYPE_F, 360, 180, 15) == true then
            f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 5, 3004, TARGET_ENE_0, 0, 0, 0, 0, 0)
        else
            COMMON_EasySetup3(f1_arg0)
        end
    end
    
end

function AncestorBelieverAx336000_Interupt(f2_arg0, f2_arg1)
    local f2_local0 = f2_arg0:GetPlatoonCommand()
    local f2_local1 = f2_local0:GetCommandNo()
    isChangedOrder = f2_arg0:IsInterupt(INTERUPT_PlatoonAiOrder)
    if isChangedOrder and f2_local1 == PLAN_PLATOON_COMMAND__STOP then
        f2_arg1:ClearSubGoal()
        f2_arg0:Replaning()
    end
    if f2_arg0:IsInterupt(INTERUPT_ChangeSoundTarget) and f2_arg0:GetLatestSoundBehaviorID() == 300000 then
        f2_arg1:ClearSubGoal()
        f2_arg0:Replaning()
        return true
    end
    return false
    
end


