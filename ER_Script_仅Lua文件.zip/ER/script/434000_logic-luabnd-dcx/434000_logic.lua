﻿function PumpkinHead4Frail434000_Logic(f1_arg0)
    COMMON_Initialize(f1_arg0)
    if COMMON_EasySetup_Initial(f1_arg0) == false then
        local f1_local0 = f1_arg0:GetEventRequest()
        local f1_local1 = f1_arg0:IsSearchTarget(TARGET_ENE_0)
        local f1_local2 = f1_arg0:GetMovePointNumber()
        if f1_local0 == 100 then
            f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 5, POINT_INITIAL, 0.5, TARGET_SELF, true, -1)
        elseif f1_local0 == 110 then
            f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 5, POINT_INITIAL, 0.5, TARGET_SELF, false, -1)
        elseif f1_arg0:HasSpecialEffectId(TARGET_SELF, 13255) == true and f1_arg0:IsBattleState() == false and f1_arg0:IsSearchLowState() == false and f1_arg0:IsSearchHighState() == false and f1_arg0:IsCautionState() == false and f1_arg0:IsMemoryState() == false and f1_local2 == -1 and f1_arg0:IsValidPlatoon() == false then
            local f1_local3 = 2
            local f1_local4 = 10
            local f1_local5 = true
            local f1_local6 = 3010
            local f1_local7 = 7
            local f1_local8 = 1
            local f1_local9 = false
            local f1_local10 = true
            local f1_local11 = false
            f1_arg0:AddTopGoal(GOAL_COMMON_WalkAround_Anywhere, -1, f1_local3, f1_local4, f1_local5, f1_local6, f1_local7, f1_local8, f1_local9, f1_local10, f1_local11)
        elseif f1_arg0:HasSpecialEffectId(TARGET_SELF, 13250) == true and (f1_arg0:IsSearchLowState() == true or f1_arg0:IsSearchHighState() == true or f1_arg0:IsCautionState() == true) then
            if f1_arg0:IsInsideTarget(TARGET_SOUND, AI_DIR_TYPE_B, 60) then
                f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 5, 3022, TARGET_SELF, 9998, 0, 0, 0, 0)
            elseif f1_arg0:IsInsideTarget(TARGET_SOUND, AI_DIR_TYPE_R, 90) then
                f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 5, 3021, TARGET_SELF, 9998, 0, 0, 0, 0)
            elseif f1_arg0:IsInsideTarget(TARGET_SOUND, AI_DIR_TYPE_L, 90) then
                f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 5, 3020, TARGET_SELF, 9998, 0, 0, 0, 0)
            end
        else
            COMMON_EasySetup3(f1_arg0)
        end
    end
    
end

function PumpkinHead4Frail434000_Interupt(f2_arg0, f2_arg1)
    
end


