﻿RegisterTableGoal(GOAL_Wilddragonfly608000_Battle, "Wilddragonfly608000_Battle")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_Wilddragonfly608000_Battle, true)

Goal.Initialize = function (f1_arg0, f1_arg1, f1_arg2, f1_arg3)
    
end

Goal.Activate = function (f2_arg0, f2_arg1, f2_arg2)
    Init_Pseudo_Global(f2_arg1, f2_arg2)
    f2_arg1:SetStringIndexedNumber("Dist_SideStep", 5)
    f2_arg1:SetStringIndexedNumber("Dist_BackStep", 5)
    local f2_local0 = {}
    local f2_local1 = {}
    local f2_local2 = {}
    Common_Clear_Param(f2_local0, f2_local1, f2_local2)
    f2_arg1:SetNumber(1, 0)
    f2_arg1:SetTimer(1, 0)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_ENE_0, 150)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    local f2_local3 = f2_arg1:GetOffsetY(TARGET_SELF)
    local f2_local4 = f2_arg1:GetDistY(POINT_NEAR_NAVIMESH)
    local f2_local5 = f2_arg1:GetDist(TARGET_ENE_0)
    local f2_local6 = f2_arg1:GetRandam_Int(1, 100)
    local f2_local7 = f2_arg1:HasSpecialEffectId(TARGET_ENE_0, 150)
    local f2_local8 = f2_arg1:GetAreaHour()
    local f2_local9 = f2_arg1:HasSpecialEffectId(TARGET_SELF, 11456)
    local f2_local10 = f2_arg1:HasSpecialEffectId(TARGET_SELF, 11457)
    local f2_local11 = f2_arg1:HasSpecialEffectId(TARGET_SELF, 11458)
    if f2_arg1:IsBattleState() then
        if f2_local3 > 1.7 then
            f2_local0[23] = 20
            f2_local0[24] = 20
            f2_local0[1] = 20
            if f2_arg1:IsFinishTimer(0) then
                f2_local0[21] = 50
            end
        elseif f2_local3 == 0 then
            f2_local0[22] = 50
        else
            f2_local0[1] = 20
            f2_local0[22] = 30
            f2_local0[23] = 30
            f2_local0[24] = 30
            f2_local0[10] = 40
        end
    end
    f2_local0[10] = SetCoolTime(f2_arg1, f2_arg2, 3000, 5, f2_local0[10], 1)
    f2_local0[10] = SetCoolTime(f2_arg1, f2_arg2, 3001, 5, f2_local0[10], 1)
    f2_local0[22] = SetCoolTime(f2_arg1, f2_arg2, 3011, 10, f2_local0[22], 1)
    f2_local1[1] = REGIST_FUNC(f2_arg1, f2_arg2, Wilddragonfly608000_Act01)
    f2_local1[10] = REGIST_FUNC(f2_arg1, f2_arg2, Wilddragonfly608000_Act10)
    f2_local1[21] = REGIST_FUNC(f2_arg1, f2_arg2, Wilddragonfly608000_Act21)
    f2_local1[22] = REGIST_FUNC(f2_arg1, f2_arg2, Wilddragonfly608000_Act22)
    f2_local1[23] = REGIST_FUNC(f2_arg1, f2_arg2, Wilddragonfly608000_Act23)
    f2_local1[24] = REGIST_FUNC(f2_arg1, f2_arg2, Wilddragonfly608000_Act24)
    local f2_local12 = REGIST_FUNC(f2_arg1, f2_arg2, Wilddragonfly608000_ActAfter_AdjustSpace)
    Common_Battle_Activate(f2_arg1, f2_arg2, f2_local0, f2_local1, f2_local12)
    
end

function Wilddragonfly608000_Act01(f3_arg0, f3_arg1, f3_arg2)
    local f3_local0 = f3_arg0:GetDist(TARGET_ENE_0)
    if f3_local0 < 10 then
        f3_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget_Continuous, 2, TARGET_ENE_0, 15, TARGET_SELF, false, -1, 5)
    else
        f3_arg1:AddSubGoal(GOAL_COMMON_Wait, f3_arg0:GetRandam_Float(2, 3.5), TARGET_ENE_0, 0, 0, 0)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wilddragonfly608000_Act10(f4_arg0, f4_arg1, f4_arg2)
    local f4_local0 = f4_arg0:GetRandam_Int(1, 100)
    local f4_local1 = f4_arg0:GetAreaHour()
    local f4_local2 = f4_arg0:GetDist(TARGET_ENE_0)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    local f4_local3 = f4_arg0:HasSpecialEffectId(TARGET_SELF, 11458)
    if f4_local3 == true then
        if f4_local2 < 5 then
            f4_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget_Continuous, 2, TARGET_ENE_0, 10, TARGET_SELF, false, -1, 5)
        else
            local f4_local4 = 15 - f4_arg0:GetMapHitRadius(TARGET_SELF)
            local f4_local5 = 15 - f4_arg0:GetMapHitRadius(TARGET_SELF)
            local f4_local6 = 15 - f4_arg0:GetMapHitRadius(TARGET_SELF)
            local f4_local7 = 50
            local f4_local8 = 0
            local f4_local9 = 1
            local f4_local10 = 8
            Approach_Act_Flex(f4_arg0, f4_arg1, f4_local4, f4_local5, f4_local6, f4_local7, f4_local8, f4_local9, f4_local10)
        end
    elseif f4_local2 < 2 then
        f4_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget_Continuous, 2, TARGET_ENE_0, 4, TARGET_SELF, false, -1, 5)
    else
        local f4_local4 = 9 - f4_arg0:GetMapHitRadius(TARGET_SELF)
        local f4_local5 = 9 - f4_arg0:GetMapHitRadius(TARGET_SELF)
        local f4_local6 = 9 - f4_arg0:GetMapHitRadius(TARGET_SELF)
        local f4_local7 = 50
        local f4_local8 = 0
        local f4_local9 = 1
        local f4_local10 = 8
        Approach_Act_Flex(f4_arg0, f4_arg1, f4_local4, f4_local5, f4_local6, f4_local7, f4_local8, f4_local9, f4_local10)
    end
    local f4_local4 = 3000
    local f4_local5 = 3001
    local f4_local6 = 5 - f4_arg0:GetMapHitRadius(TARGET_SELF)
    local f4_local7 = 0
    local f4_local8 = 0
    local f4_local9 = f4_arg0:HasSpecialEffectId(TARGET_ENE_0, 150)
    if f4_local9 == true then
        f4_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3001, TARGET_ENE_0, f4_local6, f4_local7, f4_local8, 0, 0)
    else
        f4_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3000, TARGET_ENE_0, f4_local6, f4_local7, f4_local8, 0, 0)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wilddragonfly608000_Act21(f5_arg0, f5_arg1, f5_arg2)
    local f5_local0 = 3010
    local f5_local1 = 5 - f5_arg0:GetMapHitRadius(TARGET_SELF)
    local f5_local2 = 0
    local f5_local3 = 0
    f5_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f5_local0, TARGET_ENE_0, f5_local1, f5_local2, f5_local3, 0, 0)
    f5_arg1:AddSubGoal(GOAL_COMMON_Wait, f5_arg0:GetRandam_Float(2, 3.5), TARGET_ENE_0, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wilddragonfly608000_Act22(f6_arg0, f6_arg1, f6_arg2)
    local f6_local0 = 3011
    local f6_local1 = 5 - f6_arg0:GetMapHitRadius(TARGET_SELF)
    local f6_local2 = 0
    local f6_local3 = 0
    local f6_local4 = f6_arg0:GetRandam_Int(1, 100)
    f6_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f6_local0, TARGET_ENE_0, f6_local1, f6_local2, f6_local3, 0, 0)
    if f6_local4 <= 50 then
        f6_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, 0.5, TARGET_ENE_0, 1, TARGET_SELF, false, -1, AI_DIR_TYPE_R, 3)
    else
        f6_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, 0.5, TARGET_ENE_0, 1, TARGET_SELF, false, -1, AI_DIR_TYPE_L, 3)
    end
    f6_arg0:SetTimer(0, f6_arg0:GetRandam_Int(3, 10))
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wilddragonfly608000_Act23(f7_arg0, f7_arg1, f7_arg2)
    f7_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f7_arg0:GetRandam_Float(2, 3.5), TARGET_ENE_0, 1, TARGET_SELF, false, -1, AI_DIR_TYPE_ToBR, 15)
    f7_arg1:AddSubGoal(GOAL_COMMON_Wait, 1.2, TARGET_NONE, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wilddragonfly608000_Act24(f8_arg0, f8_arg1, f8_arg2)
    f8_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f8_arg0:GetRandam_Float(2, 3.5), TARGET_ENE_0, 1, TARGET_SELF, false, -1, AI_DIR_TYPE_ToBL, 15)
    f8_arg1:AddSubGoal(GOAL_COMMON_Wait, 1.2, TARGET_NONE, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wilddragonfly608000_ActAfter_AdjustSpace(f9_arg0, f9_arg1, f9_arg2)
    f9_arg1:AddSubGoal(GOAL_Wilddragonfly608000_AfterAttackAct, 10)
    
end

Goal.Update = function (f10_arg0, f10_arg1, f10_arg2)
    return Update_Default_NoSubGoal(f10_arg0, f10_arg1, f10_arg2)
    
end

Goal.Terminate = function (f11_arg0, f11_arg1, f11_arg2)
    
end

Goal.Interrupt = function (f12_arg0, f12_arg1, f12_arg2)
    local f12_local0 = f12_arg1:GetRandam_Int(1, 100)
    local f12_local1 = f12_arg1:GetRandam_Int(1, 100)
    local f12_local2 = f12_arg1:GetRandam_Int(1, 100)
    local f12_local3 = f12_arg1:GetDist(TARGET_ENE_0)
    if f12_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f12_arg1:HasSpecialEffectId(TARGET_SELF, 5025) and f12_local3 <= 10 then
        if f12_local0 < 30 then
            f12_arg2:ClearSubGoal()
            Wilddragonfly608000_Act21(f12_arg1, f12_arg2, paramTbl)
            return true
        elseif f12_local0 < 70 then
            f12_arg2:ClearSubGoal()
            Wilddragonfly608000_Act25(f12_arg1, f12_arg2, paramTbl)
            return true
        elseif f12_local0 <= 80 then
            f12_arg2:ClearSubGoal()
            Wilddragonfly608000_Act22(f12_arg1, f12_arg2, paramTbl)
            return true
        elseif f12_local0 <= 90 then
            f12_arg2:ClearSubGoal()
            Wilddragonfly608000_Act23(f12_arg1, f12_arg2, paramTbl)
            return true
        else
            f12_arg2:ClearSubGoal()
            Wilddragonfly608000_Act24(f12_arg1, f12_arg2, paramTbl)
            return true
        end
    end
    if f12_arg1:IsInterupt(INTERUPT_Shoot) then
        if f12_arg1:HasSpecialEffectId(TARGET_SELF, 11450) == true then
            f12_arg2:ClearSubGoal()
            f12_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 10, 3011, TARGET_ENE_0, 3, 0, 0)
            return true
        else
            return false
        end
    end
    return false
    
end

RegisterTableGoal(GOAL_Wilddragonfly608000_AfterAttackAct, "Wilddragonfly608000_AfterAttackAct")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_Wilddragonfly608000_AfterAttackAct, true)

Goal.Activate = function (f13_arg0, f13_arg1, f13_arg2)
    local f13_local0 = f13_arg1:GetDist(TARGET_ENE_0)
    local f13_local1 = f13_arg1:GetToTargetAngle(TARGET_ENE_0)
    f13_arg1:SetStringIndexedNumber("DistMin_AAA", -999)
    f13_arg1:SetStringIndexedNumber("DistMax_AAA", 7)
    f13_arg1:SetStringIndexedNumber("BaseDir_AAA", AI_DIR_TYPE_F)
    f13_arg1:SetStringIndexedNumber("Angle_AAA", 180)
    f13_arg1:SetStringIndexedNumber("DistMin_Inter_AAA", 1)
    f13_arg1:SetStringIndexedNumber("DistMax_Inter_AAA", 10)
    f13_arg1:SetStringIndexedNumber("BaseAng_Inter_AAA", 0)
    f13_arg1:SetStringIndexedNumber("Ang_Inter_AAA", 180)
    if f13_local0 >= 5 then
        f13_arg1:SetStringIndexedNumber("Odds_Guard_AAA", 80)
        f13_arg1:SetStringIndexedNumber("Odds_NoAct_AAA", 70)
        f13_arg1:SetStringIndexedNumber("Odds_BackAndSide_AAA", 30)
    elseif f13_local0 >= 2 then
        f13_arg1:SetStringIndexedNumber("Odds_Guard_AAA", 80)
        f13_arg1:SetStringIndexedNumber("Odds_NoAct_AAA", 50)
        f13_arg1:SetStringIndexedNumber("Odds_BackAndSide_AAA", 30)
        f13_arg1:SetStringIndexedNumber("Odds_Back_AAA", 10)
        f13_arg1:SetStringIndexedNumber("Odds_Backstep_AAA", 10)
    else
        f13_arg1:SetStringIndexedNumber("Odds_Guard_AAA", 80)
        f13_arg1:SetStringIndexedNumber("Odds_NoAct_AAA", 50)
        f13_arg1:SetStringIndexedNumber("Odds_BackAndSide_AAA", 10)
        f13_arg1:SetStringIndexedNumber("Odds_Back_AAA", 10)
        f13_arg1:SetStringIndexedNumber("Odds_Backstep_AAA", 5)
        f13_arg1:SetStringIndexedNumber("Odds_Sidestep_AAA", 10)
        f13_arg1:SetStringIndexedNumber("Odds_BsAndSide_AAA", 15)
    end
    f13_arg2:AddSubGoal(GOAL_COMMON_AfterAttackAct, 10)
    
end

Goal.Update = function (f14_arg0, f14_arg1, f14_arg2)
    return Update_Default_NoSubGoal(f14_arg0, f14_arg1, f14_arg2)
    
end


