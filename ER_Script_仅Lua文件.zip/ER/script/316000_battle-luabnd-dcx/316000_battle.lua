﻿RegisterTableGoal(GOAL_RuneHunterKnightHorse316000_Battle, "RuneHunterKnightHorse316000_Battle")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_RuneHunterKnightHorse316000_Battle, true)

Goal.Initialize = function (f1_arg0, f1_arg1, f1_arg2, f1_arg3)
    
end

Goal.Activate = function (f2_arg0, f2_arg1, f2_arg2)
    Init_Pseudo_Global(f2_arg1, f2_arg2)
    f2_arg1:SetStringIndexedNumber("Dist_SideStep", 5)
    f2_arg1:SetStringIndexedNumber("Dist_BackStep", 5)
    local f2_local0 = {}
    local f2_local1 = {}
    local f2_local2 = {}
    Common_Clear_Param(f2_local0, f2_local1, f2_local2)
    local f2_local3 = f2_arg1:GetDist(TARGET_ENE_0)
    local f2_local4 = f2_arg1:GetRandam_Int(1, 100)
    f2_local0[16] = 100
    f2_local1[15] = REGIST_FUNC(f2_arg1, f2_arg2, RuneHunterKnightHorse316000_Act15)
    f2_local1[16] = REGIST_FUNC(f2_arg1, f2_arg2, RuneHunterKnightHorse316000_Act16)
    local f2_local5 = REGIST_FUNC(f2_arg1, f2_arg2, RuneHunterKnightHorse316000_ActAfter_AdjustSpace)
    Common_Battle_Activate(f2_arg1, f2_arg2, f2_local0, f2_local1, f2_local5, f2_local2)
    
end

function RuneHunterKnightHorse316000_Act15(f3_arg0, f3_arg1, f3_arg2)
    f3_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 5, TARGET_ENE_0, 20, TARGET_SELF, false, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RuneHunterKnightHorse316000_Act16(f4_arg0, f4_arg1, f4_arg2)
    f4_arg1:AddSubGoal(GOAL_COMMON_Wait, 1, TARGET_NONE, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RuneHunterKnightHorse316000_ActAfter_AdjustSpace(f5_arg0, f5_arg1, f5_arg2)
    f5_arg1:AddSubGoal(GOAL_RuneHunterKnightHorse316000_AfterAttackAct, 10)
    
end

Goal.Update = function (f6_arg0, f6_arg1, f6_arg2)
    return Update_Default_NoSubGoal(f6_arg0, f6_arg1, f6_arg2)
    
end

Goal.Terminate = function (f7_arg0, f7_arg1, f7_arg2)
    
end

Goal.Interrupt = function (f8_arg0, f8_arg1, f8_arg2)
    local f8_local0 = f8_arg1:GetDist(TARGET_ENE_0)
    local f8_local1 = 5 - f8_arg1:GetMapHitRadius(TARGET_SELF)
    local f8_local2 = f8_arg1:GetRandam_Int(1, 100)
    local f8_local3 = f8_arg1:GetHpRate(TARGET_SELF)
    if f8_arg1:IsLadderAct(TARGET_SELF) then
        return false
    end
    if f8_arg1:IsInterupt(INTERUPT_Damaged) then
        f8_arg2:ClearSubGoal()
        f8_arg2:AddSubGoal(GOAL_COMMON_LeaveTarget, 10, TARGET_ENE_0, 40, TARGET_SELF, false, 0)
        return true
    end
    return false
    
end

RegisterTableGoal(GOAL_RuneHunterKnightHorse316000_AfterAttackAct, "RuneHunterKnightHorse316000_AfterAttackAct")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_RuneHunterKnightHorse316000_AfterAttackAct, true)

Goal.Activate = function (f9_arg0, f9_arg1, f9_arg2)
    
end

Goal.Update = function (f10_arg0, f10_arg1, f10_arg2)
    return Update_Default_NoSubGoal(f10_arg0, f10_arg1, f10_arg2)
    
end


