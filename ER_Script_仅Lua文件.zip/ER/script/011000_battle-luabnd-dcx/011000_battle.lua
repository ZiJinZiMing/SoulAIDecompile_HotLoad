﻿function Nanimosinai11000Battle_Activate(f1_arg0, f1_arg1)
    f1_arg1:AddSubGoal(GOAL_COMMON_Wait, 5, TARGET_NONE, 0, 0, 0)
    
end

function Nanimosinai11000Battle_Update(f2_arg0, f2_arg1)
    return GOAL_RESULT_Continue
    
end

function Nanimosinai11000Battle_Terminate(f3_arg0, f3_arg1)
    
end

function Nanimosinai11000Battle_Interupt(f4_arg0, f4_arg1)
    return false
    
end


