﻿function RuneHunterKnight315010_Logic(f1_arg0)
    COMMON_Initialize(f1_arg0)
    f1_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 11805)
    f1_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 11825)
    if COMMON_EasySetup_Initial(f1_arg0) == false then
        if f1_arg0:IsValidPlatoon() == false then
            COMMON_EasySetup3(f1_arg0)
        else
            local f1_local0 = true
            local f1_local1 = true
            local f1_local2 = f1_arg0:GetAreaHour()
            if f1_arg0:IsBattleState() or f1_arg0:IsCautionState() or f1_arg0:IsSearchHighState() or f1_arg0:IsSearchLowState() or f1_arg0:IsMemoryState() then
                f1_local0 = false
            end
            if f1_local2 >= 6 and f1_local2 <= 19 then
                f1_local1 = false
            end
            if f1_local0 == true and f1_local1 == false and f1_arg0:HasSpecialEffectId(TARGET_SELF, 11830) == false then
                f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, -1, 3038, TARGET_NONE, 0, 0, 0, 0, 0)
                return
            elseif f1_local1 == true and f1_arg0:HasSpecialEffectId(TARGET_SELF, 11830) == true then
                f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, -1, 3039, TARGET_NONE, 0, 0, 0, 0, 0)
                return
            else
                local f1_local3 = f1_arg0:GetPlatoonCommand()
                local f1_local4 = f1_local3:GetCommandNo()
                if f1_local4 == PLAN_PLATOON_COMMAND__MOVE and f1_local0 == true then
                    local f1_local5 = f1_arg0:GetDist(TARGET_TEAM_FORMATION)
                    if f1_local5 < 3 then
                        f1_arg0:AddTopGoal(GOAL_COMMON_Stay, 0.5, 0, TARGET_SELF)
                    else
                        f1_arg0:AddTopGoal(GOAL_COMMON_MoveToSomewhere, 3, TARGET_TEAM_FORMATION, AI_DIR_TYPE_CENTER, 3, TARGET_SELF, true)
                    end
                else
                    COMMON_EasySetup3(f1_arg0)
                end
            end
        end
    end
    
end

function RuneHunterKnight315010_Interupt(f2_arg0, f2_arg1)
    f2_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 11805)
    f2_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 11825)
    if f2_arg0:IsInterupt(INTERUPT_ActivateSpecialEffect) and f2_arg0:HasSpecialEffectId(TARGET_SELF, 11805) and f2_arg0:ReserveRide(10) == true then
        f2_arg1:ClearSubGoal()
        f2_arg1:AddSubGoal(GOAL_COMMON_Mount, 10, 3, 5)
        return true
    end
    if f2_arg0:IsInterupt(INTERUPT_MovedEnd_OnFailedPath) and f2_arg0:IsRiding(TARGET_SELF) == false and f2_arg0:HasSpecialEffectId(TARGET_SELF, 11805) == false and f2_arg0:HasSpecialEffectId(TARGET_SELF, 11825) == true then
        f2_arg1:ClearSubGoal()
        local f2_local0 = f2_arg0:GetDist(TARGET_ENE_0)
        local f2_local1 = 3025
        local f2_local2 = 0
        local f2_local3 = 0
        f2_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f2_local1, TARGET_ENE_0, 999, f2_local2, f2_local3, 0, 0)
        return true
    end
    return false
    
end


