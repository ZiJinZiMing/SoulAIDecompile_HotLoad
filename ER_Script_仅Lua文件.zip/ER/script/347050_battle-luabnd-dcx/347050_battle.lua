﻿RegisterTableGoal(GOAL_FrogHuman_347050_Battle, "GOAL_FrogHuman_347050_Battle")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_FrogHuman_347050_Battle, true)

Goal.Initialize = function (f1_arg0, f1_arg1, f1_arg2, f1_arg3)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3000)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3001)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3002)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3005)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3006)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3007)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3008)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3009)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3011)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3012)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3013)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3014)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3015)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3016)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3017)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3018)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3023)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3024)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3025)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3026)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3027)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3028)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3029)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3030)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3031)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3032)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3033)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3034)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3035)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3036)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3037)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3038)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3039)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3000)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3001)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3002)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3005)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3016)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3010)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3011)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3012)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3020)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3021)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3022)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3024)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3025)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3026)
    
end

Goal.Activate = function (f2_arg0, f2_arg1, f2_arg2)
    Init_Pseudo_Global(f2_arg1, f2_arg2)
    local f2_local0 = {}
    local f2_local1 = {}
    local f2_local2 = {}
    Common_Clear_Param(f2_local0, f2_local1, f2_local2)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    local f2_local3 = f2_arg1:GetDist(TARGET_ENE_0)
    local f2_local4 = f2_arg1:GetRandam_Int(1, 100)
    local f2_local5 = f2_arg1:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__thinkAttr_doAdmirer)
    f2_arg1:SetStringIndexedNumber("c3470_DashRate", 0)
    if f2_local5 == 1 and f2_arg1:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Kankyaku then
        if f2_local3 >= 4 then
            f2_local0[7] = 10
            f2_local0[8] = 10
            f2_local0[30] = 30
            f2_local0[15] = 0
            f2_local0[18] = 50
        else
            f2_local0[7] = 20
            f2_local0[8] = 20
            f2_local0[15] = 20
            f2_local0[30] = 40
        end
    elseif f2_local5 == 1 and f2_arg1:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Torimaki then
        if f2_local3 >= 6 then
            f2_local0[2] = 30
            f2_local0[3] = 10
            f2_local0[7] = 20
            f2_local0[8] = 20
            f2_local0[15] = 0
            f2_local0[18] = 20
        else
            f2_local0[1] = 10
            f2_local0[7] = 20
            f2_local0[8] = 20
            f2_local0[15] = 20
            f2_local0[30] = 30
        end
    elseif f2_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_B, 180) then
        local f2_local6 = 1
        if f2_arg1:HasSpecialEffectId(TARGET_SELF, 15607) then
            f2_local6 = 0
        end
        if f2_local3 <= 6.5 then
            f2_local0[2] = 70
            f2_local0[17] = 30
        else
            f2_local0[17] = 30
        end
    else
        local f2_local6 = 1
        if f2_arg1:HasSpecialEffectId(TARGET_SELF, 15607) then
            f2_local6 = 0
        end
        if f2_local3 >= 10 then
            f2_local0[3] = 20 * f2_local6
            f2_local0[18] = 80
        elseif f2_local3 >= 5 then
            f2_local0[1] = 40
            f2_local0[2] = 25
            f2_local0[3] = 20 * f2_local6
            f2_local0[5] = 15
        elseif f2_local3 >= 2 then
            f2_local0[1] = 30
            f2_local0[4] = 50
            f2_local0[5] = 20
        else
            f2_local0[1] = 20
            f2_local0[4] = 35
            f2_local0[5] = 15
            f2_local0[15] = 30
        end
    end
    f2_local0[1] = SetCoolTime(f2_arg1, f2_arg2, 3024, 5, f2_local0[1], 1)
    f2_local0[2] = SetCoolTime(f2_arg1, f2_arg2, 3025, 5, f2_local0[2], 1)
    f2_local0[3] = SetCoolTime(f2_arg1, f2_arg2, 3026, 5, f2_local0[3], 1)
    f2_local0[4] = SetCoolTime(f2_arg1, f2_arg2, 3020, 10, f2_local0[4], 1)
    f2_local0[5] = SetCoolTime(f2_arg1, f2_arg2, 3022, 15, f2_local0[5], 1)
    f2_local0[7] = SetCoolTime(f2_arg1, f2_arg2, 3003, 7, f2_local0[7], 1)
    f2_local0[8] = SetCoolTime(f2_arg1, f2_arg2, 3004, 7, f2_local0[8], 1)
    f2_local1[1] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347050_Act01)
    f2_local1[2] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347050_Act02)
    f2_local1[3] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347050_Act03)
    f2_local1[4] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347050_Act04)
    f2_local1[5] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347050_Act05)
    f2_local1[7] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347050_Act07)
    f2_local1[8] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347050_Act08)
    f2_local1[15] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347050_Act15)
    f2_local1[17] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347050_Act17)
    f2_local1[18] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347050_Act18)
    f2_local1[25] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347050_Act25)
    f2_local1[30] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347050_Act30)
    f2_local1[31] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347050_Act31)
    local f2_local6 = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347050_ActAfter_AdjustSpace)
    Common_Battle_Activate(f2_arg1, f2_arg2, f2_local0, f2_local1, f2_local6, f2_local2)
    
end

function FrogHuman_347050_Act01(f3_arg0, f3_arg1, f3_arg2)
    local f3_local0 = 4.5
    local f3_local1 = 100
    local f3_local2 = 999
    local f3_local3 = 0
    local f3_local4 = 0
    local f3_local5 = 4
    local f3_local6 = 8
    Approach_Act_Flex(f3_arg0, f3_arg1, f3_local0, f3_local1, f3_local2, f3_local3, f3_local4, f3_local5, f3_local6)
    local f3_local7 = 3024
    local f3_local8 = 6
    local f3_local9 = 0
    local f3_local10 = 180
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f3_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 5, f3_local7, TARGET_ENE_0, f3_local8, f3_local9, f3_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347050_Act02(f4_arg0, f4_arg1, f4_arg2)
    local f4_local0 = 6
    local f4_local1 = 100
    local f4_local2 = 999
    local f4_local3 = 0
    local f4_local4 = 0
    local f4_local5 = 4
    local f4_local6 = 8
    Approach_Act_Flex(f4_arg0, f4_arg1, f4_local0, f4_local1, f4_local2, f4_local3, f4_local4, f4_local5, f4_local6)
    local f4_local7 = 3025
    local f4_local8 = 6
    local f4_local9 = 0
    local f4_local10 = 180
    f4_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 5, f4_local7, TARGET_ENE_0, f4_local8, f4_local9, f4_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347050_Act03(f5_arg0, f5_arg1, f5_arg2)
    local f5_local0 = 12
    local f5_local1 = 100
    local f5_local2 = 999
    local f5_local3 = 0
    local f5_local4 = 0
    local f5_local5 = 4
    local f5_local6 = 8
    Approach_Act_Flex(f5_arg0, f5_arg1, f5_local0, f5_local1, f5_local2, f5_local3, f5_local4, f5_local5, f5_local6)
    local f5_local7 = 3026
    local f5_local8 = 6
    local f5_local9 = 0
    local f5_local10 = 180
    f5_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 5, f5_local7, TARGET_ENE_0, f5_local8, f5_local9, f5_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347050_Act04(f6_arg0, f6_arg1, f6_arg2)
    local f6_local0 = 4
    local f6_local1 = 100
    local f6_local2 = 999
    local f6_local3 = 0
    local f6_local4 = 0
    local f6_local5 = 4
    local f6_local6 = 8
    Approach_Act_Flex(f6_arg0, f6_arg1, f6_local0, f6_local1, f6_local2, f6_local3, f6_local4, f6_local5, f6_local6)
    local f6_local7 = 3020
    local f6_local8 = 6
    local f6_local9 = 7
    local f6_local10 = 0
    local f6_local11 = 180
    local f6_local12 = f6_arg0:GetRandam_Int(1, 100)
    f6_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    f6_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f6_local7, TARGET_ENE_0, f6_local0, f6_local10, f6_local11, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347050_Act05(f7_arg0, f7_arg1, f7_arg2)
    local f7_local0 = 4.5
    local f7_local1 = 100
    local f7_local2 = 999
    local f7_local3 = 0
    local f7_local4 = 0
    local f7_local5 = 4
    local f7_local6 = 8
    Approach_Act_Flex(f7_arg0, f7_arg1, f7_local0, f7_local1, f7_local2, f7_local3, f7_local4, f7_local5, f7_local6)
    local f7_local7 = 3022
    local f7_local8 = 4.5
    local f7_local9 = 0
    local f7_local10 = 180
    f7_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 2, f7_local7, TARGET_ENE_0, f7_local8, f7_local9, f7_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347050_Act07(f8_arg0, f8_arg1, f8_arg2)
    local f8_local0 = 20
    local f8_local1 = 100
    local f8_local2 = 999
    local f8_local3 = 0
    local f8_local4 = 0
    local f8_local5 = 4
    local f8_local6 = 8
    Approach_Act_Flex(f8_arg0, f8_arg1, f8_local0, f8_local1, f8_local2, f8_local3, f8_local4, f8_local5, f8_local6)
    local f8_local7 = 3003
    local f8_local8 = 5
    local f8_local9 = 0
    local f8_local10 = 180
    f8_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 2, f8_local7, TARGET_ENE_0, f8_local8, f8_local9, f8_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347050_Act08(f9_arg0, f9_arg1, f9_arg2)
    local f9_local0 = 20
    local f9_local1 = 100
    local f9_local2 = 999
    local f9_local3 = 0
    local f9_local4 = 0
    local f9_local5 = 4
    local f9_local6 = 8
    Approach_Act_Flex(f9_arg0, f9_arg1, f9_local0, f9_local1, f9_local2, f9_local3, f9_local4, f9_local5, f9_local6)
    local f9_local7 = 3004
    local f9_local8 = 5
    local f9_local9 = 0
    local f9_local10 = 180
    f9_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 2, f9_local7, TARGET_ENE_0, f9_local8, f9_local9, f9_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347050_Act15(f10_arg0, f10_arg1, f10_arg2)
    local f10_local0 = f10_arg0:GetDist(TARGET_ENE_0)
    local f10_local1 = 4
    local f10_local2 = 0
    local f10_local3 = 0
    local f10_local4 = f10_arg0:GetRandam_Int(1, 100)
    local f10_local5 = -1
    if f10_local4 <= f10_local3 then
        f10_local5 = 9910
    end
    f10_arg0:SetTimer(0, 6)
    f10_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 2, TARGET_ENE_0, f10_local1, TARGET_ENE_0, true, f10_local5)
    
end

function FrogHuman_347050_Act17(f11_arg0, f11_arg1, f11_arg2)
    f11_arg1:AddSubGoal(GOAL_COMMON_Turn, 1, TARGET_ENE_0, 90, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347050_Act18(f12_arg0, f12_arg1, f12_arg2)
    local f12_local0 = f12_arg0:GetDist(TARGET_ENE_0)
    local f12_local1 = 3
    local f12_local2 = 30
    local f12_local3 = f12_arg0:GetRandam_Int(1, 100)
    local f12_local4 = true
    local f12_local5 = -1
    f12_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 4, TARGET_ENE_0, f12_local1, TARGET_ENE_0, f12_local4, f12_local5)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347050_Act30(f13_arg0, f13_arg1, f13_arg2)
    local f13_local0 = f13_arg0:GetDist(TARGET_ENE_0)
    local f13_local1 = f13_arg0:GetRandam_Int(4, 8)
    local f13_local2 = 999
    local f13_local3 = 0
    local f13_local4 = f13_arg0:GetStringIndexedNumber("c3470_DashRate")
    local f13_local5 = 0
    local f13_local6 = f13_arg0:GetRandam_Int(2, 10)
    local f13_local7 = 0
    Approach_Act_Flex(f13_arg0, f13_arg1, f13_local1, f13_local2, f13_local3, f13_local4, f13_local5, f13_local6, f13_local7)
    local f13_local8 = f13_arg0:GetRandam_Int(2, 5)
    local f13_local9 = TARGET_ENE_0
    local f13_local10 = f13_arg0:GetRandam_Int(0, 1)
    local f13_local11 = f13_arg0:GetRandam_Int(90, 360)
    local f13_local12 = 2
    local f13_local13 = TARGET_SELF
    local f13_local14 = true
    local f13_local15 = true
    local f13_local16 = f13_arg0:GetDist(TARGET_ENE_0)
    local f13_local17 = 0
    local f13_local18 = f13_arg0:GetRandam_Int(1, 100)
    local f13_local19 = -1
    if f13_local18 <= f13_local17 then
        f13_local19 = -1
    end
    f13_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, f13_local8, f13_local9, f13_local10, f13_local11, f13_local14, -1, f13_local15, f13_local19)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347050_Act31(f14_arg0, f14_arg1, f14_arg2)
    local f14_local0 = 10
    local f14_local1 = TARGET_ENE_0
    local f14_local2 = 7
    local f14_local3 = TARGET_ENE_0
    local f14_local4 = true
    local f14_local5 = f14_arg0:GetDist(TARGET_ENE_0)
    local f14_local6 = 0
    local f14_local7 = f14_arg0:GetRandam_Int(1, 100)
    local f14_local8 = -1
    if f14_local7 <= f14_local6 then
        f14_local8 = -1
    end
    f14_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, f14_local0, f14_local1, f14_local2, f14_local3, f14_local4, f14_local8)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347050_ActAfter_AdjustSpace(f15_arg0, f15_arg1, f15_arg2)
    f15_arg1:AddSubGoal(GOAL_FrogHuman_347050_AfterAttackAct, 10)
    
end

Goal.Update = function (f16_arg0, f16_arg1, f16_arg2)
    return Update_Default_NoSubGoal(f16_arg0, f16_arg1, f16_arg2)
    
end

Goal.Terminate = function (f17_arg0, f17_arg1, f17_arg2)
    
end

Goal.Interrupt = function (f18_arg0, f18_arg1, f18_arg2)
    local f18_local0 = f18_arg1:GetRandam_Int(1, 100)
    if f18_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) then
        if f18_arg1:HasSpecialEffectId(TARGET_SELF, 15607) == false then
            if f18_arg1:HasSpecialEffectId(TARGET_SELF, 5025) then
                local f18_local1 = f18_arg1:GetDist(TARGET_ENE_0)
                if f18_local1 >= 3 then
                    f18_arg2:ClearSubGoal()
                    f18_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3028, TARGET_ENE_0, 99, 0, 0, 0)
                    return true
                elseif f18_local1 <= 5 and f18_local0 <= 30 and f18_arg1:GetAttackPassedTime(3020) >= 10 then
                    f18_arg2:ClearSubGoal()
                    f18_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 5, 3020, TARGET_ENE_0, 5, 0, 180, 0, 0)
                    f18_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 5026)
                    return true
                elseif f18_local1 <= 5 and f18_local0 <= 60 and f18_arg1:GetAttackPassedTime(3022) >= 10 then
                    f18_arg2:ClearSubGoal()
                    f18_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 5, 3022, TARGET_ENE_0, 5, 0, 180, 0, 0)
                    return true
                end
            elseif f18_arg1:HasSpecialEffectId(TARGET_SELF, 5026) then
                local f18_local1 = f18_arg1:GetDist(TARGET_ENE_0)
                if f18_local1 <= 4 and f18_local0 <= 70 then
                    f18_arg2:ClearSubGoal()
                    f18_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3027, TARGET_ENE_0, 99, 0, 0, 0)
                    return true
                else
                    f18_arg2:ClearSubGoal()
                    f18_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3021, TARGET_ENE_0, 99, 0, 0, 0)
                    return true
                end
            end
            return false
        end
        return false
    end
    if f18_arg1:IsInterupt(INTERUPT_Damaged) then
        local f18_local1 = f18_arg1:GetDist(TARGET_ENE_0)
        if f18_local1 <= 5.5 and f18_arg1:GetAttackPassedTime(3025) >= 10 and f18_local0 <= 75 then
            f18_arg2:ClearSubGoal()
            f18_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3025, TARGET_ENE_0, 99, 0, 0, 0, 0, 0)
            return true
        end
        return false
    end
    return false
    
end

RegisterTableGoal(GOAL_FrogHuman_347050_AfterAttackAct, "GOAL_FrogHuman_347050_AfterAttackAct")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_FrogHuman_347050_AfterAttackAct, true)

Goal.Activate = function (f19_arg0, f19_arg1, f19_arg2)
    
end

Goal.Update = function (f20_arg0, f20_arg1, f20_arg2)
    return Update_Default_NoSubGoal(f20_arg0, f20_arg1, f20_arg2)
    
end


