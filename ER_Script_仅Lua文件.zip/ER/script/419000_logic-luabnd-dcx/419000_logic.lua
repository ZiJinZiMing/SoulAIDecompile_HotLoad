﻿function ScarabLarge419000_Logic(f1_arg0)
    COMMON_Initialize(f1_arg0)
    f1_arg0:SetEnableUsePath(true)
    if COMMON_EasySetup_Initial(f1_arg0) == false then
        local f1_local0 = f1_arg0:GetEventRequest()
        local f1_local1 = f1_arg0:IsSearchTarget(TARGET_ENE_0)
        if f1_arg0:HasSpecialEffectId(TARGET_SELF, 12604) == true then
            if f1_arg0:IsBattleState() == true then
                COMMON_EasySetup3(f1_arg0)
            else
                f1_arg0:AddTopGoal(GOAL_COMMON_Wait, f1_arg0:GetRandam_Float(0, 0.25), TARGET_NONE, 0, 0, 0)
            end
        else
            COMMON_EasySetup3(f1_arg0)
        end
    end
    
end

function ScarabLarge419000_Interupt(f2_arg0, f2_arg1)
    
end


