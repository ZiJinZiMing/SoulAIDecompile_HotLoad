﻿RegisterTableGoal(GOAL_DosouSkeletonSickle350020_Battle, "GOAL_DosouSkeletonSickle350020_Battle")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_DosouSkeletonSickle350020_Battle, true)

Goal.Initialize = function (f1_arg0, f1_arg1, f1_arg2, f1_arg3)
    
end

Goal.Activate = function (f2_arg0, f2_arg1, f2_arg2)
    Init_Pseudo_Global(f2_arg1, f2_arg2)
    local f2_local0 = {}
    local f2_local1 = {}
    local f2_local2 = {}
    Common_Clear_Param(f2_local0, f2_local1, f2_local2)
    local f2_local3 = f2_arg1:GetDist(TARGET_ENE_0)
    local f2_local4 = f2_arg1:GetRandam_Int(1, 100)
    local f2_local5 = f2_arg1:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__thinkAttr_doAdmirer)
    local f2_local6 = f2_arg1:HasSpecialEffectId(TARGET_SELF, 12545)
    local f2_local7 = f2_arg1:GetEventRequest()
    if f2_arg1:HasSpecialEffectId(TARGET_SELF, 19050) then
        if f2_local7 == 10 then
            f2_local0[41] = 10
        elseif f2_local3 > 3 then
            f2_local0[40] = 20
            f2_local0[30] = 5
        else
            f2_local0[1] = 10
            f2_local0[2] = 10
            f2_local0[40] = 20
        end
    elseif f2_local5 == 1 and f2_arg1:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Kankyaku then
        if f2_local3 >= 7 then
            f2_local0[31] = 100
        else
            f2_local0[30] = 100
        end
    elseif f2_local5 == 1 and f2_arg1:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Torimaki then
        if f2_local3 >= 7 then
            f2_local0[31] = 100
        else
            f2_local0[3] = 20
            f2_local0[4] = 40
            f2_local0[30] = 40
        end
    elseif f2_local3 >= 7 then
        f2_local0[1] = 0
        f2_local0[2] = 0
        f2_local0[3] = 70
        f2_local0[4] = 30
        f2_local0[5] = 0
        f2_local0[15] = 40
    elseif f2_local3 >= 3 then
        if InsideRange(f2_arg1, f2_arg2, 0, 150, 0, 99) then
            f2_local0[2] = 40
            f2_local0[3] = 20
            f2_local0[4] = 40
            f2_local0[5] = 20
            f2_local0[15] = 40
            f2_local0[32] = 30
        else
            f2_local0[2] = 0
            f2_local0[4] = 60
            f2_local0[5] = 40
            f2_local0[15] = 40
            f2_local0[32] = 30
        end
    elseif InsideRange(f2_arg1, f2_arg2, 0, 180, 0, 99) then
        f2_local0[1] = 70
        f2_local0[32] = 30
        f2_local0[15] = 40
    else
        f2_local0[1] = 1
        f2_local0[32] = 1
    end
    f2_local0[4] = SetCoolTime(f2_arg1, f2_arg2, 3013, 5, f2_local0[4], 0)
    f2_local0[15] = SetCoolTime(f2_arg1, f2_arg2, 3030, 15, f2_local0[15], 0)
    if f2_local6 == false then
        f2_local0[15] = 0
    end
    f2_local1[1] = REGIST_FUNC(f2_arg1, f2_arg2, DosouSkeletonSickle350020_Act01)
    f2_local1[2] = REGIST_FUNC(f2_arg1, f2_arg2, DosouSkeletonSickle350020_Act02)
    f2_local1[3] = REGIST_FUNC(f2_arg1, f2_arg2, DosouSkeletonSickle350020_Act03)
    f2_local1[4] = REGIST_FUNC(f2_arg1, f2_arg2, DosouSkeletonSickle350020_Act04)
    f2_local1[5] = REGIST_FUNC(f2_arg1, f2_arg2, DosouSkeletonSickle350020_Act05)
    f2_local1[15] = REGIST_FUNC(f2_arg1, f2_arg2, DosouSkeletonSickle350020_Act15)
    f2_local1[30] = REGIST_FUNC(f2_arg1, f2_arg2, DosouSkeletonSickle350020_Act30)
    f2_local1[31] = REGIST_FUNC(f2_arg1, f2_arg2, DosouSkeletonSickle350020_Act31)
    f2_local1[32] = REGIST_FUNC(f2_arg1, f2_arg2, DosouSkeletonSickle350020_Act32)
    f2_local1[40] = REGIST_FUNC(f2_arg1, f2_arg2, DosouSkeletonSickle350020_Act40)
    f2_local1[41] = REGIST_FUNC(f2_arg1, f2_arg2, DosouSkeletonSickle350020_Act41)
    f2_local1[42] = REGIST_FUNC(f2_arg1, f2_arg2, DosouSkeletonSickle350020_Act42)
    local f2_local8 = REGIST_FUNC(f2_arg1, f2_arg2, DosouSkeletonSickle350020_ActAfter_AdjustSpace)
    Common_Battle_Activate(f2_arg1, f2_arg2, f2_local0, f2_local1, f2_local8, f2_local2)
    
end

function DosouSkeletonSickle350020_Act01(f3_arg0, f3_arg1, f3_arg2)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17410)
    local f3_local0 = 4 - f3_arg0:GetMapHitRadius(TARGET_SELF)
    local f3_local1 = f3_local0 + 0
    local f3_local2 = f3_local0 + 50
    local f3_local3 = 0
    local f3_local4 = 0
    local f3_local5 = 4
    local f3_local6 = 8
    Approach_Act_Flex(f3_arg0, f3_arg1, f3_local0, f3_local1, f3_local2, f3_local3, f3_local4, f3_local5, f3_local6)
    local f3_local7 = 3011
    local f3_local8 = 3015
    local f3_local9 = 4
    local f3_local10 = 4
    local f3_local11 = 0
    local f3_local12 = 0
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f3_local7, TARGET_ENE_0, f3_local9, 0, 0, 0, 0)
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 10, f3_local8, TARGET_ENE_0, f3_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DosouSkeletonSickle350020_Act02(f4_arg0, f4_arg1, f4_arg2)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17410)
    local f4_local0 = 6 - f4_arg0:GetMapHitRadius(TARGET_SELF)
    local f4_local1 = f4_local0 + 0
    local f4_local2 = f4_local0 + 50
    local f4_local3 = 0
    local f4_local4 = 0
    local f4_local5 = 4
    local f4_local6 = 8
    Approach_Act_Flex(f4_arg0, f4_arg1, f4_local0, f4_local1, f4_local2, f4_local3, f4_local4, f4_local5, f4_local6)
    local f4_local7 = 3012
    local f4_local8 = 5 - f4_arg0:GetMapHitRadius(TARGET_SELF)
    local f4_local9 = 0
    local f4_local10 = 0
    f4_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f4_local7, TARGET_ENE_0, f4_local8, f4_local9, f4_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DosouSkeletonSickle350020_Act03(f5_arg0, f5_arg1, f5_arg2)
    local f5_local0 = 20 - f5_arg0:GetMapHitRadius(TARGET_SELF)
    local f5_local1 = f5_local0 + 0
    local f5_local2 = f5_local0 + 50
    local f5_local3 = 0
    local f5_local4 = 0
    local f5_local5 = 4
    local f5_local6 = 8
    Approach_Act_Flex(f5_arg0, f5_arg1, f5_local0, f5_local1, f5_local2, f5_local3, f5_local4, f5_local5, f5_local6)
    local f5_local7 = f5_arg0:GetRandam_Int(1, 100)
    local f5_local8 = f5_arg0:GetDist(TARGET_ENE_0)
    if f5_local8 <= 1.5 then
        f5_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 5, TARGET_ENE_0, 2, TARGET_ENE_0, false, -1)
    end
    local f5_local9 = 3013
    local f5_local10 = 5 - f5_arg0:GetMapHitRadius(TARGET_SELF)
    local f5_local11 = 0
    local f5_local12 = 0
    f5_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f5_local9, TARGET_ENE_0, f5_local10, f5_local11, f5_local12, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DosouSkeletonSickle350020_Act04(f6_arg0, f6_arg1, f6_arg2)
    local f6_local0 = 3010
    local f6_local1 = 5 - f6_arg0:GetMapHitRadius(TARGET_SELF)
    local f6_local2 = 0
    local f6_local3 = 0
    f6_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f6_local0, TARGET_ENE_0, f6_local1, f6_local2, f6_local3, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DosouSkeletonSickle350020_Act05(f7_arg0, f7_arg1, f7_arg2)
    local f7_local0 = 5.5 - f7_arg0:GetMapHitRadius(TARGET_SELF)
    local f7_local1 = f7_local0 + 0
    local f7_local2 = f7_local0 + 50
    local f7_local3 = 0
    local f7_local4 = 0
    local f7_local5 = 4
    local f7_local6 = 8
    Approach_Act_Flex(f7_arg0, f7_arg1, f7_local0, f7_local1, f7_local2, f7_local3, f7_local4, f7_local5, f7_local6)
    local f7_local7 = 3014
    local f7_local8 = 5 - f7_arg0:GetMapHitRadius(TARGET_SELF)
    local f7_local9 = 0
    local f7_local10 = 0
    f7_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f7_local7, TARGET_ENE_0, f7_local8, f7_local9, f7_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DosouSkeletonSickle350020_Act15(f8_arg0, f8_arg1, f8_arg2)
    local f8_local0 = 13
    local f8_local1 = f8_local0 + 0
    local f8_local2 = f8_local0 + 50
    local f8_local3 = 100
    local f8_local4 = 0
    local f8_local5 = 4
    local f8_local6 = 8
    Approach_Act_Flex(f8_arg0, f8_arg1, f8_local0, f8_local1, f8_local2, f8_local3, f8_local4, f8_local5, f8_local6)
    f8_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17602)
    local f8_local7 = 3030
    local f8_local8 = 7
    local f8_local9 = 7
    local f8_local10 = 0
    local f8_local11 = 0
    local f8_local12 = f8_arg0:GetRandam_Int(1, 100)
    f8_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f8_local7, TARGET_ENE_0, f8_local0, f8_local10, f8_local11, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DosouSkeletonSickle350020_Act30(f9_arg0, f9_arg1, f9_arg2)
    f9_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17410)
    f9_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, f9_arg0:GetRandam_Float(2, 3), TARGET_ENE_0, f9_arg0:GetRandam_Int(0, 1), f9_arg0:GetRandam_Int(30, 45), true, true, -1)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DosouSkeletonSickle350020_Act31(f10_arg0, f10_arg1, f10_arg2)
    local f10_local0 = f10_arg0:GetDist(TARGET_ENE_0)
    local f10_local1 = f10_arg0:GetRandam_Float(2, 4)
    local f10_local2 = f10_arg0:GetRandam_Float(4, 6)
    local f10_local3 = -1
    f10_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, f10_local1, TARGET_ENE_0, f10_local2, TARGET_SELF, true, f10_local3)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DosouSkeletonSickle350020_Act32(f11_arg0, f11_arg1, f11_arg2)
    local f11_local0 = f11_arg0:GetDist(TARGET_ENE_0)
    local f11_local1 = f11_arg0:GetRandam_Float(2, 4)
    local f11_local2 = f11_arg0:GetRandam_Float(4, 6)
    local f11_local3 = -1
    if f11_local0 > 5 then
        f11_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 5, TARGET_ENE_0, 8, TARGET_ENE_0, false, -1)
    else
        f11_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 5, TARGET_ENE_0, 5, TARGET_ENE_0, false, -1)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DosouSkeletonSickle350020_Act40(f12_arg0, f12_arg1, f12_arg2)
    local f12_local0 = f12_arg0:GetRandam_Int(1, 100)
    local f12_local1 = f12_arg0:GetDist(TARGET_ENE_0)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17410)
    if f12_local1 <= 30 then
        local f12_local2 = 3016
        local f12_local3 = 5 - f12_arg0:GetMapHitRadius(TARGET_SELF)
        local f12_local4 = 0
        local f12_local5 = 0
        f12_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f12_local2, TARGET_ENE_0, f12_local3, f12_local4, f12_local5, 0, 0)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DosouSkeletonSickle350020_Act41(f13_arg0, f13_arg1, f13_arg2)
    local f13_local0 = 20020
    local f13_local1 = 5 - f13_arg0:GetMapHitRadius(TARGET_SELF)
    local f13_local2 = 0
    local f13_local3 = 0
    f13_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f13_local0, TARGET_ENE_0, f13_local1, f13_local2, f13_local3, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DosouSkeletonSickle350020_Act42(f14_arg0, f14_arg1, f14_arg2)
    f14_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17410)
    local f14_local0 = f14_arg0:GetDist(TARGET_ENE_0)
    local f14_local1 = f14_arg0:GetRandam_Float(2, 4)
    local f14_local2 = f14_arg0:GetRandam_Float(4, 6)
    local f14_local3 = -1
    if f14_local0 > 5 then
        f14_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 5, TARGET_ENE_0, 8, TARGET_ENE_0, false, -1)
    else
        f14_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 5, TARGET_ENE_0, 5, TARGET_ENE_0, false, -1)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DosouSkeletonSickle350020_ActAfter_AdjustSpace(f15_arg0, f15_arg1, f15_arg2)
    f15_arg1:AddSubGoal(GOAL_DosouSkeletonSickle350020_AfterAttackAct, 10)
    
end

Goal.Update = function (f16_arg0, f16_arg1, f16_arg2)
    return Update_Default_NoSubGoal(f16_arg0, f16_arg1, f16_arg2)
    
end

Goal.Terminate = function (f17_arg0, f17_arg1, f17_arg2)
    
end

Goal.Interrupt = function (f18_arg0, f18_arg1, f18_arg2)
    f18_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 17410)
    if f18_arg1:HasSpecialEffectId(TARGET_SELF, 17410) then
        f18_arg2:ClearSubGoal()
        DosouSkeletonSickle350020_Act41(f18_arg1, f18_arg2)
        return true
    end
    return false
    
end

RegisterTableGoal(GOAL_DosouSkeletonSickle350020_AfterAttackAct, "GOAL_DosouSkeletonSickle350020_AfterAttackAct")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_DosouSkeletonSickle350020_AfterAttackAct, true)

Goal.Activate = function (f19_arg0, f19_arg1, f19_arg2)
    
end

Goal.Update = function (f20_arg0, f20_arg1, f20_arg2)
    return Update_Default_NoSubGoal(f20_arg0, f20_arg1, f20_arg2)
    
end


