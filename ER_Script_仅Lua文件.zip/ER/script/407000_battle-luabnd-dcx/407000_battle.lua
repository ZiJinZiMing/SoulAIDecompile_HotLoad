﻿RegisterTableGoal(GOAL_Wolf407000_Battle, "GOAL_Wolf407000_Battle")
REGISTER_GOAL_NO_UPDATE(GOAL_Wolf407000_Battle, true)

Goal.Initialize = function (f1_arg0, f1_arg1, f1_arg2, f1_arg3)
    f1_arg1:GetStringIndexedNumber("firstBark")
    f1_arg1:SetTimer(4, 4)
    f1_arg1:SetNumber(5, 0)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3000)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3001)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3002)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3003)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3004)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3005)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3010)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3012)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3013)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3014)
    
end

Goal.Activate = function (f2_arg0, f2_arg1, f2_arg2)
    Init_Pseudo_Global(f2_arg1, f2_arg2)
    if FearOfFire(f2_arg1, f2_arg2, PLAN_SIDEWAYTYPE__DEFAULT) == true then
        return
    end
    f2_arg1:DeleteObserve(0)
    f2_arg1:SetStringIndexedNumber("Dist_SideStep", 2.5)
    f2_arg1:SetStringIndexedNumber("Dist_BackStep", 4)
    if f2_arg1:GetNumber(0) == 1 then
        f2_arg1:SetStringIndexedNumber("AddDistRun", 1.5)
    else
        f2_arg1:SetStringIndexedNumber("AddDistRun", 1.2)
    end
    if f2_arg1:GetNumber(0) ~= 1 then
        f2_arg1:SetNumber(1, -1.4)
    end
    local f2_local0 = {}
    local f2_local1 = {}
    local f2_local2 = {}
    Common_Clear_Param(f2_local0, f2_local1, f2_local2)
    local f2_local3 = f2_arg1:GetDist(TARGET_ENE_0)
    local f2_local4 = f2_arg1:GetDist(TARGET_EVENT)
    local f2_local5 = f2_arg1:GetRandam_Int(1, 100)
    local f2_local6 = f2_arg1:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__thinkAttr_doAdmirer)
    local f2_local7 = f2_arg1:GetEventRequest()
    local f2_local8 = f2_arg1:IsSearchTarget(TARGET_ENE_0)
    if f2_arg1:HasSpecialEffectId(TARGET_SELF, 14570) then
        if f2_arg1:HasSpecialEffectId(TARGET_SELF, 14572) then
            f2_local0[35] = 100
        else
            f2_local0[13] = 50
            f2_local0[16] = 1
            f2_local0[31] = 20
            f2_local0[32] = 20
            f2_local0[3] = 30
            f2_local0[36] = 80
        end
    elseif f2_arg1:HasSpecialEffectId(TARGET_SELF, 16941) then
        f2_local0[33] = 100
    elseif (f2_arg1:GetNpcThinkParamID() == 40703000 or f2_arg1:IsFinishTimer(4)) and f2_local3 >= 5 and f2_arg1:HasSpecialEffectId(TARGET_SELF, 13020) == false and f2_arg1:GetStringIndexedNumber("firstBark") == 0 then
        f2_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3200, TARGET_ENE_0, 10, 0, 180, 0, 0)
        f2_arg1:SetStringIndexedNumber("firstBark", 1)
    elseif f2_arg1:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_BUDDY_DECLARE) == true then
        if f2_arg1:GetNumber(5) == 0 then
            f2_local0[9] = 100
        elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_B, 180, 90, 20) then
            f2_local0[13] = 20
            f2_local0[14] = 80
        elseif f2_local3 <= 2 then
            f2_local0[1] = 30
            f2_local0[4] = 50
            f2_local0[10] = 20
        elseif f2_local3 <= 7 then
            f2_local0[1] = 10
            f2_local0[2] = 30
            f2_local0[3] = 20
            f2_local0[5] = 40
        else
            f2_local0[2] = 20
            f2_local0[5] = 30
            f2_local0[27] = 50
        end
    else
        if not f2_arg1:HasSpecialEffectId(TARGET_SELF, 13020) then
            f2_local0[22] = 35
            f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 13020)
        else
            local f2_local9 = f2_arg1:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__thinkAttr_doAdmirer)
            if f2_local9 == 1 and f2_arg1:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Kankyaku then
                local f2_local10 = f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_B, 180, 90, 50)
                if f2_local10 == true then
                    if f2_local3 >= 4 then
                        f2_local0[14] = 100
                    else
                        f2_local0[10] = 20
                        f2_local0[13] = 70
                        f2_local0[14] = 10
                    end
                elseif f2_local3 >= 5 then
                    f2_local0[9] = 50
                    f2_local0[22] = 50
                    if f2_arg1:HasSpecialEffectId(TARGET_SELF, 16940) then
                        f2_local0[33] = 50
                    end
                else
                    f2_local0[21] = 80
                    f2_local0[22] = 50
                end
            elseif f2_local9 == 1 and f2_arg1:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Torimaki then
                local f2_local10 = f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_B, 180, 180, 50)
                if f2_local10 == true then
                    if f2_local3 >= 4 then
                        f2_local0[14] = 100
                    else
                        f2_local0[10] = 30
                        f2_local0[13] = 60
                        f2_local0[14] = 10
                    end
                elseif f2_local3 >= 5 then
                    f2_local0[9] = 60
                    f2_local0[22] = 40
                    if f2_arg1:HasSpecialEffectId(TARGET_SELF, 16940) then
                        f2_local0[33] = 50
                    end
                else
                    f2_local0[13] = 25
                    f2_local0[16] = 75
                end
            else
                local f2_local10 = f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 140, 180, 50)
                local f2_local11 = f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_B, 60, 180, 50)
                if f2_local11 == true then
                    if f2_local3 >= 4 then
                        f2_local0[14] = 100
                    else
                        f2_local0[13] = 40
                    end
                elseif f2_local10 == true then
                    if f2_local3 >= 9 then
                        f2_local0[2] = 15
                        f2_local0[16] = 50
                        f2_local0[22] = 35
                    elseif f2_local3 >= 5 then
                        f2_local0[1] = 55
                        f2_local0[2] = 45
                    elseif f2_local3 >= 2 then
                        f2_local0[1] = 50
                        f2_local0[3] = 30
                        f2_local0[10] = 20
                    else
                        f2_local0[3] = 20
                        f2_local0[4] = 60
                        f2_local0[10] = 10
                        f2_local0[13] = 10
                    end
                elseif f2_local3 >= 9 then
                    f2_local0[14] = 20
                    f2_local0[16] = 60
                    f2_local0[22] = 20
                elseif f2_local3 >= 4 then
                    f2_local0[1] = 10
                    f2_local0[2] = 10
                    f2_local0[13] = 40
                    f2_local0[14] = 40
                elseif f2_local3 >= 2 then
                    f2_local0[3] = 20
                    f2_local0[13] = 80
                else
                    f2_local0[4] = 50
                    f2_local0[10] = 10
                    f2_local0[13] = 40
                end
            end
        end
        f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 13025)
        f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 13020)
        f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5030)
        if not f2_arg1:IsFinishTimer(0) then
            f2_local0[13] = 1
        end
        if not f2_arg1:IsFinishTimer(2) then
            f2_local0[10] = 1
        end
        if not f2_arg1:IsFinishTimer(3) and f2_arg1:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Attack then
            f2_local0[22] = 1
        end
    end
    f2_local0[2] = SetCoolTime(f2_arg1, f2_arg2, 3001, 5, f2_local0[2], 1)
    f2_local0[3] = SetCoolTime(f2_arg1, f2_arg2, 3002, 5, f2_local0[3], 1)
    f2_local0[3] = SetCoolTime(f2_arg1, f2_arg2, 3202, 5, f2_local0[3], 1)
    f2_local0[4] = SetCoolTime(f2_arg1, f2_arg2, 3003, 5, f2_local0[4], 1)
    f2_local0[5] = SetCoolTime(f2_arg1, f2_arg2, 3004, 5, f2_local0[5], 1)
    f2_local0[5] = SetCoolTime(f2_arg1, f2_arg2, 3005, 5, f2_local0[5], 1)
    f2_local0[7] = SetCoolTime(f2_arg1, f2_arg2, 3006, 5, f2_local0[7], 1)
    f2_local0[8] = SetCoolTime(f2_arg1, f2_arg2, 3007, 20, f2_local0[8], 1)
    f2_local0[9] = SetCoolTime(f2_arg1, f2_arg2, 3008, 20, f2_local0[9], 1)
    f2_local0[31] = SetCoolTime(f2_arg1, f2_arg2, 3000, 5, f2_local0[31], 1)
    f2_local0[32] = SetCoolTime(f2_arg1, f2_arg2, 3001, 5, f2_local0[32], 1)
    f2_local0[33] = SetCoolTime(f2_arg1, f2_arg2, 3011, 30, f2_local0[33], 1)
    f2_local1[1] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act01)
    f2_local1[2] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act02)
    f2_local1[3] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act03)
    f2_local1[4] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act04)
    f2_local1[5] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act05)
    f2_local1[6] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act06)
    f2_local1[7] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act07)
    f2_local1[8] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act08)
    f2_local1[9] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act09)
    f2_local1[10] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act10)
    f2_local1[11] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act11)
    f2_local1[12] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act12)
    f2_local1[13] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act13)
    f2_local1[14] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act14)
    f2_local1[15] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act15)
    f2_local1[16] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act16)
    f2_local1[17] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act17)
    f2_local1[18] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act18)
    f2_local1[19] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act19)
    f2_local1[20] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act20)
    f2_local1[21] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act21)
    f2_local1[22] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act22)
    f2_local1[23] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act23)
    f2_local1[25] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act25)
    f2_local1[26] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act26)
    f2_local1[27] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act27)
    f2_local1[28] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act28)
    f2_local1[29] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act29)
    f2_local1[30] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act30)
    f2_local1[31] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act31)
    f2_local1[32] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act32)
    f2_local1[33] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act33)
    f2_local1[35] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act35)
    f2_local1[36] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act36)
    f2_local1[40] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act40)
    f2_local1[41] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act41)
    f2_local1[42] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act42)
    f2_local1[43] = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_Act43)
    local f2_local9 = REGIST_FUNC(f2_arg1, f2_arg2, Wolf407000_ActAfter_AdjustSpace)
    Common_Battle_Activate(f2_arg1, f2_arg2, f2_local0, f2_local1, f2_local9, f2_local2)
    
end

function Wolf407000_Act01(f3_arg0, f3_arg1, f3_arg2)
    local f3_local0 = 2.5
    local f3_local1 = 2.5
    local f3_local2 = AI_DIR_TYPE_ToR
    local f3_local3 = f3_arg0:GetRandam_Int(1, 100)
    local f3_local4 = 0
    local f3_local5 = 999
    local f3_local6 = 100
    local f3_local7 = 0
    local f3_local8 = 2
    local f3_local9 = 2
    local f3_local10 = false
    local f3_local11 = false
    if f3_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_R, 120) then
        f3_arg1:AddSubGoal(GOAL_COMMON_ApproachAround, 10, TARGET_ENE_0, 3.5, TARGET_SELF, false, -1, AI_DIR_TYPE_ToL, 1.5)
    elseif f3_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_L, 120) then
        f3_arg1:AddSubGoal(GOAL_COMMON_ApproachAround, 10, TARGET_ENE_0, 3.5, TARGET_SELF, false, -1, AI_DIR_TYPE_ToR, 1.5)
    end
    Approach_Act_Flex(f3_arg0, f3_arg1, f3_local0, f3_local4, f3_local5, f3_local6, f3_local7, f3_local8, f3_local9)
    local f3_local12 = 3000
    local f3_local13 = 0.7 - f3_arg0:GetMapHitRadius(TARGET_SELF)
    local f3_local14 = 4.4 - f3_arg0:GetMapHitRadius(TARGET_SELF)
    local f3_local15 = 0
    local f3_local16 = 60
    local f3_local17 = f3_arg0:GetRandam_Int(1, 100)
    local f3_local18 = f3_arg0:GetRandam_Int(1, 100)
    if f3_local17 <= 30 then
        f3_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f3_local12, TARGET_ENE_0, 5, f3_local15, f3_local16, 0, 0)
        f3_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 10, 3003, TARGET_ENE_0, 1, 0)
    else
        f3_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f3_local12, TARGET_ENE_0, 5, f3_local15, f3_local16, 0, 0)
        f3_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 10, 3010, TARGET_ENE_0, 4, 0)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wolf407000_Act02(f4_arg0, f4_arg1, f4_arg2)
    local f4_local0 = 3
    local f4_local1 = 2.5
    local f4_local2 = AI_DIR_TYPE_ToR
    local f4_local3 = f4_arg0:GetRandam_Int(1, 100)
    local f4_local4 = 0
    local f4_local5 = 999
    local f4_local6 = 100
    local f4_local7 = 0
    local f4_local8 = 2
    local f4_local9 = 2
    local f4_local10 = false
    local f4_local11 = false
    if f4_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_R, 120) then
        f4_arg1:AddSubGoal(GOAL_COMMON_ApproachAround, 10, TARGET_ENE_0, 4, TARGET_SELF, false, -1, AI_DIR_TYPE_ToL, 1.5)
    elseif f4_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_L, 120) then
        f4_arg1:AddSubGoal(GOAL_COMMON_ApproachAround, 10, TARGET_ENE_0, 4, TARGET_SELF, false, -1, AI_DIR_TYPE_ToR, 1.5)
    end
    Approach_Act_Flex(f4_arg0, f4_arg1, f4_local0, f4_local4, f4_local5, f4_local6, f4_local7, f4_local8, f4_local9)
    local f4_local12 = 3001
    local f4_local13 = 4.9 - f4_arg0:GetMapHitRadius(TARGET_SELF) + 2
    local f4_local14 = 4.4 - f4_arg0:GetMapHitRadius(TARGET_SELF)
    local f4_local15 = 0
    local f4_local16 = 60
    local f4_local17 = f4_arg0:GetRandam_Int(1, 100)
    f4_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f4_local12, TARGET_ENE_0, 5, f4_local15, f4_local16, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wolf407000_Act03(f5_arg0, f5_arg1, f5_arg2)
    local f5_local0 = 2
    local f5_local1 = 0
    local f5_local2 = 999
    local f5_local3 = 100
    local f5_local4 = 0
    local f5_local5 = 2
    local f5_local6 = 2
    local f5_local7 = false
    local f5_local8 = false
    Approach_Act_Flex(f5_arg0, f5_arg1, f5_local0, f5_local1, f5_local2, f5_local3, f5_local4, f5_local5, f5_local6)
    local f5_local9 = 3002
    local f5_local10 = 3.3 - f5_arg0:GetMapHitRadius(TARGET_SELF) + 2
    local f5_local11 = 4.4 - f5_arg0:GetMapHitRadius(TARGET_SELF)
    local f5_local12 = 0
    local f5_local13 = 60
    local f5_local14 = f5_arg0:GetRandam_Int(1, 100)
    f5_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f5_local9, TARGET_ENE_0, 5, f5_local12, f5_local13, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wolf407000_Act04(f6_arg0, f6_arg1, f6_arg2)
    local f6_local0 = 3003
    local f6_local1 = 0
    local f6_local2 = 180
    f6_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f6_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f6_local0, TARGET_ENE_0, 2, f6_local1, f6_local2, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wolf407000_Act05(f7_arg0, f7_arg1, f7_arg2)
    local f7_local0 = 6.5
    local f7_local1 = 0
    local f7_local2 = 999
    local f7_local3 = 100
    local f7_local4 = 100
    local f7_local5 = 0
    local f7_local6 = 2
    local f7_local7 = 2
    local f7_local8 = false
    local f7_local9 = false
    Approach_Act_Flex(f7_arg0, f7_arg1, f7_local0, f7_local1, f7_local2, f7_local4, f7_local5, f7_local6, f7_local7)
    local f7_local10 = 3004
    local f7_local11 = 5.14 - f7_arg0:GetMapHitRadius(TARGET_SELF)
    local f7_local12 = 4
    local f7_local13 = 0
    local f7_local14 = 60
    local f7_local15 = f7_arg0:GetRandam_Int(1, 100)
    local f7_local16 = f7_arg0:GetRandam_Int(1, 100)
    if f7_local15 <= 50 then
        f7_local10 = 3004
    else
        f7_local10 = 3005
    end
    f7_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f7_local10, TARGET_ENE_0, f7_local12, f7_local13, f7_local14, 0, 0)
    f7_arg0:SetTimer(2, 8)
    f7_arg0:SetTimer(0, 8)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wolf407000_Act06(f8_arg0, f8_arg1, f8_arg2)
    if f8_arg0:HasSpecialEffectId(TARGET_SELF, 13027) then
        f8_arg1:AddSubGoal(GOAL_COMMON_Wait, f8_arg0:GetRandam_Float(0, 0.3), TARGET_NONE, 0, 0, 0)
    end
    if not f8_arg0:IsInsideTargetEx(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 90, 999) then
        f8_arg1:AddSubGoal(GOAL_COMMON_Turn, 2, TARGET_ENE_0, 90)
    end
    local f8_local0 = 3009
    local f8_local1 = 0
    local f8_local2 = 0
    local f8_local3 = 0
    local f8_local4 = 180
    if f8_arg0:HasSpecialEffectId(TARGET_ENE_0, NKM_SP_EFFECT_IS_MIMMICK) then
        f8_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3020, TARGET_ENE_0, f8_local2, f8_local3, f8_local4, 0, 0)
    else
        f8_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3009, TARGET_ENE_0, f8_local2, f8_local3, f8_local4, 0, 0)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wolf407000_Act07(f9_arg0, f9_arg1, f9_arg2)
    f9_arg1:AddSubGoal(GOAL_COMMON_Wait, f9_arg0:GetRandam_Float(0.1, 1), TARGET_NONE, 0, 0, 0)
    local f9_local0 = 3006
    local f9_local1 = 0
    local f9_local2 = 0
    local f9_local3 = 0
    local f9_local4 = 180
    f9_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f9_local0, TARGET_ENE_0, f9_local2, f9_local3, f9_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wolf407000_Act08(f10_arg0, f10_arg1, f10_arg2)
    if f10_arg0:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Kankyaku or f10_arg0:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Torimaki then
        local f10_local0 = f10_arg0:GetStringIndexedNumber("Dist_SideStep")
        if f10_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_R, 180) then
            f10_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6002, TARGET_ENE_0, 0, AI_DIR_TYPE_L, f10_local0)
        else
            f10_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6003, TARGET_ENE_0, 0, AI_DIR_TYPE_R, f10_local0)
        end
    end
    local f10_local0 = 3007
    local f10_local1 = 0
    local f10_local2 = 0
    local f10_local3 = 0
    local f10_local4 = 180
    f10_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f10_local0, TARGET_ENE_0, f10_local2, f10_local3, f10_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wolf407000_Act09(f11_arg0, f11_arg1, f11_arg2)
    f11_arg1:AddSubGoal(GOAL_COMMON_Wait, f11_arg0:GetRandam_Float(0.1, 1), TARGET_NONE, 0, 0, 0)
    local f11_local0 = f11_arg0:GetDist(TARGET_ENE_0)
    local f11_local1 = 3008
    local f11_local2 = 0
    local f11_local3 = 0
    local f11_local4 = 0
    local f11_local5 = 180
    f11_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f11_local1, TARGET_ENE_0, f11_local3, f11_local4, f11_local5, 0, 0)
    f11_arg0:SetNumber(5, 1)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wolf407000_Act10(f12_arg0, f12_arg1, f12_arg2)
    local f12_local0 = 3
    local f12_local1 = -1
    local f12_local2 = 100
    local f12_local3 = -1
    local f12_local4 = -1
    local f12_local5 = TARGET_ENE_0
    local f12_local6 = 3
    local f12_local7 = 0
    local f12_local8 = true
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f12_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6001, TARGET_ENE_0, 0, AI_DIR_TYPE_B, 0)
    f12_arg0:SetTimer(2, 4)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wolf407000_Act11(f13_arg0, f13_arg1, f13_arg2)
    local f13_local0 = 5
    f13_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6002, TARGET_ENE_0, 0, AI_DIR_TYPE_L, f13_local0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wolf407000_Act12(f14_arg0, f14_arg1, f14_arg2)
    local f14_local0 = 5
    f14_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6003, TARGET_ENE_0, 0, AI_DIR_TYPE_R, f14_local0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wolf407000_Act13(f15_arg0, f15_arg1, f15_arg2)
    if f15_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_L, 180) then
        local f15_local0 = 4
        local f15_local1 = 6003
        local f15_local2 = TARGET_ENE_0
        local f15_local3 = 0
        local f15_local4 = AI_DIR_TYPE_R
        local f15_local5 = 0
        f15_arg1:AddSubGoal(GOAL_COMMON_SpinStep, f15_local0, f15_local1, f15_local2, f15_local3, f15_local4, f15_local5)
        f15_arg0:SetTimer(0, 4)
        GetWellSpace_Odds = 0
        return GetWellSpace_Odds
    elseif f15_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_R, 180) then
        local f15_local0 = 4
        local f15_local1 = 6002
        local f15_local2 = TARGET_ENE_0
        local f15_local3 = 0
        local f15_local4 = AI_DIR_TYPE_L
        local f15_local5 = 0
        f15_arg1:AddSubGoal(GOAL_COMMON_SpinStep, f15_local0, f15_local1, f15_local2, f15_local3, f15_local4, f15_local5)
        f15_arg0:SetTimer(0, 4)
        GetWellSpace_Odds = 0
        return GetWellSpace_Odds
    end
    
end

function Wolf407000_Act14(f16_arg0, f16_arg1, f16_arg2)
    f16_arg1:AddSubGoal(GOAL_COMMON_Turn, 2, TARGET_ENE_0, 60, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wolf407000_Act15(f17_arg0, f17_arg1, f17_arg2)
    local f17_local0 = f17_arg0:GetDist(TARGET_ENE_0)
    local f17_local1 = 1.5
    local f17_local2 = 4
    f17_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f17_local1, TARGET_ENE_0, 0, TARGET_SELF, false, -1, AI_DIR_TYPE_ToB, f17_local2)
    return 0
    
end

function Wolf407000_Act16(f18_arg0, f18_arg1, f18_arg2)
    local f18_local0 = f18_arg0:GetNumber(2) + 1
    f18_arg0:SetNumber(2, f18_local0)
    local f18_local1 = f18_arg0:GetDist(TARGET_ENE_0)
    local f18_local2 = 1.5
    local f18_local3 = 7
    local f18_local4 = 2
    local f18_local5 = f18_arg0:GetHpRate(TARGET_SELF)
    if f18_arg0:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Kankyaku then
        f18_local3 = 8
        f18_local2 = f18_arg0:GetRandam_Float(1.7, 2)
    elseif f18_arg0:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Torimaki then
        f18_local3 = 6
        f18_local2 = f18_arg0:GetRandam_Float(1.5, 1.8)
    else
        f18_local3 = 6
        f18_local2 = 1.4
    end
    if f18_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_R, 180) then
        f18_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f18_local2, TARGET_ENE_0, 5, TARGET_SELF, false, -1, AI_DIR_TYPE_ToL, f18_local3):SetTargetRange(3, f18_local4, 100)
    else
        f18_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f18_local2, TARGET_ENE_0, 5, TARGET_SELF, false, -1, AI_DIR_TYPE_ToR, f18_local3):SetTargetRange(3, f18_local4, 100)
    end
    return 0
    
end

function Wolf407000_Act17(f19_arg0, f19_arg1, f19_arg2)
    local f19_local0 = 5
    local f19_local1 = f19_arg0:GetRandam_Float(1, 2)
    f19_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, f19_local1, TARGET_ENE_0, 999, TARGET_ENE_0, true, -1)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wolf407000_Act18(f20_arg0, f20_arg1, f20_arg2)
    local f20_local0 = f20_arg0:GetNumber(2) + 1
    f20_arg0:SetNumber(2, f20_local0)
    local f20_local1 = f20_arg0:GetDist(TARGET_ENE_0)
    local f20_local2 = 1.5
    local f20_local3 = 0.5
    if f20_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_R, 180) then
        f20_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f20_local2, TARGET_ENE_0, 2, TARGET_SELF, false, -1, AI_DIR_TYPE_ToL, f20_local3)
    else
        f20_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f20_local2, TARGET_ENE_0, 2, TARGET_SELF, false, -1, AI_DIR_TYPE_ToR, f20_local3)
    end
    
end

function Wolf407000_Act19(f21_arg0, f21_arg1, f21_arg2)
    local f21_local0 = f21_arg0:GetDist(TARGET_ENE_0)
    local f21_local1 = 8.5
    local f21_local2 = 12
    local f21_local3 = 0
    if f21_arg0:GetNumber(0) == 1 then
        f21_local3 = 3.5
    else
        f21_local3 = 3.5
    end
    if f21_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_R, 180) then
        f21_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f21_local1, TARGET_ENE_0, 2, TARGET_SELF, true, 9920, AI_DIR_TYPE_ToL, f21_local2)
        f21_arg0:AddObserveAreaCustom(0, TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 360, 180, 6.5)
    else
        f21_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f21_local1, TARGET_ENE_0, 2, TARGET_SELF, true, 9920, AI_DIR_TYPE_ToR, f21_local2)
        f21_arg0:AddObserveAreaCustom(0, TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 360, 180, 6.5)
    end
    
end

function Wolf407000_Act20(f22_arg0, f22_arg1, f22_arg2)
    local f22_local0 = 9.1 - f22_arg0:GetMapHitRadius(TARGET_SELF)
    local f22_local1 = 9.1 - f22_arg0:GetMapHitRadius(TARGET_SELF)
    local f22_local2 = 0
    local f22_local3 = 0
    local f22_local4 = 0
    local f22_local5 = 4
    local f22_local6 = 5.5
    f22_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 10, TARGET_ENE_0, 2, TARGET_SELF, true, -1)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wolf407000_Act21(f23_arg0, f23_arg1, f23_arg2)
    local f23_local0 = 3.5
    local f23_local1 = f23_arg0:GetRandam_Float(3, 4.5)
    f23_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, f23_local1, TARGET_ENE_0, 15, TARGET_ENE_0, true, 9920)
    f23_arg0:AddObserveAreaCustom(0, TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 360, 180, 6)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wolf407000_Act22(f24_arg0, f24_arg1, f24_arg2)
    local f24_local0 = f24_arg0:GetRandam_Float(3.5, 5.5)
    local f24_local1 = f24_arg0:GetDist(TARGET_ENE_0)
    local f24_local2 = 15
    local f24_local3 = f24_arg0:GetRandam_Int(1, 100)
    if f24_arg0:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Attack then
        WalkLife = f24_arg0:GetRandam_Float(2.5, 3.5)
    end
    local f24_local4 = AI_DIR_TYPE_ToL
    if f24_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_R, 120) then
        f24_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f24_local0, TARGET_ENE_0, 3, TARGET_SELF, true, 9920, AI_DIR_TYPE_ToL, f24_local2)
        f24_arg0:AddObserveAreaCustom(0, TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 360, 180, 6)
        f24_arg0:SetTimer(3, 8)
    elseif f24_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_L, 120) then
        f24_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f24_local0, TARGET_ENE_0, 3, TARGET_SELF, true, 9920, AI_DIR_TYPE_ToR, f24_local2)
        f24_arg0:AddObserveAreaCustom(0, TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 360, 180, 6)
        f24_arg0:SetTimer(3, 8)
    elseif f24_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_F, 60) then
        f24_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, f24_local0, TARGET_ENE_0, 3, TARGET_SELF, true, 9920)
        f24_arg0:AddObserveAreaCustom(0, TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 360, 180, 6)
        f24_arg0:SetTimer(3, 8)
    else
        f24_arg1:AddSubGoal(GOAL_COMMON_Turn, 2, TARGET_ENE_0, 60, 0, 0)
    end
    return 0
    
end

function Wolf407000_Act23(f25_arg0, f25_arg1, f25_arg2)
    local f25_local0 = f25_arg0:GetRandam_Float(5.5, 6.5)
    local f25_local1 = f25_arg0:GetDist(TARGET_ENE_0)
    local f25_local2 = 15
    local f25_local3 = f25_arg0:GetRandam_Int(1, 100)
    if f25_arg0:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Attack then
        WalkLife = f25_arg0:GetRandam_Float(2.5, 3.5)
    end
    local f25_local4 = AI_DIR_TYPE_ToL
    if f25_local3 <= 50 then
        f25_local4 = AI_DIR_TYPE_ToL
    else
        f25_local4 = AI_DIR_TYPE_ToR
    end
    f25_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f25_local0, TARGET_ENE_0, 2, TARGET_SELF, true, -1, f25_local4, f25_local2)
    f25_arg0:SetTimer(3, 8)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wolf407000_Act24(f26_arg0, f26_arg1, f26_arg2)
    local f26_local0 = f26_arg0:GetNumber(2) + 1
    f26_arg0:SetNumber(2, f26_local0)
    local f26_local1 = 2
    local f26_local2 = 15
    if f26_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_R, 180) then
        f26_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f26_local1, TARGET_ENE_0, 0, TARGET_SELF, false, -1, AI_DIR_TYPE_ToL, f26_local2)
    else
        f26_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f26_local1, TARGET_ENE_0, 0, TARGET_SELF, false, -1, AI_DIR_TYPE_ToR, f26_local2)
    end
    return 0
    
end

function Wolf407000_Act25(f27_arg0, f27_arg1, f27_arg2)
    local f27_local0 = f27_arg0:GetRandam_Float(5.5, 6.5)
    local f27_local1 = f27_arg0:GetDist(TARGET_ENE_0)
    local f27_local2 = 15
    if f27_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_BUDDY_DECLARE) == true then
        f27_local0 = 0
    end
    local f27_local3 = 0
    if f27_arg0:GetNumber(0) == 1 then
        f27_local3 = 3.5
    else
        f27_local3 = 3.5
    end
    if f27_arg0:HasSpecialEffectId(TARGET_SELF, 13027) then
        f27_local3 = 8
    end
    local f27_local4 = 999
    if f27_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_R, 180) then
        f27_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f27_local0, TARGET_ENE_0, 2, TARGET_SELF, true, 9920, AI_DIR_TYPE_ToL, f27_local2):SetTargetRange(2, f27_local3, f27_local4)
    else
        f27_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f27_local0, TARGET_ENE_0, 2, TARGET_SELF, true, 9920, AI_DIR_TYPE_ToR, f27_local2):SetTargetRange(2, f27_local3, f27_local4)
    end
    f27_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 13025)
    f27_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 13020)
    return 0
    
end

function Wolf407000_Act26(f28_arg0, f28_arg1, f28_arg2)
    local f28_local0 = 0
    if f28_arg0:GetNumber(0) == 1 then
        f28_local0 = 3.5
    else
        f28_local0 = 3.5
    end
    if f28_arg0:HasSpecialEffectId(TARGET_SELF, 13027) then
        f28_local0 = 8
    end
    local f28_local1 = 999
    local f28_local2 = f28_arg0:GetRandam_Float(6.5, 7.5)
    if f28_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_BUDDY_DECLARE) == true then
        f28_local2 = 0
    end
    f28_arg1:AddSubGoal(GOAL_COMMON_Guard, f28_local2, 9920, TARGET_ENE_0, true, 0):SetTargetRange(2, f28_local0, f28_local1)
    f28_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 13025)
    f28_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 13020)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wolf407000_Act27(f29_arg0, f29_arg1, f29_arg2)
    local f29_local0 = 3.5
    local f29_local1 = f29_arg0:GetRandam_Float(1, 3)
    local f29_local2 = 2
    if f29_arg0:GetRandam_Int(0, 1) then
        f29_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f29_local0, TARGET_ENE_0, 0, TARGET_SELF, false, -1, AI_DIR_TYPE_ToL, f29_local1):SetTargetRange(3, f29_local2, 100)
    else
        f29_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f29_local0, TARGET_ENE_0, 0, TARGET_SELF, false, -1, AI_DIR_TYPE_ToR, f29_local1):SetTargetRange(3, f29_local2, 100)
    end
    return 0
    
end

function Wolf407000_Act28(f30_arg0, f30_arg1, f30_arg2)
    local f30_local0 = f30_arg0:GetRandam_Float(5.5, 6.5)
    local f30_local1 = f30_arg0:GetDist(POINT_EVENT)
    local f30_local2 = 5
    if f30_arg0:IsInsideTarget(POINT_EVENT, AI_DIR_TYPE_R, 180) then
        f30_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f30_local0, POINT_EVENT, 2, TARGET_SELF, true, 9920, AI_DIR_TYPE_ToL, f30_local2)
    else
        f30_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f30_local0, POINT_EVENT, 2, TARGET_SELF, true, 9920, AI_DIR_TYPE_ToR, f30_local2)
    end
    return 0
    
end

function Wolf407000_Act29(f31_arg0, f31_arg1, f31_arg2)
    local f31_local0 = f31_arg0:GetRandam_Float(6.5, 7.5)
    f31_arg1:AddSubGoal(GOAL_COMMON_Guard, f31_local0, -1, TARGET_ENE_0, true, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wolf407000_Act30(f32_arg0, f32_arg1, f32_arg2)
    local f32_local0 = f32_arg0:GetRandam_Float(5.5, 6.5)
    if f32_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_BUDDY_DECLARE) == true then
        f32_local0 = 0
    end
    local f32_local1 = f32_arg0:GetDist(TARGET_ENE_0)
    local f32_local2 = 150
    local f32_local3 = 3.5
    local f32_local4 = AI_DIR_TYPE_ToL
    if f32_arg0:HasSpecialEffectId(TARGET_SELF, 5021) then
        f32_local4 = AI_DIR_TYPE_ToL
    elseif f32_arg0:HasSpecialEffectId(TARGET_SELF, 5024) then
        f32_local4 = AI_DIR_TYPE_ToR
    elseif f32_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_R, 180) then
        f32_local4 = AI_DIR_TYPE_ToL
    else
        f32_local4 = AI_DIR_TYPE_ToR
    end
    f32_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f32_local0, TARGET_ENE_0, 2, TARGET_SELF, true, 9920, f32_local4, f32_local2):SetTargetRange(2, f32_local3, 100):SetLifeEndSuccess(true)
    return 0
    
end

function Wolf407000_Act31(f33_arg0, f33_arg1, f33_arg2)
    if not (f33_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_F, 110) and f33_arg0:IsFinishTimer(5)) then
        f33_arg0:SetTimer(0, 5)
        local f33_local0 = f33_arg0:GetStringIndexedNumber("Dist_SideStep")
        if f33_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_R, 180) then
            f33_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6002, TARGET_ENE_0, 0, AI_DIR_TYPE_L, f33_local0)
        else
            f33_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6003, TARGET_ENE_0, 0, AI_DIR_TYPE_R, f33_local0)
        end
    end
    local f33_local0 = 5.14 - f33_arg0:GetMapHitRadius(TARGET_SELF)
    local f33_local1 = f33_local0
    local f33_local2 = f33_local0 + 0
    local f33_local3 = 100
    local f33_local4 = 0
    local f33_local5 = 4
    local f33_local6 = 5.5
    f33_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 5, TARGET_ENE_0, f33_local0, TARGET_SELF, false, 0)
    local f33_local7 = 3000
    local f33_local8 = 4.5 - f33_arg0:GetMapHitRadius(TARGET_SELF)
    local f33_local9 = 0.7 - f33_arg0:GetMapHitRadius(TARGET_SELF)
    local f33_local10 = 0
    local f33_local11 = 0
    local f33_local12 = f33_arg0:GetRandam_Int(1, 100)
    local f33_local13 = f33_arg0:GetRandam_Int(1, 100)
    if f33_local12 <= 20 then
        f33_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f33_local7, TARGET_ENE_0, f33_local9, f33_local10, f33_local11, 0, 0):TimingSetTimer(6, 5, AI_TIMING_SET__ACTIVATE)
        f33_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 10, 3003, TARGET_ENE_0, 4, 0):TimingSetTimer(6, 5, AI_TIMING_SET__ACTIVATE)
    elseif f33_local12 <= 45 then
        f33_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f33_local7, TARGET_ENE_0, f33_local8, f33_local10, f33_local11, 0, 0):TimingSetTimer(6, 5, AI_TIMING_SET__ACTIVATE)
        local f33_local14 = f33_arg0:GetStringIndexedNumber("Dist_SideStep")
        if f33_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_R, 180) then
            f33_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6002, TARGET_ENE_0, 0, AI_DIR_TYPE_L, f33_local14)
        else
            f33_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6003, TARGET_ENE_0, 0, AI_DIR_TYPE_R, f33_local14)
        end
        f33_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 5, TARGET_ENE_0, f33_local0, TARGET_SELF, false, 0)
        f33_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3002, TARGET_ENE_0, SuccessDist, f33_local10, f33_local11, 0, 0):TimingSetTimer(6, 5, AI_TIMING_SET__ACTIVATE)
    elseif f33_local12 <= 70 then
        f33_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f33_local7, TARGET_ENE_0, f33_local8, f33_local10, f33_local11, 0, 0):TimingSetTimer(6, 5, AI_TIMING_SET__ACTIVATE)
        f33_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 10, 3010, TARGET_ENE_0, 4, 0):TimingSetTimer(6, 5, AI_TIMING_SET__ACTIVATE)
        local f33_local14 = 1.3
        local f33_local15 = 0.5
        if f33_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_R, 180) then
            f33_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f33_local14, TARGET_ENE_0, 0, TARGET_SELF, false, -1, AI_DIR_TYPE_ToL, f33_local15)
        else
            f33_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f33_local14, TARGET_ENE_0, 0, TARGET_SELF, false, -1, AI_DIR_TYPE_ToR, f33_local15)
        end
    else
        f33_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f33_local7, TARGET_ENE_0, f33_local8, f33_local10, f33_local11, 0, 0):TimingSetTimer(6, 5, AI_TIMING_SET__ACTIVATE)
        local f33_local14 = 1.3
        local f33_local15 = 0.5
        if f33_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_R, 180) then
            f33_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f33_local14, TARGET_ENE_0, 0, TARGET_SELF, false, -1, AI_DIR_TYPE_ToL, f33_local15)
        else
            f33_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f33_local14, TARGET_ENE_0, 0, TARGET_SELF, false, -1, AI_DIR_TYPE_ToR, f33_local15)
        end
    end
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function Wolf407000_Act32(f34_arg0, f34_arg1, f34_arg2)
    if not (f34_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_F, 120) and f34_arg0:IsFinishTimer(5)) then
        f34_arg0:SetTimer(0, 5)
        local f34_local0 = f34_arg0:GetStringIndexedNumber("Dist_SideStep")
        if f34_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_R, 180) then
            f34_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6002, TARGET_ENE_0, 0, AI_DIR_TYPE_L, f34_local0)
        else
            f34_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6003, TARGET_ENE_0, 0, AI_DIR_TYPE_R, f34_local0)
        end
    end
    local f34_local0 = 4.9 - f34_arg0:GetMapHitRadius(TARGET_SELF) + f34_arg0:GetNumber(1) + f34_arg0:GetStringIndexedNumber("AddDistRun")
    local f34_local1 = f34_local0
    local f34_local2 = f34_local0 + 0
    local f34_local3 = 100
    local f34_local4 = 0
    local f34_local5 = 4
    local f34_local6 = 5.5
    f34_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 5, TARGET_ENE_0, f34_local0, TARGET_SELF, false, 0)
    local f34_local7 = 3001
    local f34_local8 = 4.9 - f34_arg0:GetMapHitRadius(TARGET_SELF) + 2
    local f34_local9 = 4.4 - f34_arg0:GetMapHitRadius(TARGET_SELF)
    local f34_local10 = 0
    local f34_local11 = 0
    local f34_local12 = f34_arg0:GetRandam_Int(1, 100)
    f34_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f34_local7, TARGET_ENE_0, f34_local9, f34_local10, f34_local11, 0, 0):TimingSetTimer(6, 5, AI_TIMING_SET__ACTIVATE)
    local f34_local13 = 1.3
    local f34_local14 = 0.5
    if f34_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_R, 180) then
        f34_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f34_local13, TARGET_ENE_0, 0, TARGET_SELF, false, -1, AI_DIR_TYPE_ToL, f34_local14)
    else
        f34_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f34_local13, TARGET_ENE_0, 0, TARGET_SELF, false, -1, AI_DIR_TYPE_ToR, f34_local14)
    end
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function Wolf407000_Act33(f35_arg0, f35_arg1, f35_arg2)
    local f35_local0 = 10
    local f35_local1 = 3011
    local f35_local2 = 4.4 - f35_arg0:GetMapHitRadius(TARGET_SELF)
    local f35_local3 = 0
    local f35_local4 = 0
    f35_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f35_local0, f35_local1, TARGET_ENE_0, f35_local2, f35_local3, f35_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wolf407000_Act35(f36_arg0, f36_arg1, f36_arg2)
    local f36_local0 = 10
    local f36_local1 = 3035
    local f36_local2 = 4.4 - f36_arg0:GetMapHitRadius(TARGET_SELF)
    local f36_local3 = 0
    local f36_local4 = 0
    f36_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f36_local0, f36_local1, TARGET_ENE_0, f36_local2, f36_local3, f36_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wolf407000_Act36(f37_arg0, f37_arg1, f37_arg2)
    local f37_local0 = 4.9 - f37_arg0:GetMapHitRadius(TARGET_SELF) + f37_arg0:GetNumber(1)
    local f37_local1 = f37_local0
    local f37_local2 = f37_local0 + 0
    local f37_local3 = 100
    local f37_local4 = 0
    local f37_local5 = 4
    local f37_local6 = 5.5
    f37_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 5, TARGET_ENE_0, f37_local0, TARGET_SELF, false, 0)
    local f37_local7 = 3036
    local f37_local8 = 4.9 - f37_arg0:GetMapHitRadius(TARGET_SELF) + 2
    local f37_local9 = 4.4 - f37_arg0:GetMapHitRadius(TARGET_SELF)
    local f37_local10 = 0
    local f37_local11 = 0
    local f37_local12 = f37_arg0:GetRandam_Int(1, 100)
    f37_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f37_local7, TARGET_ENE_0, f37_local9, f37_local10, f37_local11, 0, 0):TimingSetTimer(6, 5, AI_TIMING_SET__ACTIVATE)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function Wolf407000_Act40(f38_arg0, f38_arg1, f38_arg2)
    local f38_local0 = 5.5
    if f38_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_BUDDY_DECLARE) == true then
        f38_local0 = 0
    end
    local f38_local1 = f38_arg0:GetDist(TARGET_ENE_0)
    local f38_local2 = 150
    local f38_local3 = 0
    if f38_arg0:GetNumber(0) == 1 then
        f38_local3 = 8
    else
        f38_local3 = 7
    end
    if f38_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_R, 180) then
        f38_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f38_local0, TARGET_ENE_0, 2, TARGET_SELF, true, 9920, AI_DIR_TYPE_ToL, f38_local2)
    else
        f38_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f38_local0, TARGET_ENE_0, 2, TARGET_SELF, true, 9920, AI_DIR_TYPE_ToR, f38_local2)
    end
    local f38_local4 = 5.5
    if f38_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_BUDDY_DECLARE) == true then
        f38_local4 = 0
    end
    f38_arg1:AddSubGoal(GOAL_COMMON_Guard, f38_local4, 9920, TARGET_ENE_0, true, 0)
    return 0
    
end

function Wolf407000_Act41(f39_arg0, f39_arg1, f39_arg2)
    local f39_local0 = 5.14 - f39_arg0:GetMapHitRadius(TARGET_SELF) + f39_arg0:GetNumber(1) + f39_arg0:GetStringIndexedNumber("AddDistRun")
    local f39_local1 = f39_local0
    local f39_local2 = f39_local0 + 0
    local f39_local3 = 100
    local f39_local4 = 0
    local f39_local5 = 4
    local f39_local6 = 5.5
    f39_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 5, TARGET_ENE_0, f39_local0, TARGET_SELF, false, 0)
    local f39_local7 = 3000
    local f39_local8 = 0.7 - f39_arg0:GetMapHitRadius(TARGET_SELF) + 0
    local f39_local9 = 1
    local f39_local10 = 0
    local f39_local11 = 60
    local f39_local12 = f39_arg0:GetRandam_Int(1, 100)
    local f39_local13 = f39_arg0:GetRandam_Int(1, 100)
    if f39_local12 <= 75 then
        f39_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f39_local7, TARGET_ENE_0, f39_local8, f39_local10, f39_local11, 0, 0):TimingSetTimer(6, 5, AI_TIMING_SET__ACTIVATE)
        f39_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 10, 3003, TARGET_ENE_0, 4, 0):TimingSetTimer(6, 5, AI_TIMING_SET__ACTIVATE)
    else
        f39_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f39_local7, TARGET_ENE_0, f39_local8, f39_local10, f39_local11, 0, 0):TimingSetTimer(6, 5, AI_TIMING_SET__ACTIVATE)
    end
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function Wolf407000_Act42(f40_arg0, f40_arg1, f40_arg2)
    local f40_local0 = 4.9 - f40_arg0:GetMapHitRadius(TARGET_SELF) + f40_arg0:GetNumber(1) + f40_arg0:GetStringIndexedNumber("AddDistRun")
    local f40_local1 = f40_local0
    local f40_local2 = f40_local0 + 0
    local f40_local3 = 100
    local f40_local4 = 0
    local f40_local5 = 4
    local f40_local6 = 5.5
    local f40_local7 = 3014
    local f40_local8 = 4.9 - f40_arg0:GetMapHitRadius(TARGET_SELF) + 2
    local f40_local9 = 4.4 - f40_arg0:GetMapHitRadius(TARGET_SELF)
    local f40_local10 = 0
    local f40_local11 = 0
    local f40_local12 = f40_arg0:GetRandam_Int(1, 100)
    f40_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f40_local7, TARGET_ENE_0, f40_local9, f40_local10, f40_local11, 0, 0):TimingSetTimer(6, 5, AI_TIMING_SET__ACTIVATE)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function Wolf407000_Act43(f41_arg0, f41_arg1, f41_arg2)
    f41_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 10, TARGET_ENE_0, 10, TARGET_SELF, false, 0)
    local f41_local0 = 5.5
    local f41_local1 = f41_arg0:GetDist(TARGET_ENE_0)
    local f41_local2 = 150
    local f41_local3 = 0
    if f41_arg0:GetNumber(0) == 1 then
        f41_local3 = 8
    else
        f41_local3 = 7
    end
    f41_arg1:AddSubGoal(GOAL_COMMON_StepSafety, 2, -1, 1, -1, -1, TARGET_ENE_0, 0, 0, true)
    f41_arg1:AddSubGoal(GOAL_COMMON_StepSafety, 2, -1, 1, -1, -1, TARGET_ENE_0, 0, 0, true)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wolf407000_ActAfter_AdjustSpace(f42_arg0, f42_arg1, f42_arg2)
    f42_arg1:AddSubGoal(GOAL_Wolf407000_AfterAttackAct, 10)
    
end

Goal.Update = function (f43_arg0, f43_arg1, f43_arg2)
    return Update_Default_NoSubGoal(f43_arg0, f43_arg1, f43_arg2)
    
end

Goal.Terminate = function (f44_arg0, f44_arg1, f44_arg2)
    
end

Goal.Interrupt = function (f45_arg0, f45_arg1, f45_arg2)
    local f45_local0 = f45_arg1:GetDist(TARGET_ENE_0)
    local f45_local1 = f45_arg1:GetRandam_Int(1, 100)
    local f45_local2 = f45_arg1:GetRandam_Int(1, 100)
    if f45_arg1:IsInterupt(INTERUPT_Inside_ObserveArea) or f45_arg1:IsInterupt(INTERUPT_Damaged) and not f45_arg1:HasSpecialEffectId(TARGET_SELF, 13020) then
        f45_arg2:ClearSubGoal()
        if f45_arg1:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Attack then
            if f45_arg1:IsFinishTimer(2) and f45_local1 <= 30 then
                Wolf407000_Act10(f45_arg1, f45_arg2, paramTbl)
                return true
            elseif f45_local1 <= 70 then
                f45_arg2:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, 3201, TARGET_ENE_0, 6, 0, 90, 0, 0)
                f45_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 10, 3010, TARGET_ENE_0, 4, 0)
                return true
            else
                f45_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3202, TARGET_ENE_0, 5, 0, 90, 0, 0)
                return true
            end
        else
            Wolf407000_Act10(f45_arg1, f45_arg2, paramTbl)
            return true
        end
        f45_arg1:DeleteObserve(0)
    end
    if f45_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f45_arg1:HasSpecialEffectId(TARGET_SELF, 5030) then
        local f45_local3 = f45_arg1:GetDist(TARGET_ENE_0)
        if f45_arg1:IsFinishTimer(3) and f45_local3 >= 6 then
            f45_arg2:ClearSubGoal()
            Wolf407000_Act22(f45_arg1, f45_arg2, paramTbl)
        end
        return true
    end
    return false
    
end

RegisterTableGoal(GOAL_Wolf407000_AfterAttackAct, "GOAL_Wolf407000_AfterAttackAct")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_Wolf407000_AfterAttackAct, true)

Goal.Activate = function (f46_arg0, f46_arg1, f46_arg2)
    
end

Goal.Update = function (f47_arg0, f47_arg1, f47_arg2)
    return Update_Default_NoSubGoal(f47_arg0, f47_arg1, f47_arg2)
    
end


