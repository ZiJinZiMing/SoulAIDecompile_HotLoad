﻿RegisterTableGoal(GOAL_RottenDead_366100_Battle, "RottenDead_366100_Battle")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_RottenDead_366100_Battle, true)

Goal.Initialize = function (f1_arg0, f1_arg1, f1_arg2, f1_arg3)
    f1_arg1:SetNumber(0, 0)
    f1_arg1:SetNumber(5, 0)
    f1_arg1:SetNumber(6, 0)
    f1_arg1:SetStringIndexedNumber("TestNumber", 0)
    
end

Goal.Activate = function (f2_arg0, f2_arg1, f2_arg2)
    Init_Pseudo_Global(f2_arg1, f2_arg2)
    f2_arg1:GetStringIndexedNumber("Loop_Cnt")
    f2_arg1:GetStringIndexedNumber("Warcry_Cnt")
    f2_arg1:GetStringIndexedNumber("Beam_Cnt")
    local f2_local0 = {}
    local f2_local1 = {}
    local f2_local2 = {}
    Common_Clear_Param(f2_local0, f2_local1, f2_local2)
    local f2_local3 = f2_arg1:GetDist(TARGET_ENE_0)
    local f2_local4 = f2_arg1:GetRandam_Int(1, 100)
    local f2_local5 = f2_arg1:GetDist(TARGET_ENE_0)
    local f2_local6 = f2_arg1:GetDist(TARGET_FRI_0)
    local f2_local7 = f2_arg1:GetDist(TARGET_SOUND)
    local f2_local8 = f2_arg1:GetRandam_Int(1, 100)
    local f2_local9 = f2_arg1:GetEventRequest()
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    local f2_local10 = f2_arg1:HasSpecialEffectId(TARGET_SELF, 17001)
    local f2_local11 = f2_arg1:HasSpecialEffectId(TARGET_SELF, 17002)
    local f2_local12 = f2_arg1:HasSpecialEffectId(TARGET_SELF, 17005)
    local f2_local13 = f2_arg1:HasSpecialEffectId(TARGET_SELF, 17006)
    local f2_local14 = f2_arg1:HasSpecialEffectId(TARGET_SELF, 17009)
    local f2_local15 = f2_arg1:HasSpecialEffectId(TARGET_SELF, 17040)
    local f2_local16 = f2_arg1:HasSpecialEffectId(TARGET_SELF, 17041)
    local f2_local17 = f2_arg1:HasSpecialEffectId(TARGET_SELF, 17014)
    local f2_local18 = f2_arg1:HasSpecialEffectId(TARGET_SELF, 17043)
    local f2_local19 = f2_arg1:HasSpecialEffectId(TARGET_SELF, 17044)
    local f2_local20 = f2_arg1:HasSpecialEffectId(TARGET_SELF, 17045)
    local f2_local21 = f2_arg1:HasSpecialEffectId(TARGET_SELF, 13471)
    local f2_local22 = f2_arg1:HasSpecialEffectId(TARGET_SELF, 17049)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 17030)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 17031)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 13477)
    f2_arg1:SetNumber(5, 0)
    if f2_local16 == true then
        if f2_local19 == true then
            f2_local0[19] = 15
        else
            f2_local0[8] = 100
        end
    elseif f2_local15 == true then
        if f2_local19 == true then
            f2_local0[19] = 15
        else
            f2_local0[7] = 100
        end
    elseif f2_local11 == true then
        if f2_local19 == true then
            f2_local0[19] = 15
        else
            f2_local0[7] = 100
        end
    elseif f2_local12 == true then
        if f2_local21 == true then
            f2_local0[15] = 15
        elseif f2_local5 > 5 then
            f2_local0[22] = 1
        else
            f2_local0[22] = 30
            f2_local0[6] = 10
        end
    elseif f2_local19 == true and f2_arg1:GetNumber(6) == 0 and f2_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_F, 120) then
        f2_local0[10] = 9999
        f2_local0[22] = 1
    elseif f2_local20 == true and f2_arg1:GetNumber(6) == 0 and f2_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_F, 120) then
        f2_local0[9] = 9999
        f2_local0[22] = 1
    elseif f2_local10 == true and f2_local17 == true then
        if f2_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_B, 120) then
            f2_local0[22] = 15
        else
            f2_local0[5] = 45
        end
    elseif f2_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_B, 140) then
        f2_local0[22] = 30
        f2_local0[23] = 30
    elseif f2_local5 >= 9 then
        f2_local0[4] = 20
        f2_local0[6] = 10
        f2_local0[22] = 40
        f2_local0[23] = 40
    elseif f2_local5 >= 6 then
        f2_local0[1] = 10
        f2_local0[2] = 15
        f2_local0[4] = 20
        f2_local0[5] = 40
        f2_local0[6] = 10
        f2_local0[9] = 20
        f2_local0[10] = 15
        f2_local0[22] = 30
        f2_local0[23] = 25
    else
        f2_local0[1] = 25
        f2_local0[2] = 25
        f2_local0[4] = 15
        f2_local0[5] = 45
        f2_local0[6] = 5
        f2_local0[9] = 20
        f2_local0[10] = 15
        f2_local0[22] = 35
    end
    f2_local0[4] = SetCoolTime(f2_arg1, f2_arg2, 3017, 10, f2_local0[4], 0)
    f2_local0[4] = SetCoolTime(f2_arg1, f2_arg2, 3019, 10, f2_local0[4], 0)
    f2_local0[5] = SetCoolTime(f2_arg1, f2_arg2, 3016, 15, f2_local0[5], 5)
    f2_local0[6] = SetCoolTime(f2_arg1, f2_arg2, 3007, 15, f2_local0[6], 1)
    f2_local0[10] = SetCoolTime(f2_arg1, f2_arg2, 3037, 15, f2_local0[10], 1)
    f2_local0[10] = SetCoolTime(f2_arg1, f2_arg2, 3038, 15, f2_local0[10], 1)
    if f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 90, 90, 12) == false then
        f2_local0[4] = 0
    end
    if f2_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_F, 120) == false then
        f2_local0[9] = 0
        f2_local0[4] = 0
    end
    if f2_local5 < 2 then
        f2_local0[4] = 0
    end
    if f2_local10 == false and f2_local22 == false then
        f2_local0[5] = 0
    end
    if f2_local18 == false then
        f2_local0[10] = 0
    end
    if f2_arg1:GetLatestSoundBehaviorID() == 366100 and f2_local5 <= 6 then
        f2_local0[1] = 0
        f2_local0[2] = 0
        f2_local0[4] = 0
        f2_local0[5] = 0
        f2_local0[9] = 0
        f2_local0[10] = 0
    end
    if f2_arg1:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_BUDDY_DECLARE) == true then
        f2_local0[1] = 0
        f2_local0[9] = 0
        f2_local0[6] = f2_local0[6] * 3
    end
    f2_local1[1] = REGIST_FUNC(f2_arg1, f2_arg2, RottenDead_366100_Act01)
    f2_local1[2] = REGIST_FUNC(f2_arg1, f2_arg2, RottenDead_366100_Act02)
    f2_local1[3] = REGIST_FUNC(f2_arg1, f2_arg2, RottenDead_366100_Act03)
    f2_local1[4] = REGIST_FUNC(f2_arg1, f2_arg2, RottenDead_366100_Act04)
    f2_local1[5] = REGIST_FUNC(f2_arg1, f2_arg2, RottenDead_366100_Act05)
    f2_local1[6] = REGIST_FUNC(f2_arg1, f2_arg2, RottenDead_366100_Act06)
    f2_local1[7] = REGIST_FUNC(f2_arg1, f2_arg2, RottenDead_366100_Act07)
    f2_local1[8] = REGIST_FUNC(f2_arg1, f2_arg2, RottenDead_366100_Act08)
    f2_local1[9] = REGIST_FUNC(f2_arg1, f2_arg2, RottenDead_366100_Act09)
    f2_local1[10] = REGIST_FUNC(f2_arg1, f2_arg2, RottenDead_366100_Act10)
    f2_local1[11] = REGIST_FUNC(f2_arg1, f2_arg2, RottenDead_366100_Act11)
    f2_local1[12] = REGIST_FUNC(f2_arg1, f2_arg2, RottenDead_366100_Act12)
    f2_local1[13] = REGIST_FUNC(f2_arg1, f2_arg2, RottenDead_366100_Act13)
    f2_local1[14] = REGIST_FUNC(f2_arg1, f2_arg2, RottenDead_366100_Act14)
    f2_local1[15] = REGIST_FUNC(f2_arg1, f2_arg2, RottenDead_366100_Act15)
    f2_local1[16] = REGIST_FUNC(f2_arg1, f2_arg2, RottenDead_366100_Act16)
    f2_local1[17] = REGIST_FUNC(f2_arg1, f2_arg2, RottenDead_366100_Act17)
    f2_local1[18] = REGIST_FUNC(f2_arg1, f2_arg2, RottenDead_366100_Act18)
    f2_local1[19] = REGIST_FUNC(f2_arg1, f2_arg2, RottenDead_366100_Act19)
    f2_local1[20] = REGIST_FUNC(f2_arg1, f2_arg2, RottenDead_366100_Act20)
    f2_local1[21] = REGIST_FUNC(f2_arg1, f2_arg2, RottenDead_366100_Act21)
    f2_local1[22] = REGIST_FUNC(f2_arg1, f2_arg2, RottenDead_366100_Act22)
    f2_local1[23] = REGIST_FUNC(f2_arg1, f2_arg2, RottenDead_366100_Act23)
    f2_local1[24] = REGIST_FUNC(f2_arg1, f2_arg2, RottenDead_366100_Act24)
    f2_local1[25] = REGIST_FUNC(f2_arg1, f2_arg2, RottenDead_366100_Act25)
    f2_local1[26] = REGIST_FUNC(f2_arg1, f2_arg2, RottenDead_366100_Act26)
    f2_local1[27] = REGIST_FUNC(f2_arg1, f2_arg2, RottenDead_366100_Act27)
    f2_local1[28] = REGIST_FUNC(f2_arg1, f2_arg2, RottenDead_366100_Act28)
    f2_local1[29] = REGIST_FUNC(f2_arg1, f2_arg2, RottenDead_366100_Act29)
    f2_local1[30] = REGIST_FUNC(f2_arg1, f2_arg2, RottenDead_366100_Act30)
    local f2_local23 = REGIST_FUNC(f2_arg1, f2_arg2, RottenDead_366100_ActAfter_AdjustSpace)
    Common_Battle_Activate(f2_arg1, f2_arg2, f2_local0, f2_local1, f2_local23, f2_local2)
    
end

function RottenDead_366100_Act01(f3_arg0, f3_arg1, f3_arg2)
    Loop_Cnt = 0
    local f3_local0 = 10
    local f3_local1 = 3023
    local f3_local2 = 999
    local f3_local3 = 0
    local f3_local4 = 120
    local f3_local5 = f3_arg0:GetRandam_Int(1, 100)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5028)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5029)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17020)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17021)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17022)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17023)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17026)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17024)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17025)
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f3_local0, f3_local1, TARGET_ENE_0, f3_local2, f3_local3, f3_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RottenDead_366100_Act02(f4_arg0, f4_arg1, f4_arg2)
    local f4_local0 = f4_arg0:GetDist(TARGET_ENE_0)
    local f4_local1 = -1.4
    local f4_local2 = 999
    local f4_local3 = 999
    local f4_local4 = 0
    local f4_local5 = 0
    local f4_local6 = 3
    local f4_local7 = 3
    Loop_Cnt = 0
    local f4_local8 = 10
    local f4_local9 = 3000
    local f4_local10 = 3010
    local f4_local11 = 3000
    local f4_local12 = 3010
    local f4_local13 = 3000
    local f4_local14 = 3010
    local f4_local15 = 999
    local f4_local16 = 0
    local f4_local17 = 120
    local f4_local18 = f4_arg0:GetRandam_Int(1, 100)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5028)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5029)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17020)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17021)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17022)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17023)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17026)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17024)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17025)
    if f4_local18 > 50 then
        f4_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f4_local8, f4_local9, TARGET_ENE_0, f4_local15, f4_local16, f4_local17, 0, 0)
    else
        f4_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f4_local8, f4_local10, TARGET_ENE_0, f4_local15, f4_local16, f4_local17, 0, 0)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RottenDead_366100_Act03(f5_arg0, f5_arg1, f5_arg2)
    local f5_local0 = f5_arg0:GetDist(TARGET_ENE_0)
    local f5_local1 = -1.4
    local f5_local2 = 999
    local f5_local3 = 999
    local f5_local4 = 0
    local f5_local5 = 0
    local f5_local6 = 3
    local f5_local7 = 3
    f5_arg1:AddSubGoal(GOAL_COMMON_Wait, GetRandam_Float(0.1, 1), TARGET_ENE_0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RottenDead_366100_Act04(f6_arg0, f6_arg1, f6_arg2)
    Loop_Cnt = 0
    local f6_local0 = 10
    local f6_local1 = 3017
    local f6_local2 = 3019
    local f6_local3 = 999
    local f6_local4 = 0
    local f6_local5 = 0
    local f6_local6 = f6_arg0:GetRandam_Int(1, 100)
    f6_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17020)
    f6_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17021)
    f6_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17022)
    f6_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17023)
    f6_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17026)
    f6_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17024)
    f6_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17025)
    if f6_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_BUDDY_DECLARE) == true then
        if f6_local6 > 50 then
            f6_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f6_local0, f6_local1, TARGET_NONE, f6_local3, f6_local4, f6_local5, 0, 0)
            local f6_local7 = f6_arg0:GetRandam_Int(1, 100)
            if f6_local7 > 60 then
                f6_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3012, TARGET_ENE_0, DistToAtt3, 0, 0)
            elseif f6_local7 > 20 then
                f6_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3002, TARGET_ENE_0, DistToAtt3, 0, 0)
            end
        else
            f6_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f6_local0, f6_local2, TARGET_NONE, f6_local3, f6_local4, f6_local5, 0, 0)
            local f6_local7 = f6_arg0:GetRandam_Int(1, 100)
            if f6_local7 > 60 then
                f6_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3012, TARGET_ENE_0, DistToAtt3, 0, 0)
            elseif f6_local7 > 20 then
                f6_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3002, TARGET_ENE_0, DistToAtt3, 0, 0)
            end
        end
    elseif f6_local6 > 50 then
        f6_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f6_local0, f6_local1, TARGET_NONE, f6_local3, f6_local4, f6_local5, 0, 0)
        local f6_local7 = f6_arg0:GetRandam_Int(1, 100)
        if f6_local7 > 80 then
            f6_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3022, TARGET_ENE_0, DistToAtt3, 0, 0)
        elseif f6_local7 > 60 then
            f6_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3012, TARGET_ENE_0, DistToAtt3, 0, 0)
        elseif f6_local7 > 40 then
            f6_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3002, TARGET_ENE_0, DistToAtt3, 0, 0)
        elseif f6_local7 > 20 then
            f6_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3035, TARGET_ENE_0, DistToAtt3, 0, 0)
        end
    else
        f6_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f6_local0, f6_local2, TARGET_NONE, f6_local3, f6_local4, f6_local5, 0, 0)
        local f6_local7 = f6_arg0:GetRandam_Int(1, 100)
        if f6_local7 > 80 then
            f6_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3022, TARGET_ENE_0, DistToAtt3, 0, 0)
        elseif f6_local7 > 60 then
            f6_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3012, TARGET_ENE_0, DistToAtt3, 0, 0)
        elseif f6_local7 > 40 then
            f6_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3002, TARGET_ENE_0, DistToAtt3, 0, 0)
        elseif f6_local7 > 20 then
            f6_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3035, TARGET_ENE_0, DistToAtt3, 0, 0)
        end
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RottenDead_366100_Act05(f7_arg0, f7_arg1, f7_arg2)
    local f7_local0 = 5
    local f7_local1 = 3016
    local f7_local2 = 6
    local f7_local3 = 0
    local f7_local4 = 180
    local f7_local5 = f7_arg0:GetRandam_Int(1, 100)
    f7_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f7_local0, f7_local1, TARGET_ENE_0, f7_local2, f7_local3, f7_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RottenDead_366100_Act06(f8_arg0, f8_arg1, f8_arg2)
    local f8_local0 = 5
    local f8_local1 = 3007
    local f8_local2 = 6
    local f8_local3 = 0
    local f8_local4 = 180
    local f8_local5 = f8_arg0:GetRandam_Int(1, 100)
    f8_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f8_local0, f8_local1, TARGET_SELF, f8_local2, f8_local3, f8_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RottenDead_366100_Act07(f9_arg0, f9_arg1, f9_arg2)
    Loop_Cnt = 0
    local f9_local0 = f9_arg0:HasSpecialEffectId(TARGET_SELF, 17009)
    f9_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17031)
    local f9_local1 = 5
    local f9_local2 = 3030
    local f9_local3 = 3031
    local f9_local4 = 999
    local f9_local5 = 1.5
    local f9_local6 = 120
    local f9_local7 = f9_arg0:GetRandam_Int(1, 100)
    local f9_local8 = f9_arg0:GetRandam_Int(8, 11)
    local f9_local9 = 999
    local f9_local10 = 999
    local f9_local11 = 0
    local f9_local12 = 0
    local f9_local13 = 4
    local f9_local14 = 8
    Approach_Act_Flex(f9_arg0, f9_arg1, f9_local8, f9_local9, f9_local10, f9_local11, f9_local12, f9_local13, f9_local14)
    if f9_local0 == true then
        f9_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f9_local1, f9_local3, TARGET_ENE_0, f9_local4, f9_local5, f9_local6, 0, 0)
    else
        f9_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f9_local1, f9_local2, TARGET_ENE_0, f9_local4, f9_local5, f9_local6, 0, 0)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RottenDead_366100_Act08(f10_arg0, f10_arg1, f10_arg2)
    local f10_local0 = f10_arg0:HasSpecialEffectId(TARGET_SELF, 17009)
    local f10_local1 = 5
    local f10_local2 = 3034
    local f10_local3 = 3033
    local f10_local4 = 999
    local f10_local5 = 1.5
    local f10_local6 = 120
    local f10_local7 = f10_arg0:GetRandam_Int(1, 100)
    if f10_local0 == true then
        f10_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f10_local1, f10_local3, TARGET_ENE_0, f10_local4, f10_local5, f10_local6, 0, 0)
    else
        f10_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f10_local1, f10_local2, TARGET_ENE_0, f10_local4, f10_local5, f10_local6, 0, 0)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RottenDead_366100_Act09(f11_arg0, f11_arg1, f11_arg2)
    local f11_local0 = f11_arg0:GetDist(TARGET_ENE_0)
    local f11_local1 = f11_arg0:GetRandam_Int(1, 100)
    f11_arg0:SetNumber(6, 1)
    Loop_Cnt = 0
    local f11_local2 = 10
    local f11_local3 = 3035
    local f11_local4 = 3036
    local f11_local5 = 3017
    local f11_local6 = 999
    local f11_local7 = 0
    local f11_local8 = 120
    local f11_local9 = f11_arg0:GetRandam_Int(1, 100)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5028)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5029)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17020)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17021)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17022)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17023)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17026)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17024)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17025)
    local f11_local10 = 7
    local f11_local11 = 999
    local f11_local12 = 999
    local f11_local13 = 0
    local f11_local14 = 0
    local f11_local15 = 3
    local f11_local16 = 0
    Approach_Act_Flex(f11_arg0, f11_arg1, f11_local10, f11_local11, f11_local12, f11_local13, f11_local14, f11_local15, f11_local16)
    if f11_local0 > 6 then
        if f11_local9 > 60 then
            f11_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f11_local2, f11_local5, TARGET_ENE_0, f11_local6, f11_local7, f11_local8, 0, 0)
            f11_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, f11_local3, TARGET_ENE_0, 0, 0, 0, 0, 0)
        else
            f11_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, f11_local3, TARGET_ENE_0, 0, 0, 0, 0, 0)
        end
    elseif f11_local0 > 2 then
        f11_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f11_local2, f11_local3, TARGET_ENE_0, f11_local6, f11_local7, f11_local8, 0, 0)
    else
        f11_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f11_local2, f11_local4, TARGET_ENE_0, f11_local6, f11_local7, f11_local8, 0, 0)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RottenDead_366100_Act10(f12_arg0, f12_arg1, f12_arg2)
    local f12_local0 = f12_arg0:GetDist(TARGET_ENE_0)
    local f12_local1 = f12_arg0:GetRandam_Int(1, 100)
    f12_arg0:SetNumber(6, 1)
    Loop_Cnt = 0
    local f12_local2 = 10
    local f12_local3 = 3037
    local f12_local4 = 3038
    local f12_local5 = 999
    local f12_local6 = 0
    local f12_local7 = 120
    local f12_local8 = f12_arg0:GetRandam_Int(1, 100)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5028)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5029)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17020)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17021)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17022)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17023)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17026)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17024)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17025)
    f12_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f12_local2, f12_local4, TARGET_ENE_0, f12_local5, f12_local6, f12_local7, 0, 0)
    
end

function RottenDead_366100_Act11(f13_arg0, f13_arg1, f13_arg2)
    local f13_local0 = f13_arg0:GetDist(TARGET_ENE_0)
    local f13_local1 = f13_arg0:GetRandam_Int(3, 11)
    local f13_local2 = 999
    local f13_local3 = 999
    local f13_local4 = 0
    local f13_local5 = 0
    local f13_local6 = 3
    local f13_local7 = 3
    Approach_Act_Flex(f13_arg0, f13_arg1, f13_local1, f13_local2, f13_local3, f13_local4, f13_local5, f13_local6, f13_local7)
    local f13_local8 = 10
    local f13_local9 = 20010
    local f13_local10 = 5 - f13_arg0:GetMapHitRadius(TARGET_SELF)
    local f13_local11 = 0
    local f13_local12 = 120
    f13_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f13_local8, f13_local9, TARGET_ENE_0, f13_local10, f13_local11, f13_local12, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RottenDead_366100_Act12(f14_arg0, f14_arg1, f14_arg2)
    local f14_local0 = f14_arg0:GetDist(TARGET_ENE_0)
    local f14_local1 = f14_arg0:GetRandam_Int(3, 11)
    local f14_local2 = 999
    local f14_local3 = 999
    local f14_local4 = 0
    local f14_local5 = 0
    local f14_local6 = 3
    local f14_local7 = 3
    Approach_Act_Flex(f14_arg0, f14_arg1, f14_local1, f14_local2, f14_local3, f14_local4, f14_local5, f14_local6, f14_local7)
    local f14_local8 = 10
    local f14_local9 = 20011
    local f14_local10 = 5 - f14_arg0:GetMapHitRadius(TARGET_SELF)
    local f14_local11 = 0
    local f14_local12 = 120
    f14_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f14_local8, f14_local9, TARGET_ENE_0, f14_local10, f14_local11, f14_local12, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RottenDead_366100_Act13(f15_arg0, f15_arg1, f15_arg2)
    local f15_local0 = 10
    local f15_local1 = 20011
    local f15_local2 = 5 - f15_arg0:GetMapHitRadius(TARGET_SELF)
    local f15_local3 = 0
    local f15_local4 = 120
    f15_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f15_local0, f15_local1, TARGET_ENE_0, f15_local2, f15_local3, f15_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RottenDead_366100_Act14(f16_arg0, f16_arg1, f16_arg2)
    f16_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17035)
    local f16_local0 = 10
    local f16_local1 = 20012
    local f16_local2 = 5 - f16_arg0:GetMapHitRadius(TARGET_SELF)
    local f16_local3 = 0
    local f16_local4 = 120
    f16_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f16_local0, f16_local1, TARGET_ENE_0, f16_local2, f16_local3, f16_local4, 0, 0)
    
end

function RottenDead_366100_Act15(f17_arg0, f17_arg1, f17_arg2)
    local f17_local0 = f17_arg0:GetDist(TARGET_ENE_0)
    local f17_local1 = 18
    local f17_local2 = 0
    local f17_local3 = 999
    local f17_local4 = 100
    local f17_local5 = 0
    local f17_local6 = 0
    local f17_local7 = 5
    Approach_Act_Flex(f17_arg0, f17_arg1, f17_local1, f17_local2, f17_local3, f17_local4, f17_local5, f17_local6, f17_local7)
    f17_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 13477)
    local f17_local8 = 10
    local f17_local9 = 20013
    local f17_local10 = 5 - f17_arg0:GetMapHitRadius(TARGET_SELF)
    local f17_local11 = 1.5
    local f17_local12 = 90
    f17_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f17_local8, f17_local9, TARGET_ENE_0, f17_local10, f17_local11, f17_local12, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RottenDead_366100_Act16(f18_arg0, f18_arg1, f18_arg2)
    local f18_local0 = f18_arg0:GetDist(TARGET_ENE_0)
    local f18_local1 = 18
    local f18_local2 = 0
    local f18_local3 = 999
    local f18_local4 = 100
    local f18_local5 = 0
    local f18_local6 = 0
    local f18_local7 = 5
    local f18_local8 = 10
    local f18_local9 = 20015
    local f18_local10 = 5 - f18_arg0:GetMapHitRadius(TARGET_SELF)
    local f18_local11 = 1.5
    local f18_local12 = 90
    f18_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f18_local8, f18_local9, TARGET_ENE_0, f18_local10, f18_local11, f18_local12, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RottenDead_366100_Act17(f19_arg0, f19_arg1, f19_arg2)
    local f19_local0 = f19_arg0:GetDist(TARGET_ENE_0)
    local f19_local1 = 18
    local f19_local2 = 0
    local f19_local3 = 999
    local f19_local4 = 100
    local f19_local5 = 0
    local f19_local6 = 0
    local f19_local7 = 5
    f19_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 13477)
    local f19_local8 = 10
    local f19_local9 = 20016
    local f19_local10 = 5 - f19_arg0:GetMapHitRadius(TARGET_SELF)
    local f19_local11 = 1.5
    local f19_local12 = 90
    f19_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f19_local8, f19_local9, TARGET_ENE_0, f19_local10, f19_local11, f19_local12, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RottenDead_366100_Act18(f20_arg0, f20_arg1, f20_arg2)
    local f20_local0 = f20_arg0:GetDist(TARGET_ENE_0)
    local f20_local1 = 6
    local f20_local2 = 0
    local f20_local3 = 999
    local f20_local4 = 100
    local f20_local5 = 0
    local f20_local6 = 0
    local f20_local7 = 5
    Approach_Act_Flex(f20_arg0, f20_arg1, f20_local1, f20_local2, f20_local3, f20_local4, f20_local5, f20_local6, f20_local7)
    f20_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 13477)
    local f20_local8 = 10
    local f20_local9 = 20017
    local f20_local10 = 5 - f20_arg0:GetMapHitRadius(TARGET_SELF)
    local f20_local11 = 1.5
    local f20_local12 = 90
    f20_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f20_local8, f20_local9, TARGET_ENE_0, f20_local10, f20_local11, f20_local12, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RottenDead_366100_Act19(f21_arg0, f21_arg1, f21_arg2)
    local f21_local0 = f21_arg0:GetDist(TARGET_ENE_0)
    if f21_local0 > 5 then
        local f21_local1 = 18
        local f21_local2 = 0
        local f21_local3 = 999
        local f21_local4 = 100
        local f21_local5 = 0
        local f21_local6 = 0
        local f21_local7 = 5
        Approach_Act_Flex(f21_arg0, f21_arg1, f21_local1, f21_local2, f21_local3, f21_local4, f21_local5, f21_local6, f21_local7)
        f21_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 13477)
        local f21_local8 = 10
        local f21_local9 = 20018
        local f21_local10 = 5 - f21_arg0:GetMapHitRadius(TARGET_SELF)
        local f21_local11 = 1.5
        local f21_local12 = 90
        f21_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f21_local8, f21_local9, TARGET_ENE_0, f21_local10, f21_local11, f21_local12, 0, 0)
    elseif f21_local0 > 2 then
        local f21_local1 = f21_arg0:GetDist(TARGET_ENE_0)
        local f21_local2 = 6
        local f21_local3 = 0
        local f21_local4 = 999
        local f21_local5 = 100
        local f21_local6 = 0
        local f21_local7 = 0
        local f21_local8 = 5
        Approach_Act_Flex(f21_arg0, f21_arg1, f21_local2, f21_local3, f21_local4, f21_local5, f21_local6, f21_local7, f21_local8)
        f21_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 13477)
        local f21_local9 = 10
        local f21_local10 = 20017
        local f21_local11 = 5 - f21_arg0:GetMapHitRadius(TARGET_SELF)
        local f21_local12 = 1.5
        local f21_local13 = 90
        f21_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f21_local9, f21_local10, TARGET_ENE_0, f21_local11, f21_local12, f21_local13, 0, 0)
    else
        local f21_local1 = 10
        local f21_local2 = 20015
        local f21_local3 = 5 - f21_arg0:GetMapHitRadius(TARGET_SELF)
        local f21_local4 = 1.5
        local f21_local5 = 90
        f21_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f21_local1, f21_local2, TARGET_ENE_0, f21_local3, f21_local4, f21_local5, 0, 0)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RottenDead_366100_Act20(f22_arg0, f22_arg1, f22_arg2)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RottenDead_366100_Act22(f23_arg0, f23_arg1, f23_arg2)
    f23_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, f23_arg0:GetRandam_Int(3, 5), TARGET_ENE_0, 0.5, TARGET_SELF, true, -1)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RottenDead_366100_Act23(f24_arg0, f24_arg1, f24_arg2)
    local f24_local0 = f24_arg0:GetRandam_Int(1, 100)
    if f24_local0 > 50 then
        f24_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f24_arg0:GetRandam_Int(4, 6), TARGET_ENE_0, 1, TARGET_SELF, true, -1, AI_DIR_TYPE_ToR, f24_arg0:GetRandam_Int(3, 5))
    else
        f24_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f24_arg0:GetRandam_Int(4, 6), TARGET_ENE_0, 1, TARGET_SELF, true, -1, AI_DIR_TYPE_ToL, f24_arg0:GetRandam_Int(3, 5))
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RottenDead_366100_Act24(f25_arg0, f25_arg1, f25_arg2)
    f25_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f25_arg0:GetRandam_Float(0.1, 0.3), TARGET_ENE_0, 1, TARGET_SELF, false, -1, AI_DIR_TYPE_ToF, f25_arg0:GetRandam_Int(3, 5)):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
    f25_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, f25_arg0:GetRandam_Int(3, 5), TARGET_ENE_0, 3, TARGET_SELF, false, -1)
    local f25_local0 = 10
    local f25_local1 = 3017
    local f25_local2 = 3019
    local f25_local3 = 999
    local f25_local4 = 0
    local f25_local5 = 0
    local f25_local6 = f25_arg0:GetRandam_Int(1, 100)
    f25_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17020)
    f25_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17021)
    f25_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17022)
    f25_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17023)
    f25_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17026)
    f25_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17024)
    f25_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17025)
    f25_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16458)
    f25_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16459)
    if f25_local6 > 50 then
        local f25_local7 = f25_arg0:GetRandam_Int(1, 100)
        if f25_local7 > 70 then
            f25_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3029, TARGET_ENE_0, DistToAtt3, 0, 0)
        elseif f25_local7 > 60 then
            f25_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3027, TARGET_ENE_0, DistToAtt3, 0, 0)
        elseif f25_local7 > 40 then
            f25_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3027, TARGET_ENE_0, DistToAtt3, 0, 0)
        end
    else
        local f25_local7 = f25_arg0:GetRandam_Int(1, 100)
        if f25_local7 > 70 then
            f25_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3029, TARGET_ENE_0, DistToAtt3, 0, 0)
        elseif f25_local7 > 60 then
            f25_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3025, TARGET_ENE_0, DistToAtt3, 0, 0)
        elseif f25_local7 > 40 then
            f25_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3025, TARGET_ENE_0, DistToAtt3, 0, 0)
        end
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RottenDead_366100_Act26(f26_arg0, f26_arg1, f26_arg2)
    f26_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5028)
    f26_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5029)
    f26_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16468)
    local f26_local0 = 5
    local f26_local1 = -1
    local f26_local2 = -1
    local f26_local3 = -1
    local f26_local4 = 1
    local f26_local5 = TARGET_ENE_0
    local f26_local6 = 3
    local f26_local7 = 0
    local f26_local8 = true
    f26_arg0:SetTimer(2, 20)
    f26_arg1:AddSubGoal(GOAL_COMMON_StepSafety, f26_local0, f26_local1, f26_local2, f26_local3, f26_local4, f26_local5, f26_local6, f26_local7, f26_local8)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RottenDead_366100_Act27(f27_arg0, f27_arg1, f27_arg2)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RottenDead_366100_Act28(f28_arg0, f28_arg1, f28_arg2)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RottenDead_366100_Act29(f29_arg0, f29_arg1, f29_arg2)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RottenDead_366100_Act30(f30_arg0, f30_arg1, f30_arg2)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RottenDead_366100_ActAfter_AdjustSpace(f31_arg0, f31_arg1, f31_arg2)
    f31_arg1:AddSubGoal(GOAL_RottenDead_366100_AfterAttackAct, 10)
    
end

Goal.Update = function (f32_arg0, f32_arg1, f32_arg2)
    return Update_Default_NoSubGoal(f32_arg0, f32_arg1, f32_arg2)
    
end

Goal.Terminate = function (f33_arg0, f33_arg1, f33_arg2)
    
end

Goal.Interrupt = function (f34_arg0, f34_arg1, f34_arg2)
    local f34_local0 = 5 - f34_arg1:GetMapHitRadius(TARGET_SELF)
    local f34_local1 = 0
    local f34_local2 = 20
    local f34_local3 = f34_arg1:GetDist(TARGET_ENE_0)
    local f34_local4 = f34_arg1:GetRandam_Int(1, 100)
    local f34_local5 = STEP_CANCELDIST
    local f34_local6 = f34_arg1:HasSpecialEffectId(TARGET_SELF, 17001)
    local f34_local7 = f34_arg1:HasSpecialEffectId(TARGET_SELF, 17002)
    local f34_local8 = f34_arg1:HasSpecialEffectId(TARGET_SELF, 17009)
    if f34_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) then
        if f34_arg1:GetSpecialEffectActivateInterruptId(17030) then
            local f34_local9 = f34_arg1:GetDist(TARGET_ENE_0)
            local f34_local10 = f34_arg1:GetRandam_Int(1, 100)
            f34_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 17031)
            if f34_local9 > 4 and Loop_Cnt < 6 then
                f34_arg2:ClearSubGoal()
                Loop_Cnt = Loop_Cnt + 1
                if f34_local8 == true then
                    f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3032, TARGET_ENE_0, 0, 0, 0, 0, 0)
                    return true
                else
                    f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3031, TARGET_ENE_0, 0, 0, 0, 0, 0)
                    return true
                end
            elseif Loop_Cnt > 3 and f34_local10 > 70 then
                f34_arg2:ClearSubGoal()
                if f34_local8 == true then
                    f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3033, TARGET_ENE_0, 0, 0, 0, 0, 0)
                    return true
                else
                    f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3032, TARGET_ENE_0, 0, 0, 0, 0, 0)
                    return true
                end
            else
                f34_arg2:ClearSubGoal()
                if f34_local8 == true then
                    f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3033, TARGET_ENE_0, 0, 0, 0, 0, 0)
                    return true
                else
                    f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3032, TARGET_ENE_0, 0, 0, 0, 0, 0)
                    return true
                end
            end
        end
        if f34_arg1:GetSpecialEffectActivateInterruptId(13477) then
            local f34_local9 = f34_arg1:GetDist(TARGET_ENE_0)
            local f34_local10 = f34_arg1:GetRandam_Int(1, 100)
            f34_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 13477)
            if f34_local9 < 8 then
                f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 20013, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            end
        end
    end
    if f34_arg1:HasSpecialEffectId(TARGET_SELF, 17031) then
        local f34_local9 = f34_arg1:GetDist(TARGET_ENE_0)
        local f34_local10 = f34_arg1:GetRandam_Int(1, 100)
        f34_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 17031)
        if f34_local9 < 4 then
            f34_arg2:ClearSubGoal()
            if f34_local8 == true then
                f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3033, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            else
                f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3032, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            end
        end
    end
    if f34_arg1:HasSpecialEffectId(TARGET_SELF, 17020) then
        f34_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 17021)
        local f34_local9 = f34_arg1:GetDist(TARGET_ENE_0)
        local f34_local10 = f34_arg1:GetRandam_Int(1, 100)
        if f34_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_F, 180) then
            if f34_local9 <= 3 or Loop_Cnt > 8 then
                if f34_local10 > 20 or 5 < Loop_Cnt then
                    f34_arg2:ClearSubGoal()
                    f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3022, TARGET_ENE_0, 0, 0, 0, 0, 0)
                    return true
                else
                    f34_arg2:ClearSubGoal()
                    Loop_Cnt = Loop_Cnt + 1
                    f34_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 17021)
                    f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3021, TARGET_ENE_0, 0, 0, 0, 0, 0)
                    return true
                end
            else
                f34_arg2:ClearSubGoal()
                Loop_Cnt = Loop_Cnt + 1
                f34_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 17021)
                f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3021, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            end
        else
            f34_arg2:ClearSubGoal()
            f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3022, TARGET_ENE_0, 0, 0, 0, 0, 0)
            return true
        end
    end
    if f34_arg1:HasSpecialEffectId(TARGET_SELF, 17021) then
        local f34_local9 = f34_arg1:GetDist(TARGET_ENE_0)
        local f34_local10 = f34_arg1:GetRandam_Int(1, 100)
        local f34_local11 = f34_arg1:GetRandam_Int(1, 100)
        if f34_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_F, 180) then
            if f34_local9 <= 3 or Loop_Cnt > 8 then
                if f34_local10 > 20 or 5 < Loop_Cnt then
                    if f34_local11 > 40 then
                        f34_arg2:ClearSubGoal()
                        f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3022, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    else
                        f34_arg2:ClearSubGoal()
                        f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3036, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    end
                else
                    f34_arg2:ClearSubGoal()
                    Loop_Cnt = Loop_Cnt + 1
                    f34_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 17021)
                    f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3021, TARGET_ENE_0, 0, 0, 0, 0, 0)
                    return true
                end
            elseif f34_local9 <= 6 and f34_local10 > 80 then
                f34_arg2:ClearSubGoal()
                f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3036, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            else
                f34_arg2:ClearSubGoal()
                Loop_Cnt = Loop_Cnt + 1
                f34_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 17021)
                f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3021, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            end
        else
            f34_arg2:ClearSubGoal()
            f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3022, TARGET_ENE_0, 0, 0, 0, 0, 0)
            return true
        end
    end
    if f34_arg1:HasSpecialEffectId(TARGET_SELF, 17022) then
        f34_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 17023)
        local f34_local9 = f34_arg1:GetDist(TARGET_ENE_0)
        local f34_local10 = f34_arg1:GetRandam_Int(1, 100)
        if f34_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_F, 180) then
            if f34_local9 < 3 then
                if f34_local10 > 20 then
                    local f34_local11 = f34_arg1:GetRandam_Int(1, 100)
                    if f34_local11 > 50 then
                        f34_arg2:ClearSubGoal()
                        f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3002, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    else
                        f34_arg2:ClearSubGoal()
                        f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3003, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    end
                else
                    f34_arg2:ClearSubGoal()
                    Loop_Cnt = Loop_Cnt + 1
                    f34_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 17023)
                    f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3001, TARGET_ENE_0, 0, 0, 0, 0, 0)
                    return true
                end
            elseif Loop_Cnt > 7 then
                local f34_local11 = f34_arg1:GetRandam_Int(1, 100)
                if f34_local11 > 80 then
                    local f34_local12 = f34_arg1:GetRandam_Int(1, 100)
                    if f34_local12 > 50 then
                        f34_arg2:ClearSubGoal()
                        f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3002, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    else
                        f34_arg2:ClearSubGoal()
                        f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3003, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    end
                else
                    f34_arg2:ClearSubGoal()
                    Loop_Cnt = Loop_Cnt + 1
                    f34_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 17023)
                    f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3001, TARGET_ENE_0, 0, 0, 0, 0, 0)
                    return true
                end
            else
                f34_arg2:ClearSubGoal()
                Loop_Cnt = Loop_Cnt + 1
                f34_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 17023)
                f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3001, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            end
        else
            local f34_local11 = f34_arg1:GetRandam_Int(1, 100)
            if f34_local11 > 50 then
                f34_arg2:ClearSubGoal()
                f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3002, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            else
                f34_arg2:ClearSubGoal()
                f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3003, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            end
        end
    end
    if f34_arg1:HasSpecialEffectId(TARGET_SELF, 17024) then
        f34_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 17025)
        local f34_local9 = f34_arg1:GetDist(TARGET_ENE_0)
        local f34_local10 = f34_arg1:GetRandam_Int(1, 100)
        if f34_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_F, 180) then
            if f34_local9 < 3 then
                if f34_local10 > 20 then
                    local f34_local11 = f34_arg1:GetRandam_Int(1, 100)
                    if f34_local11 > 50 then
                        f34_arg2:ClearSubGoal()
                        f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3012, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    else
                        f34_arg2:ClearSubGoal()
                        f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3013, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    end
                else
                    f34_arg2:ClearSubGoal()
                    Loop_Cnt = Loop_Cnt + 1
                    f34_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 17025)
                    f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3011, TARGET_ENE_0, 0, 0, 0, 0, 0)
                    return true
                end
            elseif Loop_Cnt > 7 then
                local f34_local11 = f34_arg1:GetRandam_Int(1, 100)
                if f34_local11 > 80 then
                    local f34_local12 = f34_arg1:GetRandam_Int(1, 100)
                    if f34_local12 > 50 then
                        f34_arg2:ClearSubGoal()
                        f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3012, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    else
                        f34_arg2:ClearSubGoal()
                        f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3013, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    end
                else
                    f34_arg2:ClearSubGoal()
                    Loop_Cnt = Loop_Cnt + 1
                    f34_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 17025)
                    f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3011, TARGET_ENE_0, 0, 0, 0, 0, 0)
                    return true
                end
            else
                f34_arg2:ClearSubGoal()
                Loop_Cnt = Loop_Cnt + 1
                f34_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 17025)
                f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3011, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            end
        else
            local f34_local11 = f34_arg1:GetRandam_Int(1, 100)
            if f34_local11 > 50 then
                f34_arg2:ClearSubGoal()
                f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3012, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            else
                f34_arg2:ClearSubGoal()
                f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3013, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            end
        end
    end
    if f34_arg1:HasSpecialEffectId(TARGET_SELF, 17023) then
        local f34_local9 = f34_arg1:GetDist(TARGET_ENE_0)
        local f34_local10 = f34_arg1:GetRandam_Int(1, 100)
        if f34_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_F, 180) then
            if f34_local9 < 3 then
                if f34_local10 > 20 then
                    local f34_local11 = f34_arg1:GetRandam_Int(1, 100)
                    if f34_local11 > 50 then
                        f34_arg2:ClearSubGoal()
                        f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3002, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    else
                        f34_arg2:ClearSubGoal()
                        f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3003, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    end
                else
                    f34_arg2:ClearSubGoal()
                    Loop_Cnt = Loop_Cnt + 1
                    f34_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 17023)
                    f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3001, TARGET_ENE_0, 0, 0, 0, 0, 0)
                    return true
                end
            elseif Loop_Cnt > 7 then
                local f34_local11 = f34_arg1:GetRandam_Int(1, 100)
                if f34_local11 > 80 then
                    local f34_local12 = f34_arg1:GetRandam_Int(1, 100)
                    if f34_local12 > 50 then
                        f34_arg2:ClearSubGoal()
                        f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3002, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    else
                        f34_arg2:ClearSubGoal()
                        f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3003, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    end
                else
                    f34_arg2:ClearSubGoal()
                    Loop_Cnt = Loop_Cnt + 1
                    f34_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 17023)
                    f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3001, TARGET_ENE_0, 0, 0, 0, 0, 0)
                    return true
                end
            else
                f34_arg2:ClearSubGoal()
                Loop_Cnt = Loop_Cnt + 1
                f34_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 17023)
                f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3001, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            end
        else
            local f34_local11 = f34_arg1:GetRandam_Int(1, 100)
            if f34_local11 > 50 then
                f34_arg2:ClearSubGoal()
                f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3002, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            else
                f34_arg2:ClearSubGoal()
                f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3003, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            end
        end
    end
    if f34_arg1:HasSpecialEffectId(TARGET_SELF, 17025) then
        local f34_local9 = f34_arg1:GetDist(TARGET_ENE_0)
        local f34_local10 = f34_arg1:GetRandam_Int(1, 100)
        if f34_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_F, 180) then
            if f34_local9 < 3 then
                if f34_local10 > 20 then
                    local f34_local11 = f34_arg1:GetRandam_Int(1, 100)
                    if f34_local11 > 50 then
                        f34_arg2:ClearSubGoal()
                        f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3012, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    else
                        f34_arg2:ClearSubGoal()
                        f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3013, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    end
                else
                    f34_arg2:ClearSubGoal()
                    Loop_Cnt = Loop_Cnt + 1
                    f34_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 17025)
                    f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3011, TARGET_ENE_0, 0, 0, 0, 0, 0)
                    return true
                end
            elseif Loop_Cnt > 7 then
                local f34_local11 = f34_arg1:GetRandam_Int(1, 100)
                if f34_local11 > 80 then
                    local f34_local12 = f34_arg1:GetRandam_Int(1, 100)
                    if f34_local12 > 50 then
                        f34_arg2:ClearSubGoal()
                        f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3012, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    else
                        f34_arg2:ClearSubGoal()
                        f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3013, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    end
                else
                    f34_arg2:ClearSubGoal()
                    Loop_Cnt = Loop_Cnt + 1
                    f34_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 17025)
                    f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3011, TARGET_ENE_0, 0, 0, 0, 0, 0)
                    return true
                end
            else
                f34_arg2:ClearSubGoal()
                Loop_Cnt = Loop_Cnt + 1
                f34_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 17025)
                f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3011, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            end
        else
            local f34_local11 = f34_arg1:GetRandam_Int(1, 100)
            if f34_local11 > 50 then
                f34_arg2:ClearSubGoal()
                f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3012, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            else
                f34_arg2:ClearSubGoal()
                f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3013, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            end
        end
    end
    if f34_arg1:HasSpecialEffectId(TARGET_SELF, 17026) then
        f34_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 17020)
        f34_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 17021)
        f34_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 17022)
        f34_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 17023)
        f34_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 17024)
        f34_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 17025)
        f34_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 17026)
        local f34_local9 = f34_arg1:GetDist(TARGET_ENE_0)
        local f34_local10 = f34_arg1:GetRandam_Int(1, 100)
        if f34_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_F, 180) then
            if f34_arg1:GetNumber(5) >= 1 or f34_local10 > 60 then
                if f34_local10 > 90 then
                    f34_arg2:ClearSubGoal()
                    f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3004, TARGET_ENE_0, 0, 0, 0, 0, 0)
                    return true
                elseif f34_local10 > 80 then
                    f34_arg2:ClearSubGoal()
                    f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3018, TARGET_ENE_0, 0, 0, 0, 0, 0)
                    return true
                elseif f34_local10 > 65 then
                    f34_arg2:ClearSubGoal()
                    f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3005, TARGET_ENE_0, 0, 0, 0, 0, 0)
                    return true
                elseif f34_local10 > 50 then
                    if f34_arg1:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_BUDDY_DECLARE) == true then
                        f34_arg2:ClearSubGoal()
                        f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3007, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    else
                        f34_arg2:ClearSubGoal()
                        f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3006, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    end
                end
            else
                f34_arg1:SetNumber(5, 1)
                if f34_local6 == true then
                    local f34_local11 = f34_arg1:GetRandam_Int(1, 100)
                    if f34_local11 > 75 then
                        f34_arg2:ClearSubGoal()
                        f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3012, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    elseif f34_local11 > 50 then
                        f34_arg2:ClearSubGoal()
                        f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3002, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    elseif f34_local11 > 30 then
                        f34_arg2:ClearSubGoal()
                        f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3016, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    elseif f34_arg1:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_BUDDY_DECLARE) == true then
                        f34_arg2:ClearSubGoal()
                        f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3007, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    elseif f34_local9 > 2 then
                        f34_arg2:ClearSubGoal()
                        f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3035, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    else
                        f34_arg2:ClearSubGoal()
                        f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3036, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    end
                else
                    local f34_local11 = f34_arg1:GetRandam_Int(1, 100)
                    if f34_local11 > 70 then
                        f34_arg2:ClearSubGoal()
                        f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3012, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    elseif f34_local11 > 35 then
                        f34_arg2:ClearSubGoal()
                        f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3002, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    elseif f34_arg1:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_BUDDY_DECLARE) == true then
                        f34_arg2:ClearSubGoal()
                        f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3007, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    elseif f34_local9 > 2 then
                        f34_arg2:ClearSubGoal()
                        f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3035, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    else
                        f34_arg2:ClearSubGoal()
                        f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3036, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    end
                end
            end
        end
    end
    if f34_arg1:HasSpecialEffectId(TARGET_SELF, 17035) then
        local f34_local9 = f34_arg1:GetDist(TARGET_ENE_0)
        f34_arg2:ClearSubGoal()
        f34_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 20013, TARGET_ENE_0, 0, 0, 0, 0, 0)
        return true
    end
    return false
    
end

RegisterTableGoal(GOAL_RottenDead_366100_AfterAttackAct, "RottenDead_366100_AfterAttackAct")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_RottenDead_366100_AfterAttackAct, true)

Goal.Activate = function (f35_arg0, f35_arg1, f35_arg2)
    
end

Goal.Update = function (f36_arg0, f36_arg1, f36_arg2)
    return Update_Default_NoSubGoal(f36_arg0, f36_arg1, f36_arg2)
    
end


