﻿RegisterTableGoal(GOAL_DemiHuman_Elite_410100_Battle, "DemiHuman_Elite_410100_Battle")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_DemiHuman_Elite_410100_Battle, true)

Goal.Initialize = function (f1_arg0, f1_arg1, f1_arg2, f1_arg3)
    f1_arg1:EnableUnfavorableAttackCheck(2000000, 3000)
    f1_arg1:EnableUnfavorableAttackCheck(2000000, 3001)
    f1_arg1:EnableUnfavorableAttackCheck(2000000, 3002)
    f1_arg1:EnableUnfavorableAttackCheck(2000000, 3003)
    f1_arg1:EnableUnfavorableAttackCheck(2000000, 3004)
    f1_arg1:EnableUnfavorableAttackCheck(2000000, 3005)
    f1_arg1:EnableUnfavorableAttackCheck(2000000, 3006)
    f1_arg1:EnableUnfavorableAttackCheck(2000000, 3007)
    f1_arg1:EnableUnfavorableAttackCheck(2000000, 3008)
    f1_arg1:EnableUnfavorableAttackCheck(2000000, 3011)
    f1_arg1:EnableUnfavorableAttackCheck(2000000, 3012)
    
end

Goal.Activate = function (f2_arg0, f2_arg1, f2_arg2)
    local f2_local0 = {}
    local f2_local1 = {}
    local f2_local2 = {}
    Common_Clear_Param(f2_local0, f2_local1, f2_local2)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 10530)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 10551)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 10553)
    local f2_local3 = f2_arg1:GetDist(TARGET_ENE_0)
    local f2_local4 = f2_arg1:GetDistY(TARGET_ENE_0)
    local f2_local5 = f2_arg1:GetHpRate(TARGET_SELF)
    local f2_local6 = f2_arg1:GetRandam_Int(1, 100)
    local f2_local7 = f2_arg1:GetDist(TARGET_FRI_0)
    local f2_local8 = f2_arg1:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__thinkAttr_doAdmirer)
    if f2_local8 == 1 and f2_arg1:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Kankyaku then
        if f2_arg1:HasSpecialEffectId(TARGET_SELF, 10553) == true then
            f2_local0[21] = 10
            f2_local0[22] = 10
            f2_local0[23] = 10
            f2_local0[30] = 70
            f2_local0[31] = 0
            f2_local0[32] = 0
            f2_local0[33] = 0
            f2_local0[34] = 0
        elseif f2_arg1:HasSpecialEffectId(TARGET_SELF, 10530) == true and f2_arg1:HasSpecialEffectId(TARGET_SELF, 10551) == true then
            f2_local0[21] = 10
            f2_local0[22] = 10
            f2_local0[23] = 10
            f2_local0[30] = 70
            f2_local0[31] = 0
            f2_local0[32] = 0
            f2_local0[33] = 0
            f2_local0[34] = 0
        elseif f2_arg1:HasSpecialEffectId(TARGET_SELF, 10530) == true and f2_arg1:HasSpecialEffectId(TARGET_SELF, 10551) == false then
            f2_local0[21] = 10
            f2_local0[22] = 10
            f2_local0[23] = 10
            f2_local0[30] = 50
            f2_local0[31] = 0
            f2_local0[32] = 0
            f2_local0[33] = 20
            f2_local0[34] = 0
        elseif f2_arg1:HasSpecialEffectId(TARGET_SELF, 10530) == false and f2_local3 < 100 then
            if f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 100) then
                f2_local0[21] = 35
                f2_local0[22] = 35
                f2_local0[23] = 30
            else
                f2_local0[30] = 100
            end
        end
    elseif f2_local8 == 1 and f2_arg1:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Torimaki then
        if f2_arg1:HasSpecialEffectId(TARGET_SELF, 10553) == true then
            f2_local0[21] = 10
            f2_local0[22] = 10
            f2_local0[23] = 10
            f2_local0[30] = 70
            f2_local0[31] = 0
            f2_local0[32] = 0
            f2_local0[33] = 0
            f2_local0[34] = 0
        elseif f2_arg1:HasSpecialEffectId(TARGET_SELF, 10530) == true and f2_arg1:HasSpecialEffectId(TARGET_SELF, 10551) == true then
            f2_local0[21] = 10
            f2_local0[22] = 10
            f2_local0[23] = 10
            f2_local0[30] = 70
            f2_local0[31] = 0
            f2_local0[32] = 0
            f2_local0[33] = 0
            f2_local0[34] = 0
        elseif f2_arg1:HasSpecialEffectId(TARGET_SELF, 10530) == true and f2_arg1:HasSpecialEffectId(TARGET_SELF, 10551) == false then
            f2_local0[21] = 10
            f2_local0[22] = 10
            f2_local0[23] = 10
            f2_local0[30] = 50
            f2_local0[31] = 0
            f2_local0[32] = 0
            f2_local0[33] = 20
            f2_local0[34] = 0
        elseif f2_arg1:HasSpecialEffectId(TARGET_SELF, 10530) == false and f2_local3 < 100 then
            if f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 100) then
                f2_local0[21] = 35
                f2_local0[22] = 35
                f2_local0[23] = 30
            else
                f2_local0[30] = 100
            end
        end
    elseif f2_arg1:HasSpecialEffectId(TARGET_SELF, 10553) == true then
        if f2_local3 > 15 then
            if f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 100) then
                f2_local0[1] = 10
                f2_local0[2] = 10
                f2_local0[3] = 0
                f2_local0[4] = 0
                f2_local0[5] = 10
                f2_local0[7] = 0
                f2_local0[8] = 0
                f2_local0[21] = 10
                f2_local0[22] = 10
                f2_local0[23] = 10
                f2_local0[30] = 40
                f2_local0[31] = 0
                f2_local0[32] = 0
                f2_local0[33] = 0
                f2_local0[34] = 0
            else
                f2_local0[30] = 100
                f2_local0[31] = 0
                f2_local0[32] = 0
                f2_local0[33] = 0
                f2_local0[34] = 0
            end
        elseif f2_local3 > 10 then
            if f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 100) then
                f2_local0[1] = 10
                f2_local0[2] = 10
                f2_local0[3] = 0
                f2_local0[4] = 0
                f2_local0[5] = 10
                f2_local0[7] = 0
                f2_local0[8] = 0
                f2_local0[21] = 10
                f2_local0[22] = 10
                f2_local0[23] = 10
                f2_local0[30] = 40
                f2_local0[31] = 0
                f2_local0[32] = 0
                f2_local0[33] = 0
                f2_local0[34] = 0
            else
                f2_local0[30] = 100
                f2_local0[31] = 0
                f2_local0[32] = 0
                f2_local0[33] = 0
                f2_local0[34] = 0
            end
        elseif f2_local3 > 5 then
            if f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 100) then
                f2_local0[1] = 10
                f2_local0[2] = 10
                f2_local0[3] = 0
                f2_local0[4] = 0
                f2_local0[5] = 30
                f2_local0[7] = 0
                f2_local0[8] = 0
                f2_local0[21] = 10
                f2_local0[22] = 10
                f2_local0[23] = 10
                f2_local0[30] = 20
                f2_local0[31] = 0
                f2_local0[32] = 0
                f2_local0[33] = 0
                f2_local0[34] = 0
            else
                f2_local0[30] = 100
                f2_local0[31] = 0
                f2_local0[32] = 0
                f2_local0[33] = 0
                f2_local0[34] = 0
            end
        elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 100) then
            f2_local0[1] = 10
            f2_local0[2] = 10
            f2_local0[3] = 50
            f2_local0[4] = 10
            f2_local0[5] = 10
            f2_local0[7] = 10
            f2_local0[8] = 100
            f2_local0[21] = 0
            f2_local0[22] = 0
            f2_local0[23] = 0
            f2_local0[30] = 0
            f2_local0[31] = 0
            f2_local0[32] = 0
            f2_local0[33] = 0
            f2_local0[34] = 0
        elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_L, 120, 180, 100) then
            f2_local0[1] = 10
            f2_local0[2] = 10
            f2_local0[3] = 50
            f2_local0[4] = 10
            f2_local0[5] = 10
            f2_local0[7] = 10
            f2_local0[8] = 100
            f2_local0[21] = 0
            f2_local0[22] = 0
            f2_local0[23] = 0
            f2_local0[30] = 0
            f2_local0[31] = 0
            f2_local0[32] = 0
            f2_local0[33] = 0
            f2_local0[34] = 0
        elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_R, 120, 180, 100) then
            f2_local0[1] = 10
            f2_local0[2] = 10
            f2_local0[3] = 50
            f2_local0[4] = 10
            f2_local0[5] = 10
            f2_local0[7] = 10
            f2_local0[8] = 100
            f2_local0[21] = 0
            f2_local0[22] = 0
            f2_local0[23] = 0
            f2_local0[30] = 0
            f2_local0[31] = 0
            f2_local0[32] = 0
            f2_local0[33] = 0
            f2_local0[34] = 0
        else
            f2_local0[30] = 100
            f2_local0[31] = 0
            f2_local0[32] = 0
            f2_local0[33] = 0
            f2_local0[34] = 0
        end
    elseif f2_arg1:HasSpecialEffectId(TARGET_SELF, 10530) == true and f2_arg1:HasSpecialEffectId(TARGET_SELF, 10551) == true then
        if f2_local3 > 15 then
            if f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 100) then
                f2_local0[1] = 10
                f2_local0[2] = 10
                f2_local0[3] = 0
                f2_local0[4] = 0
                f2_local0[5] = 10
                f2_local0[7] = 0
                f2_local0[21] = 10
                f2_local0[22] = 10
                f2_local0[23] = 10
                f2_local0[30] = 40
                f2_local0[31] = 0
                f2_local0[32] = 0
                f2_local0[33] = 0
                f2_local0[34] = 0
            else
                f2_local0[30] = 100
                f2_local0[31] = 0
                f2_local0[32] = 0
                f2_local0[33] = 0
                f2_local0[34] = 0
            end
        elseif f2_local3 > 10 then
            if f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 100) then
                f2_local0[1] = 10
                f2_local0[2] = 10
                f2_local0[3] = 0
                f2_local0[4] = 0
                f2_local0[5] = 10
                f2_local0[7] = 0
                f2_local0[21] = 10
                f2_local0[22] = 10
                f2_local0[23] = 10
                f2_local0[30] = 40
                f2_local0[31] = 0
                f2_local0[32] = 0
                f2_local0[33] = 0
                f2_local0[34] = 0
            else
                f2_local0[30] = 100
                f2_local0[31] = 0
                f2_local0[32] = 0
                f2_local0[33] = 0
                f2_local0[34] = 0
            end
        elseif f2_local3 > 5 then
            if f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 100) then
                f2_local0[1] = 10
                f2_local0[2] = 10
                f2_local0[3] = 0
                f2_local0[4] = 0
                f2_local0[5] = 30
                f2_local0[7] = 0
                f2_local0[21] = 10
                f2_local0[22] = 10
                f2_local0[23] = 10
                f2_local0[30] = 20
                f2_local0[31] = 0
                f2_local0[32] = 0
                f2_local0[33] = 0
                f2_local0[34] = 0
            else
                f2_local0[30] = 100
                f2_local0[31] = 0
                f2_local0[32] = 0
                f2_local0[33] = 0
                f2_local0[34] = 0
            end
        elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 100) then
            f2_local0[1] = 10
            f2_local0[2] = 10
            f2_local0[3] = 100
            f2_local0[4] = 10
            f2_local0[5] = 10
            f2_local0[7] = 10
            f2_local0[21] = 0
            f2_local0[22] = 0
            f2_local0[23] = 0
            f2_local0[30] = 0
            f2_local0[31] = 0
            f2_local0[32] = 0
            f2_local0[33] = 0
            f2_local0[34] = 0
        elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_L, 120, 180, 100) then
            f2_local0[1] = 10
            f2_local0[2] = 10
            f2_local0[3] = 100
            f2_local0[4] = 10
            f2_local0[5] = 10
            f2_local0[7] = 10
            f2_local0[21] = 0
            f2_local0[22] = 0
            f2_local0[23] = 0
            f2_local0[30] = 0
            f2_local0[31] = 0
            f2_local0[32] = 0
            f2_local0[33] = 0
            f2_local0[34] = 0
        elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_R, 120, 180, 100) then
            f2_local0[1] = 10
            f2_local0[2] = 10
            f2_local0[3] = 100
            f2_local0[4] = 10
            f2_local0[5] = 10
            f2_local0[7] = 10
            f2_local0[21] = 0
            f2_local0[22] = 0
            f2_local0[23] = 0
            f2_local0[30] = 0
            f2_local0[31] = 0
            f2_local0[32] = 0
            f2_local0[33] = 0
            f2_local0[34] = 0
        else
            f2_local0[30] = 100
            f2_local0[31] = 0
            f2_local0[32] = 0
            f2_local0[33] = 0
            f2_local0[34] = 0
        end
    elseif f2_arg1:HasSpecialEffectId(TARGET_SELF, 10530) == true and f2_arg1:HasSpecialEffectId(TARGET_SELF, 10551) == false then
        if f2_local3 > 15 then
            if f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 100) then
                f2_local0[1] = 10
                f2_local0[2] = 10
                f2_local0[4] = 0
                f2_local0[5] = 10
                f2_local0[7] = 0
                f2_local0[21] = 10
                f2_local0[22] = 10
                f2_local0[23] = 10
                f2_local0[30] = 40
                f2_local0[31] = 0
                f2_local0[32] = 0
                f2_local0[33] = 0
                f2_local0[34] = 0
            else
                f2_local0[30] = 100
                f2_local0[31] = 0
                f2_local0[32] = 0
                f2_local0[33] = 0
                f2_local0[34] = 0
            end
        elseif f2_local3 > 10 then
            if f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 100) then
                f2_local0[1] = 10
                f2_local0[2] = 10
                f2_local0[4] = 0
                f2_local0[5] = 10
                f2_local0[7] = 0
                f2_local0[21] = 10
                f2_local0[22] = 10
                f2_local0[23] = 10
                f2_local0[30] = 40
                f2_local0[31] = 0
                f2_local0[32] = 0
                f2_local0[33] = 0
                f2_local0[34] = 0
            else
                f2_local0[30] = 100
                f2_local0[31] = 0
                f2_local0[32] = 0
                f2_local0[33] = 0
                f2_local0[34] = 0
            end
        elseif f2_local3 > 5 then
            if f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 100) then
                f2_local0[1] = 10
                f2_local0[2] = 10
                f2_local0[4] = 0
                f2_local0[5] = 10
                f2_local0[7] = 0
                f2_local0[21] = 10
                f2_local0[22] = 10
                f2_local0[23] = 10
                f2_local0[30] = 20
                f2_local0[31] = 0
                f2_local0[32] = 0
                f2_local0[33] = 20
                f2_local0[34] = 0
            else
                f2_local0[30] = 100
                f2_local0[31] = 0
                f2_local0[32] = 0
                f2_local0[33] = 0
                f2_local0[34] = 0
            end
        elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 100) then
            f2_local0[1] = 15
            f2_local0[2] = 15
            f2_local0[4] = 15
            f2_local0[5] = 10
            f2_local0[7] = 15
            f2_local0[21] = 0
            f2_local0[22] = 0
            f2_local0[23] = 0
            f2_local0[30] = 0
            f2_local0[31] = 0
            f2_local0[32] = 0
            f2_local0[33] = 10
            f2_local0[34] = 0
        elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_L, 120, 180, 100) then
            f2_local0[1] = 15
            f2_local0[2] = 15
            f2_local0[4] = 15
            f2_local0[5] = 10
            f2_local0[7] = 15
            f2_local0[21] = 0
            f2_local0[22] = 0
            f2_local0[23] = 0
            f2_local0[30] = 0
            f2_local0[31] = 0
            f2_local0[32] = 0
            f2_local0[33] = 10
            f2_local0[34] = 0
        elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_R, 120, 180, 100) then
            f2_local0[1] = 15
            f2_local0[2] = 15
            f2_local0[4] = 15
            f2_local0[5] = 10
            f2_local0[7] = 15
            f2_local0[21] = 0
            f2_local0[22] = 0
            f2_local0[23] = 0
            f2_local0[30] = 0
            f2_local0[31] = 0
            f2_local0[32] = 0
            f2_local0[33] = 10
            f2_local0[34] = 0
        else
            f2_local0[30] = 100
            f2_local0[31] = 0
            f2_local0[32] = 0
            f2_local0[33] = 0
            f2_local0[34] = 0
        end
    elseif f2_arg1:HasSpecialEffectId(TARGET_SELF, 10530) == false and f2_local3 < 100 then
        if f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 100) then
            f2_local0[21] = 35
            f2_local0[22] = 35
            f2_local0[23] = 30
        else
            f2_local0[30] = 100
        end
    end
    f2_local0[1] = SetCoolTime(f2_arg1, f2_arg2, 3000, 10, f2_local0[1], 1)
    f2_local0[2] = SetCoolTime(f2_arg1, f2_arg2, 3001, 10, f2_local0[2], 1)
    f2_local0[3] = SetCoolTime(f2_arg1, f2_arg2, 3002, 15, f2_local0[3], 1)
    f2_local0[4] = SetCoolTime(f2_arg1, f2_arg2, 3005, 10, f2_local0[4], 1)
    f2_local0[5] = SetCoolTime(f2_arg1, f2_arg2, 3006, 10, f2_local0[5], 1)
    f2_local0[6] = SetCoolTime(f2_arg1, f2_arg2, 3007, 10, f2_local0[6], 1)
    f2_local0[7] = SetCoolTime(f2_arg1, f2_arg2, 3008, 10, f2_local0[7], 1)
    f2_local0[8] = SetCoolTime(f2_arg1, f2_arg2, 3011, 15, f2_local0[8], 1)
    f2_local0[21] = SetCoolTime(f2_arg1, f2_arg2, 3022, 5, f2_local0[21], 1)
    f2_local0[21] = SetCoolTime(f2_arg1, f2_arg2, 3025, 5, f2_local0[21], 1)
    f2_local0[21] = SetCoolTime(f2_arg1, f2_arg2, 3026, 5, f2_local0[21], 1)
    f2_local0[22] = SetCoolTime(f2_arg1, f2_arg2, 3022, 5, f2_local0[22], 1)
    f2_local0[22] = SetCoolTime(f2_arg1, f2_arg2, 3025, 5, f2_local0[22], 1)
    f2_local0[22] = SetCoolTime(f2_arg1, f2_arg2, 3026, 5, f2_local0[22], 1)
    f2_local0[23] = SetCoolTime(f2_arg1, f2_arg2, 3022, 5, f2_local0[23], 1)
    f2_local0[23] = SetCoolTime(f2_arg1, f2_arg2, 3025, 5, f2_local0[23], 1)
    f2_local0[23] = SetCoolTime(f2_arg1, f2_arg2, 3026, 5, f2_local0[23], 1)
    f2_local1[1] = REGIST_FUNC(f2_arg1, f2_arg2, DemiHuman_Elite_410100_Act01)
    f2_local1[2] = REGIST_FUNC(f2_arg1, f2_arg2, DemiHuman_Elite_410100_Act02)
    f2_local1[3] = REGIST_FUNC(f2_arg1, f2_arg2, DemiHuman_Elite_410100_Act03)
    f2_local1[4] = REGIST_FUNC(f2_arg1, f2_arg2, DemiHuman_Elite_410100_Act04)
    f2_local1[5] = REGIST_FUNC(f2_arg1, f2_arg2, DemiHuman_Elite_410100_Act05)
    f2_local1[6] = REGIST_FUNC(f2_arg1, f2_arg2, DemiHuman_Elite_410100_Act06)
    f2_local1[7] = REGIST_FUNC(f2_arg1, f2_arg2, DemiHuman_Elite_410100_Act07)
    f2_local1[8] = REGIST_FUNC(f2_arg1, f2_arg2, DemiHuman_Elite_410100_Act08)
    f2_local1[21] = REGIST_FUNC(f2_arg1, f2_arg2, DemiHuman_Elite_410100_Act21)
    f2_local1[22] = REGIST_FUNC(f2_arg1, f2_arg2, DemiHuman_Elite_410100_Act22)
    f2_local1[23] = REGIST_FUNC(f2_arg1, f2_arg2, DemiHuman_Elite_410100_Act23)
    f2_local1[24] = REGIST_FUNC(f2_arg1, f2_arg2, DemiHuman_Elite_410100_Act24)
    f2_local1[25] = REGIST_FUNC(f2_arg1, f2_arg2, DemiHuman_Elite_410100_Act25)
    f2_local1[26] = REGIST_FUNC(f2_arg1, f2_arg2, DemiHuman_Elite_410100_Act26)
    f2_local1[27] = REGIST_FUNC(f2_arg1, f2_arg2, DemiHuman_Elite_410100_Act27)
    f2_local1[28] = REGIST_FUNC(f2_arg1, f2_arg2, DemiHuman_Elite_410100_Act28)
    f2_local1[30] = REGIST_FUNC(f2_arg1, f2_arg2, DemiHuman_Elite_410100_Act30)
    f2_local1[31] = REGIST_FUNC(f2_arg1, f2_arg2, DemiHuman_Elite_410100_Act31)
    f2_local1[32] = REGIST_FUNC(f2_arg1, f2_arg2, DemiHuman_Elite_410100_Act32)
    f2_local1[33] = REGIST_FUNC(f2_arg1, f2_arg2, DemiHuman_Elite_410100_Act33)
    f2_local1[34] = REGIST_FUNC(f2_arg1, f2_arg2, DemiHuman_Elite_410100_Act34)
    f2_local1[35] = REGIST_FUNC(f2_arg1, f2_arg2, DemiHuman_Elite_410100_Act35)
    f2_local1[36] = REGIST_FUNC(f2_arg1, f2_arg2, DemiHuman_Elite_410100_Act36)
    f2_local1[37] = REGIST_FUNC(f2_arg1, f2_arg2, DemiHuman_Elite_410100_Act37)
    local f2_local9 = REGIST_FUNC(f2_arg1, f2_arg2, DemiHuman_Elite_410100_ActAfter_AdjustSpace)
    Common_Battle_Activate(f2_arg1, f2_arg2, f2_local0, f2_local1, f2_local9, f2_local2)
    
end

function DemiHuman_Elite_410100_Act01(f3_arg0, f3_arg1, f3_arg2)
    local f3_local0 = 5 - f3_arg0:GetMapHitRadius(TARGET_SELF)
    local f3_local1 = f3_local0 + 0
    local f3_local2 = f3_local0 + 50
    local f3_local3 = 0
    local f3_local4 = 0
    local f3_local5 = 3
    local f3_local6 = 3
    if f3_arg0:HasSpecialEffectId(TARGET_SELF, 10553) == true or f3_arg0:HasSpecialEffectId(TARGET_SELF, 10551) == true then
        f3_local3 = 70
    end
    Approach_Act_Flex(f3_arg0, f3_arg1, f3_local0, f3_local1, f3_local2, f3_local3, f3_local4, f3_local5, f3_local6)
    local f3_local7 = 3000
    local f3_local8 = 2.5 - f3_arg0:GetMapHitRadius(TARGET_SELF) + 999
    local f3_local9 = 0
    local f3_local10 = 0
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, f3_local7, TARGET_ENE_0, f3_local8, f3_local9, f3_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DemiHuman_Elite_410100_Act02(f4_arg0, f4_arg1, f4_arg2)
    local f4_local0 = 4 - f4_arg0:GetMapHitRadius(TARGET_SELF)
    local f4_local1 = f4_local0 + 0
    local f4_local2 = f4_local0 + 50
    local f4_local3 = 0
    local f4_local4 = 0
    local f4_local5 = 3
    local f4_local6 = 3
    if f4_arg0:HasSpecialEffectId(TARGET_SELF, 10553) == true or f4_arg0:HasSpecialEffectId(TARGET_SELF, 10551) == true then
        f4_local3 = 70
    end
    Approach_Act_Flex(f4_arg0, f4_arg1, f4_local0, f4_local1, f4_local2, f4_local3, f4_local4, f4_local5, f4_local6)
    local f4_local7 = 3001
    local f4_local8 = 2.5 - f4_arg0:GetMapHitRadius(TARGET_SELF) + 999
    local f4_local9 = 0
    local f4_local10 = 0
    f4_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, f4_local7, TARGET_ENE_0, f4_local8, f4_local9, f4_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DemiHuman_Elite_410100_Act03(f5_arg0, f5_arg1, f5_arg2)
    local f5_local0 = 3.5 - f5_arg0:GetMapHitRadius(TARGET_SELF)
    local f5_local1 = f5_local0 + 0
    local f5_local2 = f5_local0 + 50
    local f5_local3 = 0
    local f5_local4 = 0
    local f5_local5 = 3
    local f5_local6 = 3
    if f5_arg0:HasSpecialEffectId(TARGET_SELF, 10553) == true or f5_arg0:HasSpecialEffectId(TARGET_SELF, 10551) == true then
        f5_local3 = 70
    end
    Approach_Act_Flex(f5_arg0, f5_arg1, f5_local0, f5_local1, f5_local2, f5_local3, f5_local4, f5_local5, f5_local6)
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    local f5_local7 = 3002
    local f5_local8 = 2.5 - f5_arg0:GetMapHitRadius(TARGET_SELF) + 999
    local f5_local9 = 0
    local f5_local10 = 0
    f5_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, f5_local7, TARGET_ENE_0, f5_local8, f5_local9, f5_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DemiHuman_Elite_410100_Act04(f6_arg0, f6_arg1, f6_arg2)
    local f6_local0 = 5.5 - f6_arg0:GetMapHitRadius(TARGET_SELF)
    local f6_local1 = f6_local0 + 0
    local f6_local2 = f6_local0 + 50
    local f6_local3 = 0
    local f6_local4 = 0
    local f6_local5 = 3
    local f6_local6 = 3
    if f6_arg0:HasSpecialEffectId(TARGET_SELF, 10553) == true or f6_arg0:HasSpecialEffectId(TARGET_SELF, 10551) == true then
        f6_local3 = 70
    end
    Approach_Act_Flex(f6_arg0, f6_arg1, f6_local0, f6_local1, f6_local2, f6_local3, f6_local4, f6_local5, f6_local6)
    local f6_local7 = 3005
    local f6_local8 = 2.5 - f6_arg0:GetMapHitRadius(TARGET_SELF) + 999
    local f6_local9 = 0
    local f6_local10 = 0
    f6_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, f6_local7, TARGET_ENE_0, f6_local8, f6_local9, f6_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DemiHuman_Elite_410100_Act05(f7_arg0, f7_arg1, f7_arg2)
    local f7_local0 = 4.5 - f7_arg0:GetMapHitRadius(TARGET_SELF)
    local f7_local1 = f7_local0 + 0
    local f7_local2 = f7_local0 + 50
    local f7_local3 = 0
    local f7_local4 = 0
    local f7_local5 = 3
    local f7_local6 = 3
    if f7_arg0:HasSpecialEffectId(TARGET_SELF, 10553) == true or f7_arg0:HasSpecialEffectId(TARGET_SELF, 10551) == true then
        f7_local3 = 70
    end
    Approach_Act_Flex(f7_arg0, f7_arg1, f7_local0, f7_local1, f7_local2, f7_local3, f7_local4, f7_local5, f7_local6)
    local f7_local7 = 3006
    local f7_local8 = 2.5 - f7_arg0:GetMapHitRadius(TARGET_SELF) + 999
    local f7_local9 = 0
    local f7_local10 = 0
    f7_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, f7_local7, TARGET_ENE_0, f7_local8, f7_local9, f7_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DemiHuman_Elite_410100_Act06(f8_arg0, f8_arg1, f8_arg2)
    local f8_local0 = 1.5 - f8_arg0:GetMapHitRadius(TARGET_SELF)
    local f8_local1 = f8_local0 + 0
    local f8_local2 = f8_local0 + 50
    local f8_local3 = 0
    local f8_local4 = 0
    local f8_local5 = 3
    local f8_local6 = 3
    if f8_arg0:HasSpecialEffectId(TARGET_SELF, 10553) == true or f8_arg0:HasSpecialEffectId(TARGET_SELF, 10551) == true then
        f8_local3 = 70
    end
    Approach_Act_Flex(f8_arg0, f8_arg1, f8_local0, f8_local1, f8_local2, f8_local3, f8_local4, f8_local5, f8_local6)
    local f8_local7 = 3007
    local f8_local8 = 2.5 - f8_arg0:GetMapHitRadius(TARGET_SELF)
    local f8_local9 = 0
    local f8_local10 = 0
    f8_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, f8_local7, TARGET_ENE_0, f8_local8, f8_local9, f8_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DemiHuman_Elite_410100_Act07(f9_arg0, f9_arg1, f9_arg2)
    local f9_local0 = 5 - f9_arg0:GetMapHitRadius(TARGET_SELF)
    local f9_local1 = f9_local0 + 0
    local f9_local2 = f9_local0 + 50
    local f9_local3 = 0
    local f9_local4 = 0
    local f9_local5 = 3
    local f9_local6 = 3
    if f9_arg0:HasSpecialEffectId(TARGET_SELF, 10553) == true or f9_arg0:HasSpecialEffectId(TARGET_SELF, 10551) == true then
        f9_local3 = 70
    end
    Approach_Act_Flex(f9_arg0, f9_arg1, f9_local0, f9_local1, f9_local2, f9_local3, f9_local4, f9_local5, f9_local6)
    local f9_local7 = 3008
    local f9_local8 = 2.5 - f9_arg0:GetMapHitRadius(TARGET_SELF)
    local f9_local9 = 0
    local f9_local10 = 0
    f9_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, f9_local7, TARGET_ENE_0, f9_local8, f9_local9, f9_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DemiHuman_Elite_410100_Act08(f10_arg0, f10_arg1, f10_arg2)
    local f10_local0 = 3.5 - f10_arg0:GetMapHitRadius(TARGET_SELF)
    local f10_local1 = f10_local0 + 0
    local f10_local2 = f10_local0 + 50
    local f10_local3 = 0
    local f10_local4 = 0
    local f10_local5 = 3
    local f10_local6 = 3
    if f10_arg0:HasSpecialEffectId(TARGET_SELF, 10553) == true or f10_arg0:HasSpecialEffectId(TARGET_SELF, 10551) == true then
        f10_local3 = 70
    end
    Approach_Act_Flex(f10_arg0, f10_arg1, f10_local0, f10_local1, f10_local2, f10_local3, f10_local4, f10_local5, f10_local6)
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    local f10_local7 = 3011
    local f10_local8 = 2.5 - f10_arg0:GetMapHitRadius(TARGET_SELF) + 999
    local f10_local9 = 0
    local f10_local10 = 0
    f10_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, f10_local7, TARGET_ENE_0, f10_local8, f10_local9, f10_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DemiHuman_Elite_410100_Act21(f11_arg0, f11_arg1, f11_arg2)
    local f11_local0 = 3022
    local f11_local1 = 2.5 - f11_arg0:GetMapHitRadius(TARGET_SELF) + 999
    local f11_local2 = 0
    local f11_local3 = 0
    f11_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, f11_local0, TARGET_ENE_0, f11_local1, f11_local2, f11_local3, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DemiHuman_Elite_410100_Act22(f12_arg0, f12_arg1, f12_arg2)
    local f12_local0 = 3025
    local f12_local1 = 2.5 - f12_arg0:GetMapHitRadius(TARGET_SELF) + 999
    local f12_local2 = 0
    local f12_local3 = 0
    f12_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, f12_local0, TARGET_ENE_0, f12_local1, f12_local2, f12_local3, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DemiHuman_Elite_410100_Act23(f13_arg0, f13_arg1, f13_arg2)
    local f13_local0 = 3026
    local f13_local1 = 2.5 - f13_arg0:GetMapHitRadius(TARGET_SELF) + 999
    local f13_local2 = 0
    local f13_local3 = 0
    f13_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, f13_local0, TARGET_ENE_0, f13_local1, f13_local2, f13_local3, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DemiHuman_Elite_410100_Act24(f14_arg0, f14_arg1, f14_arg2)
    local f14_local0 = 3027
    local f14_local1 = 2.5 - f14_arg0:GetMapHitRadius(TARGET_SELF) + 999
    local f14_local2 = 0
    local f14_local3 = 0
    f14_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, f14_local0, TARGET_ENE_0, f14_local1, f14_local2, f14_local3, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DemiHuman_Elite_410100_Act25(f15_arg0, f15_arg1, f15_arg2)
    local f15_local0 = 3028
    local f15_local1 = 2.5 - f15_arg0:GetMapHitRadius(TARGET_SELF) + 999
    local f15_local2 = 0
    local f15_local3 = 0
    f15_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, f15_local0, TARGET_ENE_0, f15_local1, f15_local2, f15_local3, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DemiHuman_Elite_410100_Act26(f16_arg0, f16_arg1, f16_arg2)
    local f16_local0 = 3029
    local f16_local1 = 2.5 - f16_arg0:GetMapHitRadius(TARGET_SELF) + 999
    local f16_local2 = 0
    local f16_local3 = 0
    f16_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, f16_local0, TARGET_ENE_0, f16_local1, f16_local2, f16_local3, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DemiHuman_Elite_410100_Act27(f17_arg0, f17_arg1, f17_arg2)
    local f17_local0 = 3035
    local f17_local1 = 2.5 - f17_arg0:GetMapHitRadius(TARGET_SELF) + 999
    local f17_local2 = 0
    local f17_local3 = 0
    f17_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, f17_local0, TARGET_SELF, f17_local1, f17_local2, f17_local3, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DemiHuman_Elite_410100_Act28(f18_arg0, f18_arg1, f18_arg2)
    local f18_local0 = 3039
    local f18_local1 = 2.5 - f18_arg0:GetMapHitRadius(TARGET_SELF) + 999
    local f18_local2 = 0
    local f18_local3 = 360
    local f18_local4 = f18_arg0:GetRandam_Int(1, 100)
    if f18_local4 <= 35 then
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, f18_local0, TARGET_ENE_0, f18_local1, f18_local2, f18_local3, 0, 0)
    elseif f18_local4 <= 70 then
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, f18_local0, TARGET_ENE_0, f18_local1, f18_local2, f18_local3, 0, 0)
    else
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 10, 3038, TARGET_SELF):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f18_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, f18_local0, TARGET_ENE_0, f18_local1, f18_local2, f18_local3, 0, 0)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DemiHuman_Elite_410100_Act30(f19_arg0, f19_arg1, f19_arg2)
    f19_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 2, TARGET_ENE_0, 2, TARGET_ENE_0, true, -1)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DemiHuman_Elite_410100_Act31(f20_arg0, f20_arg1, f20_arg2)
    local f20_local0 = f20_arg0:GetRandam_Int(1, 100)
    if f20_local0 <= 50 then
        f20_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f20_arg0:GetRandam_Int(2, 4), TARGET_ENE_0, 3, TARGET_SELF, false, -1, AI_DIR_TYPE_ToL, f20_arg0:GetRandam_Int(5, 8))
    else
        f20_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f20_arg0:GetRandam_Int(2, 4), TARGET_ENE_0, 3, TARGET_SELF, false, -1, AI_DIR_TYPE_ToR, f20_arg0:GetRandam_Int(5, 8))
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DemiHuman_Elite_410100_Act32(f21_arg0, f21_arg1, f21_arg2)
    local f21_local0 = f21_arg0:GetMapHitRadius(TARGET_SELF)
    if f21_arg0:GetExistMeshOnLineDistEx(TARGET_SELF, AI_DIR_TYPE_B, 2, f21_local0, 0) >= 2 then
        f21_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 2, TARGET_ENE_0, 10, TARGET_ENE_0, true, -1)
    else
        f21_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, f21_arg0:GetRandam_Float(2, 2.5), TARGET_ENE_0, f21_arg0:GetRandam_Int(0, 1), f21_arg0:GetRandam_Int(30, 45), true, true, -1)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DemiHuman_Elite_410100_Act33(f22_arg0, f22_arg1, f22_arg2)
    f22_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, f22_arg0:GetRandam_Float(2, 2.5), TARGET_ENE_0, f22_arg0:GetRandam_Int(0, 1), f22_arg0:GetRandam_Int(30, 45), true, true, -1)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DemiHuman_Elite_410100_Act34(f23_arg0, f23_arg1, f23_arg2)
    f23_arg1:AddSubGoal(GOAL_COMMON_Turn, 2, TARGET_ENE_0, 90, -1, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DemiHuman_Elite_410100_Act35(f24_arg0, f24_arg1, f24_arg2)
    f24_arg1:AddSubGoal(GOAL_COMMON_StepSafety, 2, -1, 1, -1, -1, TARGET_ENE_0, 0, 0, true)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DemiHuman_Elite_410100_Act36(f25_arg0, f25_arg1, f25_arg2)
    if f25_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_R, 180) then
        f25_arg1:AddSubGoal(GOAL_COMMON_StepSafety, 2, -1, -1, 1, -1, TARGET_ENE_0, 0, 0, true)
    else
        f25_arg1:AddSubGoal(GOAL_COMMON_StepSafety, 2, -1, -1, -1, 1, TARGET_ENE_0, 0, 0, true)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DemiHuman_Elite_410100_Act37(f26_arg0, f26_arg1, f26_arg2)
    local f26_local0 = 6011
    local f26_local1 = 2.5 - f26_arg0:GetMapHitRadius(TARGET_SELF) + 999
    local f26_local2 = 0
    local f26_local3 = 0
    f26_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, f26_local0, TARGET_ENE_0, f26_local1, f26_local2, f26_local3, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DemiHuman_Elite_410100_ActAfter_AdjustSpace(f27_arg0, f27_arg1, f27_arg2)
    f27_arg1:AddSubGoal(GOAL_DemiHuman_Elite_410100_AfterAttackAct, 10)
    
end

Goal.Update = function (f28_arg0, f28_arg1, f28_arg2)
    return Update_Default_NoSubGoal(f28_arg0, f28_arg1, f28_arg2)
    
end

Goal.Terminate = function (f29_arg0, f29_arg1, f29_arg2)
    
end

Goal.Interrupt = function (f30_arg0, f30_arg1, f30_arg2)
    local f30_local0 = f30_arg1:GetDist(TARGET_ENE_0)
    local f30_local1 = 2.5 - f30_arg1:GetMapHitRadius(TARGET_SELF)
    local f30_local2 = 0
    local f30_local3 = 0
    local f30_local4 = f30_arg1:GetRandam_Int(1, 100)
    local f30_local5 = f30_arg1:GetHpRate(TARGET_SELF)
    if f30_arg1:HasSpecialEffectId(TARGET_SELF, 5110) == true or f30_arg1:HasSpecialEffectAttribute(TARGET_SELF, SP_EFFECT_TYPE_SLEEP) == true then
        return false
    end
    if f30_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f30_arg1:GetSpecialEffectActivateInterruptId(5025) and f30_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 3.5) then
        f30_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3003, TARGET_ENE_0, 999, 0, 0, 0, 0)
        return true
    end
    if f30_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f30_arg1:GetSpecialEffectActivateInterruptId(5026) and f30_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 3.5) then
        f30_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 10, 3004, TARGET_ENE_0, 999, 0, 0)
        return true
    end
    if f30_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f30_arg1:GetSpecialEffectActivateInterruptId(5027) and f30_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 3.5) then
        f30_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 10, 3012, TARGET_ENE_0, 999, 0, 0)
        return true
    end
    return false
    
end

RegisterTableGoal(GOAL_DemiHuman_Elite_410100_AfterAttackAct, "DemiHuman_Elite_410100_AfterAttackAct")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_DemiHuman_Elite_410100_AfterAttackAct, true)

Goal.Activate = function (f31_arg0, f31_arg1, f31_arg2)
    
end

Goal.Update = function (f32_arg0, f32_arg1, f32_arg2)
    return Update_Default_NoSubGoal(f32_arg0, f32_arg1, f32_arg2)
    
end


