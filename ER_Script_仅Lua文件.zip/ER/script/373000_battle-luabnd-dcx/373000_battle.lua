﻿RegisterTableGoal(GOAL_Magicianball_373000_Battle, "Magicianball_373000_Battle")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_Magicianball_373000_Battle, true)

Goal.Initialize = function (f1_arg0, f1_arg1, f1_arg2, f1_arg3)
    
end

Goal.Activate = function (f2_arg0, f2_arg1, f2_arg2)
    Init_Pseudo_Global(f2_arg1, f2_arg2)
    local f2_local0 = {}
    local f2_local1 = {}
    local f2_local2 = {}
    Common_Clear_Param(f2_local0, f2_local1, f2_local2)
    local f2_local3 = f2_arg1:GetDist(TARGET_ENE_0)
    local f2_local4 = f2_arg1:GetDistY(TARGET_ENE_0)
    local f2_local5 = f2_arg1:GetHpRate(TARGET_SELF)
    local f2_local6 = f2_arg1:GetRandam_Int(1, 100)
    local f2_local7 = f2_arg1:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__thinkAttr_doAdmirer)
    if f2_local3 >= 999 then
        if f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 360, 180, 100) then
            f2_local0[1] = 100
        end
    elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 360, 180, 100) then
        f2_local0[1] = 100
    end
    f2_local0[1] = SetCoolTime(f2_arg1, f2_arg2, 3000, 0, f2_local0[1], 1)
    f2_local1[1] = REGIST_FUNC(f2_arg1, f2_arg2, Magicianball_373000_Act01)
    local f2_local8 = REGIST_FUNC(f2_arg1, f2_arg2, Magicianball_373000_Act01_ActAfter_AdjustSpace)
    Common_Battle_Activate(f2_arg1, f2_arg2, f2_local0, f2_local1, f2_local8, f2_local2)
    
end

function Magicianball_373000_Act01(f3_arg0, f3_arg1, f3_arg2)
    local f3_local0 = 999 - f3_arg0:GetMapHitRadius(TARGET_SELF)
    local f3_local1 = f3_local0 + 0
    local f3_local2 = f3_local0 + 0
    local f3_local3 = 0
    local f3_local4 = 0
    local f3_local5 = 3
    local f3_local6 = 3
    Approach_Act_Flex(f3_arg0, f3_arg1, f3_local0, f3_local1, f3_local2, f3_local3, f3_local4, f3_local5, f3_local6)
    local f3_local7 = 3000
    local f3_local8 = 5 - f3_arg0:GetMapHitRadius(TARGET_SELF) + 999
    local f3_local9 = 0
    local f3_local10 = 0
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, f3_local7, TARGET_ENE_0, f3_local8, f3_local9, f3_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Magicianball_373000_ActAfter_AdjustSpace(f4_arg0, f4_arg1, f4_arg2)
    f4_arg1:AddSubGoal(GOAL_Magicianball_373000_AfterAttackAct, 10)
    
end

Goal.Update = function (f5_arg0, f5_arg1, f5_arg2)
    return Update_Default_NoSubGoal(f5_arg0, f5_arg1, f5_arg2)
    
end

Goal.Terminate = function (f6_arg0, f6_arg1, f6_arg2)
    
end

RegisterTableGoal(GOAL_Magicianball_373000_AfterAttackAct, "Magicianball_373000_AfterAttackAct")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_Magicianball_373000_AfterAttackAct, true)

Goal.Activate = function (f7_arg0, f7_arg1, f7_arg2)
    
end

Goal.Update = function (f8_arg0, f8_arg1, f8_arg2)
    return Update_Default_NoSubGoal(f8_arg0, f8_arg1, f8_arg2)
    
end


