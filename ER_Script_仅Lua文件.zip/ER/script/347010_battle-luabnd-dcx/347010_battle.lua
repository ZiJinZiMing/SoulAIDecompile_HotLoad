﻿RegisterTableGoal(GOAL_FrogHuman_347010_Battle, "GOAL_FrogHuman_347010_Battle")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_FrogHuman_347010_Battle, true)

Goal.Initialize = function (f1_arg0, f1_arg1, f1_arg2, f1_arg3)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3000)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3001)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3002)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3005)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3006)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3007)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3008)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3009)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3011)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3012)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3013)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3014)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3015)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3016)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3017)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3018)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3023)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3024)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3025)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3026)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3027)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3028)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3029)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3030)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3031)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3032)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3033)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3034)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3035)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3036)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3037)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3038)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3039)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3000)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3001)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3002)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3005)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3016)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3010)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3011)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3012)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3020)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3021)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3022)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3024)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3025)
    f1_arg1:EnableUnfavorableAttackCheck(1, 3026)
    
end

Goal.Activate = function (f2_arg0, f2_arg1, f2_arg2)
    Init_Pseudo_Global(f2_arg1, f2_arg2)
    local f2_local0 = {}
    local f2_local1 = {}
    local f2_local2 = {}
    Common_Clear_Param(f2_local0, f2_local1, f2_local2)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    local f2_local3 = f2_arg1:GetDist(TARGET_ENE_0)
    local f2_local4 = f2_arg1:GetRandam_Int(1, 100)
    local f2_local5 = f2_arg1:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__thinkAttr_doAdmirer)
    f2_arg1:SetStringIndexedNumber("c3470_DashRate", 0)
    if f2_arg1:HasSpecialEffectId(TARGET_SELF, 15606) then
        if f2_arg1:IsInsideTargetCustom(TARGET_ENE_0, TARGET_SELF, AI_DIR_TYPE_B, 180, 180, 4) then
            f2_local0[21] = 60
        elseif f2_local3 >= 15 then
            f2_local0[30] = 100
        elseif f2_local3 >= 4 then
            f2_local0[6] = 80
            f2_local0[30] = 20
        else
            local f2_local6 = 1
            if f2_arg1:HasSpecialEffectId(TARGET_SELF, 15607) then
                f2_local6 = 0
            end
            f2_local0[1] = 20
            f2_local0[5] = 20
            f2_local0[7] = 20
            f2_local0[10] = 5 * f2_local6
            f2_local0[14] = 30 * f2_local6
            f2_local0[20] = 5
        end
    elseif f2_local5 == 1 and f2_arg1:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Kankyaku then
        if f2_arg1:HasSpecialEffectId(TARGET_SELF, 15610) then
            f2_local0[6] = 100
        elseif f2_local3 >= 4 then
            f2_local0[13] = 50
            f2_local0[30] = 40
            f2_local0[21] = 10
        else
            f2_local0[13] = 60
            f2_local0[30] = 20
            f2_local0[20] = 20
        end
    elseif f2_local5 == 1 and f2_arg1:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Torimaki then
        local f2_local6 = 0
        if f2_arg1:HasSpecialEffectId(TARGET_SELF, 15608) then
            f2_local6 = 1
        end
        if f2_arg1:HasSpecialEffectId(TARGET_SELF, 15610) then
            f2_local0[6] = 100
        elseif f2_local3 >= 4 then
            f2_local0[4] = 20
            f2_local0[6] = 10
            f2_local0[10] = 10
            f2_local0[13] = 50
            f2_local0[21] = 10
            f2_local0[19] = 20 * f2_local6
        else
            f2_local0[6] = 10
            f2_local0[13] = 50
            f2_local0[30] = 20
            f2_local0[20] = 20
        end
    elseif f2_arg1:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_BUDDY_DECLARE) == true then
        if f2_local3 >= 5 then
            f2_local0[4] = 0
            f2_local0[6] = 20
            f2_local0[5] = 0
            f2_local0[10] = 30
            f2_local0[13] = 50
        elseif f2_local3 >= 3 then
            f2_local0[1] = 0
            f2_local0[4] = 0
            f2_local0[5] = 0
            f2_local0[6] = 20
            f2_local0[10] = 30
            f2_local0[13] = 50
        else
            f2_local0[1] = 30
            f2_local0[5] = 0
            f2_local0[7] = 0
            f2_local0[10] = 70
            f2_local0[20] = 0
        end
    elseif f2_arg1:IsInsideTargetCustom(TARGET_ENE_0, TARGET_SELF, AI_DIR_TYPE_B, 180, 180, 4) then
        local f2_local6 = 1
        if f2_arg1:HasSpecialEffectId(TARGET_SELF, 15607) then
            f2_local6 = 0
        end
        f2_local0[13] = 40 * f2_local6
        f2_local0[21] = 60
    else
        local f2_local6 = 1
        if f2_arg1:HasSpecialEffectId(TARGET_SELF, 15607) then
            f2_local6 = 0
        end
        local f2_local7 = 0
        if f2_arg1:HasSpecialEffectId(TARGET_SELF, 15608) then
            f2_local7 = 1
        end
        local f2_local8 = 0
        if f2_arg1:HasSpecialEffectId(TARGET_SELF, 15609) then
            f2_local8 = 1
        end
        if f2_local3 >= 5 then
            if f2_arg1:HasSpecialEffectId(TARGET_SELF, 15610) then
                f2_local0[6] = 100
            else
                f2_local0[4] = 30
                f2_local0[6] = 35
                f2_local0[5] = 15
                f2_local0[13] = 20 * f2_local6
                f2_local0[17] = 80 * f2_local8
                f2_local0[18] = 80 * f2_local7
                f2_local0[19] = 0 * f2_local7
            end
        elseif f2_local3 >= 3 then
            f2_local0[1] = 15
            f2_local0[4] = 30
            f2_local0[5] = 10
            f2_local0[6] = 10
            f2_local0[10] = 15 * f2_local6
            f2_local0[13] = 20 * f2_local6
            f2_local0[17] = 60 * f2_local8
            f2_local0[18] = 60 * f2_local7
            f2_local0[19] = 20 * f2_local7
        else
            f2_local0[1] = 20
            f2_local0[5] = 20
            f2_local0[7] = 20
            f2_local0[10] = 5 * f2_local6
            f2_local0[14] = 30
            f2_local0[20] = 5
        end
    end
    if f2_arg1:HasSpecialEffectId(TARGET_SELF, 15611) then
        f2_local0[15] = 0
        f2_local0[16] = 0
        f2_local0[25] = 0
        f2_local0[30] = 0
        f2_local0[31] = 0
    end
    f2_local0[1] = SetCoolTime(f2_arg1, f2_arg2, 3000, 5, f2_local0[1], 0)
    f2_local0[2] = SetCoolTime(f2_arg1, f2_arg2, 3003, 8, f2_local0[2], 0)
    f2_local0[2] = SetCoolTime(f2_arg1, f2_arg2, 3004, 8, f2_local0[2], 0)
    f2_local0[2] = SetCoolTime(f2_arg1, f2_arg2, 3026, 8, f2_local0[2], 0)
    f2_local0[2] = SetCoolTime(f2_arg1, f2_arg2, 3027, 8, f2_local0[2], 0)
    f2_local0[3] = SetCoolTime(f2_arg1, f2_arg2, 3003, 8, f2_local0[3], 0)
    f2_local0[3] = SetCoolTime(f2_arg1, f2_arg2, 3004, 8, f2_local0[3], 0)
    f2_local0[3] = SetCoolTime(f2_arg1, f2_arg2, 3026, 8, f2_local0[3], 0)
    f2_local0[3] = SetCoolTime(f2_arg1, f2_arg2, 3027, 8, f2_local0[3], 0)
    f2_local0[4] = SetCoolTime(f2_arg1, f2_arg2, 3012, 7, f2_local0[4], 0)
    f2_local0[5] = SetCoolTime(f2_arg1, f2_arg2, 3013, 10, f2_local0[5], 0)
    if f2_arg1:HasSpecialEffectId(TARGET_SELF, 15606) == false then
        f2_local0[6] = SetCoolTime(f2_arg1, f2_arg2, 3021, 20, f2_local0[6], 0)
    elseif f2_arg1:HasSpecialEffectId(TARGET_SELF, 15610) then
        f2_local0[6] = SetCoolTime(f2_arg1, f2_arg2, 3020, 0, f2_local0[6], 0)
    else
        f2_local0[6] = SetCoolTime(f2_arg1, f2_arg2, 3021, 20, f2_local0[6], 0)
    end
    f2_local0[7] = SetCoolTime(f2_arg1, f2_arg2, 3011, 10, f2_local0[7], 0)
    f2_local0[8] = SetCoolTime(f2_arg1, f2_arg2, 3012, 12, f2_local0[8], 0)
    f2_local0[10] = SetCoolTime(f2_arg1, f2_arg2, 3005, 15, f2_local0[10], 0)
    f2_local0[11] = SetCoolTime(f2_arg1, f2_arg2, 3003, 10, f2_local0[11], 0)
    f2_local0[12] = SetCoolTime(f2_arg1, f2_arg2, 3004, 10, f2_local0[12], 0)
    f2_local0[13] = SetCoolTime(f2_arg1, f2_arg2, 3003, 8, f2_local0[13], 0)
    f2_local0[13] = SetCoolTime(f2_arg1, f2_arg2, 3004, 8, f2_local0[13], 0)
    f2_local0[13] = SetCoolTime(f2_arg1, f2_arg2, 3026, 8, f2_local0[13], 0)
    f2_local0[13] = SetCoolTime(f2_arg1, f2_arg2, 3027, 8, f2_local0[13], 0)
    f2_local0[14] = SetCoolTime(f2_arg1, f2_arg2, 20010, 8, f2_local0[14], 0)
    f2_local0[17] = SetCoolTime(f2_arg1, f2_arg2, 20013, 10, f2_local0[17], 0)
    f2_local0[18] = SetCoolTime(f2_arg1, f2_arg2, 20011, 25, f2_local0[18], 0)
    f2_local0[19] = SetCoolTime(f2_arg1, f2_arg2, 20012, 15, f2_local0[19], 0)
    f2_local1[1] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347010_Act01)
    f2_local1[2] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347010_Act02)
    f2_local1[3] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347010_Act03)
    f2_local1[4] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347010_Act04)
    f2_local1[5] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347010_Act05)
    f2_local1[6] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347010_Act06)
    f2_local1[7] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347010_Act07)
    f2_local1[8] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347010_Act08)
    f2_local1[10] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347010_Act10)
    f2_local1[11] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347010_Act11)
    f2_local1[12] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347010_Act12)
    f2_local1[13] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347010_Act13)
    f2_local1[14] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347010_Act14)
    f2_local1[15] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347010_Act15)
    f2_local1[16] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347010_Act16)
    f2_local1[17] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347010_Act17)
    f2_local1[18] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347010_Act18)
    f2_local1[19] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347010_Act19)
    f2_local1[20] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347010_Act20)
    f2_local1[21] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347010_Act21)
    f2_local1[25] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347010_Act25)
    f2_local1[30] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347010_Act30)
    f2_local1[31] = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347010_Act31)
    local f2_local6 = REGIST_FUNC(f2_arg1, f2_arg2, FrogHuman_347010_ActAfter_AdjustSpace)
    Common_Battle_Activate(f2_arg1, f2_arg2, f2_local0, f2_local1, f2_local6, f2_local2)
    
end

function FrogHuman_347010_Act01(f3_arg0, f3_arg1, f3_arg2)
    local f3_local0 = 4.4 - f3_arg0:GetMapHitRadius(TARGET_SELF)
    local f3_local1 = f3_local0 + 0
    local f3_local2 = f3_local0 + 50
    local f3_local3 = f3_arg0:GetStringIndexedNumber("c3470_DashRate")
    local f3_local4 = 70
    local f3_local5 = 4
    local f3_local6 = 8
    if f3_arg0:HasSpecialEffectId(TARGET_SELF, 15611) then
        f3_local4 = 0
    end
    Approach_Act_Flex(f3_arg0, f3_arg1, f3_local0, f3_local1, f3_local2, f3_local3, f3_local4, f3_local5, f3_local6)
    local f3_local7 = 3023
    local f3_local8 = 3024
    local f3_local9 = 3025
    local f3_local10 = 5
    local f3_local11 = 5
    local f3_local12 = 5 - f3_arg0:GetMapHitRadius(TARGET_SELF)
    local f3_local13 = 0
    local f3_local14 = 180
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f3_local7, TARGET_ENE_0, f3_local10, 0, 0, 0, 0)
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, f3_local8, TARGET_ENE_0, f3_local11, 0, 0, 0, 0)
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 10, f3_local9, TARGET_ENE_0, f3_local12, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347010_Act02(f4_arg0, f4_arg1, f4_arg2)
    local f4_local0 = 8 - f4_arg0:GetMapHitRadius(TARGET_SELF)
    local f4_local1 = f4_local0 + 0
    local f4_local2 = f4_local0 + 50
    local f4_local3 = f4_arg0:GetStringIndexedNumber("c3470_DashRate")
    local f4_local4 = 70
    local f4_local5 = 4
    local f4_local6 = 8
    if f4_arg0:HasSpecialEffectId(TARGET_SELF, 15611) then
        f4_local4 = 0
    end
    Approach_Act_Flex(f4_arg0, f4_arg1, f4_local0, f4_local1, f4_local2, f4_local3, f4_local4, f4_local5, f4_local6)
    local f4_local7 = 3003
    local f4_local8 = 2.5
    local f4_local9 = 0
    local f4_local10 = 0
    f4_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f4_local7, TARGET_ENE_0, f4_local8, f4_local9, f4_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347010_Act03(f5_arg0, f5_arg1, f5_arg2)
    local f5_local0 = 8 - f5_arg0:GetMapHitRadius(TARGET_SELF)
    local f5_local1 = f5_local0 + 0
    local f5_local2 = f5_local0 + 50
    local f5_local3 = f5_arg0:GetStringIndexedNumber("c3470_DashRate")
    local f5_local4 = 70
    local f5_local5 = 4
    local f5_local6 = 8
    if f5_arg0:HasSpecialEffectId(TARGET_SELF, 15611) then
        f5_local4 = 0
    end
    Approach_Act_Flex(f5_arg0, f5_arg1, f5_local0, f5_local1, f5_local2, f5_local3, f5_local4, f5_local5, f5_local6)
    local f5_local7 = 3004
    local f5_local8 = 2.5
    local f5_local9 = 0
    local f5_local10 = 0
    f5_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f5_local7, TARGET_ENE_0, f5_local8, f5_local9, f5_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347010_Act04(f6_arg0, f6_arg1, f6_arg2)
    local f6_local0 = 5.5 - f6_arg0:GetMapHitRadius(TARGET_SELF)
    local f6_local1 = f6_local0 + 0
    local f6_local2 = f6_local0 + 50
    local f6_local3 = f6_arg0:GetStringIndexedNumber("c3470_DashRate")
    local f6_local4 = 70
    local f6_local5 = 4
    local f6_local6 = 8
    if f6_arg0:HasSpecialEffectId(TARGET_SELF, 15611) then
        f6_local4 = 0
    end
    Approach_Act_Flex(f6_arg0, f6_arg1, f6_local0, f6_local1, f6_local2, f6_local3, f6_local4, f6_local5, f6_local6)
    local f6_local7 = 3012
    local f6_local8 = 4.4
    local f6_local9 = 0
    local f6_local10 = 0
    f6_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f6_local7, TARGET_ENE_0, f6_local8, f6_local9, f6_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347010_Act05(f7_arg0, f7_arg1, f7_arg2)
    local f7_local0 = 4.5 - f7_arg0:GetMapHitRadius(TARGET_SELF)
    local f7_local1 = f7_local0 + 0
    local f7_local2 = f7_local0 + 50
    local f7_local3 = f7_arg0:GetStringIndexedNumber("c3470_DashRate")
    local f7_local4 = 70
    local f7_local5 = 4
    local f7_local6 = 8
    if f7_arg0:HasSpecialEffectId(TARGET_SELF, 15611) then
        f7_local4 = 0
    end
    Approach_Act_Flex(f7_arg0, f7_arg1, f7_local0, f7_local1, f7_local2, f7_local3, f7_local4, f7_local5, f7_local6)
    local f7_local7 = 3013
    local f7_local8 = 2.5
    local f7_local9 = 0
    local f7_local10 = 0
    f7_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f7_local7, TARGET_ENE_0, f7_local8, f7_local9, f7_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347010_Act06(f8_arg0, f8_arg1, f8_arg2)
    if f8_arg0:HasSpecialEffectId(TARGET_SELF, 15606) == true or f8_arg0:HasSpecialEffectId(TARGET_SELF, 15610) == true then
    else
        local f8_local0 = 6 - f8_arg0:GetMapHitRadius(TARGET_SELF)
        local f8_local1 = f8_local0 + 0
        local f8_local2 = f8_local0 + 50
        local f8_local3 = f8_arg0:GetStringIndexedNumber("c3470_DashRate")
        local f8_local4 = 70
        local f8_local5 = 4
        local f8_local6 = 8
        if f8_arg0:HasSpecialEffectId(TARGET_SELF, 15611) then
            f8_local4 = 0
        end
        Approach_Act_Flex(f8_arg0, f8_arg1, f8_local0, f8_local1, f8_local2, f8_local3, f8_local4, f8_local5, f8_local6)
    end
    local f8_local0 = 3021
    if f8_arg0:HasSpecialEffectId(TARGET_SELF, 15610) then
        f8_local0 = 3020
    end
    local f8_local1 = 5 - f8_arg0:GetMapHitRadius(TARGET_SELF)
    local f8_local2 = 0
    local f8_local3 = 0
    f8_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f8_local0, TARGET_ENE_0, f8_local1, f8_local2, f8_local3, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347010_Act07(f9_arg0, f9_arg1, f9_arg2)
    if f9_arg0:HasSpecialEffectId(TARGET_SELF, 15611) == false then
        local f9_local0 = 3
        local f9_local1 = f9_local0 + 0
        local f9_local2 = f9_local0 + 50
        local f9_local3 = f9_arg0:GetStringIndexedNumber("c3470_DashRate")
        local f9_local4 = 70
        local f9_local5 = 4
        local f9_local6 = 8
        if f9_arg0:HasSpecialEffectId(TARGET_SELF, 15611) then
            f9_local4 = 0
        end
        Approach_Act_Flex(f9_arg0, f9_arg1, f9_local0, f9_local1, f9_local2, f9_local3, f9_local4, f9_local5, f9_local6)
        local f9_local7 = 3011
        local f9_local8 = 2
        local f9_local9 = 3
        local f9_local10 = 5 - f9_arg0:GetMapHitRadius(TARGET_SELF)
        local f9_local11 = 0
        local f9_local12 = 180
        f9_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f9_local7, TARGET_ENE_0, f9_local8, 0, 0, 0, 0)
        GetWellSpace_Odds = 0
        return GetWellSpace_Odds
    end
    
end

function FrogHuman_347010_Act08(f10_arg0, f10_arg1, f10_arg2)
    local f10_local0 = 5.5 - f10_arg0:GetMapHitRadius(TARGET_SELF)
    local f10_local1 = f10_local0 + 0
    local f10_local2 = f10_local0 + 50
    local f10_local3 = f10_arg0:GetStringIndexedNumber("c3470_DashRate")
    local f10_local4 = 70
    local f10_local5 = 4
    local f10_local6 = 8
    if f10_arg0:HasSpecialEffectId(TARGET_SELF, 15611) then
        f10_local4 = 0
    end
    Approach_Act_Flex(f10_arg0, f10_arg1, f10_local0, f10_local1, f10_local2, f10_local3, f10_local4, f10_local5, f10_local6)
    local f10_local7 = 3012
    local f10_local8 = 3021
    local f10_local9 = 7
    local f10_local10 = 7
    local f10_local11 = 0
    local f10_local12 = 0
    local f10_local13 = f10_arg0:GetRandam_Int(1, 100)
    f10_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f10_local7, TARGET_ENE_0, f10_local0, f10_local11, f10_local12, 0, 0)
    f10_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 10, f10_local8, TARGET_ENE_0, f10_local9, 90)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347010_Act10(f11_arg0, f11_arg1, f11_arg2)
    local f11_local0 = 10 - f11_arg0:GetMapHitRadius(TARGET_SELF)
    local f11_local1 = f11_local0 + 0
    local f11_local2 = f11_local0 + 50
    local f11_local3 = f11_arg0:GetStringIndexedNumber("c3470_DashRate")
    local f11_local4 = 70
    local f11_local5 = 4
    local f11_local6 = 8
    if f11_arg0:HasSpecialEffectId(TARGET_SELF, 15611) then
        f11_local4 = 0
    end
    Approach_Act_Flex(f11_arg0, f11_arg1, f11_local0, f11_local1, f11_local2, f11_local3, f11_local4, f11_local5, f11_local6)
    local f11_local7 = 3005
    local f11_local8 = 6
    local f11_local9 = 0
    local f11_local10 = 0
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f11_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f11_local7, TARGET_ENE_0, f11_local8, f11_local9, f11_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347010_Act11(f12_arg0, f12_arg1, f12_arg2)
    local f12_local0 = 8 - f12_arg0:GetMapHitRadius(TARGET_SELF)
    local f12_local1 = f12_local0 + 0
    local f12_local2 = f12_local0 + 50
    local f12_local3 = f12_arg0:GetStringIndexedNumber("c3470_DashRate")
    local f12_local4 = 70
    local f12_local5 = 4
    local f12_local6 = 8
    if f12_arg0:HasSpecialEffectId(TARGET_SELF, 15611) then
        f12_local4 = 0
    end
    Approach_Act_Flex(f12_arg0, f12_arg1, f12_local0, f12_local1, f12_local2, f12_local3, f12_local4, f12_local5, f12_local6)
    local f12_local7 = 3003
    local f12_local8 = 3012
    local f12_local9 = 7
    local f12_local10 = 7
    local f12_local11 = 0
    local f12_local12 = 0
    local f12_local13 = f12_arg0:GetRandam_Int(1, 100)
    f12_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f12_local7, TARGET_ENE_0, f12_local0, f12_local11, f12_local12, 0, 0)
    f12_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 10, f12_local8, TARGET_ENE_0, f12_local9, 90)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347010_Act12(f13_arg0, f13_arg1, f13_arg2)
    local f13_local0 = 8 - f13_arg0:GetMapHitRadius(TARGET_SELF)
    local f13_local1 = f13_local0 + 0
    local f13_local2 = f13_local0 + 50
    local f13_local3 = f13_arg0:GetStringIndexedNumber("c3470_DashRate")
    local f13_local4 = 70
    local f13_local5 = 4
    local f13_local6 = 8
    if f13_arg0:HasSpecialEffectId(TARGET_SELF, 15611) then
        f13_local4 = 0
    end
    Approach_Act_Flex(f13_arg0, f13_arg1, f13_local0, f13_local1, f13_local2, f13_local3, f13_local4, f13_local5, f13_local6)
    local f13_local7 = 3004
    local f13_local8 = 3012
    local f13_local9 = 7
    local f13_local10 = 7
    local f13_local11 = 0
    local f13_local12 = 0
    local f13_local13 = f13_arg0:GetRandam_Int(1, 100)
    f13_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f13_local7, TARGET_ENE_0, f13_local0, f13_local11, f13_local12, 0, 0)
    f13_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 10, f13_local8, TARGET_ENE_0, f13_local9, 90)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347010_Act13(f14_arg0, f14_arg1, f14_arg2)
    local f14_local0 = 15
    local f14_local1 = 100
    local f14_local2 = 999
    local f14_local3 = 0
    local f14_local4 = 70
    local f14_local5 = 4
    local f14_local6 = 8
    if f14_arg0:HasSpecialEffectId(TARGET_SELF, 15611) then
        f14_local4 = 0
    end
    Approach_Act_Flex(f14_arg0, f14_arg1, f14_local0, f14_local1, f14_local2, f14_local3, f14_local4, f14_local5, f14_local6)
    local f14_local7 = 3026
    local f14_local8 = 5
    local f14_local9 = 0
    local f14_local10 = 180
    if f14_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_L, 180) then
        f14_local7 = 3027
        f14_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5026)
        f14_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    else
        f14_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
        f14_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    end
    f14_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f14_local7, TARGET_ENE_0, f14_local8, f14_local9, f14_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347010_Act14(f15_arg0, f15_arg1, f15_arg2)
    local f15_local0 = 3
    local f15_local1 = f15_local0 + 0
    local f15_local2 = f15_local0 + 50
    local f15_local3 = f15_arg0:GetStringIndexedNumber("c3470_DashRate")
    local f15_local4 = 0
    local f15_local5 = 4
    local f15_local6 = 8
    local f15_local7 = 20010
    local f15_local8 = 5
    local f15_local9 = 5 - f15_arg0:GetMapHitRadius(TARGET_SELF)
    local f15_local10 = 0
    local f15_local11 = 180
    f15_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f15_local7, TARGET_ENE_0, f15_local8, f15_local10, f15_local11, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347010_Act15(f16_arg0, f16_arg1, f16_arg2)
    local f16_local0 = f16_arg0:GetDist(TARGET_ENE_0)
    local f16_local1 = 0
    local f16_local2 = 0
    local f16_local3 = 100
    local f16_local4 = f16_arg0:GetRandam_Int(1, 100)
    local f16_local5 = -1
    if f16_local4 <= f16_local3 then
        f16_local5 = 9910
    end
    f16_arg1:AddSubGoal(GOAL_COMMON_Guard, 15, 30, TARGET_ENE_0, resultTypeIfGuardSuccess, true)
    
end

function FrogHuman_347010_Act16(f17_arg0, f17_arg1, f17_arg2)
    local f17_local0 = f17_arg0:GetRandam_Int(1, 100)
    local f17_local1 = 100
    local f17_local2 = 9910
    if f17_arg0:HasSpecialEffectId(TARGET_SELF, 15611) then
        f17_local2 = -1
    end
    f17_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, 2, TARGET_ENE_0, f17_arg0:GetRandam_Int(0, 1), f17_arg0:GetRandam_Int(30, 45), true, true, f17_local2)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347010_Act17(f18_arg0, f18_arg1, f18_arg2)
    local f18_local0 = 5
    local f18_local1 = 20013
    local f18_local2 = TARGET_ENE_0
    local f18_local3 = 10
    local f18_local4 = 0
    local f18_local5 = 0
    local f18_local6 = 0
    f18_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, f18_local0, f18_local1, f18_local2, f18_local3, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347010_Act18(f19_arg0, f19_arg1, f19_arg2)
    local f19_local0 = 5
    local f19_local1 = 20011
    local f19_local2 = TARGET_ENE_0
    local f19_local3 = 10
    local f19_local4 = 0
    local f19_local5 = 0
    local f19_local6 = 0
    f19_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, f19_local0, f19_local1, f19_local2, f19_local3, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347010_Act19(f20_arg0, f20_arg1, f20_arg2)
    local f20_local0 = 5
    local f20_local1 = 20012
    local f20_local2 = TARGET_ENE_0
    local f20_local3 = 10
    local f20_local4 = 0
    local f20_local5 = 0
    local f20_local6 = 0
    f20_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, f20_local0, f20_local1, f20_local2, f20_local3, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347010_Act20(f21_arg0, f21_arg1, f21_arg2)
    local f21_local0 = 3
    local f21_local1 = TARGET_ENE_0
    local f21_local2 = 5
    local f21_local3 = TARGET_ENE_0
    local f21_local4 = true
    local f21_local5 = f21_arg0:GetDist(TARGET_ENE_0)
    local f21_local6 = 0
    local f21_local7 = f21_arg0:GetRandam_Int(1, 100)
    local f21_local8 = 9910
    if f21_arg0:HasSpecialEffectId(TARGET_SELF, 15611) then
        f21_local8 = -1
    end
    f21_arg0:SetTimer(0, 4)
    f21_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, f21_local0, f21_local1, f21_local2, f21_local3, f21_local4, f21_local8)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347010_Act21(f22_arg0, f22_arg1, f22_arg2)
    local f22_local0 = f22_arg0:GetDist(TARGET_ENE_0)
    local f22_local1 = f22_arg0:GetRandam_Int(1.5, 3)
    local f22_local2 = 30
    local f22_local3 = f22_arg0:GetRandam_Int(1, 100)
    local f22_local4 = true
    local f22_local5 = 9910
    if f22_arg0:HasSpecialEffectId(TARGET_SELF, 15611) then
        f22_local5 = -1
    end
    f22_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, f22_arg0:GetRandam_Int(3, 5), TARGET_ENE_0, f22_local1, TARGET_ENE_0, f22_local4, f22_local5)
    f22_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, f22_arg0:GetRandam_Int(2, 3.5), TARGET_ENE_0, f22_arg0:GetRandam_Int(0, 1), f22_arg0:GetRandam_Int(90, 360), f22_local4, false, f22_local5)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347010_Act30(f23_arg0, f23_arg1, f23_arg2)
    local f23_local0 = f23_arg0:GetRandam_Int(1, 3)
    local f23_local1 = TARGET_ENE_0
    local f23_local2 = f23_arg0:GetRandam_Int(0, 1)
    local f23_local3 = f23_arg0:GetRandam_Int(90, 360)
    local f23_local4 = 2
    local f23_local5 = TARGET_SELF
    local f23_local6 = true
    local f23_local7 = true
    local f23_local8 = f23_arg0:GetDist(TARGET_ENE_0)
    local f23_local9 = 9910
    if f23_arg0:HasSpecialEffectId(TARGET_SELF, 15611) then
        f23_local9 = -1
    end
    f23_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, f23_local0, f23_local1, f23_local2, f23_local3, f23_local6, -1, f23_local7, f23_local9)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347010_Act31(f24_arg0, f24_arg1, f24_arg2)
    local f24_local0 = 10
    local f24_local1 = TARGET_ENE_0
    local f24_local2 = 7
    local f24_local3 = TARGET_ENE_0
    local f24_local4 = true
    local f24_local5 = f24_arg0:GetDist(TARGET_ENE_0)
    local f24_local6 = 0
    local f24_local7 = f24_arg0:GetRandam_Int(1, 100)
    local f24_local8 = 9910
    if f24_arg0:HasSpecialEffectId(TARGET_SELF, 15611) then
        f24_local8 = -1
    end
    f24_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, f24_local0, f24_local1, f24_local2, f24_local3, f24_local4, f24_local8)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function FrogHuman_347010_ActAfter_AdjustSpace(f25_arg0, f25_arg1, f25_arg2)
    f25_arg1:AddSubGoal(GOAL_FrogHuman_347010_AfterAttackAct, 10)
    
end

Goal.Update = function (f26_arg0, f26_arg1, f26_arg2)
    return Update_Default_NoSubGoal(f26_arg0, f26_arg1, f26_arg2)
    
end

Goal.Terminate = function (f27_arg0, f27_arg1, f27_arg2)
    
end

Goal.Interrupt = function (f28_arg0, f28_arg1, f28_arg2)
    local f28_local0 = f28_arg1:GetDist(TARGET_ENE_0)
    local f28_local1 = f28_arg1:GetRandam_Int(1, 100)
    if f28_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) then
        if f28_arg1:HasSpecialEffectId(TARGET_SELF, 15607) == false then
            if f28_arg1:HasSpecialEffectId(TARGET_SELF, 5030) then
                local f28_local2 = f28_arg1:GetDist(TARGET_ENE_0)
                if f28_local2 <= 4.5 and f28_local1 <= 50 then
                    f28_arg2:ClearSubGoal()
                    f28_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3036, TARGET_ENE_0, 99, 0, 0, 0)
                end
                return true
            elseif f28_arg1:HasSpecialEffectId(TARGET_SELF, 5025) then
                local f28_local2 = f28_arg1:GetDist(TARGET_ENE_0)
                if f28_local2 <= 4.5 then
                    f28_arg2:ClearSubGoal()
                    f28_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3036, TARGET_ENE_0, 99, 0, 0, 0)
                end
                return true
            end
            if f28_arg1:HasSpecialEffectId(TARGET_SELF, 5031) then
                local f28_local2 = f28_arg1:GetDist(TARGET_ENE_0)
                if f28_local2 <= 4.5 and f28_local1 <= 50 then
                    f28_arg2:ClearSubGoal()
                    f28_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3037, TARGET_ENE_0, 99, 0, 0, 0)
                end
                return true
            elseif f28_arg1:HasSpecialEffectId(TARGET_SELF, 5026) then
                local f28_local2 = f28_arg1:GetDist(TARGET_ENE_0)
                if f28_local2 <= 4.5 then
                    f28_arg2:ClearSubGoal()
                    f28_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3037, TARGET_ENE_0, 99, 0, 0, 0)
                end
                return true
            end
            return false
        end
        if f28_arg1:HasSpecialEffectId(TARGET_SELF, 5027) then
            local f28_local2 = f28_arg1:GetDist(TARGET_ENE_0)
            if f28_local2 <= 3 or f28_local1 <= 50 then
                f28_arg2:ClearSubGoal()
                f28_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3022, TARGET_ENE_0, 5, 0, 0, 0)
            end
            return true
        end
        return false
    end
    
end

RegisterTableGoal(GOAL_FrogHuman_347010_AfterAttackAct, "GOAL_FrogHuman_347010_AfterAttackAct")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_FrogHuman_347010_AfterAttackAct, true)

Goal.Activate = function (f29_arg0, f29_arg1, f29_arg2)
    
end

Goal.Update = function (f30_arg0, f30_arg1, f30_arg2)
    return Update_Default_NoSubGoal(f30_arg0, f30_arg1, f30_arg2)
    
end


