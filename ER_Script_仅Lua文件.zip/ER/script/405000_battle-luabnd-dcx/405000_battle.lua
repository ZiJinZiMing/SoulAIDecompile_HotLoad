﻿RegisterTableGoal(GOAL_WarKingWarrior405000_Battle, "WarKingWarrior405000_Battle")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_WarKingWarrior405000_Battle, true)

Goal.Initialize = function (f1_arg0, f1_arg1, f1_arg2, f1_arg3)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3000)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3001)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3002)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3003)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3004)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3005)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3006)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3007)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3008)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3009)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3010)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3011)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3012)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3013)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3014)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3015)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3016)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3020)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3021)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3022)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3023)
    f1_arg1:EnableUnfavorableAttackCheck(3000000, 3000)
    f1_arg1:EnableUnfavorableAttackCheck(3000000, 3001)
    f1_arg1:EnableUnfavorableAttackCheck(3000000, 3002)
    f1_arg1:EnableUnfavorableAttackCheck(3000000, 3003)
    f1_arg1:EnableUnfavorableAttackCheck(3000000, 3004)
    f1_arg1:EnableUnfavorableAttackCheck(3000000, 3005)
    f1_arg1:EnableUnfavorableAttackCheck(3000000, 3006)
    f1_arg1:EnableUnfavorableAttackCheck(3000000, 3007)
    f1_arg1:EnableUnfavorableAttackCheck(3000000, 3008)
    f1_arg1:EnableUnfavorableAttackCheck(3000000, 3009)
    f1_arg1:EnableUnfavorableAttackCheck(3000000, 3010)
    f1_arg1:EnableUnfavorableAttackCheck(3000000, 3011)
    f1_arg1:EnableUnfavorableAttackCheck(3000000, 3015)
    
end

Goal.Activate = function (f2_arg0, f2_arg1, f2_arg2)
    local f2_local0 = {}
    local f2_local1 = {}
    local f2_local2 = {}
    Common_Clear_Param(f2_local0, f2_local1, f2_local2)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5028)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5029)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5034)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5035)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5036)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5038)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_ENE_0, 79)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_ENE_0, 90)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_ENE_0, 6992)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 5037)
    local f2_local3 = f2_arg1:GetDist(TARGET_ENE_0)
    local f2_local4 = f2_arg1:GetRandam_Int(1, 100)
    local f2_local5 = f2_arg1:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__thinkAttr_doAdmirer)
    local f2_local6 = 0
    local f2_local7 = 1
    if f2_arg1:GetHpRate(TARGET_SELF) <= 0.6 and f2_arg1:HasSpecialEffectId(TARGET_SELF, 12800) == false or f2_arg1:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_BUDDY_DECLARE) == true then
        f2_local6 = 1000
    end
    if f2_arg1:HasSpecialEffectId(TARGET_SELF, 12820) == true then
        f2_local7 = 100
    end
    if f2_local5 == 1 and f2_arg1:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Kankyaku and f2_arg1:IsRiding(TARGET_SELF) == false and f2_arg1:IsRiding(TARGET_ENE_0) == false and f2_arg1:HasSpecialEffectId(TARGET_SELF, 12800) == false then
        if f2_local3 >= 6 then
            f2_local0[18] = 100
        else
            f2_local0[14] = 100
        end
    elseif f2_local5 == 1 and f2_arg1:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Torimaki and f2_arg1:IsRiding(TARGET_SELF) == false and f2_arg1:IsRiding(TARGET_ENE_0) == false and f2_arg1:HasSpecialEffectId(TARGET_SELF, 12800) == false then
        if f2_local3 >= 6 then
            f2_local0[18] = 100
        else
            f2_local0[2] = 10
            f2_local0[6] = 10
            f2_local0[9] = 10
            f2_local0[14] = 70
        end
    elseif f2_arg1:IsRiding(TARGET_SELF) == true then
        if f2_local3 >= 13 then
            if InsideRange(f2_arg1, f2_arg2, 180, 150, -1, 99) then
                f2_local0[17] = 100
            else
                f2_local0[24] = 1
                f2_local0[25] = 1
                f2_local0[26] = 1
                f2_local0[29] = 1
                f2_local0[30] = 1
                f2_local0[32] = 95
            end
        elseif f2_local3 >= 8 then
            if InsideRange(f2_arg1, f2_arg2, 180, 90, -1, 99) then
                f2_local0[17] = 30
                f2_local0[35] = 70
            elseif InsideRange(f2_arg1, f2_arg2, 0, 120, -1, 99) then
                f2_local0[24] = 5
                f2_local0[25] = 5
                f2_local0[26] = 20
                f2_local0[29] = 20
                f2_local0[30] = 50
            elseif InsideRange(f2_arg1, f2_arg2, 90, 120, -1, 99) then
                f2_local0[25] = 20
                f2_local0[29] = 80
            else
                f2_local0[24] = 20
                f2_local0[29] = 80
            end
        elseif f2_local3 >= 5 then
            if InsideRange(f2_arg1, f2_arg2, 180, 90, -1, 99) then
                f2_local0[17] = 100
            elseif InsideRange(f2_arg1, f2_arg2, 0, 120, -1, 99) then
                f2_local0[24] = 10
                f2_local0[25] = 10
                f2_local0[26] = 50
                f2_local0[30] = 30
            elseif InsideRange(f2_arg1, f2_arg2, 90, 120, -1, 99) then
                f2_local0[25] = 100
            else
                f2_local0[24] = 100
            end
        elseif f2_local3 >= 1.5 then
            if InsideRange(f2_arg1, f2_arg2, 0, 120, -1, 99) then
                f2_local0[20] = 45
                f2_local0[21] = 45
                f2_local0[26] = 10
            elseif InsideRange(f2_arg1, f2_arg2, 90, 90, -1, 99) then
                f2_local0[21] = 90
                f2_local0[26] = 10
            elseif InsideRange(f2_arg1, f2_arg2, 270, 90, -1, 99) then
                f2_local0[20] = 100
            else
                f2_local0[35] = 100
            end
        elseif InsideRange(f2_arg1, f2_arg2, 180, 90, -1, 99) then
            f2_local0[22] = 5
            f2_local0[23] = 5
            f2_local0[31] = 90
        elseif InsideRange(f2_arg1, f2_arg2, 0, 90, -1, 99) then
            f2_local0[22] = 60
            f2_local0[23] = 40
        elseif InsideRange(f2_arg1, f2_arg2, 90, 90, -1, 99) then
            f2_local0[21] = 80
            f2_local0[22] = 10
            f2_local0[23] = 10
        else
            f2_local0[20] = 80
            f2_local0[23] = 20
        end
    elseif f2_arg1:IsRiding(TARGET_ENE_0) == true then
        if f2_local3 >= 6 then
            f2_local0[4] = 50
            f2_local0[7] = f2_local6
            f2_local0[10] = 50
            f2_local0[16] = 0
        elseif f2_local3 >= 3 then
            if InsideRange(f2_arg1, f2_arg2, 0, 120, 0, 99) then
                f2_local0[1] = 5
                f2_local0[3] = 15
                f2_local0[4] = 15
                f2_local0[5] = 50 * f2_local7
                f2_local0[7] = f2_local6
                f2_local0[10] = 15
            elseif InsideRange(f2_arg1, f2_arg2, 0, 270, 0, 99) then
                f2_local0[2] = 10
                f2_local0[4] = 15
                f2_local0[5] = 50 * f2_local7
                f2_local0[6] = 10
                f2_local0[7] = f2_local6
                f2_local0[10] = 15
            else
                f2_local0[2] = 50
                f2_local0[6] = 40
                f2_local0[17] = 10
            end
        elseif InsideRange(f2_arg1, f2_arg2, 0, 120, 0, 99) then
            f2_local0[1] = 10
            f2_local0[3] = 20
            f2_local0[5] = 60 * f2_local7
            f2_local0[7] = f2_local6
            f2_local0[8] = 20
        elseif InsideRange(f2_arg1, f2_arg2, 0, 270, 0, 99) then
            f2_local0[2] = 15
            f2_local0[5] = 60 * f2_local7
            f2_local0[6] = 15
            f2_local0[7] = f2_local6
            f2_local0[8] = 10
        else
            f2_local0[2] = 50
            f2_local0[6] = 40
            f2_local0[17] = 10
        end
    elseif f2_arg1:HasSpecialEffectId(TARGET_ENE_0, 79) == true then
        f2_local0[11] = 100
    elseif f2_local3 >= 6 then
        if f2_arg1:GetHpRate(TARGET_SELF) < 1 then
            f2_local0[3] = 40
            f2_local0[4] = 40
            f2_local0[7] = f2_local6
            f2_local0[10] = 20
        else
            f2_local0[4] = 60
            f2_local0[7] = f2_local6
            f2_local0[10] = 40
        end
    elseif f2_local3 >= 3 then
        if InsideRange(f2_arg1, f2_arg2, 0, 120, 0, 99) then
            f2_local0[1] = 30
            f2_local0[3] = 10
            f2_local0[5] = 50 * f2_local7
            f2_local0[7] = f2_local6
            f2_local0[9] = 10
        elseif InsideRange(f2_arg1, f2_arg2, 0, 270, 0, 99) then
            f2_local0[2] = 30
            f2_local0[5] = 20 * f2_local7
            f2_local0[6] = 20
            f2_local0[7] = f2_local6
            f2_local0[9] = 30
        else
            f2_local0[2] = 50
            f2_local0[6] = 40
            f2_local0[17] = 10
        end
    elseif InsideRange(f2_arg1, f2_arg2, 0, 120, 0, 99) then
        f2_local0[1] = 10
        f2_local0[2] = 10
        f2_local0[3] = 10
        f2_local0[5] = 20 * f2_local7
        f2_local0[6] = 20
        f2_local0[7] = f2_local6
        f2_local0[8] = 15
        f2_local0[9] = 15
    elseif InsideRange(f2_arg1, f2_arg2, 0, 270, 0, 99) then
        f2_local0[2] = 30
        f2_local0[5] = 10 * f2_local7
        f2_local0[6] = 20
        f2_local0[7] = f2_local6
        f2_local0[8] = 20
        f2_local0[9] = 20
    else
        f2_local0[2] = 50
        f2_local0[6] = 40
        f2_local0[17] = 10
    end
    f2_local0[1] = SetCoolTime(f2_arg1, f2_arg2, 3000, 5, f2_local0[1], 1)
    f2_local0[2] = SetCoolTime(f2_arg1, f2_arg2, 3002, 10, f2_local0[2], 1)
    f2_local0[3] = SetCoolTime(f2_arg1, f2_arg2, 3004, 5, f2_local0[3], 1)
    f2_local0[4] = SetCoolTime(f2_arg1, f2_arg2, 3005, 5, f2_local0[4], 1)
    if f2_arg1:HasSpecialEffectId(TARGET_SELF, 12820) == false then
        f2_local0[5] = SetCoolTime(f2_arg1, f2_arg2, 3006, 10, f2_local0[5], 1)
    end
    f2_local0[6] = SetCoolTime(f2_arg1, f2_arg2, 3008, 5, f2_local0[6], 1)
    f2_local0[7] = SetCoolTime(f2_arg1, f2_arg2, 3009, 25, f2_local0[7], 1)
    f2_local0[8] = SetCoolTime(f2_arg1, f2_arg2, 3012, 10, f2_local0[8], 1)
    f2_local0[9] = SetCoolTime(f2_arg1, f2_arg2, 3011, 10, f2_local0[9], 1)
    f2_local0[10] = SetCoolTime(f2_arg1, f2_arg2, 3014, 5, f2_local0[10], 1)
    f2_local0[10] = SetCoolTime(f2_arg1, f2_arg2, 3022, 5, f2_local0[10], 1)
    f2_local0[20] = SetCoolTime(f2_arg1, f2_arg2, 3000, 5, f2_local0[20], 1)
    f2_local0[21] = SetCoolTime(f2_arg1, f2_arg2, 3001, 5, f2_local0[21], 1)
    f2_local0[22] = SetCoolTime(f2_arg1, f2_arg2, 3002, 10, f2_local0[22], 1)
    f2_local0[23] = SetCoolTime(f2_arg1, f2_arg2, 3003, 10, f2_local0[23], 1)
    f2_local0[26] = SetCoolTime(f2_arg1, f2_arg2, 3006, 10, f2_local0[26], 1)
    f2_local0[31] = SetCoolTime(f2_arg1, f2_arg2, 3011, 5, f2_local0[31], 1)
    f2_local1[1] = REGIST_FUNC(f2_arg1, f2_arg2, WarKingWarrior405000_Act01)
    f2_local1[2] = REGIST_FUNC(f2_arg1, f2_arg2, WarKingWarrior405000_Act02)
    f2_local1[3] = REGIST_FUNC(f2_arg1, f2_arg2, WarKingWarrior405000_Act03)
    f2_local1[4] = REGIST_FUNC(f2_arg1, f2_arg2, WarKingWarrior405000_Act04)
    f2_local1[5] = REGIST_FUNC(f2_arg1, f2_arg2, WarKingWarrior405000_Act05)
    f2_local1[6] = REGIST_FUNC(f2_arg1, f2_arg2, WarKingWarrior405000_Act06)
    f2_local1[7] = REGIST_FUNC(f2_arg1, f2_arg2, WarKingWarrior405000_Act07)
    f2_local1[8] = REGIST_FUNC(f2_arg1, f2_arg2, WarKingWarrior405000_Act08)
    f2_local1[9] = REGIST_FUNC(f2_arg1, f2_arg2, WarKingWarrior405000_Act09)
    f2_local1[10] = REGIST_FUNC(f2_arg1, f2_arg2, WarKingWarrior405000_Act10)
    f2_local1[11] = REGIST_FUNC(f2_arg1, f2_arg2, WarKingWarrior405000_Act11)
    f2_local1[14] = REGIST_FUNC(f2_arg1, f2_arg2, WarKingWarrior405000_Act14)
    f2_local1[15] = REGIST_FUNC(f2_arg1, f2_arg2, WarKingWarrior405000_Act15)
    f2_local1[16] = REGIST_FUNC(f2_arg1, f2_arg2, WarKingWarrior405000_Act16)
    f2_local1[17] = REGIST_FUNC(f2_arg1, f2_arg2, WarKingWarrior405000_Act17)
    f2_local1[18] = REGIST_FUNC(f2_arg1, f2_arg2, WarKingWarrior405000_Act18)
    f2_local1[19] = REGIST_FUNC(f2_arg1, f2_arg2, WarKingWarrior405000_Act19)
    f2_local1[20] = REGIST_FUNC(f2_arg1, f2_arg2, WarKingWarrior405000_Act20)
    f2_local1[21] = REGIST_FUNC(f2_arg1, f2_arg2, WarKingWarrior405000_Act21)
    f2_local1[22] = REGIST_FUNC(f2_arg1, f2_arg2, WarKingWarrior405000_Act22)
    f2_local1[23] = REGIST_FUNC(f2_arg1, f2_arg2, WarKingWarrior405000_Act23)
    f2_local1[24] = REGIST_FUNC(f2_arg1, f2_arg2, WarKingWarrior405000_Act24)
    f2_local1[25] = REGIST_FUNC(f2_arg1, f2_arg2, WarKingWarrior405000_Act25)
    f2_local1[26] = REGIST_FUNC(f2_arg1, f2_arg2, WarKingWarrior405000_Act26)
    f2_local1[29] = REGIST_FUNC(f2_arg1, f2_arg2, WarKingWarrior405000_Act29)
    f2_local1[30] = REGIST_FUNC(f2_arg1, f2_arg2, WarKingWarrior405000_Act30)
    f2_local1[31] = REGIST_FUNC(f2_arg1, f2_arg2, WarKingWarrior405000_Act31)
    f2_local1[32] = REGIST_FUNC(f2_arg1, f2_arg2, WarKingWarrior405000_Act32)
    f2_local1[33] = REGIST_FUNC(f2_arg1, f2_arg2, WarKingWarrior405000_Act33)
    f2_local1[34] = REGIST_FUNC(f2_arg1, f2_arg2, WarKingWarrior405000_Act34)
    f2_local1[35] = REGIST_FUNC(f2_arg1, f2_arg2, WarKingWarrior405000_Act35)
    f2_local1[36] = REGIST_FUNC(f2_arg1, f2_arg2, WarKingWarrior405000_Act36)
    f2_local1[50] = REGIST_FUNC(f2_arg1, f2_arg2, WarKingWarrior405000_Act50)
    local f2_local8 = REGIST_FUNC(f2_arg1, f2_arg2, WarKingWarrior405000_ActAfter_AdjustSpace)
    Common_Battle_Activate(f2_arg1, f2_arg2, f2_local0, f2_local1, f2_local8, f2_local2)
    
end

function WarKingWarrior405000_Act01(f3_arg0, f3_arg1, f3_arg2)
    local f3_local0 = 4 - f3_arg0:GetMapHitRadius(TARGET_SELF)
    local f3_local1 = f3_local0 + 0
    local f3_local2 = f3_local0 + 0
    local f3_local3 = 100
    local f3_local4 = 0
    local f3_local5 = 2
    local f3_local6 = 4
    Approach_Act_Flex(f3_arg0, f3_arg1, f3_local0, f3_local1, f3_local2, f3_local3, f3_local4, f3_local5, f3_local6)
    local f3_local7 = 3000
    local f3_local8 = 5 - f3_arg0:GetMapHitRadius(TARGET_SELF)
    local f3_local9 = 0
    local f3_local10 = 0
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5029)
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f3_local7, TARGET_ENE_0, f3_local8, f3_local9, f3_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function WarKingWarrior405000_Act02(f4_arg0, f4_arg1, f4_arg2)
    local f4_local0 = 5 - f4_arg0:GetMapHitRadius(TARGET_SELF)
    local f4_local1 = f4_local0 + 0
    local f4_local2 = f4_local0 + 0
    local f4_local3 = 100
    local f4_local4 = 0
    local f4_local5 = 2
    local f4_local6 = 4
    Approach_Act_Flex(f4_arg0, f4_arg1, f4_local0, f4_local1, f4_local2, f4_local3, f4_local4, f4_local5, f4_local6)
    local f4_local7 = 3002
    local f4_local8 = 3003
    local f4_local9 = 5 - f4_arg0:GetMapHitRadius(TARGET_SELF)
    local f4_local10 = 0
    local f4_local11 = 0
    local f4_local12 = f4_arg0:GetRandam_Int(1, 100)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5035)
    f4_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f4_local7, TARGET_ENE_0, f4_local9, f4_local10, f4_local11, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function WarKingWarrior405000_Act03(f5_arg0, f5_arg1, f5_arg2)
    local f5_local0 = 4 - f5_arg0:GetMapHitRadius(TARGET_SELF)
    local f5_local1 = f5_local0 + 0
    local f5_local2 = f5_local0 + 0
    local f5_local3 = 100
    local f5_local4 = 0
    local f5_local5 = 2
    local f5_local6 = 4
    Approach_Act_Flex(f5_arg0, f5_arg1, f5_local0, f5_local1, f5_local2, f5_local3, f5_local4, f5_local5, f5_local6)
    local f5_local7 = 3004
    local f5_local8 = 5 - f5_arg0:GetMapHitRadius(TARGET_SELF)
    local f5_local9 = 0
    local f5_local10 = 0
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f5_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f5_local7, TARGET_ENE_0, f5_local8, f5_local9, f5_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function WarKingWarrior405000_Act04(f6_arg0, f6_arg1, f6_arg2)
    local f6_local0 = 8.7 - f6_arg0:GetMapHitRadius(TARGET_SELF)
    local f6_local1 = f6_local0 + 0
    local f6_local2 = f6_local0 + 0
    local f6_local3 = 100
    local f6_local4 = 0
    local f6_local5 = 2
    local f6_local6 = 4
    Approach_Act_Flex(f6_arg0, f6_arg1, f6_local0, f6_local1, f6_local2, f6_local3, f6_local4, f6_local5, f6_local6)
    local f6_local7 = 3005
    local f6_local8 = 3010
    local f6_local9 = 5 - f6_arg0:GetMapHitRadius(TARGET_SELF)
    local f6_local10 = 0
    local f6_local11 = 0
    f6_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    f6_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f6_local7, TARGET_ENE_0, f6_local9, f6_local10, f6_local11, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function WarKingWarrior405000_Act05(f7_arg0, f7_arg1, f7_arg2)
    local f7_local0 = 5.5 - f7_arg0:GetMapHitRadius(TARGET_SELF)
    local f7_local1 = f7_local0 + 0
    local f7_local2 = f7_local0 + 0
    local f7_local3 = 100
    local f7_local4 = 0
    local f7_local5 = 2
    local f7_local6 = 4
    Approach_Act_Flex(f7_arg0, f7_arg1, f7_local0, f7_local1, f7_local2, f7_local3, f7_local4, f7_local5, f7_local6)
    local f7_local7 = 3006
    local f7_local8 = 3007
    local f7_local9 = 5 - f7_arg0:GetMapHitRadius(TARGET_SELF) + 5
    local f7_local10 = 0
    local f7_local11 = 0
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5028)
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f7_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f7_local7, TARGET_ENE_0, f7_local9, f7_local10, f7_local11, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function WarKingWarrior405000_Act06(f8_arg0, f8_arg1, f8_arg2)
    local f8_local0 = 4.5 - f8_arg0:GetMapHitRadius(TARGET_SELF)
    local f8_local1 = f8_local0 + 0
    local f8_local2 = f8_local0 + 0
    local f8_local3 = 100
    local f8_local4 = 0
    local f8_local5 = 2
    local f8_local6 = 4
    Approach_Act_Flex(f8_arg0, f8_arg1, f8_local0, f8_local1, f8_local2, f8_local3, f8_local4, f8_local5, f8_local6)
    local f8_local7 = 3008
    local f8_local8 = 5 - f8_arg0:GetMapHitRadius(TARGET_SELF)
    local f8_local9 = 0
    local f8_local10 = 0
    f8_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f8_local7, TARGET_ENE_0, f8_local8, f8_local9, f8_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function WarKingWarrior405000_Act07(f9_arg0, f9_arg1, f9_arg2)
    local f9_local0 = 3009
    local f9_local1 = 5 - f9_arg0:GetMapHitRadius(TARGET_SELF)
    local f9_local2 = 0
    local f9_local3 = 0
    f9_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f9_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f9_local0, TARGET_ENE_0, f9_local1, f9_local2, f9_local3, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function WarKingWarrior405000_Act08(f10_arg0, f10_arg1, f10_arg2)
    local f10_local0 = 3012
    local f10_local1 = 5 - f10_arg0:GetMapHitRadius(TARGET_SELF) + 20
    local f10_local2 = 0
    local f10_local3 = 0
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5038)
    f10_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f10_local0, TARGET_ENE_0, f10_local1, f10_local2, f10_local3, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function WarKingWarrior405000_Act09(f11_arg0, f11_arg1, f11_arg2)
    local f11_local0 = 5 - f11_arg0:GetMapHitRadius(TARGET_SELF)
    local f11_local1 = f11_local0 + 0
    local f11_local2 = f11_local0 + 0
    local f11_local3 = 100
    local f11_local4 = 0
    local f11_local5 = 2
    local f11_local6 = 4
    Approach_Act_Flex(f11_arg0, f11_arg1, f11_local0, f11_local1, f11_local2, f11_local3, f11_local4, f11_local5, f11_local6)
    local f11_local7 = 3011
    local f11_local8 = 3007
    local f11_local9 = 5 - f11_arg0:GetMapHitRadius(TARGET_SELF) + 20
    local f11_local10 = 0
    local f11_local11 = 0
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5028)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f11_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f11_local7, TARGET_ENE_0, f11_local9, f11_local10, f11_local11, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function WarKingWarrior405000_Act10(f12_arg0, f12_arg1, f12_arg2)
    local f12_local0 = 9 - f12_arg0:GetMapHitRadius(TARGET_SELF)
    local f12_local1 = f12_local0 + 0
    local f12_local2 = f12_local0 + 0
    local f12_local3 = 100
    local f12_local4 = 0
    local f12_local5 = 2
    local f12_local6 = 4
    Approach_Act_Flex(f12_arg0, f12_arg1, f12_local0, f12_local1, f12_local2, f12_local3, f12_local4, f12_local5, f12_local6)
    local f12_local7 = 3014
    local f12_local8 = 5 - f12_arg0:GetMapHitRadius(TARGET_SELF)
    local f12_local9 = 0
    local f12_local10 = 0
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    if f12_arg0:HasSpecialEffectId(TARGET_SELF, 12800) then
        f12_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3022, TARGET_ENE_0, f12_local8, f12_local9, f12_local10, 0, 0)
    else
        f12_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f12_local7, TARGET_ENE_0, f12_local8, f12_local9, f12_local10, 0, 0)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function WarKingWarrior405000_Act11(f13_arg0, f13_arg1, f13_arg2)
    local f13_local0 = 1.2 - f13_arg0:GetMapHitRadius(TARGET_SELF)
    local f13_local1 = f13_local0 + 0
    local f13_local2 = f13_local0 + 0
    local f13_local3 = 100
    local f13_local4 = 0
    local f13_local5 = 0.1
    local f13_local6 = 0.1
    Approach_Act_Flex(f13_arg0, f13_arg1, f13_local0, f13_local1, f13_local2, f13_local3, f13_local4, f13_local5, f13_local6)
    local f13_local7 = 3110
    local f13_local8 = 5 - f13_arg0:GetMapHitRadius(TARGET_SELF)
    local f13_local9 = 0
    local f13_local10 = 0
    f13_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 0.5, f13_local7, TARGET_ENE_0, f13_local8, f13_local9, f13_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function WarKingWarrior405000_Act14(f14_arg0, f14_arg1, f14_arg2)
    local f14_local0 = 0
    local f14_local1 = f14_arg0:GetRandam_Int(1, 100)
    local f14_local2 = -1
    if f14_local1 <= f14_local0 then
        f14_local2 = 9910
    end
    f14_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, f14_arg0:GetRandam_Float(2, 3), TARGET_ENE_0, f14_arg0:GetRandam_Int(0, 1), f14_arg0:GetRandam_Int(30, 45), true, true, f14_local2)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function WarKingWarrior405000_Act15(f15_arg0, f15_arg1, f15_arg2)
    local f15_local0 = f15_arg0:GetDist(TARGET_ENE_0)
    local f15_local1 = 10
    local f15_local2 = 12
    local f15_local3 = 80
    local f15_local4 = f15_arg0:GetRandam_Int(1, 100)
    local f15_local5 = -1
    if f15_local4 <= f15_local3 then
        f15_local5 = 9910
    end
    if f15_local1 <= f15_local0 then
        Approach_Act(f15_arg0, f15_arg1, f15_local1, f15_local2, f15_local3, 3)
    end
    f15_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 2, TARGET_ENE_0, f15_local1, TARGET_ENE_0, true, f15_local5)
    
end

function WarKingWarrior405000_Act16(f16_arg0, f16_arg1, f16_arg2)
    local f16_local0 = 100
    local f16_local1 = f16_arg0:GetRandam_Int(1, 100)
    local f16_local2 = -1
    if f16_local1 <= f16_local0 then
        f16_local2 = 9910
    end
    f16_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, f16_arg0:GetRandam_Float(2, 3), TARGET_ENE_0, f16_arg0:GetRandam_Int(0, 1), f16_arg0:GetRandam_Int(30, 45), true, true, f16_local2)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function WarKingWarrior405000_Act17(f17_arg0, f17_arg1, f17_arg2)
    f17_arg1:AddSubGoal(GOAL_COMMON_Turn, 2, TARGET_ENE_0, 45, -1, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function WarKingWarrior405000_Act18(f18_arg0, f18_arg1, f18_arg2)
    local f18_local0 = f18_arg0:GetDist(TARGET_ENE_0)
    local f18_local1 = f18_arg0:GetRandam_Float(2, 4)
    local f18_local2 = f18_arg0:GetRandam_Float(4, 5.5)
    local f18_local3 = -1
    f18_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, f18_local1, TARGET_ENE_0, f18_local2, TARGET_SELF, true, f18_local3)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function WarKingWarrior405000_Act20(f19_arg0, f19_arg1, f19_arg2)
    local f19_local0 = 6 - f19_arg0:GetMapHitRadius(TARGET_SELF)
    local f19_local1 = f19_local0 + 0
    local f19_local2 = f19_local0 + 0
    local f19_local3 = 0
    local f19_local4 = 0
    local f19_local5 = 2
    local f19_local6 = 4
    Approach_Act_Flex(f19_arg0, f19_arg1, f19_local0, f19_local1, f19_local2, f19_local3, f19_local4, f19_local5, f19_local6)
    local f19_local7 = 3000
    local f19_local8 = 5 - f19_arg0:GetMapHitRadius(TARGET_SELF)
    local f19_local9 = 0
    local f19_local10 = 0
    f19_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f19_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f19_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5034)
    f19_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 5, f19_local7, TARGET_ENE_0, f19_local8, f19_local9, f19_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function WarKingWarrior405000_Act21(f20_arg0, f20_arg1, f20_arg2)
    local f20_local0 = 5.5 - f20_arg0:GetMapHitRadius(TARGET_SELF)
    local f20_local1 = f20_local0 + 0
    local f20_local2 = f20_local0 + 0
    local f20_local3 = 100
    local f20_local4 = 0
    local f20_local5 = 2
    local f20_local6 = 4
    Approach_Act_Flex(f20_arg0, f20_arg1, f20_local0, f20_local1, f20_local2, f20_local3, f20_local4, f20_local5, f20_local6)
    local f20_local7 = 3001
    local f20_local8 = 5 - f20_arg0:GetMapHitRadius(TARGET_SELF)
    local f20_local9 = 0
    local f20_local10 = 0
    f20_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f20_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f20_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5034)
    f20_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 5, f20_local7, TARGET_ENE_0, f20_local8, f20_local9, f20_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function WarKingWarrior405000_Act22(f21_arg0, f21_arg1, f21_arg2)
    local f21_local0 = 3002
    local f21_local1 = 5 - f21_arg0:GetMapHitRadius(TARGET_SELF) + 0.5
    local f21_local2 = 0
    local f21_local3 = 0
    f21_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f21_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f21_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5034)
    f21_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 5, f21_local0, TARGET_ENE_0, f21_local1, f21_local2, f21_local3, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function WarKingWarrior405000_Act23(f22_arg0, f22_arg1, f22_arg2)
    local f22_local0 = 3003
    local f22_local1 = 5 - f22_arg0:GetMapHitRadius(TARGET_SELF) + 2
    local f22_local2 = 0
    local f22_local3 = 0
    f22_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f22_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5034)
    f22_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 5, f22_local0, TARGET_ENE_0, f22_local1, f22_local2, f22_local3, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function WarKingWarrior405000_Act24(f23_arg0, f23_arg1, f23_arg2)
    local f23_local0 = 7 - f23_arg0:GetMapHitRadius(TARGET_SELF)
    local f23_local1 = f23_local0 + 0
    local f23_local2 = f23_local0 + 0
    local f23_local3 = 100
    local f23_local4 = 0
    local f23_local5 = 1
    local f23_local6 = 2
    Approach_Act_Flex(f23_arg0, f23_arg1, f23_local0, f23_local1, f23_local2, f23_local3, f23_local4, f23_local5, f23_local6)
    local f23_local7 = 3004
    local f23_local8 = 5 - f23_arg0:GetMapHitRadius(TARGET_SELF) + 2
    local f23_local9 = 0
    local f23_local10 = 0
    f23_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f23_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 2, f23_local7, TARGET_ENE_0, f23_local8, f23_local9, f23_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function WarKingWarrior405000_Act25(f24_arg0, f24_arg1, f24_arg2)
    local f24_local0 = 6.5 - f24_arg0:GetMapHitRadius(TARGET_SELF)
    local f24_local1 = f24_local0 + 0
    local f24_local2 = f24_local0 + 0
    local f24_local3 = 100
    local f24_local4 = 0
    local f24_local5 = 1
    local f24_local6 = 2
    Approach_Act_Flex(f24_arg0, f24_arg1, f24_local0, f24_local1, f24_local2, f24_local3, f24_local4, f24_local5, f24_local6)
    local f24_local7 = 3005
    local f24_local8 = 5 - f24_arg0:GetMapHitRadius(TARGET_SELF) + 2
    local f24_local9 = 0
    local f24_local10 = 0
    f24_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f24_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 2, f24_local7, TARGET_ENE_0, f24_local8, f24_local9, f24_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function WarKingWarrior405000_Act26(f25_arg0, f25_arg1, f25_arg2)
    local f25_local0 = 7.5 - f25_arg0:GetMapHitRadius(TARGET_SELF)
    local f25_local1 = f25_local0 + 0
    local f25_local2 = f25_local0 + 0
    local f25_local3 = 100
    local f25_local4 = 0
    local f25_local5 = 2
    local f25_local6 = 4
    Approach_Act_Flex(f25_arg0, f25_arg1, f25_local0, f25_local1, f25_local2, f25_local3, f25_local4, f25_local5, f25_local6)
    local f25_local7 = 3006
    local f25_local8 = 5 - f25_arg0:GetMapHitRadius(TARGET_SELF)
    local f25_local9 = 0
    local f25_local10 = 0
    f25_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f25_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 5, f25_local7, TARGET_ENE_0, f25_local8, f25_local9, f25_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function WarKingWarrior405000_Act27(f26_arg0, f26_arg1, f26_arg2)
    local f26_local0 = ATT3003007_DIST_MAX
    local f26_local1 = f26_local0 + 0
    local f26_local2 = f26_local0 + 0
    local f26_local3 = 100
    local f26_local4 = 0
    local f26_local5 = 2
    local f26_local6 = 4
    Approach_Act_Flex(f26_arg0, f26_arg1, f26_local0, f26_local1, f26_local2, f26_local3, f26_local4, f26_local5, f26_local6)
    local f26_local7 = 3007
    local f26_local8 = 5 - f26_arg0:GetMapHitRadius(TARGET_SELF) + 2
    local f26_local9 = 0
    local f26_local10 = 0
    f26_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f26_local7, TARGET_ENE_0, f26_local8, f26_local9, f26_local10, 0, 0)
    f26_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 5, 3012, TARGET_ENE_0, DIST_None, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function WarKingWarrior405000_Act28(f27_arg0, f27_arg1, f27_arg2)
    local f27_local0 = ATT3003008_DIST_MAX
    local f27_local1 = f27_local0 + 0
    local f27_local2 = f27_local0 + 0
    local f27_local3 = 100
    local f27_local4 = 0
    local f27_local5 = 2
    local f27_local6 = 4
    Approach_Act_Flex(f27_arg0, f27_arg1, f27_local0, f27_local1, f27_local2, f27_local3, f27_local4, f27_local5, f27_local6)
    local f27_local7 = 3008
    local f27_local8 = 5 - f27_arg0:GetMapHitRadius(TARGET_SELF) + 2
    local f27_local9 = 0
    local f27_local10 = 0
    f27_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f27_local7, TARGET_ENE_0, f27_local8, f27_local9, f27_local10, 0, 0)
    f27_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 5, 3012, TARGET_ENE_0, DIST_None, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function WarKingWarrior405000_Act29(f28_arg0, f28_arg1, f28_arg2)
    local f28_local0 = 12 - f28_arg0:GetMapHitRadius(TARGET_SELF)
    local f28_local1 = f28_local0 + 0
    local f28_local2 = f28_local0 + 0
    local f28_local3 = 100
    local f28_local4 = 0
    local f28_local5 = 2
    local f28_local6 = 4
    Approach_Act_Flex(f28_arg0, f28_arg1, f28_local0, f28_local1, f28_local2, f28_local3, f28_local4, f28_local5, f28_local6)
    local f28_local7 = 3009
    local f28_local8 = 5 - f28_arg0:GetMapHitRadius(TARGET_SELF) + 2
    local f28_local9 = 0
    local f28_local10 = 0
    f28_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f28_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f28_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5034)
    f28_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 5, f28_local7, TARGET_ENE_0, f28_local8, f28_local9, f28_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function WarKingWarrior405000_Act30(f29_arg0, f29_arg1, f29_arg2)
    local f29_local0 = 9 - f29_arg0:GetMapHitRadius(TARGET_SELF)
    local f29_local1 = f29_local0 + 0
    local f29_local2 = f29_local0 + 0
    local f29_local3 = 100
    local f29_local4 = 0
    local f29_local5 = 2
    local f29_local6 = 4
    Approach_Act_Flex(f29_arg0, f29_arg1, f29_local0, f29_local1, f29_local2, f29_local3, f29_local4, f29_local5, f29_local6)
    local f29_local7 = 3010
    local f29_local8 = 5 - f29_arg0:GetMapHitRadius(TARGET_SELF) + 2
    local f29_local9 = 0
    local f29_local10 = 0
    f29_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f29_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f29_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5034)
    f29_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 5, f29_local7, TARGET_ENE_0, f29_local8, f29_local9, f29_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function WarKingWarrior405000_Act31(f30_arg0, f30_arg1, f30_arg2)
    local f30_local0 = 3011
    local f30_local1 = 5 - f30_arg0:GetMapHitRadius(TARGET_SELF) + 2
    local f30_local2 = 0
    local f30_local3 = 0
    f30_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f30_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f30_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 5, f30_local0, TARGET_ENE_0, f30_local1, f30_local2, f30_local3, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function WarKingWarrior405000_Act32(f31_arg0, f31_arg1, f31_arg2)
    local f31_local0 = 14 - f31_arg0:GetMapHitRadius(TARGET_SELF)
    local f31_local1 = f31_local0 + 0
    local f31_local2 = f31_local0 + 0
    local f31_local3 = 100
    local f31_local4 = 0
    local f31_local5 = 2
    local f31_local6 = 4
    Approach_Act_Flex(f31_arg0, f31_arg1, f31_local0, f31_local1, f31_local2, f31_local3, f31_local4, f31_local5, f31_local6)
    local f31_local7 = 3015
    local f31_local8 = 5 - f31_arg0:GetMapHitRadius(TARGET_SELF) + 2
    local f31_local9 = 0
    local f31_local10 = 0
    f31_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f31_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f31_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f31_local7, TARGET_ENE_0, f31_local8, f31_local9, f31_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function WarKingWarrior405000_Act33(f32_arg0, f32_arg1, f32_arg2)
    f32_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 5, TARGET_ENE_0, 10, TARGET_SELF, false, -1)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function WarKingWarrior405000_Act34(f33_arg0, f33_arg1, f33_arg2)
    f33_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 5, TARGET_ENE_0, 15, TARGET_SELF, false, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function WarKingWarrior405000_Act35(f34_arg0, f34_arg1, f34_arg2)
    f34_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3012, TARGET_ENE_0, DIST_None, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function WarKingWarrior405000_Act36(f35_arg0, f35_arg1, f35_arg2)
    if InsideRange(f35_arg0, f35_arg1, 0, 360, 10, 99) then
        f35_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 5, TARGET_ENE_0, 10, TARGET_SELF, false, -1)
    elseif InsideRange(f35_arg0, f35_arg1, 180, 130, 4, 10) then
        f35_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, 2, TARGET_SELF, 1, TARGET_SELF, false, -1, AI_DIR_TYPE_ToF, 2)
    elseif InsideRange(f35_arg0, f35_arg1, 180, 130, 0, 3) then
        f35_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 2, 3011, TARGET_ENE_0, 7, 0, 0, 0, 0)
    elseif InsideRange(f35_arg0, f35_arg1, 0, 130, 3, 99) then
        f35_arg1:AddSubGoal(GOAL_COMMON_Attack, 1, 3012, TARGET_ENE_0, 1)
    elseif InsideRange(f35_arg0, f35_arg1, 0, 160, 0, 99) then
        f35_arg1:AddSubGoal(GOAL_COMMON_Attack, 1, 3015, TARGET_ENE_0, 1)
    elseif InsideRange(f35_arg0, f35_arg1, 0, 240, 0, 99) and f35_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_L, 180) then
        f35_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, 2, TARGET_ENE_0, 1, TARGET_SELF, false, -1, AI_DIR_TYPE_ToR, 2)
    elseif InsideRange(f35_arg0, f35_arg1, 0, 240, 0, 99) and f35_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_R, 180) then
        f35_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, 2, TARGET_ENE_0, 1, TARGET_SELF, false, -1, AI_DIR_TYPE_ToL, 2)
    end
    
end

function WarKingWarrior405000_Act50(f36_arg0, f36_arg1, f36_arg2)
    if f36_arg0:IsRiding(TARGET_SELF) == false then
        if f36_arg0:ReserveRide(100) == true then
            f36_arg1:AddSubGoal(GOAL_COMMON_Mount, 0.1, 1.2)
        end
    else
        local f36_local0 = 3003
        local f36_local1 = 5 - f36_arg0:GetMapHitRadius(TARGET_SELF) + 2
        local f36_local2 = 0
        local f36_local3 = 0
        f36_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
        f36_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5034)
        f36_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 5, f36_local0, TARGET_ENE_0, f36_local1, f36_local2, f36_local3, 0, 0)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function WarKingWarrior405000_ActAfter_AdjustSpace(f37_arg0, f37_arg1, f37_arg2)
    f37_arg1:AddSubGoal(GOAL_WarKingWarrior405000_AfterAttackAct, 10)
    
end

Goal.Update = function (f38_arg0, f38_arg1, f38_arg2)
    return Update_Default_NoSubGoal(f38_arg0, f38_arg1, f38_arg2)
    
end

Goal.Terminate = function (f39_arg0, f39_arg1, f39_arg2)
    
end

Goal.Interrupt = function (f40_arg0, f40_arg1, f40_arg2)
    local f40_local0 = f40_arg1:GetDist(TARGET_ENE_0)
    local f40_local1 = 5 - f40_arg1:GetMapHitRadius(TARGET_SELF)
    local f40_local2 = f40_arg1:GetRandam_Int(1, 100)
    local f40_local3 = f40_arg1:GetHpRate(TARGET_SELF)
    if f40_arg1:HasSpecialEffectId(TARGET_SELF, 5110) == true or f40_arg1:HasSpecialEffectAttribute(TARGET_SELF, SP_EFFECT_TYPE_SLEEP) == true then
        return false
    end
    if f40_arg1:IsRiding(TARGET_SELF) == true then
        if f40_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f40_arg1:GetSpecialEffectActivateInterruptId(79) then
            f40_arg2:ClearSubGoal()
            if InsideRange(f40_arg1, f40_arg2, 180, 170, -1, 99) then
                if f40_local2 >= 70 then
                    f40_arg2:AddSubGoal(GOAL_COMMON_LeaveTarget, 5, TARGET_ENE_0, 9, TARGET_SELF, false, 0)
                    f40_arg2:AddSubGoal(GOAL_COMMON_Turn, 2, TARGET_ENE_0, 45, -1, 0, 0)
                    WarKingWarrior405000_Act29(f40_arg1, f40_arg2)
                else
                    f40_arg2:AddSubGoal(GOAL_COMMON_LeaveTarget, 5, TARGET_ENE_0, 13, TARGET_SELF, false, 0)
                    f40_arg2:AddSubGoal(GOAL_COMMON_Turn, 2, TARGET_ENE_0, 45, -1, 0, 0)
                    WarKingWarrior405000_Act32(f40_arg1, f40_arg2)
                end
            else
                f40_arg2:AddSubGoal(GOAL_COMMON_ApproachTarget, 10, TARGET_ENE_0, 2, TARGET_SELF, false, -1)
                f40_arg2:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, 3003, TARGET_ENE_0, DIST_None, 0, 0)
            end
            return true
        end
        if f40_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f40_arg1:GetSpecialEffectActivateInterruptId(5030) and f40_arg1:HasSpecialEffectId(TARGET_ENE_0, 90) then
            f40_arg2:ClearSubGoal()
            if InsideRange(f40_arg1, f40_arg2, 180, 170, 0, 99) then
                if f40_local2 >= 70 then
                    f40_arg2:AddSubGoal(GOAL_COMMON_LeaveTarget, 5, TARGET_ENE_0, 9, TARGET_SELF, false, 0)
                    f40_arg2:AddSubGoal(GOAL_COMMON_Turn, 2, TARGET_ENE_0, 45, -1, 0, 0)
                    WarKingWarrior405000_Act29(f40_arg1, f40_arg2)
                else
                    f40_arg2:AddSubGoal(GOAL_COMMON_LeaveTarget, 5, TARGET_ENE_0, 13, TARGET_SELF, false, 0)
                    f40_arg2:AddSubGoal(GOAL_COMMON_Turn, 2, TARGET_ENE_0, 45, -1, 0, 0)
                    WarKingWarrior405000_Act32(f40_arg1, f40_arg2)
                end
            else
                f40_arg2:AddSubGoal(GOAL_COMMON_ApproachTarget, 10, TARGET_ENE_0, 2, TARGET_SELF, false, -1)
                f40_arg2:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, 3003, TARGET_ENE_0, DIST_None, 0, 0)
            end
            return true
        end
        if f40_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f40_arg1:GetSpecialEffectActivateInterruptId(5034) and f40_local2 <= 60 and InsideRange(f40_arg1, f40_arg2, 180, 150, 0, 1.5) then
            f40_arg2:ClearSubGoal()
            WarKingWarrior405000_Act31(f40_arg1, f40_arg2)
            return true
        end
        if f40_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f40_arg1:GetSpecialEffectActivateInterruptId(5033) and f40_local2 <= 60 and InsideRange(f40_arg1, f40_arg2, 180, 240, 0, 99) then
            f40_arg2:ClearSubGoal()
            WarKingWarrior405000_Act35(f40_arg1, f40_arg2)
            return true
        end
        if f40_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f40_arg1:GetSpecialEffectActivateInterruptId(5037) then
            f40_arg2:ClearSubGoal()
            return true
        end
    else
        if f40_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f40_arg1:GetSpecialEffectActivateInterruptId(6992) then
            f40_arg2:ClearSubGoal()
            WarKingWarrior405000_Act09(f40_arg1, f40_arg2)
            f40_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5025)
            f40_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5026)
            f40_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5027)
            f40_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5029)
            f40_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5030)
            return true
        end
        if f40_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f40_arg1:GetSpecialEffectActivateInterruptId(79) then
            f40_arg2:ClearSubGoal()
            f40_arg1:Replaning()
            return true
        end
        if f40_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f40_arg1:GetSpecialEffectActivateInterruptId(5025) and f40_arg1:IsInsideTargetEx(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 180, 4) then
            f40_arg2:ClearSubGoal()
            f40_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 5, 3001, TARGET_ENE_0, 999, 0, 0)
            return true
        end
        if f40_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f40_arg1:GetSpecialEffectActivateInterruptId(5035) and f40_arg1:IsInsideTargetEx(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 130, 2.5) then
            f40_arg2:ClearSubGoal()
            if f40_arg1:HasSpecialEffectId(TARGET_SELF, 12800) then
                f40_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 2, 3020, TARGET_ENE_0, 999, 0, 0)
            else
                f40_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 2, 3003, TARGET_ENE_0, 999, 0, 0)
            end
            return true
        end
        if f40_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f40_arg1:GetSpecialEffectActivateInterruptId(5027) and f40_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 240, 90, 5) then
            f40_arg2:ClearSubGoal()
            f40_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 1, 3013, TARGET_ENE_0, 999, 0, 0)
            return true
        end
        if f40_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f40_arg1:GetSpecialEffectActivateInterruptId(5038) and f40_arg1:HasSpecialEffectId(TARGET_SELF, 12800) == true and f40_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 240, 90, 7) then
            f40_arg2:ClearSubGoal()
            f40_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 1, 3004, TARGET_ENE_0, 999, 0, 0)
            return true
        end
        if f40_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f40_arg1:GetSpecialEffectActivateInterruptId(5028) and f40_arg1:IsInsideTargetEx(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 240, 6) then
            f40_arg2:ClearSubGoal()
            f40_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3007, TARGET_ENE_0, 999, 0, 0, 0, 0)
            return true
        end
        if f40_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f40_arg1:GetSpecialEffectActivateInterruptId(5031) and f40_arg1:HasSpecialEffectId(TARGET_ENE_0, 79) == false and f40_arg1:HasSpecialEffectId(TARGET_ENE_0, 90) == false and f40_arg1:HasSpecialEffectId(TARGET_ENE_0, 6992) == false and f40_arg1:HasSpecialEffectId(TARGET_SELF, 12800) == true then
            f40_arg2:ClearSubGoal()
            if f40_arg1:IsInsideTargetEx(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 240, 5) then
                if f40_arg1:HasSpecialEffectId(TARGET_SELF, 12800) then
                    f40_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 10, 3021, TARGET_ENE_0, 999, 0, 0)
                else
                    f40_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 10, 3010, TARGET_ENE_0, 999, 0, 0)
                end
                return true
            end
        end
        if f40_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f40_arg1:GetSpecialEffectActivateInterruptId(5032) then
            f40_arg2:ClearSubGoal()
            if f40_local0 >= 5 and f40_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 200, 180, 9) then
                f40_arg2:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, 3005, TARGET_ENE_0, 999, 0, 0, 0, 0)
                if f40_arg1:HasSpecialEffectId(TARGET_SELF, 12800) then
                    f40_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 10, 3021, TARGET_ENE_0, 999, 0, 0)
                else
                    f40_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 10, 3010, TARGET_ENE_0, 999, 0, 0)
                end
                return true
            else
            end
        end
        if f40_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f40_arg1:GetSpecialEffectActivateInterruptId(5026) and f40_arg1:HasSpecialEffectId(TARGET_SELF, 12800) == true and f40_arg1:IsInsideTargetEx(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 240, 4.5) then
            f40_arg2:ClearSubGoal()
            if f40_arg1:HasSpecialEffectId(TARGET_SELF, 12800) then
                f40_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 5, 3021, TARGET_ENE_0, 999, 0, 0)
            else
                f40_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 5, 3010, TARGET_ENE_0, 999, 0, 0)
            end
            return true
        end
        if f40_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f40_arg1:GetSpecialEffectActivateInterruptId(5029) and f40_arg1:HasSpecialEffectId(TARGET_SELF, 12800) == true and f40_arg1:IsInsideTargetEx(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 240, 4.5) then
            f40_arg2:ClearSubGoal()
            if f40_arg1:HasSpecialEffectId(TARGET_SELF, 12800) then
                f40_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 5, 3021, TARGET_ENE_0, 999, 0, 0)
            else
                f40_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 5, 3010, TARGET_ENE_0, 999, 0, 0)
            end
            return true
        end
        if f40_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) then
            if f40_arg1:HasSpecialEffectId(TARGET_SELF, 12800) then
                f40_local2 = 100
            else
                f40_local2 = 0
            end
            if f40_arg1:GetSpecialEffectActivateInterruptId(5036) and f40_local2 >= 40 and f40_arg1:IsInsideTargetEx(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 300, 9) and f40_local0 >= 5 then
                f40_arg2:ClearSubGoal()
                f40_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat_SuccessAngle180, 5, 3005, TARGET_ENE_0, 999, 0, 0)
                f40_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 5026)
                return true
            end
        end
        if not f40_arg1:IsInterupt(INTERUPT_Damaged) or f40_arg1:IsRiding(TARGET_ENE_0) == true then
        else
            if f40_arg1:GetNumber(0) >= 2 then
                f40_arg1:SetNumber(0, f40_arg1:GetNumber(0) + 1)
                f40_local2 = 100
            elseif f40_arg1:GetNumber(0) >= 1 then
                f40_arg1:SetNumber(0, f40_arg1:GetNumber(0) + 1)
                f40_local2 = f40_local2 + 10
            else
                f40_arg1:SetNumber(0, f40_arg1:GetNumber(0) + 1)
                f40_local2 = f40_local2 + 5
            end
            if f40_local2 >= 60 and InsideRange(f40_arg1, f40_arg2, 0, 120, 0, 2.5) and f40_arg1:GetTimer(0) <= 0 then
                f40_arg2:ClearSubGoal()
                f40_arg2:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 3, 3015, TARGET_ENE_0, 999, 0, 0, 0, 0)
                f40_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 5036)
                f40_arg1:SetNumber(0, 0)
                f40_arg1:SetTimer(0, 7)
                return true
            elseif f40_local2 >= 60 and InsideRange(f40_arg1, f40_arg2, 0, 150, 0, 5) and f40_arg1:GetTimer(1) <= 0 then
                f40_arg2:ClearSubGoal()
                WarKingWarrior405000_Act03(f40_arg1, f40_arg2)
                f40_arg1:SetNumber(0, 0)
                f40_arg1:SetTimer(1, 20)
                return true
            elseif f40_local2 >= 60 and InsideRange(f40_arg1, f40_arg2, 0, 180, 0, 9) and f40_local0 >= 5 and f40_arg1:GetTimer(2) <= 0 then
                f40_arg2:ClearSubGoal()
                f40_arg2:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, 3005, TARGET_ENE_0, 999, 0, 0, 0, 0)
                if f40_arg1:HasSpecialEffectId(TARGET_SELF, 12800) then
                    f40_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 10, 3021, TARGET_ENE_0, 999, 0, 0)
                end
                f40_arg1:SetNumber(0, 0)
                f40_arg1:SetTimer(2, 10)
                return true
            elseif f40_local2 >= 40 and InsideRange(f40_arg1, f40_arg2, 0, 260, 0, 2.7) and f40_local0 >= 1.3 and f40_arg1:GetTimer(3) <= 0 then
                f40_arg2:ClearSubGoal()
                WarKingWarrior405000_Act08(f40_arg1, f40_arg2)
                f40_arg1:SetNumber(0, 0)
                f40_arg1:SetTimer(3, 10)
                return true
            else
            end
        end
    end
    return false
    
end

RegisterTableGoal(GOAL_WarKingWarrior405000_AfterAttackAct, "WarKingWarrior405000_AfterAttackAct")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_WarKingWarrior405000_AfterAttackAct, true)

Goal.Activate = function (f41_arg0, f41_arg1, f41_arg2)
    
end

Goal.Update = function (f42_arg0, f42_arg1, f42_arg2)
    return Update_Default_NoSubGoal(f42_arg0, f42_arg1, f42_arg2)
    
end


