﻿function GroundTaco422000_Logic(f1_arg0)
    COMMON_Initialize(f1_arg0)
    if COMMON_EasySetup_Initial(f1_arg0) == false then
        local f1_local0 = f1_arg0:GetEventRequest()
        local f1_local1 = f1_arg0:GetDist(TARGET_ENE_0)
        local f1_local2 = f1_arg0:IsSearchTarget(TARGET_ENE_0)
        local f1_local3 = f1_arg0:GetDist(POINT_INITIAL)
        local f1_local4 = GetCurrentTimeType(f1_arg0)
        local f1_local5 = f1_arg0:GetPrevTargetState()
        local f1_local6 = f1_arg0:GetCurrTargetState()
        local f1_local7 = f1_arg0:HasSpecialEffectId(TARGET_SELF, 11751)
        local f1_local8 = f1_arg0:HasSpecialEffectId(TARGET_SELF, 11753)
        local f1_local9 = f1_arg0:HasSpecialEffectId(TARGET_SELF, 11755)
        local f1_local10 = f1_arg0:HasSpecialEffectId(TARGET_SELF, 11757)
        local f1_local11 = f1_arg0:IsBattleState()
        if f1_local11 == false then
            if f1_local9 == true and f1_local10 == false then
                f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, 3031, TARGET_ENE_0, DIST_None, 0, 0)
            end
            if f1_arg0:GetHpRate(TARGET_SELF) <= 0.9 and f1_local8 == false and f1_local7 == true then
                f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, 3014, TARGET_ENE_0, DIST_None, 0, 0)
            end
        end
        COMMON_EasySetup3(f1_arg0)
    end
    
end

function GroundTaco422000_Interupt(f2_arg0, f2_arg1)
    
end


