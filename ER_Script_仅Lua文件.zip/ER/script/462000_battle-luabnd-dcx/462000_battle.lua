﻿RegisterTableGoal(GOAL_Astile462000_Battle, "Astile462000_Battle")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_Astile462000_Battle, true)

Goal.Initialize = function (f1_arg0, f1_arg1, f1_arg2, f1_arg3)
    f1_arg1:SetStringIndexedNumber("Warp_Bagworm", 0)
    f1_arg1:SetStringIndexedNumber("Warp_HU", 0)
    f1_arg1:SetNumber(10, 0)
    f1_arg1:SetNumber(9, 0)
    
end

Goal.Activate = function (f2_arg0, f2_arg1, f2_arg2)
    Init_Pseudo_Global(f2_arg1, f2_arg2)
    f2_arg1:SetStringIndexedNumber("Dist_SideStep", 5)
    f2_arg1:SetStringIndexedNumber("Dist_BackStep", 5)
    local f2_local0 = {}
    local f2_local1 = {}
    local f2_local2 = {}
    Common_Clear_Param(f2_local0, f2_local1, f2_local2)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 16710)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 16711)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 16712)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 16713)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 16720)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 16721)
    local f2_local3 = f2_arg1:GetDist(TARGET_ENE_0)
    local f2_local4 = f2_arg1:GetRandam_Int(1, 100)
    local f2_local5 = f2_arg1:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__thinkAttr_doAdmirer)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 5039)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16744)
    local f2_local6 = f2_arg1:GetEventRequest()
    if f2_arg1:HasSpecialEffectId(TARGET_SELF, 16721) or f2_arg1:HasSpecialEffectId(TARGET_SELF, 16722) or f2_arg1:HasSpecialEffectId(TARGET_SELF, 16723) then
        if f2_arg1:GetLatestSoundBehaviorID() == 462000 or f2_arg1:GetLatestSoundBehaviorID() == 462010 or f2_arg1:GetLatestSoundBehaviorID() == 462010 then
            f2_local0[35] = 999
        else
            f2_local0[36] = 999
        end
    elseif f2_local3 > 40 then
        f2_local0[11] = 999
        f2_local0[12] = 40
        f2_local0[14] = 30
        f2_local0[21] = 30
        f2_local0[30] = 30
        f2_local0[49] = 30
    elseif f2_local3 > 20 then
        f2_local0[12] = 50
        f2_local0[14] = 20
        f2_local0[21] = 30
        f2_local0[30] = 30
    elseif f2_local3 > 10 then
        if f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_B, 120, 50, 20) then
            f2_local0[2] = 20
            f2_local0[3] = 20
            f2_local0[4] = 10
            f2_local0[14] = 30
            f2_local0[30] = 50
        else
            f2_local0[14] = 30
            f2_local0[30] = 20
            f2_local0[41] = 10
        end
    elseif f2_local3 > 6 then
        if f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_B, 120, 50, 20) then
            f2_local0[2] = 20
            f2_local0[3] = 20
            f2_local0[4] = 10
            f2_local0[14] = 30
            f2_local0[24] = 20
            f2_local0[30] = 20
        elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 50, 50) then
            f2_local0[5] = 20
            f2_local0[6] = 20
            f2_local0[9] = 15
            f2_local0[10] = 15
            f2_local0[15] = 30
            f2_local0[20] = 30
            f2_local0[30] = 20
        else
            f2_local0[5] = 20
            f2_local0[6] = 20
            f2_local0[15] = 30
            f2_local0[20] = 30
            f2_local0[30] = 20
        end
    elseif f2_local3 > -2 then
        if f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_B, 120, 50, 20) then
            f2_local0[2] = 10
            f2_local0[3] = 10
            f2_local0[4] = 5
            f2_local0[9] = 15
            f2_local0[10] = 15
            f2_local0[24] = 20
            f2_local0[30] = 30
        elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 90, 50, 50) then
            f2_local0[1] = 10
            f2_local0[4] = 10
            f2_local0[5] = 20
            f2_local0[9] = 20
            f2_local0[10] = 20
            f2_local0[15] = 30
            f2_local0[23] = 5
            f2_local0[20] = 15
            f2_local0[24] = 5
            f2_local0[30] = 20
        else
            f2_local0[2] = 10
            f2_local0[3] = 10
            f2_local0[4] = 5
            f2_local0[9] = 15
            f2_local0[10] = 15
            f2_local0[20] = 15
            f2_local0[24] = 15
            f2_local0[30] = 20
        end
    else
        f2_local0[2] = 15
        f2_local0[3] = 15
        f2_local0[4] = 10
        f2_local0[9] = 20
        f2_local0[24] = 20
        f2_local0[30] = 45
    end
    local f2_local7 = 8
    f2_arg1:SetStringIndexedNumber("ExistMeshOnLine_F", f2_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_F, 25 + f2_local7, f2_local7, 0))
    f2_arg1:SetStringIndexedNumber("ExistMeshOnLine_SELF_F", f2_arg1:GetExistMeshOnLineDistEx(TARGET_SELF, AI_DIR_TYPE_F, 25 + f2_local7, f2_local7, 0))
    f2_arg1:SetStringIndexedNumber("ExistMeshOnLine_SELF_B", f2_arg1:GetExistMeshOnLineDistEx(TARGET_SELF, AI_DIR_TYPE_B, 25 + f2_local7, f2_local7, 0))
    f2_arg1:SetStringIndexedNumber("ExistMeshOnLine_SELF_L", f2_arg1:GetExistMeshOnLineDistEx(TARGET_SELF, AI_DIR_TYPE_L, 25 + f2_local7, f2_local7, 0))
    f2_arg1:SetStringIndexedNumber("ExistMeshOnLine_SELF_R", f2_arg1:GetExistMeshOnLineDistEx(TARGET_SELF, AI_DIR_TYPE_R, 25 + f2_local7, f2_local7, 0))
    f2_arg1:SetStringIndexedNumber("ExistMeshOnLine_ToB", f2_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToB, 25 + f2_local7, f2_local7, 0))
    f2_arg1:SetStringIndexedNumber("ExistMeshOnLine_ToBL", f2_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToBL, 25 + f2_local7, f2_local7, 0))
    f2_arg1:SetStringIndexedNumber("ExistMeshOnLine_ToBR", f2_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToBR, 25 + f2_local7, f2_local7, 0))
    f2_arg1:SetStringIndexedNumber("ExistMeshOnLine_ToL", f2_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToL, 25 + f2_local7, f2_local7, 0))
    f2_arg1:SetStringIndexedNumber("ExistMeshOnLine_ToR", f2_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToR, 25 + f2_local7, f2_local7, 0))
    f2_arg1:SetStringIndexedNumber("ExistMeshOnLine_ToF", f2_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToF, 25 + f2_local7, f2_local7, 0))
    f2_arg1:SetStringIndexedNumber("ExistMeshOnLine_ToFL", f2_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToFL, 25 + f2_local7, f2_local7, 0))
    f2_arg1:SetStringIndexedNumber("ExistMeshOnLine_ToFR", f2_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToFR, 25 + f2_local7, f2_local7, 0))
    f2_local0[1] = SetCoolTime(f2_arg1, f2_arg2, 3000, 5 + f2_arg1:GetRandam_Int(0, 10), f2_local0[1], 0)
    f2_local0[2] = SetCoolTime(f2_arg1, f2_arg2, 3001, 15 + f2_arg1:GetRandam_Int(0, 10), f2_local0[2], 0)
    f2_local0[3] = SetCoolTime(f2_arg1, f2_arg2, 3002, 15 + f2_arg1:GetRandam_Int(0, 10), f2_local0[3], 0)
    f2_local0[4] = SetCoolTime(f2_arg1, f2_arg2, 3024, 20 + f2_arg1:GetRandam_Int(0, 10), f2_local0[4], 0)
    f2_local0[9] = SetCoolTime(f2_arg1, f2_arg2, 3014, 10 + f2_arg1:GetRandam_Int(0, 10), f2_local0[9], 0)
    f2_local0[10] = SetCoolTime(f2_arg1, f2_arg2, 3019, 10 + f2_arg1:GetRandam_Int(0, 10), f2_local0[10], 0)
    f2_local0[11] = SetCoolTime(f2_arg1, f2_arg2, 3013, 20 + f2_arg1:GetRandam_Int(0, 10), f2_local0[11], 0)
    f2_local0[12] = SetCoolTime(f2_arg1, f2_arg2, 3012, 10 + f2_arg1:GetRandam_Int(0, 10), f2_local0[12], 1)
    f2_local0[14] = SetCoolTime(f2_arg1, f2_arg2, 3026, 15 + f2_arg1:GetRandam_Int(0, 5), f2_local0[14], 0)
    f2_local0[20] = SetCoolTime(f2_arg1, f2_arg2, 3010, 15 + f2_arg1:GetRandam_Int(0, 10), f2_local0[20], 0)
    f2_local0[23] = SetCoolTime(f2_arg1, f2_arg2, 3015, 30 + f2_arg1:GetRandam_Int(0, 10), f2_local0[23], 0)
    f2_local0[24] = SetCoolTime(f2_arg1, f2_arg2, 3016, 60 + f2_arg1:GetRandam_Int(0, 10), f2_local0[24], 0)
    f2_local0[30] = SetCoolTime(f2_arg1, f2_arg2, 3003, 40 + f2_arg1:GetRandam_Int(0, 10), f2_local0[30], 1)
    f2_local0[30] = SetCoolTime(f2_arg1, f2_arg2, 20005, 40 + f2_arg1:GetRandam_Int(0, 10), f2_local0[30], 1)
    f2_local0[30] = SetCoolTime(f2_arg1, f2_arg2, 20015, 40 + f2_arg1:GetRandam_Int(0, 10), f2_local0[30], 1)
    if f2_local3 > 50 then
        f2_local0[21] = 0
    end
    if f2_arg1:HasSpecialEffectId(TARGET_SELF, 16744) == false then
        f2_local0[11] = 0
    end
    if f2_arg1:HasSpecialEffectId(TARGET_SELF, 16744) == false and f2_arg1:GetHpRate(TARGET_SELF) <= 0.6 then
        f2_local0[30] = f2_local0[30] * 80
    end
    if f2_arg1:GetHpRate(TARGET_SELF) >= 0.97 then
        f2_local0[30] = 0
        f2_local0[49] = 0
    end
    f2_local1[1] = REGIST_FUNC(f2_arg1, f2_arg2, Astile462000_Act01)
    f2_local1[2] = REGIST_FUNC(f2_arg1, f2_arg2, Astile462000_Act02)
    f2_local1[3] = REGIST_FUNC(f2_arg1, f2_arg2, Astile462000_Act03)
    f2_local1[4] = REGIST_FUNC(f2_arg1, f2_arg2, Astile462000_Act04)
    f2_local1[5] = REGIST_FUNC(f2_arg1, f2_arg2, Astile462000_Act05)
    f2_local1[6] = REGIST_FUNC(f2_arg1, f2_arg2, Astile462000_Act06)
    f2_local1[9] = REGIST_FUNC(f2_arg1, f2_arg2, Astile462000_Act09)
    f2_local1[10] = REGIST_FUNC(f2_arg1, f2_arg2, Astile462000_Act10)
    f2_local1[11] = REGIST_FUNC(f2_arg1, f2_arg2, Astile462000_Act11)
    f2_local1[12] = REGIST_FUNC(f2_arg1, f2_arg2, Astile462000_Act12)
    f2_local1[14] = REGIST_FUNC(f2_arg1, f2_arg2, Astile462000_Act14)
    f2_local1[15] = REGIST_FUNC(f2_arg1, f2_arg2, Astile462000_Act15)
    f2_local1[20] = REGIST_FUNC(f2_arg1, f2_arg2, Astile462000_Act20)
    f2_local1[21] = REGIST_FUNC(f2_arg1, f2_arg2, Astile462000_Act21)
    f2_local1[23] = REGIST_FUNC(f2_arg1, f2_arg2, Astile462000_Act23)
    f2_local1[24] = REGIST_FUNC(f2_arg1, f2_arg2, Astile462000_Act24)
    f2_local1[30] = REGIST_FUNC(f2_arg1, f2_arg2, Astile462000_Act30)
    f2_local1[35] = REGIST_FUNC(f2_arg1, f2_arg2, Astile462000_Act35)
    f2_local1[36] = REGIST_FUNC(f2_arg1, f2_arg2, Astile462000_Act36)
    f2_local1[39] = REGIST_FUNC(f2_arg1, f2_arg2, Astile462000_Act39)
    f2_local1[40] = REGIST_FUNC(f2_arg1, f2_arg2, Astile462000_Act40)
    f2_local1[41] = REGIST_FUNC(f2_arg1, f2_arg2, Astile462000_Act41)
    f2_local1[42] = REGIST_FUNC(f2_arg1, f2_arg2, Astile462000_Act42)
    f2_local1[43] = REGIST_FUNC(f2_arg1, f2_arg2, Astile462000_Act43)
    f2_local1[44] = REGIST_FUNC(f2_arg1, f2_arg2, Astile462000_Act44)
    f2_local1[45] = REGIST_FUNC(f2_arg1, f2_arg2, Astile462000_Act45)
    f2_local1[49] = REGIST_FUNC(f2_arg1, f2_arg2, Astile462000_Act49)
    local f2_local8 = REGIST_FUNC(f2_arg1, f2_arg2, Astile462000_ActAfter_AdjustSpace)
    Common_Battle_Activate(f2_arg1, f2_arg2, f2_local0, f2_local1, f2_local8, f2_local2)
    
end

function Astile462000_Act01(f3_arg0, f3_arg1, f3_arg2)
    local f3_local0 = f3_arg0:GetDist(TARGET_ENE_0)
    local f3_local1 = f3_arg0:GetRandam_Int(1, 100)
    local f3_local2 = 2.5
    local f3_local3 = 999
    local f3_local4 = 0
    local f3_local5 = 0
    local f3_local6 = 0
    local f3_local7 = 1.5
    local f3_local8 = 1.5
    Approach_Act_Flex(f3_arg0, f3_arg1, f3_local2, f3_local3, f3_local4, f3_local5, f3_local6, f3_local7, f3_local8)
    local f3_local9 = 3000
    local f3_local10 = 3003
    local f3_local11 = 3002
    local f3_local12 = 3009
    local f3_local13 = 4.5
    local f3_local14 = 0
    local f3_local15 = 0
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16710)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16711)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16712)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16713)
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f3_local9, TARGET_ENE_0, f3_local13, 0, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Astile462000_Act02(f4_arg0, f4_arg1, f4_arg2)
    local f4_local0 = f4_arg0:GetDist(TARGET_ENE_0)
    local f4_local1 = f4_arg0:GetRandam_Int(1, 100)
    local f4_local2 = 2.5
    local f4_local3 = 999
    local f4_local4 = 0
    local f4_local5 = 0
    local f4_local6 = 0
    local f4_local7 = 1.5
    local f4_local8 = 1.5
    Approach_Act_Flex(f4_arg0, f4_arg1, f4_local2, f4_local3, f4_local4, f4_local5, f4_local6, f4_local7, f4_local8)
    local f4_local9 = 3001
    local f4_local10 = 4.5
    local f4_local11 = 0
    local f4_local12 = 0
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16710)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16711)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16712)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16713)
    f4_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f4_local9, TARGET_ENE_0, f4_local10, 0, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Astile462000_Act03(f5_arg0, f5_arg1, f5_arg2)
    local f5_local0 = f5_arg0:GetDist(TARGET_ENE_0)
    local f5_local1 = f5_arg0:GetRandam_Int(1, 100)
    local f5_local2 = 3002
    local f5_local3 = 4.5
    local f5_local4 = 0
    local f5_local5 = 0
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16710)
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16711)
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16712)
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16713)
    f5_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f5_local2, TARGET_ENE_0, f5_local3, 0, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Astile462000_Act04(f6_arg0, f6_arg1, f6_arg2)
    local f6_local0 = f6_arg0:GetDist(TARGET_ENE_0)
    local f6_local1 = f6_arg0:GetRandam_Int(1, 100)
    local f6_local2 = 6
    local f6_local3 = 999
    local f6_local4 = 0
    local f6_local5 = 0
    local f6_local6 = 0
    local f6_local7 = 1.5
    local f6_local8 = 1.5
    Approach_Act_Flex(f6_arg0, f6_arg1, f6_local2, f6_local3, f6_local4, f6_local5, f6_local6, f6_local7, f6_local8)
    local f6_local9 = 3024
    local f6_local10 = 4.5
    local f6_local11 = 0
    local f6_local12 = 0
    f6_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f6_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f6_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f6_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f6_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f6_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f6_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16710)
    f6_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16711)
    f6_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16712)
    f6_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16713)
    f6_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f6_local9, TARGET_ENE_0, f6_local10, 0, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Astile462000_Act05(f7_arg0, f7_arg1, f7_arg2)
    local f7_local0 = f7_arg0:GetDist(TARGET_ENE_0)
    local f7_local1 = f7_arg0:GetRandam_Int(1, 100)
    local f7_local2 = 3004
    local f7_local3 = 3006
    local f7_local4 = 3002
    local f7_local5 = 3009
    local f7_local6 = 999
    local f7_local7 = 0
    local f7_local8 = 0
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16710)
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16711)
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16712)
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16713)
    f7_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f7_local2, TARGET_ENE_0, f7_local6, 0, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Astile462000_Act06(f8_arg0, f8_arg1, f8_arg2)
    local f8_local0 = f8_arg0:GetDist(TARGET_ENE_0)
    local f8_local1 = f8_arg0:GetRandam_Int(1, 100)
    local f8_local2 = 3005
    local f8_local3 = 3001
    local f8_local4 = 3002
    local f8_local5 = 3009
    local f8_local6 = 4.5
    local f8_local7 = 0
    local f8_local8 = 0
    f8_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f8_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f8_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f8_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f8_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f8_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f8_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16710)
    f8_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16711)
    f8_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16712)
    f8_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16713)
    f8_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f8_local2, TARGET_ENE_0, f8_local6, 0, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Astile462000_Act07(f9_arg0, f9_arg1, f9_arg2)
    local f9_local0 = f9_arg0:GetDist(TARGET_ENE_0)
    local f9_local1 = f9_arg0:GetRandam_Int(1, 100)
    local f9_local2 = 3006
    local f9_local3 = 3001
    local f9_local4 = 3002
    local f9_local5 = 3009
    local f9_local6 = 4.5
    local f9_local7 = 0
    local f9_local8 = 0
    f9_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f9_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f9_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f9_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f9_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f9_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f9_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16710)
    f9_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16711)
    f9_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16712)
    f9_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16713)
    f9_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f9_local2, TARGET_ENE_0, f9_local6, 0, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Astile462000_Act09(f10_arg0, f10_arg1, f10_arg2)
    local f10_local0 = f10_arg0:GetDist(TARGET_ENE_0)
    local f10_local1 = f10_arg0:GetRandam_Int(1, 100)
    local f10_local2 = 3014
    local f10_local3 = 4.5
    local f10_local4 = 0
    local f10_local5 = 0
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16710)
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16711)
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16712)
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16713)
    f10_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f10_local2, TARGET_ENE_0, f10_local3, 0, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Astile462000_Act10(f11_arg0, f11_arg1, f11_arg2)
    local f11_local0 = f11_arg0:GetDist(TARGET_ENE_0)
    local f11_local1 = f11_arg0:GetRandam_Int(1, 100)
    local f11_local2 = 3019
    local f11_local3 = 4.5
    local f11_local4 = 0
    local f11_local5 = 0
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16710)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16711)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16712)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16713)
    f11_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f11_local2, TARGET_ENE_0, f11_local3, 0, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Astile462000_Act11(f12_arg0, f12_arg1, f12_arg2)
    local f12_local0 = f12_arg0:GetDist(TARGET_ENE_0)
    local f12_local1 = f12_arg0:GetRandam_Int(1, 100)
    local f12_local2 = 3013
    local f12_local3 = 4.5
    local f12_local4 = 2
    local f12_local5 = 30
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16710)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16711)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16712)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16713)
    f12_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 15, f12_local2, TARGET_ENE_0, f12_local3, f12_local4, f12_local5, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Astile462000_Act12(f13_arg0, f13_arg1, f13_arg2)
    local f13_local0 = f13_arg0:GetDist(TARGET_ENE_0)
    local f13_local1 = f13_arg0:GetRandam_Int(1, 100)
    local f13_local2 = 3012
    local f13_local3 = 4.5
    local f13_local4 = 2
    local f13_local5 = 30
    f13_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f13_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f13_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f13_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f13_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f13_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f13_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16710)
    f13_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16711)
    f13_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16712)
    f13_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16713)
    f13_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 15, f13_local2, TARGET_ENE_0, f13_local3, f13_local4, f13_local5, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Astile462000_Act14(f14_arg0, f14_arg1, f14_arg2)
    local f14_local0 = f14_arg0:GetDist(TARGET_ENE_0)
    local f14_local1 = f14_arg0:GetRandam_Int(1, 100)
    local f14_local2 = 30
    local f14_local3 = 999
    local f14_local4 = 0
    local f14_local5 = 0
    local f14_local6 = 0
    local f14_local7 = 1.5
    local f14_local8 = 1.5
    Approach_Act_Flex(f14_arg0, f14_arg1, f14_local2, f14_local3, f14_local4, f14_local5, f14_local6, f14_local7, f14_local8)
    local f14_local9 = 3026
    local f14_local10 = 4.5
    local f14_local11 = 0
    local f14_local12 = 0
    f14_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f14_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f14_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f14_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f14_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f14_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f14_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16710)
    f14_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16711)
    f14_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16712)
    f14_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16713)
    f14_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f14_local9, TARGET_ENE_0, f14_local10, 0, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Astile462000_Act15(f15_arg0, f15_arg1, f15_arg2)
    local f15_local0 = f15_arg0:GetDist(TARGET_ENE_0)
    local f15_local1 = f15_arg0:GetRandam_Int(1, 100)
    local f15_local2 = 8
    local f15_local3 = 999
    local f15_local4 = 0
    local f15_local5 = 0
    local f15_local6 = 0
    local f15_local7 = 1.5
    local f15_local8 = 1.5
    Approach_Act_Flex(f15_arg0, f15_arg1, f15_local2, f15_local3, f15_local4, f15_local5, f15_local6, f15_local7, f15_local8)
    local f15_local9 = 3008
    local f15_local10 = 4.5
    local f15_local11 = 0
    local f15_local12 = 0
    f15_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f15_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f15_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f15_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f15_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f15_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f15_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16710)
    f15_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16711)
    f15_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16712)
    f15_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16713)
    f15_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f15_local9, TARGET_ENE_0, f15_local10, 0, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Astile462000_Act20(f16_arg0, f16_arg1, f16_arg2)
    local f16_local0 = f16_arg0:GetDist(TARGET_ENE_0)
    local f16_local1 = f16_arg0:GetRandam_Int(1, 100)
    local f16_local2 = 10
    local f16_local3 = 999
    local f16_local4 = 0
    local f16_local5 = 0
    local f16_local6 = 0
    local f16_local7 = 5
    local f16_local8 = 5
    Approach_Act_Flex(f16_arg0, f16_arg1, f16_local2, f16_local3, f16_local4, f16_local5, f16_local6, f16_local7, f16_local8)
    local f16_local9 = 3010
    local f16_local10 = 3.5
    local f16_local11 = 0
    local f16_local12 = 0
    f16_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f16_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f16_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f16_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f16_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f16_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f16_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16710)
    f16_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16711)
    f16_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16712)
    f16_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16713)
    f16_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f16_local9, TARGET_ENE_0, f16_local10, 0, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Astile462000_Act21(f17_arg0, f17_arg1, f17_arg2)
    local f17_local0 = f17_arg0:GetDist(TARGET_ENE_0)
    local f17_local1 = f17_arg0:GetRandam_Int(1, 100)
    local f17_local2 = 3011
    local f17_local3 = 3.5
    local f17_local4 = 0
    local f17_local5 = 0
    f17_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f17_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f17_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f17_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f17_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f17_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f17_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16710)
    f17_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16711)
    f17_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16712)
    f17_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16713)
    f17_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f17_local2, TARGET_ENE_0, f17_local3, 0, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Astile462000_Act23(f18_arg0, f18_arg1, f18_arg2)
    local f18_local0 = f18_arg0:GetDist(TARGET_ENE_0)
    local f18_local1 = f18_arg0:GetRandam_Int(1, 100)
    local f18_local2 = 2.5
    local f18_local3 = 999
    local f18_local4 = 0
    local f18_local5 = 0
    local f18_local6 = 0
    local f18_local7 = 5
    local f18_local8 = 5
    Approach_Act_Flex(f18_arg0, f18_arg1, f18_local2, f18_local3, f18_local4, f18_local5, f18_local6, f18_local7, f18_local8)
    local f18_local9 = 3015
    local f18_local10 = 3.5
    local f18_local11 = 0
    local f18_local12 = 0
    f18_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f18_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f18_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f18_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f18_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f18_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f18_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16710)
    f18_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16711)
    f18_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16712)
    f18_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16713)
    if f18_local1 <= 30 then
        f18_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, f18_local9, TARGET_ENE_0, f18_local10, 0, 0, 0, 0)
        f18_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 10, f18_local9, TARGET_ENE_0, f18_local10, 0, 0)
    else
        f18_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f18_local9, TARGET_ENE_0, f18_local10, 0, 0, 0, 0)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Astile462000_Act24(f19_arg0, f19_arg1, f19_arg2)
    local f19_local0 = f19_arg0:GetDist(TARGET_ENE_0)
    local f19_local1 = f19_arg0:GetRandam_Int(1, 100)
    local f19_local2 = 3016
    local f19_local3 = 3.5
    local f19_local4 = 0
    local f19_local5 = 0
    f19_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f19_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f19_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f19_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f19_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f19_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f19_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16710)
    f19_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16711)
    f19_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16712)
    f19_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16713)
    f19_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f19_local2, TARGET_ENE_0, f19_local3, 0, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Astile462000_Act30(f20_arg0, f20_arg1, f20_arg2)
    local f20_local0 = f20_arg0:GetRandam_Int(1, 100)
    local f20_local1 = 3003
    local f20_local2 = 20005
    local f20_local3 = 20015
    local f20_local4 = 5 - f20_arg0:GetMapHitRadius(TARGET_SELF)
    local f20_local5 = 0
    local f20_local6 = 0
    f20_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f20_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f20_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f20_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f20_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f20_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f20_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16710)
    f20_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16711)
    f20_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16712)
    f20_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16713)
    f20_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5035)
    f20_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5036)
    f20_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5037)
    f20_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16744)
    f20_arg0:SetStringIndexedNumber("Warp_Bagworm", 0)
    if f20_arg0:GetNumber(10) >= 4 then
        f20_arg0:SetNumber(10, 0)
    end
    if f20_arg0:GetHpRate(TARGET_SELF) <= 0.85 then
        if f20_arg0:HasSpecialEffectId(TARGET_SELF, 16744) == false and f20_arg0:GetHpRate(TARGET_SELF) <= 0.6 then
            f20_arg0:SetStringIndexedNumber("Warp_Bagworm", 0)
        elseif f20_arg0:GetNumber(10) == 0 then
            f20_arg0:SetStringIndexedNumber("Warp_Bagworm", 1)
            f20_arg0:SetNumber(10, f20_arg0:GetNumber(10) + 1)
        elseif f20_local0 > 40 and f20_arg0:GetAttackPassedTime(3016) >= 60 then
            f20_arg0:SetStringIndexedNumber("Warp_Bagworm", 1)
        else
            f20_arg0:SetNumber(10, f20_arg0:GetNumber(10) + 1)
        end
    end
    if f20_arg0:HasSpecialEffectId(TARGET_SELF, 16744) == false and f20_arg0:GetHpRate(TARGET_SELF) <= 0.6 then
        f20_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f20_local3, TARGET_ENE_0, 999, 0, 0, 0, 0)
    elseif f20_arg0:HasSpecialEffectId(TARGET_SELF, 16720) and f20_arg0:HasSpecialEffectId(TARGET_SELF, 16744) and f20_arg0:GetStringIndexedNumber("Warp_Bagworm") == 1 then
        f20_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f20_local2, TARGET_ENE_0, 999, 0, 0, 0, 0)
    else
        f20_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f20_local1, TARGET_ENE_0, 999, 0, 0, 0, 0)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Astile462000_Act35(f21_arg0, f21_arg1, f21_arg2)
    local f21_local0 = f21_arg0:GetDist(TARGET_ENE_0)
    local f21_local1 = f21_arg0:GetRandam_Int(1, 100)
    f21_arg0:SetNumber(15, 0)
    f21_arg1:AddSubGoal(GOAL_COMMON_Wait, f21_arg0:GetRandam_Int(0, 0), TARGET_ENE_0)
    f21_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3017, TARGET_ENE_0, SuccessDist, 0, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Astile462000_Act36(f22_arg0, f22_arg1, f22_arg2)
    local f22_local0 = f22_arg0:GetRandam_Int(1, 100)
    local f22_local1 = 5 - f22_arg0:GetMapHitRadius(TARGET_SELF)
    local f22_local2 = 0
    local f22_local3 = 0
    f22_arg1:AddSubGoal(GOAL_COMMON_Wait, 0.2, TARGET_ENE_0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Astile462000_Act39(f23_arg0, f23_arg1, f23_arg2)
    local f23_local0 = f23_arg0:GetRandam_Int(1, 100)
    local f23_local1 = 20005
    local f23_local2 = 5 - f23_arg0:GetMapHitRadius(TARGET_SELF)
    local f23_local3 = 0
    local f23_local4 = 0
    f23_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f23_local1, TARGET_ENE_0, 999, 0, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Astile462000_Act40(f24_arg0, f24_arg1, f24_arg2)
    f24_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, 3, TARGET_ENE_0, 1, TARGET_SELF, false, -1, AI_DIR_TYPE_ToR, 3)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Astile462000_Act41(f25_arg0, f25_arg1, f25_arg2)
    f25_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f25_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 2, TARGET_ENE_0, 7, TARGET_SELF, true, -1)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Astile462000_Act42(f26_arg0, f26_arg1, f26_arg2)
    f26_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f26_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    if f26_arg0:HasSpecialEffectId(TARGET_SELF, 16500) and f26_arg0:GetHpRate(TARGET_SELF) >= 0.98 then
        f26_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 3, TARGET_ENE_0, 3, TARGET_SELF, true, -1)
    else
        f26_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 3, TARGET_ENE_0, 3, TARGET_SELF, false, -1)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Astile462000_Act43(f27_arg0, f27_arg1, f27_arg2)
    local f27_local0 = f27_arg0:GetRandam_Int(1, 100)
    if f27_local0 <= 50 then
        f27_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 2, TARGET_ENE_0, 7, TARGET_ENE_0, true, -1)
    else
        f27_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 1.2, TARGET_ENE_0, 7, TARGET_ENE_0, true, -1)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Astile462000_Act44(f28_arg0, f28_arg1, f28_arg2)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Astile462000_Act45(f29_arg0, f29_arg1, f29_arg2)
    f29_arg1:AddSubGoal(GOAL_COMMON_Turn, 2, TARGET_ENE_0, f29_arg0:GetRandam_Int(90, 180), 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Astile462000_Act46(f30_arg0, f30_arg1, f30_arg2)
    local f30_local0 = f30_arg0:GetRandam_Int(1, 100)
    local f30_local1 = 3003
    local f30_local2 = 20016
    local f30_local3 = 5 - f30_arg0:GetMapHitRadius(TARGET_SELF)
    local f30_local4 = 0
    local f30_local5 = 0
    f30_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16713)
    f30_arg1:AddSubGoal(GOAL_COMMON_StepSafety, 5, -1, 1, -1, -1, TARGET_ENE_0, 0, 0, false)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Astile462000_Act48(f31_arg0, f31_arg1, f31_arg2)
    f31_arg1:AddSubGoal(GOAL_COMMON_Wait, 3, TARGET_ENE_0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Astile462000_Act49(f32_arg0, f32_arg1, f32_arg2)
    local f32_local0 = f32_arg0:GetRandam_Int(1, 100)
    local f32_local1 = 3003
    local f32_local2 = 20005
    local f32_local3 = 20015
    local f32_local4 = 5 - f32_arg0:GetMapHitRadius(TARGET_SELF)
    local f32_local5 = 0
    local f32_local6 = 0
    f32_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f32_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f32_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f32_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f32_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f32_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f32_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16710)
    f32_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16711)
    f32_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16712)
    f32_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16713)
    f32_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5035)
    f32_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5036)
    f32_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5037)
    f32_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16744)
    f32_arg0:SetStringIndexedNumber("Warp_Bagworm", 0)
    if f32_arg0:GetNumber(10) >= 4 then
        f32_arg0:SetNumber(10, 0)
    end
    if f32_arg0:GetHpRate(TARGET_SELF) <= 0.85 then
        if f32_arg0:HasSpecialEffectId(TARGET_SELF, 16744) == false and f32_arg0:GetHpRate(TARGET_SELF) <= 0.6 then
            f32_arg0:SetStringIndexedNumber("Warp_Bagworm", 0)
        elseif f32_arg0:GetNumber(10) == 0 then
            f32_arg0:SetStringIndexedNumber("Warp_Bagworm", 1)
            f32_arg0:SetNumber(10, f32_arg0:GetNumber(10) + 1)
        elseif f32_local0 > 40 and f32_arg0:GetAttackPassedTime(3016) >= 60 then
            f32_arg0:SetStringIndexedNumber("Warp_Bagworm", 1)
        else
            f32_arg0:SetNumber(10, f32_arg0:GetNumber(10) + 1)
        end
    end
    if f32_arg0:HasSpecialEffectId(TARGET_SELF, 16744) == false and f32_arg0:GetHpRate(TARGET_SELF) <= 0.6 then
        f32_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f32_local3, TARGET_ENE_0, 999, 0, 0, 0, 0)
    elseif f32_arg0:HasSpecialEffectId(TARGET_SELF, 16720) and f32_arg0:HasSpecialEffectId(TARGET_SELF, 16744) and f32_arg0:GetStringIndexedNumber("Warp_Bagworm") == 1 then
        f32_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f32_local2, TARGET_ENE_0, 999, 0, 0, 0, 0)
    else
        f32_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f32_local1, TARGET_ENE_0, 999, 0, 0, 0, 0)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Astile462000_ActAfter_AdjustSpace(f33_arg0, f33_arg1, f33_arg2)
    f33_arg1:AddSubGoal(GOAL_Astile462000_AfterAttackAct, 10)
    
end

Goal.Update = function (f34_arg0, f34_arg1, f34_arg2)
    return Update_Default_NoSubGoal(f34_arg0, f34_arg1, f34_arg2)
    
end

Goal.Terminate = function (f35_arg0, f35_arg1, f35_arg2)
    
end

Goal.Interrupt = function (f36_arg0, f36_arg1, f36_arg2)
    local f36_local0 = f36_arg1:GetRandam_Int(1, 100)
    local f36_local1 = f36_arg1:GetRandam_Int(1, 100)
    local f36_local2 = f36_arg1:GetDist(TARGET_ENE_0)
    local f36_local3 = f36_arg1:GetHpRate(TARGET_SELF)
    local f36_local4 = f36_arg1:GetNumber(0)
    local f36_local5 = f36_arg1:GetNumber(1)
    local f36_local6 = f36_arg1:GetRandam_Int(0, 10)
    local f36_local7 = f36_arg1:GetRandam_Int(0, 5)
    if f36_arg1:IsLadderAct(TARGET_SELF) then
        return false
    end
    if f36_arg1:HasSpecialEffectId(TARGET_SELF, 16721) or f36_arg1:HasSpecialEffectId(TARGET_SELF, 16722) or f36_arg1:HasSpecialEffectId(TARGET_SELF, 16723) then
        return false
    end
    f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 5035)
    f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 5036)
    f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 5037)
    f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16744)
    if f36_arg1:IsInterupt(INTERUPT_Shoot) and f36_arg1:HasSpecialEffectId(TARGET_SELF, 5039) == false then
        if f36_local2 > 10 and f36_local2 < 20 and f36_arg1:GetAttackPassedTime(3026) >= 10 + f36_local7 then
            f36_arg2:ClearSubGoal()
            f36_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3026, TARGET_ENE_0, 999, 0, 0, 0, 0)
            return true
        elseif f36_local2 > 20 and f36_arg1:GetAttackPassedTime(3025) >= 15 + f36_local7 then
            f36_arg2:ClearSubGoal()
            f36_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3025, TARGET_ENE_0, 999, 0, 0, 0, 0)
            return true
        end
    end
    if f36_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) then
        if f36_arg1:HasSpecialEffectId(TARGET_SELF, 5035) or f36_arg1:HasSpecialEffectId(TARGET_SELF, 16713) then
            local f36_local8 = AI_DIR_TYPE_F
            local f36_local9 = TARGET_ENE_0
            local f36_local10 = 8
            local f36_local11 = 55
            local f36_local12 = 10
            local f36_local13 = 0
            local f36_local14 = 0
            local f36_local15 = 0
            local f36_local16 = 0
            local f36_local17 = 0
            local f36_local18 = 0
            local f36_local19 = 0
            local f36_local20 = 0
            local f36_local21 = 0
            local f36_local22 = 0
            local f36_local23 = 0
            local f36_local24 = 0
            local f36_local25 = 0
            local f36_local26 = 0
            f36_arg1:SetStringIndexedNumber("ExistMeshOnLine_F", f36_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_F, 25 + f36_local10, f36_local10, 0))
            f36_arg1:SetStringIndexedNumber("ExistMeshOnLine_SELF_F", f36_arg1:GetExistMeshOnLineDistEx(TARGET_SELF, AI_DIR_TYPE_F, 25 + f36_local10, f36_local10, 0))
            f36_arg1:SetStringIndexedNumber("ExistMeshOnLine_SELF_B", f36_arg1:GetExistMeshOnLineDistEx(TARGET_SELF, AI_DIR_TYPE_B, 25 + f36_local10, f36_local10, 0))
            f36_arg1:SetStringIndexedNumber("ExistMeshOnLine_SELF_L", f36_arg1:GetExistMeshOnLineDistEx(TARGET_SELF, AI_DIR_TYPE_L, 25 + f36_local10, f36_local10, 0))
            f36_arg1:SetStringIndexedNumber("ExistMeshOnLine_SELF_R", f36_arg1:GetExistMeshOnLineDistEx(TARGET_SELF, AI_DIR_TYPE_R, 25 + f36_local10, f36_local10, 0))
            f36_arg1:SetStringIndexedNumber("ExistMeshOnLine_ToB", f36_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToB, 25 + f36_local10, f36_local10, 0))
            f36_arg1:SetStringIndexedNumber("ExistMeshOnLine_ToBL", f36_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToBL, 25 + f36_local10, f36_local10, 0))
            f36_arg1:SetStringIndexedNumber("ExistMeshOnLine_ToBR", f36_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToBR, 25 + f36_local10, f36_local10, 0))
            f36_arg1:SetStringIndexedNumber("ExistMeshOnLine_ToL", f36_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToL, 25 + f36_local10, f36_local10, 0))
            f36_arg1:SetStringIndexedNumber("ExistMeshOnLine_ToR", f36_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToR, 25 + f36_local10, f36_local10, 0))
            f36_arg1:SetStringIndexedNumber("ExistMeshOnLine_ToF", f36_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToF, 25 + f36_local10, f36_local10, 0))
            f36_arg1:SetStringIndexedNumber("ExistMeshOnLine_ToFL", f36_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToFL, 25 + f36_local10, f36_local10, 0))
            f36_arg1:SetStringIndexedNumber("ExistMeshOnLine_ToFR", f36_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToFR, 25 + f36_local10, f36_local10, 0))
            f36_arg1:SetStringIndexedNumber("Warp_Goal_F", 0)
            f36_arg1:SetStringIndexedNumber("Warp_Goal_B", 0)
            f36_arg1:SetStringIndexedNumber("Warp_Goal_L", 0)
            f36_arg1:SetStringIndexedNumber("Warp_Goal_R", 0)
            f36_arg1:SetStringIndexedNumber("Warp_Goal_ToB", 0)
            f36_arg1:SetStringIndexedNumber("Warp_Goal_ToBL", 0)
            f36_arg1:SetStringIndexedNumber("Warp_Goal_ToBR", 0)
            f36_arg1:SetStringIndexedNumber("Warp_Goal_ToL", 0)
            f36_arg1:SetStringIndexedNumber("Warp_Goal_ToR", 0)
            f36_arg1:SetStringIndexedNumber("Warp_Goal_ToF", 0)
            f36_arg1:SetStringIndexedNumber("Warp_Goal_ToFL", 0)
            f36_arg1:SetStringIndexedNumber("Warp_Goal_ToFR", 0)
            f36_arg1:SetStringIndexedNumber("Failed", 0)
            f36_arg1:SetStringIndexedNumber("Passed", 0)
            f36_arg1:SetNumber(13, 0)
            if f36_arg1:GetStringIndexedNumber("Warp_Bagworm") == 1 and f36_arg1:HasSpecialEffectId(TARGET_SELF, 16713) == false then
                local f36_local27 = 13
                if f36_arg1:GetStringIndexedNumber("ExistMeshOnLine_SELF_F") <= 15 then
                    f36_local14 = 0
                end
                if f36_arg1:GetStringIndexedNumber("ExistMeshOnLine_SELF_B") <= 15 then
                    f36_local15 = 0
                end
                if f36_arg1:GetStringIndexedNumber("ExistMeshOnLine_SELF_L") <= 15 then
                    f36_local16 = 0
                end
                if f36_arg1:GetStringIndexedNumber("ExistMeshOnLine_SELF_R") <= 15 then
                    f36_local17 = 0
                end
                if f36_arg1:GetStringIndexedNumber("ExistMeshOnLine_ToB") <= 15 then
                    f36_local18 = 0
                end
                if f36_arg1:GetStringIndexedNumber("ExistMeshOnLine_ToBL") <= 15 then
                    f36_local19 = 0
                end
                if f36_arg1:GetStringIndexedNumber("ExistMeshOnLine_ToBR") <= 15 then
                    f36_local20 = 0
                end
                if f36_arg1:GetStringIndexedNumber("ExistMeshOnLine_ToF") <= 15 then
                    f36_local23 = 0
                end
                if f36_arg1:GetStringIndexedNumber("ExistMeshOnLine_ToFL") <= 15 then
                    f36_local24 = 0
                end
                if f36_arg1:GetStringIndexedNumber("ExistMeshOnLine_ToFR") <= 15 then
                    f36_local25 = 0
                end
                if f36_arg1:GetStringIndexedNumber("ExistMeshOnLine_ToL") <= 15 then
                    f36_local21 = 0
                end
                if f36_arg1:GetStringIndexedNumber("ExistMeshOnLine_ToR") <= 15 then
                    f36_local22 = 0
                end
                f36_local14 = 0
                f36_local15 = 0
                f36_local16 = 0
                f36_local17 = 0
                f36_local18 = 0
                f36_local19 = 0
                f36_local20 = 0
                f36_local21 = 0
                f36_local22 = 0
                f36_local23 = 10
                f36_local24 = 10
                f36_local25 = 10
                f36_local26 = 0
                f36_local13 = f36_arg1:GetRandam_Int(0, f36_local21 + f36_local22 + f36_local23 + f36_local24 + f36_local25)
                if f36_local21 + f36_local22 + f36_local23 + f36_local25 == 0 then
                    f36_arg1:SetStringIndexedNumber("Failed", 1)
                    f36_arg2:ClearSubGoal()
                    return true
                elseif f36_local21 ~= 0 and f36_local13 <= f36_local21 then
                    f36_arg1:SetStringIndexedNumber("Warp_Goal_ToL", 1)
                    f36_local8 = AI_DIR_TYPE_ToL
                elseif f36_local22 ~= 0 and f36_local13 <= f36_local21 + f36_local22 then
                    f36_arg1:SetStringIndexedNumber("Warp_Goal_ToR", 1)
                    f36_local8 = AI_DIR_TYPE_ToR
                elseif f36_local23 ~= 0 and f36_local13 <= f36_local21 + f36_local22 + f36_local23 then
                    f36_arg1:SetStringIndexedNumber("Warp_Goal_ToF", 1)
                    f36_local8 = AI_DIR_TYPE_ToF
                elseif f36_local24 ~= 0 and f36_local13 <= f36_local21 + f36_local22 + f36_local23 + f36_local24 then
                    f36_arg1:SetStringIndexedNumber("Warp_Goal_ToFL", 1)
                    f36_local8 = AI_DIR_TYPE_ToFL
                elseif f36_local25 ~= 0 and f36_local13 <= f36_local21 + f36_local22 + f36_local23 + f36_local24 + f36_local25 then
                    f36_arg1:SetStringIndexedNumber("Warp_Goal_ToFR", 1)
                    f36_local8 = AI_DIR_TYPE_ToFR
                else
                    f36_arg1:SetStringIndexedNumber("Failed", 1)
                    f36_local9 = TARGET_EVENT
                    local f36_local28 = f36_arg1:GetRandam_Int(0, 3)
                    if f36_local28 == 0 then
                        f36_local8 = AI_DIR_TYPE_F
                    elseif f36_local28 == 0 then
                        f36_local8 = AI_DIR_TYPE_B
                    elseif f36_local28 == 0 then
                        f36_local8 = AI_DIR_TYPE_L
                    else
                        f36_local8 = AI_DIR_TYPE_R
                    end
                    local f36_local29 = f36_arg1:GetRandam_Int(0, 30)
                    f36_local12 = 0
                end
                f36_arg2:ClearSubGoal()
                f36_arg2:AddSubGoal(GOAL_COMMON_ToTargetWarp, 10, f36_local9, f36_local8, f36_local27, TARGET_ENE_0, 0, 0, f36_local12)
                f36_arg2:AddSubGoal(GOAL_COMMON_SetNumberRealtime, 0.1, 13, 1)
                f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3017, TARGET_ENE_0, 999, 0, 0, 0, 0)
            else
                if f36_arg1:GetStringIndexedNumber("ExistMeshOnLine_SELF_F") <= 25 then
                    f36_local14 = 0
                end
                if f36_arg1:GetStringIndexedNumber("ExistMeshOnLine_SELF_B") <= 25 then
                    f36_local15 = 0
                end
                if f36_arg1:GetStringIndexedNumber("ExistMeshOnLine_SELF_L") <= 25 then
                    f36_local16 = 0
                end
                if f36_arg1:GetStringIndexedNumber("ExistMeshOnLine_SELF_R") <= 25 then
                    f36_local17 = 0
                end
                if f36_arg1:GetStringIndexedNumber("ExistMeshOnLine_ToB") <= 25 then
                    f36_local18 = 0
                end
                if f36_arg1:GetStringIndexedNumber("ExistMeshOnLine_ToBL") <= 25 then
                    f36_local19 = 0
                end
                if f36_arg1:GetStringIndexedNumber("ExistMeshOnLine_ToBR") <= 25 then
                    f36_local20 = 0
                end
                if f36_arg1:GetStringIndexedNumber("ExistMeshOnLine_ToF") <= 25 then
                    f36_local23 = 0
                end
                if f36_arg1:GetStringIndexedNumber("ExistMeshOnLine_ToFL") <= 25 then
                    f36_local24 = 0
                end
                if f36_arg1:GetStringIndexedNumber("ExistMeshOnLine_ToFR") <= 25 then
                    f36_local25 = 0
                end
                if f36_arg1:GetStringIndexedNumber("ExistMeshOnLine_ToL") <= 25 then
                    f36_local21 = 0
                end
                if f36_arg1:GetStringIndexedNumber("ExistMeshOnLine_ToR") <= 25 then
                    f36_local22 = 0
                end
                f36_local14 = 0
                f36_local15 = 0
                f36_local16 = 0
                f36_local17 = 0
                f36_local18 = 0
                f36_local19 = 0
                f36_local20 = 0
                f36_local21 = 5
                f36_local22 = 5
                f36_local23 = 10
                f36_local24 = 10
                f36_local25 = 10
                f36_local26 = 0
                f36_local13 = f36_arg1:GetRandam_Int(0, f36_local21 + f36_local22 + f36_local23 + f36_local24 + f36_local25)
                if f36_arg1:HasSpecialEffectId(TARGET_SELF, 16744) == false then
                    local f36_local27 = 55
                end
                if f36_local21 + f36_local22 + f36_local23 + f36_local25 == 0 then
                    f36_arg1:SetStringIndexedNumber("Failed", 1)
                    f36_arg2:ClearSubGoal()
                    return true
                elseif f36_local21 ~= 0 and f36_local13 <= f36_local21 then
                    f36_arg1:SetStringIndexedNumber("Warp_Goal_ToL", 1)
                    f36_local8 = AI_DIR_TYPE_ToL
                elseif f36_local22 ~= 0 and f36_local13 <= f36_local21 + f36_local22 then
                    f36_arg1:SetStringIndexedNumber("Warp_Goal_ToR", 1)
                    f36_local8 = AI_DIR_TYPE_ToR
                elseif f36_local23 ~= 0 and f36_local13 <= f36_local21 + f36_local22 + f36_local23 then
                    f36_arg1:SetStringIndexedNumber("Warp_Goal_ToF", 1)
                    f36_local8 = AI_DIR_TYPE_ToF
                elseif f36_local24 ~= 0 and f36_local13 <= f36_local21 + f36_local22 + f36_local23 + f36_local24 then
                    f36_arg1:SetStringIndexedNumber("Warp_Goal_ToFL", 1)
                    f36_local8 = AI_DIR_TYPE_ToFL
                elseif f36_local25 ~= 0 and f36_local13 <= f36_local21 + f36_local22 + f36_local23 + f36_local24 + f36_local25 then
                    f36_arg1:SetStringIndexedNumber("Warp_Goal_ToFR", 1)
                    f36_local8 = AI_DIR_TYPE_ToFR
                else
                    f36_arg1:SetStringIndexedNumber("Failed", 1)
                    f36_local9 = TARGET_EVENT
                    local f36_local27 = f36_arg1:GetRandam_Int(0, 3)
                    if f36_local27 == 0 then
                        f36_local8 = AI_DIR_TYPE_F
                    elseif f36_local27 == 0 then
                        f36_local8 = AI_DIR_TYPE_B
                    elseif f36_local27 == 0 then
                        f36_local8 = AI_DIR_TYPE_L
                    else
                        f36_local8 = AI_DIR_TYPE_R
                    end
                    local f36_local28 = f36_arg1:GetRandam_Int(0, 30)
                    f36_local12 = 0
                end
                f36_arg2:ClearSubGoal()
                f36_arg2:AddSubGoal(GOAL_COMMON_ToTargetWarp, 10, f36_local9, f36_local8, f36_local11, TARGET_ENE_0, 0, 0, f36_local12)
                f36_arg2:AddSubGoal(GOAL_COMMON_SetNumberRealtime, 0.1, 13, 1)
                if f36_local2 < 20 then
                    f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 20016, TARGET_ENE_0, 999, 0, 0, 0, 0)
                else
                    f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 20016, TARGET_ENE_0, 999, 0, 0, 0, 0)
                end
            end
        elseif f36_arg1:HasSpecialEffectId(TARGET_SELF, 5036) and f36_arg1:GetNumber(13) ~= 1 then
            local f36_local8 = AI_DIR_TYPE_F
            local f36_local9 = TARGET_ENE_0
            local f36_local10 = 8
            local f36_local11 = f36_arg1:GetRandam_Int(0, 30)
            local f36_local12 = 0
            local f36_local13 = TARGET_EVENT
            local f36_local14 = f36_arg1:GetRandam_Int(0, 3)
            if f36_local14 == 0 then
                f36_local8 = AI_DIR_TYPE_F
            elseif f36_local14 == 1 then
                f36_local8 = AI_DIR_TYPE_B
            elseif f36_local14 == 2 then
                f36_local8 = AI_DIR_TYPE_L
            else
                f36_local8 = AI_DIR_TYPE_R
            end
            f36_arg2:ClearSubGoal()
            f36_arg2:AddSubGoal(GOAL_COMMON_ToTargetWarp, 10, f36_local13, f36_local8, f36_local11, TARGET_ENE_0, 0, 0, f36_local12)
            f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 20016, TARGET_ENE_0, 999, 0, 0, 0, 0)
        end
    end
    if f36_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f36_arg1:HasSpecialEffectId(TARGET_SELF, 5027) then
        if f36_arg1:HasSpecialEffectId(TARGET_SELF, 16744) then
            if f36_arg1:GetStringIndexedNumber("Warp_HU") == 0 then
                f36_arg2:ClearSubGoal()
                f36_arg1:SetStringIndexedNumber("Warp_HU", 1)
                f36_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3013, TARGET_ENE_0, 999, 0, 0, 0, 0)
                return true
            elseif f36_local2 < 2 then
                if f36_local0 <= 50 then
                    f36_arg2:ClearSubGoal()
                    f36_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3016, TARGET_ENE_0, 999, 0, 0, 0, 0)
                    return true
                else
                    f36_arg2:ClearSubGoal()
                    f36_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3024, TARGET_ENE_0, 999, 0, 0, 0, 0)
                    return true
                end
            elseif f36_local2 < 6 then
                if f36_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 30, 50, 20) then
                    if f36_local0 <= 50 then
                        f36_arg2:ClearSubGoal()
                        f36_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3000, TARGET_ENE_0, 999, 0, 0, 0, 0)
                        return true
                    else
                        f36_arg2:ClearSubGoal()
                        f36_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3015, TARGET_ENE_0, 999, 0, 0, 0, 0)
                        return true
                    end
                elseif f36_local0 <= 50 then
                    f36_arg2:ClearSubGoal()
                    f36_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3016, TARGET_ENE_0, 999, 0, 0, 0, 0)
                    return true
                else
                    f36_arg2:ClearSubGoal()
                    f36_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3024, TARGET_ENE_0, 999, 0, 0, 0, 0)
                    return true
                end
            elseif f36_local2 < 10 then
                if f36_local0 <= 30 then
                    f36_arg2:ClearSubGoal()
                    f36_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3004, TARGET_ENE_0, 999, 0, 0, 0, 0)
                    return true
                elseif f36_local0 <= 60 then
                    f36_arg2:ClearSubGoal()
                    f36_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3005, TARGET_ENE_0, 999, 0, 0, 0, 0)
                    return true
                else
                    f36_arg2:ClearSubGoal()
                    f36_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3010, TARGET_ENE_0, 999, 0, 0, 0, 0)
                    return true
                end
            elseif f36_local2 < 20 then
                if f36_local0 < 70 and f36_arg1:GetAttackPassedTime(3013) >= 30 then
                    f36_arg2:ClearSubGoal()
                    f36_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3013, TARGET_ENE_0, 999, 0, 0, 0, 0)
                    return true
                else
                    f36_arg2:ClearSubGoal()
                    f36_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3026, TARGET_ENE_0, 999, 0, 0, 0, 0)
                    return true
                end
            elseif f36_local2 < 30 then
                if f36_local0 < 70 and f36_arg1:GetAttackPassedTime(3013) >= 30 then
                    f36_arg2:ClearSubGoal()
                    f36_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3013, TARGET_ENE_0, 999, 0, 0, 0, 0)
                    return true
                else
                    f36_arg2:ClearSubGoal()
                    f36_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3012, TARGET_ENE_0, 999, 0, 0, 0, 0)
                    return true
                end
            else
                f36_arg2:ClearSubGoal()
                f36_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3013, TARGET_ENE_0, 999, 0, 0, 0, 0)
                return true
            end
        elseif f36_local2 < 2 then
            if f36_local0 <= 50 then
                f36_arg2:ClearSubGoal()
                f36_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3016, TARGET_ENE_0, 999, 0, 0, 0, 0)
                return true
            else
                f36_arg2:ClearSubGoal()
                f36_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3024, TARGET_ENE_0, 999, 0, 0, 0, 0)
                return true
            end
        elseif f36_local2 < 6 then
            if f36_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 30, 50, 20) then
                if f36_local0 <= 50 then
                    f36_arg2:ClearSubGoal()
                    f36_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3000, TARGET_ENE_0, 999, 0, 0, 0, 0)
                    return true
                else
                    f36_arg2:ClearSubGoal()
                    f36_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3015, TARGET_ENE_0, 999, 0, 0, 0, 0)
                    return true
                end
            elseif f36_local0 <= 50 then
                f36_arg2:ClearSubGoal()
                f36_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3016, TARGET_ENE_0, 999, 0, 0, 0, 0)
                return true
            else
                f36_arg2:ClearSubGoal()
                f36_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3024, TARGET_ENE_0, 999, 0, 0, 0, 0)
                return true
            end
        elseif f36_local2 < 10 then
            if f36_local0 <= 30 then
                f36_arg2:ClearSubGoal()
                f36_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3004, TARGET_ENE_0, 999, 0, 0, 0, 0)
                return true
            elseif f36_local0 <= 60 then
                f36_arg2:ClearSubGoal()
                f36_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3005, TARGET_ENE_0, 999, 0, 0, 0, 0)
                return true
            else
                f36_arg2:ClearSubGoal()
                f36_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3010, TARGET_ENE_0, 999, 0, 0, 0, 0)
                return true
            end
        elseif f36_local2 < 20 then
            f36_arg2:ClearSubGoal()
            f36_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3026, TARGET_ENE_0, 999, 0, 0, 0, 0)
            return true
        elseif f36_local2 < 30 then
            f36_arg2:ClearSubGoal()
            f36_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3012, TARGET_ENE_0, 999, 0, 0, 0, 0)
            return true
        else
            f36_arg2:ClearSubGoal()
            f36_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3012, TARGET_ENE_0, 999, 0, 0, 0, 0)
            return true
        end
    end
    if f36_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f36_arg1:HasSpecialEffectId(TARGET_SELF, 16710) then
        if f36_local2 > 5 and f36_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 50, 20) then
            f36_arg2:ClearSubGoal()
            f36_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 10, 3006, TARGET_ENE_0, 3, 0, 0)
            return true
        elseif f36_local2 < 30 and f36_local0 > 60 then
            f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3026, TARGET_ENE_0, 999, 0, 0, 0, 0)
            return true
        end
    end
    if f36_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f36_arg1:HasSpecialEffectId(TARGET_SELF, 16711) then
        if f36_local2 > -1 and f36_local2 < 1.5 and f36_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 90, 50, 20) and f36_arg1:GetAttackPassedTime(3015) >= 20 then
            f36_arg2:ClearSubGoal()
            f36_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 10, 3015, TARGET_ENE_0, 3, 0, 0)
            return true
        elseif f36_local2 > 1.5 and f36_local2 < 13 and f36_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 180, 50, 20) then
            f36_arg2:ClearSubGoal()
            f36_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 10, 3008, TARGET_ENE_0, 3, 0, 0)
            return true
        end
    end
    if f36_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f36_arg1:HasSpecialEffectId(TARGET_SELF, 5033) and f36_local2 > -1 and f36_local2 < 4 and f36_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 90, 50, 20) and f36_arg1:GetAttackPassedTime(3015) >= 20 then
        f36_arg2:ClearSubGoal()
        f36_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 10, 3015, TARGET_ENE_0, 3, 0, 0)
        return true
    end
    if f36_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f36_arg1:HasSpecialEffectId(TARGET_SELF, 16712) and f36_local2 > 5 and f36_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 50, 20) then
        f36_arg2:ClearSubGoal()
        f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3009, TARGET_ENE_0, 999, 0, 0, 0, 0)
        return true
    end
    if f36_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f36_arg1:HasSpecialEffectId(TARGET_SELF, 5026) then
        if f36_local2 < 10 and f36_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 180, 50, 20) then
            f36_arg2:ClearSubGoal()
            f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3023, TARGET_ENE_0, 999, 0, 0, 0, 0)
            return true
        elseif f36_local2 < 30 and f36_local0 > 60 then
            f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3026, TARGET_ENE_0, 999, 0, 0, 0, 0)
            return true
        end
    end
    if f36_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f36_arg1:HasSpecialEffectId(TARGET_SELF, 5030) then
        if f36_local0 <= 50 then
            f36_arg2:ClearSubGoal()
            f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3028, TARGET_ENE_0, 999, 0, 0, 0, 0)
            return true
        else
            f36_arg2:ClearSubGoal()
            f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3027, TARGET_ENE_0, 999, 0, 0, 0, 0)
            return true
        end
    end
    if f36_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f36_arg1:HasSpecialEffectId(TARGET_SELF, 5025) then
        if f36_local2 < -1 then
            if f36_arg1:GetAttackPassedTime(3003) >= 70 + f36_local7 and f36_local3 <= 0.1 then
                if f36_arg1:GetSA(TARGET_SELF) ~= 0 then
                    f36_arg2:ClearSubGoal()
                    f36_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3003, TARGET_ENE_0, 999, 0, 0, 0, 0)
                    return true
                else
                    f36_arg2:ClearSubGoal()
                    return true
                end
            end
        elseif f36_local2 < 2 and f36_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 90, 50, 50) and f36_arg1:GetAttackPassedTime(3000) >= 10 then
            f36_arg2:ClearSubGoal()
            f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3000, TARGET_ENE_0, 999, 0, 0, 0, 0)
            return true
        end
    end
    return false
    
end

RegisterTableGoal(GOAL_Astile462000_AfterAttackAct, "Astile462000_AfterAttackAct")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_Astile462000_AfterAttackAct, true)

Goal.Activate = function (f37_arg0, f37_arg1, f37_arg2)
    local f37_local0 = f37_arg1:GetDist(TARGET_ENE_0)
    local f37_local1 = f37_arg1:GetToTargetAngle(TARGET_ENE_0)
    f37_arg1:SetStringIndexedNumber("DistMin_AAA", -999)
    f37_arg1:SetStringIndexedNumber("DistMax_AAA", 7)
    f37_arg1:SetStringIndexedNumber("BaseDir_AAA", AI_DIR_TYPE_F)
    f37_arg1:SetStringIndexedNumber("Angle_AAA", 180)
    f37_arg1:SetStringIndexedNumber("DistMin_Inter_AAA", 1)
    f37_arg1:SetStringIndexedNumber("DistMax_Inter_AAA", 10)
    f37_arg1:SetStringIndexedNumber("BaseAng_Inter_AAA", 0)
    f37_arg1:SetStringIndexedNumber("Ang_Inter_AAA", 180)
    if f37_local0 >= 5 then
        f37_arg1:SetStringIndexedNumber("Odds_Guard_AAA", 80)
        f37_arg1:SetStringIndexedNumber("Odds_NoAct_AAA", 70)
        f37_arg1:SetStringIndexedNumber("Odds_BackAndSide_AAA", 30)
    elseif f37_local0 >= 2 then
        f37_arg1:SetStringIndexedNumber("Odds_Guard_AAA", 80)
        f37_arg1:SetStringIndexedNumber("Odds_NoAct_AAA", 50)
        f37_arg1:SetStringIndexedNumber("Odds_BackAndSide_AAA", 30)
        f37_arg1:SetStringIndexedNumber("Odds_Back_AAA", 10)
        f37_arg1:SetStringIndexedNumber("Odds_Backstep_AAA", 10)
    else
        f37_arg1:SetStringIndexedNumber("Odds_Guard_AAA", 80)
        f37_arg1:SetStringIndexedNumber("Odds_NoAct_AAA", 50)
        f37_arg1:SetStringIndexedNumber("Odds_BackAndSide_AAA", 10)
        f37_arg1:SetStringIndexedNumber("Odds_Back_AAA", 10)
        f37_arg1:SetStringIndexedNumber("Odds_Backstep_AAA", 5)
        f37_arg1:SetStringIndexedNumber("Odds_Sidestep_AAA", 10)
        f37_arg1:SetStringIndexedNumber("Odds_BsAndSide_AAA", 15)
    end
    f37_arg2:AddSubGoal(GOAL_COMMON_AfterAttackAct, 10)
    
end

Goal.Update = function (f38_arg0, f38_arg1, f38_arg2)
    return Update_Default_NoSubGoal(f38_arg0, f38_arg1, f38_arg2)
    
end


