﻿RegisterTableGoal(GOAL_MeteoriteBeast_468000_Battle, "MeteoriteBeast_468000_Battle")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_MeteoriteBeast_468000_Battle, true)

Goal.Initialize = function (f1_arg0, f1_arg1, f1_arg2, f1_arg3)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3000)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3001)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3002)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3003)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3004)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3005)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3006)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3007)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3008)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3009)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3010)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3011)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3015)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3017)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3020)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3022)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3023)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3024)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3025)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3027)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3028)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3029)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3033)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3034)
    
end

Goal.Activate = function (f2_arg0, f2_arg1, f2_arg2)
    Init_Pseudo_Global(f2_arg1, f2_arg2)
    f2_arg1:GetStringIndexedNumber("Rush_Cnt")
    f2_arg1:GetStringIndexedNumber("Curve_Cnt")
    f2_arg1:GetStringIndexedNumber("Warcry_Cnt")
    local f2_local0 = {}
    local f2_local1 = {}
    local f2_local2 = {}
    Common_Clear_Param(f2_local0, f2_local1, f2_local2)
    local f2_local3 = f2_arg1:GetOriginDist(TARGET_ENE_0)
    local f2_local4 = f2_arg1:GetRandam_Int(1, 100)
    local f2_local5 = f2_arg1:HasSpecialEffectId(TARGET_SELF, 16495)
    local f2_local6 = f2_arg1:HasSpecialEffectId(TARGET_SELF, 16490)
    if f2_arg1:HasSpecialEffectId(TARGET_ENE_0, 16488) then
        f2_arg1:SetStringIndexedNumber("CantMoveErea", 1)
    else
        f2_arg1:SetStringIndexedNumber("CantMoveErea", 0)
    end
    if f2_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_B, 90) then
        if f2_local3 >= 15 then
            f2_local0[17] = 30
        else
            f2_local0[8] = 20
            f2_local0[24] = 10
            f2_local0[26] = 10
            f2_local0[27] = 10
            f2_local0[16] = 50
        end
    elseif f2_arg1:GetHpRate(TARGET_SELF) <= 0.6 and f2_local6 == true and f2_local5 == false then
        f2_local0[12] = 100
    elseif f2_local3 >= 24 then
        f2_local0[2] = 5
        f2_local0[3] = 5
        f2_local0[10] = 90
    elseif f2_local3 >= 10 then
        f2_local0[2] = 5
        f2_local0[3] = 5
        f2_local0[4] = 20
        f2_local0[9] = 20
        f2_local0[10] = 40
        f2_local0[15] = 15
        f2_local0[23] = 20
        f2_local0[26] = 10
        f2_local0[27] = 10
    elseif f2_local3 >= 7 then
        f2_local0[2] = 20
        f2_local0[3] = 10
        f2_local0[4] = 10
        f2_local0[5] = 10
        f2_local0[12] = 70
        f2_local0[15] = 20
        f2_local0[26] = 10
        f2_local0[27] = 10
        f2_local0[29] = 20
    else
        f2_local0[1] = 25
        f2_local0[3] = 25
        f2_local0[4] = 10
        f2_local0[5] = 20
        f2_local0[6] = 20
        f2_local0[7] = 25
        f2_local0[8] = 15
        f2_local0[11] = 20
        f2_local0[12] = 70
        f2_local0[14] = 25
        f2_local0[16] = 15
        f2_local0[26] = 10
        f2_local0[27] = 10
    end
    if f2_arg1:GetHpRate(TARGET_SELF) >= 0.6 then
        f2_local0[12] = 0
    end
    if f2_local6 == false then
        f2_local0[12] = 0
    end
    if f2_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_F, 90) then
        f2_local0[8] = 0
        f2_local0[16] = 0
    end
    if f2_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_L, 90) then
        f2_local0[1] = 0
        f2_local0[4] = 0
        f2_local0[29] = 0
    end
    if f2_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_R, 90) then
        f2_local0[1] = 0
        f2_local0[2] = 0
        f2_local0[3] = 0
        f2_local0[16] = 0
        f2_local0[29] = 0
    end
    if f2_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_B, 110) then
        f2_local0[1] = 0
        f2_local0[2] = 0
        f2_local0[3] = 0
        f2_local0[4] = 0
        f2_local0[6] = 0
        f2_local0[7] = 0
        f2_local0[11] = 0
        f2_local0[29] = 0
    end
    if f2_arg1:GetTimer(2) > 0 then
        f2_local0[26] = f2_local0[26] / 2
        f2_local0[27] = f2_local0[27] / 2
    end
    if f2_arg1:GetTimer(6) > 0 then
        f2_local0[19] = 0
        f2_local0[20] = 0
    end
    if f2_arg1:GetAttackPassedTime(3009) <= 15 and f2_arg1:GetAttackPassedTime(3009) == 0 then
        f2_local0[7] = 0
    end
    if f2_arg1:GetTimer(8) > 0 then
        f2_local0[15] = 0
    end
    f2_local0[16] = SetCoolTime(f2_arg1, f2_arg2, 3020, 15, f2_local0[16], 0)
    f2_local0[15] = SetCoolTime(f2_arg1, f2_arg2, 3019, 25, f2_local0[15], 0)
    f2_local0[11] = SetCoolTime(f2_arg1, f2_arg2, 3015, 12, f2_local0[11], 0)
    f2_local0[2] = SetCoolTime(f2_arg1, f2_arg2, 3001, 16, f2_local0[2], 0)
    f2_local0[28] = SetCoolTime(f2_arg1, f2_arg2, 3033, 8, f2_local0[28], 0)
    f2_local0[5] = SetCoolTime(f2_arg1, f2_arg2, 3007, 15, f2_local0[5], 0)
    f2_local0[10] = SetCoolTime(f2_arg1, f2_arg2, 3014, 30, f2_local0[10], 0)
    f2_local0[10] = SetCoolTime(f2_arg1, f2_arg2, 3017, 30, f2_local0[10], 0)
    f2_local0[16] = SetCoolTime(f2_arg1, f2_arg2, 3020, 8, f2_local0[16], 0)
    f2_local0[15] = SetCoolTime(f2_arg1, f2_arg2, 3035, 30, f2_local0[15], 0)
    f2_local0[12] = SetCoolTime(f2_arg1, f2_arg2, 3016, 60, f2_local0[12], 1)
    f2_local0[9] = SetCoolTime(f2_arg1, f2_arg2, 3011, 15, f2_local0[9], 0)
    f2_local0[1] = SetCoolTime(f2_arg1, f2_arg2, 3000, 4, f2_local0[1], 0)
    f2_local0[6] = SetCoolTime(f2_arg1, f2_arg2, 3008, 10, f2_local0[6], 0)
    f2_local0[4] = SetCoolTime(f2_arg1, f2_arg2, 3006, 8, f2_local0[4], 0)
    f2_local0[8] = SetCoolTime(f2_arg1, f2_arg2, 3010, 20, f2_local0[8], 0)
    f2_local0[14] = SetCoolTime(f2_arg1, f2_arg2, 3018, 30, f2_local0[14], 0)
    f2_local0[14] = SetCoolTime(f2_arg1, f2_arg2, 3026, 30, f2_local0[14], 0)
    f2_local0[3] = SetCoolTime(f2_arg1, f2_arg2, 3004, 16, f2_local0[3], 0)
    f2_local0[29] = SetCoolTime(f2_arg1, f2_arg2, 3034, 16, f2_local0[29], 0)
    if f2_arg1:IsFinishTimer(0) == true and f2_arg1:GetStringIndexedNumber("CantMoveErea") == 1 then
        f2_local0[41] = 300
        f2_local0[42] = 300
        if f2_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_L, 90) then
            f2_local0[41] = 0
        elseif f2_local3 > 29 then
            f2_local0[41] = 0
        end
    end
    f2_local1[1] = REGIST_FUNC(f2_arg1, f2_arg2, MeteoriteBeast_468000_Act01)
    f2_local1[2] = REGIST_FUNC(f2_arg1, f2_arg2, MeteoriteBeast_468000_Act02)
    f2_local1[3] = REGIST_FUNC(f2_arg1, f2_arg2, MeteoriteBeast_468000_Act03)
    f2_local1[4] = REGIST_FUNC(f2_arg1, f2_arg2, MeteoriteBeast_468000_Act04)
    f2_local1[5] = REGIST_FUNC(f2_arg1, f2_arg2, MeteoriteBeast_468000_Act05)
    f2_local1[6] = REGIST_FUNC(f2_arg1, f2_arg2, MeteoriteBeast_468000_Act06)
    f2_local1[7] = REGIST_FUNC(f2_arg1, f2_arg2, MeteoriteBeast_468000_Act07)
    f2_local1[8] = REGIST_FUNC(f2_arg1, f2_arg2, MeteoriteBeast_468000_Act08)
    f2_local1[9] = REGIST_FUNC(f2_arg1, f2_arg2, MeteoriteBeast_468000_Act09)
    f2_local1[10] = REGIST_FUNC(f2_arg1, f2_arg2, MeteoriteBeast_468000_Act10)
    f2_local1[11] = REGIST_FUNC(f2_arg1, f2_arg2, MeteoriteBeast_468000_Act11)
    f2_local1[12] = REGIST_FUNC(f2_arg1, f2_arg2, MeteoriteBeast_468000_Act12)
    f2_local1[13] = REGIST_FUNC(f2_arg1, f2_arg2, MeteoriteBeast_468000_Act13)
    f2_local1[14] = REGIST_FUNC(f2_arg1, f2_arg2, MeteoriteBeast_468000_Act14)
    f2_local1[15] = REGIST_FUNC(f2_arg1, f2_arg2, MeteoriteBeast_468000_Act15)
    f2_local1[16] = REGIST_FUNC(f2_arg1, f2_arg2, MeteoriteBeast_468000_Act16)
    f2_local1[17] = REGIST_FUNC(f2_arg1, f2_arg2, MeteoriteBeast_468000_Act17)
    f2_local1[18] = REGIST_FUNC(f2_arg1, f2_arg2, MeteoriteBeast_468000_Act18)
    f2_local1[19] = REGIST_FUNC(f2_arg1, f2_arg2, MeteoriteBeast_468000_Act19)
    f2_local1[20] = REGIST_FUNC(f2_arg1, f2_arg2, MeteoriteBeast_468000_Act20)
    f2_local1[21] = REGIST_FUNC(f2_arg1, f2_arg2, MeteoriteBeast_468000_Act21)
    f2_local1[22] = REGIST_FUNC(f2_arg1, f2_arg2, MeteoriteBeast_468000_Act22)
    f2_local1[23] = REGIST_FUNC(f2_arg1, f2_arg2, MeteoriteBeast_468000_Act23)
    f2_local1[24] = REGIST_FUNC(f2_arg1, f2_arg2, MeteoriteBeast_468000_Act24)
    f2_local1[25] = REGIST_FUNC(f2_arg1, f2_arg2, MeteoriteBeast_468000_Act25)
    f2_local1[26] = REGIST_FUNC(f2_arg1, f2_arg2, MeteoriteBeast_468000_Act26)
    f2_local1[27] = REGIST_FUNC(f2_arg1, f2_arg2, MeteoriteBeast_468000_Act27)
    f2_local1[28] = REGIST_FUNC(f2_arg1, f2_arg2, MeteoriteBeast_468000_Act28)
    f2_local1[29] = REGIST_FUNC(f2_arg1, f2_arg2, MeteoriteBeast_468000_Act29)
    f2_local1[30] = REGIST_FUNC(f2_arg1, f2_arg2, MeteoriteBeast_468000_Act30)
    f2_local1[41] = REGIST_FUNC(f2_arg1, f2_arg2, MeteoriteBeast_468000_Act41)
    f2_local1[42] = REGIST_FUNC(f2_arg1, f2_arg2, MeteoriteBeast_468000_Act42)
    local f2_local7 = REGIST_FUNC(f2_arg1, f2_arg2, MeteoriteBeast_468000_ActAfter_AdjustSpace)
    Common_Battle_Activate(f2_arg1, f2_arg2, f2_local0, f2_local1, f2_local7, f2_local2)
    
end

function MeteoriteBeast_468000_Act01(f3_arg0, f3_arg1, f3_arg2)
    local f3_local0 = 5
    local f3_local1 = 3000
    local f3_local2 = 6
    local f3_local3 = 0
    local f3_local4 = 120
    local f3_local5 = f3_arg0:GetRandam_Int(1, 100)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16470)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16471)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16450)
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f3_local0, f3_local1, TARGET_ENE_0, f3_local2, f3_local3, f3_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function MeteoriteBeast_468000_Act02(f4_arg0, f4_arg1, f4_arg2)
    local f4_local0 = 5
    local f4_local1 = 3001
    local f4_local2 = 3033
    local f4_local3 = 6
    local f4_local4 = 0
    local f4_local5 = 120
    local f4_local6 = f4_arg0:GetOriginDist(TARGET_ENE_0)
    local f4_local7 = f4_arg0:GetRandam_Int(1, 100)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16470)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16471)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16450)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16495)
    if f4_arg0:HasSpecialEffectId(TARGET_SELF, 16495) and f4_local6 > 3 then
        local f4_local8 = 11.5 - f4_arg0:GetMapHitRadius(TARGET_SELF)
        local f4_local9 = 999
        local f4_local10 = 999
        local f4_local11 = 0
        local f4_local12 = 0
        local f4_local13 = 4
        local f4_local14 = 4
        Approach_Act_Flex(f4_arg0, f4_arg1, f4_local8, f4_local9, f4_local10, f4_local11, f4_local12, f4_local13, f4_local14)
        f4_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f4_local0, f4_local2, TARGET_ENE_0, f4_local3, f4_local4, f4_local5, 0, 0)
    else
        local f4_local8 = 6.2 - f4_arg0:GetMapHitRadius(TARGET_SELF)
        local f4_local9 = 999
        local f4_local10 = 999
        local f4_local11 = 0
        local f4_local12 = 0
        local f4_local13 = 4
        local f4_local14 = 4
        Approach_Act_Flex(f4_arg0, f4_arg1, f4_local8, f4_local9, f4_local10, f4_local11, f4_local12, f4_local13, f4_local14)
        f4_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f4_local0, f4_local1, TARGET_ENE_0, f4_local3, f4_local4, f4_local5, 0, 0)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function MeteoriteBeast_468000_Act03(f5_arg0, f5_arg1, f5_arg2)
    local f5_local0 = f5_arg0:GetOriginDist(TARGET_ENE_0)
    local f5_local1 = 4.9 - f5_arg0:GetMapHitRadius(TARGET_SELF)
    local f5_local2 = 999
    local f5_local3 = 999
    local f5_local4 = 0
    local f5_local5 = 0
    local f5_local6 = 4
    local f5_local7 = 4
    Approach_Act_Flex(f5_arg0, f5_arg1, f5_local1, f5_local2, f5_local3, f5_local4, f5_local5, f5_local6, f5_local7)
    local f5_local8 = 5
    local f5_local9 = 3004
    local f5_local10 = 6
    local f5_local11 = 0
    local f5_local12 = 120
    local f5_local13 = f5_arg0:GetRandam_Int(1, 100)
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16470)
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16471)
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16452)
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16455)
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16463)
    f5_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f5_local8, f5_local9, TARGET_ENE_0, f5_local10, f5_local11, f5_local12, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function MeteoriteBeast_468000_Act04(f6_arg0, f6_arg1, f6_arg2)
    local f6_local0 = 5
    local f6_local1 = 3006
    local f6_local2 = 6
    local f6_local3 = 0
    local f6_local4 = 180
    local f6_local5 = f6_arg0:GetRandam_Int(1, 100)
    f6_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f6_local0, f6_local1, TARGET_ENE_0, f6_local2, f6_local3, f6_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function MeteoriteBeast_468000_Act05(f7_arg0, f7_arg1, f7_arg2)
    local f7_local0 = 5
    local f7_local1 = 3007
    local f7_local2 = 6
    local f7_local3 = 0
    local f7_local4 = 120
    local f7_local5 = f7_arg0:GetRandam_Int(1, 100)
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16470)
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16471)
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16461)
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16477)
    f7_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f7_local0, f7_local1, TARGET_ENE_0, f7_local2, f7_local3, f7_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function MeteoriteBeast_468000_Act06(f8_arg0, f8_arg1, f8_arg2)
    f8_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16470)
    f8_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16471)
    f8_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16456)
    f8_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3008, TARGET_ENE_0, DIST_None, 0, 90)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function MeteoriteBeast_468000_Act07(f9_arg0, f9_arg1, f9_arg2)
    f9_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16470)
    f9_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16471)
    f9_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3009, TARGET_ENE_0, DIST_None, 0, 90)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function MeteoriteBeast_468000_Act08(f10_arg0, f10_arg1, f10_arg2)
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16470)
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16471)
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16465)
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16478)
    f10_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3010, TARGET_SELF, DIST_None, 0, 90)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function MeteoriteBeast_468000_Act09(f11_arg0, f11_arg1, f11_arg2)
    local f11_local0 = 19 - f11_arg0:GetMapHitRadius(TARGET_SELF)
    local f11_local1 = 999
    local f11_local2 = 999
    local f11_local3 = 0
    local f11_local4 = 0
    local f11_local5 = 4
    local f11_local6 = 4
    Approach_Act_Flex(f11_arg0, f11_arg1, f11_local0, f11_local1, f11_local2, f11_local3, f11_local4, f11_local5, f11_local6)
    local f11_local7 = 5
    local f11_local8 = 3011
    local f11_local9 = 6
    local f11_local10 = 2
    local f11_local11 = 120
    local f11_local12 = f11_arg0:GetRandam_Int(1, 100)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16470)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16471)
    f11_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f11_local7, f11_local8, TARGET_ENE_0, f11_local9, f11_local10, f11_local11, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function MeteoriteBeast_468000_Act10(f12_arg0, f12_arg1, f12_arg2)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16470)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16471)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16472)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16473)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16474)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16475)
    f12_arg0:SetStringIndexedNumber("Rush_Cnt", 0)
    f12_arg0:SetStringIndexedNumber("Curve_Cnt", 0)
    local f12_local0 = 15
    local f12_local1 = 3012
    local f12_local2 = 5 - f12_arg0:GetMapHitRadius(TARGET_SELF)
    local f12_local3 = 2
    local f12_local4 = 120
    f12_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f12_local0, f12_local1, TARGET_ENE_0, f12_local2, f12_local3, f12_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function MeteoriteBeast_468000_Act11(f13_arg0, f13_arg1, f13_arg2)
    f13_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16470)
    f13_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16471)
    f13_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16460)
    local f13_local0 = f13_arg0:GetOriginDist(TARGET_ENE_0)
    local f13_local1 = 8 - f13_arg0:GetMapHitRadius(TARGET_SELF)
    local f13_local2 = 999
    local f13_local3 = 999
    local f13_local4 = 0
    local f13_local5 = 0
    local f13_local6 = 3
    local f13_local7 = 3
    Approach_Act_Flex(f13_arg0, f13_arg1, f13_local1, f13_local2, f13_local3, f13_local4, f13_local5, f13_local6, f13_local7)
    local f13_local8 = 10
    local f13_local9 = 3015
    local f13_local10 = 5 - f13_arg0:GetMapHitRadius(TARGET_SELF)
    local f13_local11 = 0
    local f13_local12 = 120
    f13_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f13_local8, f13_local9, TARGET_ENE_0, f13_local10, f13_local11, f13_local12, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function MeteoriteBeast_468000_Act12(f14_arg0, f14_arg1, f14_arg2)
    f14_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16462)
    local f14_local0 = 15
    local f14_local1 = 3016
    local f14_local2 = 5 - f14_arg0:GetMapHitRadius(TARGET_SELF)
    local f14_local3 = 0
    local f14_local4 = 180
    f14_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f14_local0, f14_local1, TARGET_ENE_0, f14_local2, f14_local3, f14_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function MeteoriteBeast_468000_Act13(f15_arg0, f15_arg1, f15_arg2)
    f15_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f15_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    Rollingx_Cnt = 0
    local f15_local0 = 10
    local f15_local1 = 3012
    local f15_local2 = 5 - f15_arg0:GetMapHitRadius(TARGET_SELF)
    local f15_local3 = 0
    local f15_local4 = 120
    f15_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f15_local0, f15_local1, TARGET_ENE_0, f15_local2, f15_local3, f15_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function MeteoriteBeast_468000_Act14(f16_arg0, f16_arg1, f16_arg2)
    f16_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16495)
    local f16_local0 = 10
    local f16_local1 = 3018
    local f16_local2 = 3026
    local f16_local3 = 5 - f16_arg0:GetMapHitRadius(TARGET_SELF)
    local f16_local4 = 0
    local f16_local5 = 120
    if f16_arg0:HasSpecialEffectId(TARGET_SELF, 16495) then
        f16_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f16_local0, f16_local1, TARGET_SELF, f16_local3, f16_local4, f16_local5, 0, 0)
        GetWellSpace_Odds = 0
        return GetWellSpace_Odds
    else
        f16_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f16_local0, f16_local2, TARGET_SELF, f16_local3, f16_local4, f16_local5, 0, 0)
        GetWellSpace_Odds = 0
        return GetWellSpace_Odds
    end
    
end

function MeteoriteBeast_468000_Act15(f17_arg0, f17_arg1, f17_arg2)
    f17_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16481)
    f17_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16480)
    f17_arg0:SetStringIndexedNumber("Warcry_Cnt", 0)
    local f17_local0 = 10
    local f17_local1 = 3030
    local f17_local2 = 5 - f17_arg0:GetMapHitRadius(TARGET_SELF)
    local f17_local3 = 0
    local f17_local4 = 120
    f17_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f17_local0, f17_local1, TARGET_ENE_0, f17_local2, f17_local3, f17_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function MeteoriteBeast_468000_Act16(f18_arg0, f18_arg1, f18_arg2)
    local f18_local0 = 5
    local f18_local1 = 3020
    local f18_local2 = 5 - f18_arg0:GetMapHitRadius(TARGET_SELF)
    local f18_local3 = 0
    local f18_local4 = 0
    f18_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f18_local1, TARGET_ENE_0, f18_local2, f18_local3, f18_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function MeteoriteBeast_468000_Act17(f19_arg0, f19_arg1, f19_arg2)
    f19_arg1:AddSubGoal(GOAL_COMMON_Turn, 2, TARGET_ENE_0, 120, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function MeteoriteBeast_468000_Act18(f20_arg0, f20_arg1, f20_arg2)
    local f20_local0 = 5
    local f20_local1 = 3023
    local f20_local2 = 6
    local f20_local3 = 0
    local f20_local4 = 120
    local f20_local5 = f20_arg0:GetRandam_Int(1, 100)
    f20_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f20_local0, f20_local1, TARGET_ENE_0, f20_local2, f20_local3, f20_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function MeteoriteBeast_468000_Act19(f21_arg0, f21_arg1, f21_arg2)
    local f21_local0 = 5
    local f21_local1 = 3027
    local f21_local2 = 5 - f21_arg0:GetMapHitRadius(TARGET_SELF)
    local f21_local3 = 0
    local f21_local4 = 0
    f21_arg0:SetTimer(6, 18)
    f21_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f21_local0, f21_local1, TARGET_ENE_0, f21_local2, f21_local3, f21_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function MeteoriteBeast_468000_Act20(f22_arg0, f22_arg1, f22_arg2)
    local f22_local0 = 5
    local f22_local1 = 3028
    local f22_local2 = 5 - f22_arg0:GetMapHitRadius(TARGET_SELF)
    local f22_local3 = 0
    local f22_local4 = 0
    f22_arg0:SetTimer(6, 18)
    f22_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f22_local0, f22_local1, TARGET_ENE_0, f22_local2, f22_local3, f22_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function MeteoriteBeast_468000_Act22(f23_arg0, f23_arg1, f23_arg2)
    local f23_local0 = f23_arg0:GetOriginDist(TARGET_ENE_0)
    local f23_local1 = 8
    local f23_local2 = 0
    local f23_local3 = true
    local f23_local4 = f23_arg0:GetRandam_Int(1, 100)
    local f23_local5 = -1
    f23_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 8, TARGET_ENE_0, f23_local1, TARGET_ENE_0, f23_local3, f23_local5)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function MeteoriteBeast_468000_Act23(f24_arg0, f24_arg1, f24_arg2)
    f24_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16470)
    f24_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16471)
    local f24_local0 = f24_arg0:GetRandam_Int(1, 100)
    local f24_local1 = -1
    if f24_arg0:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_R, 180) then
        f24_arg1:AddSubGoal(GOAL_COMMON_ApproachAround, f24_arg0:GetRandam_Int(3, 5), TARGET_ENE_0, 0, TARGET_SELF, true, -1, AI_DIR_TYPE_ToL, f24_arg0:GetRandam_Int(15, 20))
    else
        f24_arg1:AddSubGoal(GOAL_COMMON_ApproachAround, f24_arg0:GetRandam_Int(3, 5), TARGET_ENE_0, 0, TARGET_SELF, true, -1, AI_DIR_TYPE_ToR, f24_arg0:GetRandam_Int(15, 20))
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function MeteoriteBeast_468000_Act24(f25_arg0, f25_arg1, f25_arg2)
    f25_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16470)
    f25_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16471)
    f25_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16459)
    f25_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16495)
    local f25_local0 = 5
    local f25_local1 = -1
    local f25_local2 = 1
    local f25_local3 = -1
    local f25_local4 = -1
    local f25_local5 = TARGET_ENE_0
    local f25_local6 = 3
    local f25_local7 = 0
    local f25_local8 = true
    f25_arg0:SetTimer(2, 20)
    f25_arg1:AddSubGoal(GOAL_COMMON_StepSafety, f25_local0, f25_local1, f25_local2, f25_local3, f25_local4, f25_local5, f25_local6, f25_local7, f25_local8)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function MeteoriteBeast_468000_Act26(f26_arg0, f26_arg1, f26_arg2)
    f26_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16470)
    f26_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16471)
    f26_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16464)
    local f26_local0 = 5
    local f26_local1 = -1
    local f26_local2 = -1
    local f26_local3 = 1
    local f26_local4 = 1
    local f26_local5 = TARGET_ENE_0
    local f26_local6 = 3
    local f26_local7 = 0
    local f26_local8 = true
    f26_arg0:SetTimer(2, 20)
    f26_arg1:AddSubGoal(GOAL_COMMON_StepSafety, f26_local0, f26_local1, f26_local2, f26_local3, f26_local4, f26_local5, f26_local6, f26_local7, f26_local8)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function MeteoriteBeast_468000_Act27(f27_arg0, f27_arg1, f27_arg2)
    f27_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16470)
    f27_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16471)
    f27_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16464)
    local f27_local0 = 5
    local f27_local1 = -1
    local f27_local2 = -1
    local f27_local3 = 1
    local f27_local4 = 1
    local f27_local5 = TARGET_ENE_0
    local f27_local6 = 3
    local f27_local7 = 0
    local f27_local8 = true
    f27_arg0:SetTimer(2, 20)
    f27_arg1:AddSubGoal(GOAL_COMMON_StepSafety, f27_local0, f27_local1, f27_local2, f27_local3, f27_local4, f27_local5, f27_local6, f27_local7, f27_local8)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function MeteoriteBeast_468000_Act28(f28_arg0, f28_arg1, f28_arg2)
    local f28_local0 = 11.5 - f28_arg0:GetMapHitRadius(TARGET_SELF)
    local f28_local1 = 999
    local f28_local2 = 999
    local f28_local3 = 0
    local f28_local4 = 0
    local f28_local5 = 4
    local f28_local6 = 4
    Approach_Act_Flex(f28_arg0, f28_arg1, f28_local0, f28_local1, f28_local2, f28_local3, f28_local4, f28_local5, f28_local6)
    local f28_local7 = 5
    local f28_local8 = 3033
    local f28_local9 = 6
    local f28_local10 = 0
    local f28_local11 = 120
    local f28_local12 = f28_arg0:GetRandam_Int(1, 100)
    f28_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16470)
    f28_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16471)
    f28_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16450)
    f28_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f28_local7, f28_local8, TARGET_ENE_0, f28_local9, f28_local10, f28_local11, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function MeteoriteBeast_468000_Act29(f29_arg0, f29_arg1, f29_arg2)
    local f29_local0 = 11 - f29_arg0:GetMapHitRadius(TARGET_SELF)
    local f29_local1 = 999
    local f29_local2 = 999
    local f29_local3 = 0
    local f29_local4 = 0
    local f29_local5 = 4
    local f29_local6 = 4
    Approach_Act_Flex(f29_arg0, f29_arg1, f29_local0, f29_local1, f29_local2, f29_local3, f29_local4, f29_local5, f29_local6)
    local f29_local7 = 5
    local f29_local8 = 3034
    local f29_local9 = 6
    local f29_local10 = 0
    local f29_local11 = 120
    local f29_local12 = f29_arg0:GetRandam_Int(1, 100)
    f29_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f29_local7, f29_local8, TARGET_ENE_0, f29_local9, f29_local10, f29_local11, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function MeteoriteBeast_468000_Act30(f30_arg0, f30_arg1, f30_arg2)
    local f30_local0 = f30_arg0:GetOriginDist(TARGET_ENE_0)
    local f30_local1 = 4.9 - f30_arg0:GetMapHitRadius(TARGET_SELF)
    local f30_local2 = 999
    local f30_local3 = 999
    local f30_local4 = 0
    local f30_local5 = 0
    local f30_local6 = 4
    local f30_local7 = 4
    Approach_Act_Flex(f30_arg0, f30_arg1, f30_local1, f30_local2, f30_local3, f30_local4, f30_local5, f30_local6, f30_local7)
    local f30_local8 = 5
    local f30_local9 = 3004
    local f30_local10 = 6
    local f30_local11 = 0
    local f30_local12 = 120
    local f30_local13 = f30_arg0:GetRandam_Int(1, 100)
    f30_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f30_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16484)
    f30_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f30_local8, f30_local9, TARGET_ENE_0, f30_local10, f30_local11, f30_local12, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function MeteoriteBeast_468000_Act41(f31_arg0, f31_arg1, f31_arg2)
    f31_arg0:SetTimer(0, 15)
    local f31_local0 = 5
    local f31_local1 = 3006
    local f31_local2 = 6
    local f31_local3 = 0
    local f31_local4 = 180
    local f31_local5 = f31_arg0:GetRandam_Int(1, 100)
    f31_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f31_local0, f31_local1, TARGET_ENE_0, f31_local2, f31_local3, f31_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function MeteoriteBeast_468000_Act42(f32_arg0, f32_arg1, f32_arg2)
    f32_arg0:SetTimer(0, 15)
    f32_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16481)
    f32_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 16480)
    f32_arg0:SetStringIndexedNumber("Warcry_Cnt", 0)
    local f32_local0 = 10
    local f32_local1 = 3030
    local f32_local2 = 5 - f32_arg0:GetMapHitRadius(TARGET_SELF)
    local f32_local3 = 0
    local f32_local4 = 120
    f32_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f32_local0, f32_local1, TARGET_ENE_0, f32_local2, f32_local3, f32_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function MeteoriteBeast_468000_ActAfter_AdjustSpace(f33_arg0, f33_arg1, f33_arg2)
    f33_arg1:AddSubGoal(GOAL_MeteoriteBeast_468000_AfterAttackAct, 10)
    
end

Goal.Update = function (f34_arg0, f34_arg1, f34_arg2)
    return Update_Default_NoSubGoal(f34_arg0, f34_arg1, f34_arg2)
    
end

Goal.Terminate = function (f35_arg0, f35_arg1, f35_arg2)
    
end

Goal.Interrupt = function (f36_arg0, f36_arg1, f36_arg2)
    local f36_local0 = 5 - f36_arg1:GetMapHitRadius(TARGET_SELF)
    local f36_local1 = 0
    local f36_local2 = 20
    local f36_local3 = f36_arg1:GetOriginDist(TARGET_ENE_0)
    local f36_local4 = f36_arg1:GetRandam_Int(1, 100)
    local f36_local5 = STEP_CANCELDIST
    f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16470)
    f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16471)
    f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16472)
    f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16473)
    f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16474)
    f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16475)
    f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16495)
    f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16484)
    f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16466)
    f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16467)
    local f36_local6 = f36_arg1:HasSpecialEffectId(TARGET_SELF, 16495)
    if f36_arg1:IsInterupt(INTERUPT_Damaged) then
        local f36_local7 = f36_arg1:GetOriginDist(TARGET_ENE_0)
        local f36_local8 = f36_arg1:GetRandam_Int(1, 100)
        if (f36_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_BR, 110, 120, 4) or f36_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_BL, 110, 120, 4)) and f36_arg1:GetTimer(6) > 0 == false and f36_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_B, 50, 120, 4) == false and f36_arg1:HasSpecialEffectId(TARGET_SELF, 16484) == false and f36_local8 > 40 then
            f36_arg1:SetTimer(6, 18)
            if f36_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_BR, 110, 120, 4) then
                f36_arg2:ClearSubGoal()
                f36_arg2:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, 3027, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            elseif f36_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_BL, 110, 120, 4) then
                f36_arg2:ClearSubGoal()
                f36_arg2:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, 3028, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            end
        end
    end
    if f36_arg1:HasSpecialEffectId(TARGET_SELF, 16466) then
        local f36_local7 = f36_arg1:GetOriginDist(TARGET_ENE_0)
        local f36_local8 = f36_arg1:GetRandam_Int(1, 100)
        if f36_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_F, 240) and f36_local7 < 14 then
            f36_arg2:ClearSubGoal()
            f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 5, 3023, TARGET_ENE_0, 4, 0, 90)
            return true
        end
    end
    if f36_arg1:HasSpecialEffectId(TARGET_SELF, 16467) then
        local f36_local7 = f36_arg1:GetOriginDist(TARGET_ENE_0)
        local f36_local8 = f36_arg1:GetRandam_Int(1, 100)
        if f36_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_F, 240) and f36_local7 < 14 then
            f36_arg2:ClearSubGoal()
            f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 5, 3006, TARGET_ENE_0, 4, 0, 90)
            return true
        end
    end
    if f36_arg1:HasSpecialEffectId(TARGET_SELF, 16450) then
        local f36_local7 = f36_arg1:GetOriginDist(TARGET_ENE_0)
        local f36_local8 = f36_arg1:GetRandam_Int(1, 100)
        if f36_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_R, 90) and f36_local7 < 9 then
            f36_arg2:ClearSubGoal()
            f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 5, 3025, TARGET_ENE_0, 4, 0, 90)
            return true
        elseif f36_local7 <= 9 then
            f36_arg2:ClearSubGoal()
            f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 5, 3022, TARGET_ENE_0, 4, 0, 90)
            return true
        elseif f36_local7 <= 11 then
            f36_arg2:ClearSubGoal()
            f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16451)
            f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16491)
            f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 5, 3002, TARGET_ENE_0, 4, 0, 90)
            return true
        end
    end
    if f36_arg1:HasSpecialEffectId(TARGET_SELF, 16451) then
        local f36_local7 = f36_arg1:GetOriginDist(TARGET_ENE_0)
        local f36_local8 = f36_arg1:GetRandam_Int(1, 100)
        f36_arg2:ClearSubGoal()
        f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 5, 3003, TARGET_ENE_0, 4, 0, 90)
        return true
    end
    if f36_arg1:HasSpecialEffectId(TARGET_SELF, 16452) then
        local f36_local7 = f36_arg1:GetOriginDist(TARGET_ENE_0)
        local f36_local8 = f36_arg1:GetRandam_Int(1, 100)
        if f36_local7 <= 10.5 then
            f36_arg2:ClearSubGoal()
            f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16455)
            f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 5, 3005, TARGET_ENE_0, 4, 0, 90)
        end
    end
    if f36_arg1:HasSpecialEffectId(TARGET_SELF, 16463) then
        local f36_local7 = f36_arg1:GetOriginDist(TARGET_ENE_0)
        local f36_local8 = f36_arg1:GetRandam_Int(1, 100)
        if f36_local7 <= 9 and f36_local8 > 30 then
            f36_arg2:ClearSubGoal()
            f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 5, 3015, TARGET_ENE_0, 4, 0, 90)
            return true
        end
    end
    if f36_arg1:HasSpecialEffectId(TARGET_SELF, 16455) then
        local f36_local7 = f36_arg1:GetOriginDist(TARGET_ENE_0)
        local f36_local8 = f36_arg1:GetRandam_Int(1, 100)
        if f36_local7 > 10 then
            if f36_arg1:HasSpecialEffectId(TARGET_SELF, 16495) then
                if f36_local8 > 70 then
                    f36_arg2:ClearSubGoal()
                    f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 5, 3023, TARGET_ENE_0, 4, 0, 90)
                    return true
                else
                    f36_arg2:ClearSubGoal()
                    f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 5, 3034, TARGET_ENE_0, 4, 0, 90)
                    return true
                end
            else
                f36_arg2:ClearSubGoal()
                f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 5, 3023, TARGET_ENE_0, 4, 0, 90)
                return true
            end
        elseif f36_local7 > 6 then
            f36_arg2:ClearSubGoal()
            f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 5, 3023, TARGET_ENE_0, 4, 0, 90)
            return true
        elseif f36_local8 > 50 then
            f36_arg2:ClearSubGoal()
            f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 5, 3008, TARGET_ENE_0, 4, 0, 90)
            return true
        else
            f36_arg2:ClearSubGoal()
            f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 5, 3023, TARGET_ENE_0, 4, 0, 90)
            return true
        end
    end
    if f36_arg1:HasSpecialEffectId(TARGET_SELF, 16478) then
        local f36_local7 = f36_arg1:GetOriginDist(TARGET_ENE_0)
        local f36_local8 = f36_arg1:GetRandam_Int(1, 100)
        if f36_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_B, 120, 120, 15) then
            f36_arg2:ClearSubGoal()
            f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 5, 3024, TARGET_SELF, 4, 0, 90)
            return true
        end
    end
    if f36_arg1:HasSpecialEffectId(TARGET_SELF, 16465) then
        local f36_local7 = f36_arg1:GetOriginDist(TARGET_ENE_0)
        local f36_local8 = f36_arg1:GetRandam_Int(1, 100)
        if f36_local8 > 20 then
            f36_arg2:ClearSubGoal()
            f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 5, 3023, TARGET_SELF, 4, 0, 90)
            return true
        end
    end
    if f36_arg1:HasSpecialEffectId(TARGET_SELF, 16456) then
        local f36_local7 = f36_arg1:GetOriginDist(TARGET_ENE_0)
        local f36_local8 = f36_arg1:GetRandam_Int(1, 100)
        if f36_local7 <= 6.5 then
            if f36_local8 > 60 then
                f36_arg2:ClearSubGoal()
                f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 5, 3009, TARGET_ENE_0, 4, 0, 90)
                return true
            else
                f36_arg2:ClearSubGoal()
                f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16469)
                f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 5, 3029, TARGET_ENE_0, 4, 0, 90)
                return true
            end
        end
    end
    if f36_arg1:HasSpecialEffectId(TARGET_SELF, 16469) and f36_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_FR, 100, 120, 3) then
        local f36_local7 = f36_arg1:GetOriginDist(TARGET_ENE_0)
        local f36_local8 = f36_arg1:GetRandam_Int(1, 100)
        f36_arg2:ClearSubGoal()
        f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 5, 3025, TARGET_SELF, 4, 0, 90)
        return true
    end
    if f36_arg1:HasSpecialEffectId(TARGET_SELF, 16008) then
        local f36_local7 = f36_arg1:GetOriginDist(TARGET_ENE_0)
        local f36_local8 = f36_arg1:GetRandam_Int(1, 100)
        if f36_local7 < 9 then
            if f36_local8 < 50 then
                f36_arg2:ClearSubGoal()
                f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16051)
                f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16055)
                f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 5, 3009, TARGET_ENE_0, 4, 0, 180)
                return true
            elseif f36_local8 < 75 then
                f36_arg2:ClearSubGoal()
                f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 5, 3002, TARGET_ENE_0, 4, 0, 0, 180)
                return true
            end
        end
    end
    if f36_arg1:HasSpecialEffectId(TARGET_SELF, 16460) then
        local f36_local7 = f36_arg1:GetOriginDist(TARGET_ENE_0)
        local f36_local8 = f36_arg1:GetRandam_Int(1, 100)
        if f36_local8 > 50 and f36_local7 < 11 then
            f36_arg2:ClearSubGoal()
            f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 5, 3009, TARGET_ENE_0, 4, 0, 0, 180)
            return true
        elseif f36_local8 > 40 and f36_local7 < 10 then
            f36_arg2:ClearSubGoal()
            local f36_local9 = 5
            local f36_local10 = -1
            local f36_local11 = 1
            local f36_local12 = -1
            local f36_local13 = -1
            local f36_local14 = TARGET_ENE_0
            local f36_local15 = 3
            local f36_local16 = 0
            local f36_local17 = true
            f36_arg2:AddSubGoal(GOAL_COMMON_StepSafety, f36_local9, f36_local10, f36_local11, f36_local12, f36_local13, f36_local14, f36_local15, f36_local16, f36_local17)
            return true
        elseif f36_local8 > 30 and f36_local7 < 10 then
            f36_arg2:ClearSubGoal()
            local f36_local9 = 5
            local f36_local10 = -1
            local f36_local11 = -1
            local f36_local12 = 1
            local f36_local13 = -1
            local f36_local14 = TARGET_ENE_0
            local f36_local15 = 3
            local f36_local16 = 0
            local f36_local17 = true
            f36_arg2:AddSubGoal(GOAL_COMMON_StepSafety, f36_local9, f36_local10, f36_local11, f36_local12, f36_local13, f36_local14, f36_local15, f36_local16, f36_local17)
            return true
        elseif f36_local8 > 20 and f36_local7 < 10 then
            f36_arg2:ClearSubGoal()
            local f36_local9 = 5
            local f36_local10 = -1
            local f36_local11 = -1
            local f36_local12 = -1
            local f36_local13 = 1
            local f36_local14 = TARGET_ENE_0
            local f36_local15 = 3
            local f36_local16 = 0
            local f36_local17 = true
            f36_arg2:AddSubGoal(GOAL_COMMON_StepSafety, f36_local9, f36_local10, f36_local11, f36_local12, f36_local13, f36_local14, f36_local15, f36_local16, f36_local17)
            return true
        end
    end
    if f36_arg1:HasSpecialEffectId(TARGET_SELF, 16462) then
        local f36_local7 = f36_arg1:GetOriginDist(TARGET_ENE_0)
        local f36_local8 = f36_arg1:GetRandam_Int(1, 100)
        if f36_local7 < 14 then
            f36_arg2:ClearSubGoal()
            f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 15, 3007, TARGET_ENE_0, 0, 0, 0, 0, 0)
            return true
        end
    end
    if f36_arg1:HasSpecialEffectId(TARGET_SELF, 16464) then
        local f36_local7 = f36_arg1:GetOriginDist(TARGET_ENE_0)
        local f36_local8 = f36_arg1:GetRandam_Int(1, 100)
        if f36_local7 >= 10 then
            if f36_local8 > 60 and f36_arg1:GetTimer(8) > 0 == false then
                f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16481)
                f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16480)
                f36_arg1:SetStringIndexedNumber("Warcry_Cnt", 0)
                f36_arg2:ClearSubGoal()
                f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 5, 3030, TARGET_ENE_0, 4, 0, 90)
                return true
            elseif f36_local8 > 50 then
                f36_arg2:ClearSubGoal()
                local f36_local9 = f36_arg1:GetOriginDist(TARGET_ENE_0)
                local f36_local10 = 6.2 - f36_arg1:GetMapHitRadius(TARGET_SELF)
                local f36_local11 = 999
                local f36_local12 = 999
                local f36_local13 = 0
                local f36_local14 = 0
                local f36_local15 = 3
                local f36_local16 = 3
                Approach_Act_Flex(f36_arg1, f36_arg2, f36_local10, f36_local11, f36_local12, f36_local13, f36_local14, f36_local15, f36_local16)
                local f36_local17 = 5
                local f36_local18 = 3001
                local f36_local19 = 6
                local f36_local20 = 0
                local f36_local21 = 120
                local f36_local22 = f36_arg1:GetRandam_Int(1, 100)
                f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16470)
                f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16471)
                f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16450)
                f36_arg2:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f36_local17, f36_local18, TARGET_ENE_0, f36_local19, f36_local20, f36_local21, 0, 0)
                return true
            elseif f36_local8 > 30 then
                f36_arg2:ClearSubGoal()
                local f36_local9 = f36_arg1:GetOriginDist(TARGET_ENE_0)
                local f36_local10 = 19 - f36_arg1:GetMapHitRadius(TARGET_SELF)
                local f36_local11 = 0
                local f36_local12 = 999
                local f36_local13 = 0
                local f36_local14 = 0
                local f36_local15 = 3
                local f36_local16 = 3
                Approach_Act_Flex(f36_arg1, f36_arg2, f36_local10, f36_local11, f36_local12, f36_local13, f36_local14, f36_local15, f36_local16)
                local f36_local17 = 5
                local f36_local18 = 3011
                local f36_local19 = 6
                local f36_local20 = 2
                local f36_local21 = 120
                local f36_local22 = f36_arg1:GetRandam_Int(1, 100)
                f36_arg2:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f36_local17, f36_local18, TARGET_ENE_0, f36_local19, f36_local20, f36_local21, 0, 0)
                return true
            elseif f36_arg1:GetTimer(4) > 0 == false then
                f36_arg2:ClearSubGoal()
                f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16470)
                f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16471)
                f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16472)
                f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16473)
                f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16474)
                f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16475)
                f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16495)
                f36_arg1:SetStringIndexedNumber("Rush_Cnt", 0)
                local f36_local9 = 10
                local f36_local10 = 3012
                local f36_local11 = 5 - f36_arg1:GetMapHitRadius(TARGET_SELF)
                local f36_local12 = 2
                local f36_local13 = 90
                f36_arg2:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f36_local9, f36_local10, TARGET_ENE_0, f36_local11, f36_local12, f36_local13, 0, 0)
                return true
            end
        else
            f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16495)
            if f36_local8 > 70 then
                local f36_local9 = 10
                local f36_local10 = 3018
                local f36_local11 = 3026
                local f36_local12 = 5 - f36_arg1:GetMapHitRadius(TARGET_SELF)
                local f36_local13 = 0
                local f36_local14 = 120
                if f36_arg1:HasSpecialEffectId(TARGET_SELF, 16495) then
                    f36_arg2:ClearSubGoal()
                    f36_arg2:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f36_local9, f36_local10, TARGET_SELF, f36_local12, f36_local13, f36_local14, 0, 0)
                    return true
                else
                    f36_arg2:ClearSubGoal()
                    f36_arg2:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f36_local9, f36_local11, TARGET_SELF, f36_local12, f36_local13, f36_local14, 0, 0)
                    return true
                end
            elseif f36_local8 > 40 then
                f36_arg2:ClearSubGoal()
                local f36_local9 = 5
                local f36_local10 = 3007
                local f36_local11 = 6
                local f36_local12 = 0
                local f36_local13 = 120
                local f36_local14 = f36_arg1:GetRandam_Int(1, 100)
                f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16470)
                f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16471)
                f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16461)
                f36_arg2:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f36_local9, f36_local10, TARGET_ENE_0, f36_local11, f36_local12, f36_local13, 0, 0)
                return true
            else
                f36_arg2:ClearSubGoal()
                local f36_local9 = f36_arg1:GetOriginDist(TARGET_ENE_0)
                local f36_local10 = 3
                local f36_local11 = 999
                local f36_local12 = 999
                local f36_local13 = 0
                local f36_local14 = 0
                local f36_local15 = 3
                local f36_local16 = 3
                Approach_Act_Flex(f36_arg1, f36_arg2, f36_local10, f36_local11, f36_local12, f36_local13, f36_local14, f36_local15, f36_local16)
                local f36_local17 = 5
                local f36_local18 = 3001
                local f36_local19 = 6
                local f36_local20 = 0
                local f36_local21 = 120
                local f36_local22 = f36_arg1:GetRandam_Int(1, 100)
                f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16470)
                f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16471)
                f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16450)
                f36_arg2:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f36_local17, f36_local18, TARGET_ENE_0, f36_local19, f36_local20, f36_local21, 0, 0)
                return true
            end
        end
    end
    if f36_arg1:HasSpecialEffectId(TARGET_SELF, 16459) then
        f36_arg2:ClearSubGoal()
        f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16470)
        f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16471)
        f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16472)
        f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16473)
        f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16474)
        f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16475)
        f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16495)
        f36_arg1:SetStringIndexedNumber("Rush_Cnt", 0)
        local f36_local7 = 10
        local f36_local8 = 3012
        local f36_local9 = 5 - f36_arg1:GetMapHitRadius(TARGET_SELF)
        local f36_local10 = 2
        local f36_local11 = 90
        f36_arg2:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f36_local7, f36_local8, TARGET_ENE_0, f36_local9, f36_local10, f36_local11, 0, 0)
        return true
    end
    if f36_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f36_arg1:GetSpecialEffectActivateInterruptId(16470) then
        f36_arg2:ClearSubGoal()
        local f36_local7 = f36_arg1:GetOriginDist(TARGET_ENE_0)
        f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16470)
        f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16471)
        f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16472)
        f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16473)
        f36_arg1:SetStringIndexedNumber("Rush_Cnt", f36_arg1:GetStringIndexedNumber("Rush_Cnt") + 1)
        f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 5, 3013, TARGET_ENE_0, 0, 0, 0, 0, 0)
        return true
    end
    f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16470)
    f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16471)
    f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16472)
    f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16473)
    f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16495)
    if f36_arg1:HasSpecialEffectId(TARGET_SELF, 16471) then
        local f36_local7 = f36_arg1:GetOriginDist(TARGET_ENE_0)
        local f36_local8 = f36_arg1:GetRandam_Int(1, 100)
        if f36_arg1:GetStringIndexedNumber("Rush_Cnt") > 4 then
            f36_arg2:ClearSubGoal()
            f36_arg1:SetTimer(4, 35)
            f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3014, TARGET_ENE_0, 0, 0, 0, 0, 0)
            return true
        elseif f36_arg1:GetStringIndexedNumber("Curve_Cnt") >= 2 then
            if f36_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_F, 180) and f36_local7 <= 17 or f36_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_B, 180) then
                f36_arg2:ClearSubGoal()
                f36_arg1:SetTimer(4, 35)
                f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3014, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            else
                f36_arg2:ClearSubGoal()
                f36_arg1:SetStringIndexedNumber("Rush_Cnt", f36_arg1:GetStringIndexedNumber("Rush_Cnt") + 1)
                f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3013, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            end
        elseif f36_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_F, 180) or f36_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_B, 180, 90, 7) then
            f36_arg2:ClearSubGoal()
            f36_arg1:SetStringIndexedNumber("Rush_Cnt", f36_arg1:GetStringIndexedNumber("Rush_Cnt") + 1)
            f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3013, TARGET_ENE_0, 0, 0, 0, 0, 0)
            return true
        else
            f36_arg2:ClearSubGoal()
            f36_arg1:SetStringIndexedNumber("Rush_Cnt", 0)
            f36_arg1:SetStringIndexedNumber("Curve_Cnt", f36_arg1:GetStringIndexedNumber("Curve_Cnt") + 1)
            f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3021, TARGET_ENE_0, 0, 0, 0, 0, 0)
            return true
        end
    end
    if f36_arg1:HasSpecialEffectId(TARGET_SELF, 16472) then
        local f36_local7 = f36_arg1:GetRandam_Int(1, 100)
        local f36_local8 = f36_arg1:GetOriginDist(TARGET_ENE_0)
        if f36_local6 == true then
            if f36_arg1:GetStringIndexedNumber("Curve_Cnt") > 1 and f36_local7 > 30 then
                f36_arg2:ClearSubGoal()
                f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16474)
                f36_arg1:SetTimer(4, 35)
                f36_arg1:SetStringIndexedNumber("Rush_Cnt", 0)
                f36_arg1:SetStringIndexedNumber("Curve_Cnt", 0)
                f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 5, 3017, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            elseif f36_arg1:GetStringIndexedNumber("Curve_Cnt") > 2 then
                f36_arg2:ClearSubGoal()
                f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16474)
                f36_arg1:SetTimer(4, 35)
                f36_arg1:SetStringIndexedNumber("Rush_Cnt", 0)
                f36_arg1:SetStringIndexedNumber("Curve_Cnt", 0)
                f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 5, 3017, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            end
        end
    end
    if f36_arg1:HasSpecialEffectId(TARGET_SELF, 16474) then
        local f36_local7 = f36_arg1:GetOriginDist(TARGET_ENE_0)
        f36_arg2:ClearSubGoal()
        f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 5, 3031, TARGET_ENE_0, 0, 0, 0, 0, 0)
        return true
    end
    if f36_arg1:HasSpecialEffectId(TARGET_SELF, 16475) then
        local f36_local7 = f36_arg1:GetRandam_Int(1, 100)
        local f36_local8 = f36_arg1:GetOriginDist(TARGET_ENE_0)
        f36_arg2:ClearSubGoal()
        f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3032, TARGET_ENE_0, 0, 0, 0, 0, 0)
        return true
    end
    if f36_arg1:HasSpecialEffectId(TARGET_SELF, 16473) then
        local f36_local7 = f36_arg1:GetOriginDist(TARGET_ENE_0)
        local f36_local8 = f36_arg1:GetRandam_Int(1, 100)
        if f36_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_B, 180) and f36_arg1:GetStringIndexedNumber("Curve_Cnt") < 3 then
            f36_arg2:ClearSubGoal()
            f36_arg1:SetStringIndexedNumber("Rush_Cnt", 0)
            f36_arg1:SetStringIndexedNumber("Curve_Cnt", f36_arg1:GetStringIndexedNumber("Curve_Cnt") + 1)
            f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16470)
            f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16471)
            f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16472)
            f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16473)
            f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3021, TARGET_ENE_0, 0, 0, 0, 0, 0)
            return true
        elseif f36_arg1:GetStringIndexedNumber("Curve_Cnt") >= 3 and f36_local7 < 17 then
            f36_arg2:ClearSubGoal()
            f36_arg1:SetTimer(4, 35)
            f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16470)
            f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16471)
            f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16472)
            f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16473)
            f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3014, TARGET_ENE_0, 0, 0, 0, 0, 0)
            return true
        else
            f36_arg2:ClearSubGoal()
            f36_arg1:SetStringIndexedNumber("Rush_Cnt", f36_arg1:GetStringIndexedNumber("Rush_Cnt") + 1)
            f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16470)
            f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16471)
            f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16472)
            f36_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16473)
            f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3013, TARGET_ENE_0, 0, 0, 0, 0, 0)
            return true
        end
    end
    if f36_arg1:HasSpecialEffectId(TARGET_SELF, 16480) then
        local f36_local7 = f36_arg1:GetRandam_Int(1, 100)
        local f36_local8 = f36_arg1:GetOriginDist(TARGET_ENE_0)
        f36_arg2:ClearSubGoal()
        f36_arg1:SetStringIndexedNumber("Warcry_Cnt", f36_arg1:GetStringIndexedNumber("Warcry_Cnt") + 1)
        f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3019, TARGET_ENE_0, 0, 0, 0, 0, 0)
        return true
    end
    if f36_arg1:HasSpecialEffectId(TARGET_SELF, 16481) then
        local f36_local7 = f36_arg1:GetRandam_Int(1, 100)
        local f36_local8 = f36_arg1:GetOriginDist(TARGET_ENE_0)
        if f36_arg1:GetStringIndexedNumber("Warcry_Cnt") <= 1 then
            f36_arg2:ClearSubGoal()
            f36_arg1:SetStringIndexedNumber("Warcry_Cnt", f36_arg1:GetStringIndexedNumber("Warcry_Cnt") + 1)
            f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3019, TARGET_ENE_0, 0, 0, 0, 0, 0)
            return true
        else
            f36_arg2:ClearSubGoal()
            f36_arg1:SetStringIndexedNumber("Warcry_Cnt", 0)
            f36_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3035, TARGET_ENE_0, 0, 0, 0, 0, 0)
            return true
        end
    end
    return false
    
end

RegisterTableGoal(GOAL_MeteoriteBeast_468000_AfterAttackAct, "MeteoriteBeast_468000_AfterAttackAct")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_MeteoriteBeast_468000_AfterAttackAct, true)

Goal.Activate = function (f37_arg0, f37_arg1, f37_arg2)
    
end

Goal.Update = function (f38_arg0, f38_arg1, f38_arg2)
    return Update_Default_NoSubGoal(f38_arg0, f38_arg1, f38_arg2)
    
end


