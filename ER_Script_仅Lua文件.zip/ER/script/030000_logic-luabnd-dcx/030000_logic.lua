﻿function npc30000_Logic(f1_arg0)
    local f1_local0 = f1_arg0:GetEventRequest(0)
    local f1_local1 = f1_arg0:GetEventRequest(1)
    local f1_local2 = f1_arg0:GetDist(TARGET_ENE_0)
    local f1_local3 = f1_arg0:GetDist(TARGET_HOSTPLAYER)
    local f1_local4 = nil
    local f1_local5 = f1_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__battleGoalID)
    local f1_local6 = f1_arg0:IsBattleState()
    f1_arg0:SetStringIndexedNumber("IsApproachingHost", 0)
    if COMMON_EasySetup_Initial(f1_arg0) == false then
        if f1_local6 == true and f1_arg0:HasSpecialEffectId(TARGET_ENE_0, 13945) == true then
            f1_local6 = false
        end
        if f1_local0 == 10 then
            if f1_local3 <= 3 then
                f1_arg0:AddTopGoal(GOAL_COMMON_LeaveTarget, 2, TARGET_HOSTPLAYER, 999, TARGET_SELF, true, -1)
            elseif f1_arg0:GetDist(POINT_EVENT) <= 0.3 then
                f1_arg0:AddTopGoal(GOAL_COMMON_Wait, 0.5, TARGET_SELF)
            else
                f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 2, POINT_EVENT, 0.3, TARGET_SELF, false, -1)
            end
        elseif f1_local0 == 80 then
            f1_arg0:AddTopGoal(GOAL_COMMON_Wait, 0.5, TARGET_NONE)
            f1_arg0:AddTopGoal(GOAL_COMMON_WaitWithAnime, 10, 1000 + f1_local1, TARGET_NONE)
        elseif f1_local3 >= 22 then
            f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 2, TARGET_HOSTPLAYER, 2, TARGET_SELF, false, -1)
            f1_arg0:SetStringIndexedNumber("IsApproachingHost", 1)
        elseif f1_local3 >= 15 then
            if f1_local6 == true then
                if f1_local2 >= 6 then
                    f1_arg0:AddTopGoal(GOAL_COMMON_SidewayMove, 2, TARGET_ENE_0, f1_arg0:GetRandam_Int(0, 1), f1_arg0:GetRandam_Int(30, 45), true, true, -1)
                    f1_arg0:SetStringIndexedNumber("IsApproachingHost", 1)
                else
                    f1_local4 = f1_arg0:AddTopGoal(f1_local5, -1)
                end
            else
                f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 2, TARGET_HOSTPLAYER, 2, TARGET_SELF, false, -1)
                f1_arg0:SetStringIndexedNumber("IsApproachingHost", 1)
            end
        elseif f1_local3 >= 5 then
            if f1_local6 == true then
                if f1_local2 >= 15 then
                    f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 2, TARGET_HOSTPLAYER, 2, TARGET_SELF, false, -1)
                    f1_arg0:SetStringIndexedNumber("IsApproachingHost", 1)
                else
                    f1_local4 = f1_arg0:AddTopGoal(f1_local5, -1)
                end
            else
                f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 2, TARGET_HOSTPLAYER, 2, TARGET_SELF, false, -1)
                f1_arg0:SetStringIndexedNumber("IsApproachingHost", 1)
            end
        elseif f1_local3 >= 2 then
            if f1_local6 == true then
                if f1_local2 >= 15 then
                    f1_arg0:AddTopGoal(GOAL_COMMON_Wait, 0.5, TARGET_SELF)
                else
                    f1_local4 = f1_arg0:AddTopGoal(f1_local5, -1)
                end
            else
                f1_arg0:AddTopGoal(GOAL_COMMON_Wait, 0.5, TARGET_SELF)
            end
        elseif f1_local6 == true then
            if f1_local2 > 15 then
                f1_arg0:AddTopGoal(GOAL_COMMON_LeaveTarget, 2, TARGET_HOSTPLAYER, 999, TARGET_SELF, true, -1)
            else
                f1_local4 = f1_arg0:AddTopGoal(f1_local5, -1)
            end
        else
            f1_arg0:AddTopGoal(GOAL_COMMON_LeaveTarget, 2, TARGET_HOSTPLAYER, 999, TARGET_SELF, true, -1)
        end
        if f1_local4 then
            f1_local4:SetManagementGoal()
        end
    end
    
end

function npc30000_Interupt(f2_arg0, f2_arg1)
    if f2_arg0:IsLadderAct(TARGET_SELF) then
        return false
    end
    if (f2_arg0:IsInterupt(INTERUPT_MovedEnd_OnFailedPath) or f2_arg0:IsInterupt(INTERUPT_FindUnfavorableFailedPoint)) and f2_arg0:GetStringIndexedNumber("IsApproachingHost") == 1 then
        if f2_arg0:IsBattleState() then
            local f2_local0 = f2_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__battleGoalID)
            f2_arg1:ClearSubGoal()
            addedBattleGoal = f2_arg0:AddTopGoal(f2_local0, -1)
            addedBattleGoal:SetManagementGoal()
        else
            f2_arg1:ClearSubGoal()
            f2_arg0:AddTopGoal(GOAL_COMMON_SideWay_On_FailedPath_WhiteGhost, 10, 1)
            return true
        end
    end
    return false
    
end


