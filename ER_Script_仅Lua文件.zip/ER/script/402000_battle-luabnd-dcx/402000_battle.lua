﻿RegisterTableGoal(GOAL_HorriblenessGrub402000_Battle, "HorriblenessGrub402000_Battle")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_HorriblenessGrub402000_Battle, true)

Goal.Initialize = function (f1_arg0, f1_arg1, f1_arg2, f1_arg3)
    f1_arg1:SetNumber(1, 2)
    f1_arg1:SetNumber(5, 0)
    f1_arg1:SetNumber(3, 0)
    f1_arg1:SetNumber(4, 0)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3000)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3001)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3002)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3003)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3004)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3005)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3006)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3007)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3008)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3011)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3019)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3020)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3021)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3022)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3023)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3024)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3028)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3030)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3031)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3032)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3033)
    
end

Goal.Activate = function (f2_arg0, f2_arg1, f2_arg2)
    Init_Pseudo_Global(f2_arg1, f2_arg2)
    f2_arg1:SetStringIndexedNumber("Dist_SideStep", 5)
    f2_arg1:SetStringIndexedNumber("Dist_BackStep", 5)
    f2_arg1:GetStringIndexedNumber("Handstand_Cnt")
    local f2_local0 = {}
    local f2_local1 = {}
    local f2_local2 = {}
    Common_Clear_Param(f2_local0, f2_local1, f2_local2)
    local f2_local3 = f2_arg1:GetDist(TARGET_ENE_0)
    local f2_local4 = f2_arg1:GetRandam_Int(1, 100)
    local f2_local5 = f2_arg1:GetRandam_Int(1, 10)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16650)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16651)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16652)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16653)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16654)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16655)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16656)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16657)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16658)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16659)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16660)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16661)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16652)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16663)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16664)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16665)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16666)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16667)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16668)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16669)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16670)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16671)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16672)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16673)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16674)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16675)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    local f2_local6 = f2_arg1:HasSpecialEffectId(TARGET_SELF, 16683)
    f2_arg1:SetNumber(6, 0)
    f2_arg1:SetNumber(7, 0)
    f2_arg1:SetNumber(10, 0)
    if f2_arg1:HasSpecialEffectId(TARGET_SELF, 5030) or f2_arg1:HasSpecialEffectId(TARGET_SELF, 5031) or f2_arg1:HasSpecialEffectId(TARGET_SELF, 5032) then
        if f2_arg1:HasSpecialEffectId(TARGET_SELF, 5030) then
            if f2_local6 == true then
                if f2_local3 < 3 then
                    f2_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 20, 3017, TARGET_ENE_0, 999, 0, 0)
                else
                    f2_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 20, 3013, TARGET_ENE_0, 999, 0, 0)
                end
            else
                f2_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 20, 3013, TARGET_ENE_0, 999, 0, 0)
            end
        elseif f2_arg1:HasSpecialEffectId(TARGET_SELF, 5031) then
            if f2_local4 < 40 then
                f2_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 20, 3031, TARGET_ENE_0, 999, 0, 0)
            elseif f2_local4 < 70 then
                f2_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 20, 3033, TARGET_ENE_0, 999, 0, 0)
            else
                f2_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 20, 3016, TARGET_ENE_0, 999, 0, 0)
            end
        elseif f2_arg1:HasSpecialEffectId(TARGET_SELF, 5032) then
            if f2_local4 < 50 then
                f2_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 20, 3030, TARGET_ENE_0, 999, 0, 0)
            else
                f2_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 20, 3016, TARGET_ENE_0, 999, 0, 0)
            end
        end
    end
    if f2_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_B, 140) then
        if f2_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_L, 180) and f2_local3 <= 3 then
            f2_local0[4] = 45
            f2_local0[8] = 15
            f2_local0[9] = 15
            f2_local0[14] = 10
            f2_local0[17] = 35
        elseif f2_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_R, 180) and f2_local3 <= 3 then
            f2_local0[3] = 45
            f2_local0[8] = 15
            f2_local0[9] = 15
            f2_local0[13] = 10
            f2_local0[17] = 35
        else
            f2_local0[17] = 20
        end
    elseif f2_local3 >= 18 then
        f2_local0[8] = 70
        f2_local0[9] = 70
        f2_local0[16] = 30
    elseif f2_local3 >= 15 then
        f2_local0[1] = 10
        f2_local0[5] = 10
        f2_local0[7] = 30
        f2_local0[8] = 10
        f2_local0[9] = 10
        f2_local0[16] = 15
    elseif f2_local3 >= 10 then
        if f2_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_F, 100) then
            f2_local0[5] = 20
            f2_local0[7] = 30
            f2_local0[8] = 30
            f2_local0[9] = 30
        else
            f2_local0[1] = 20
            f2_local0[2] = 25
            f2_local0[5] = 10
            f2_local0[7] = 30
            f2_local0[8] = 30
            f2_local0[9] = 30
            f2_local0[20] = 10
        end
    elseif f2_local3 >= 6 then
        if f2_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_F, 100) then
            f2_local0[2] = 10
            f2_local0[5] = 20
            f2_local0[7] = 30
            f2_local0[8] = 30
            f2_local0[9] = 30
            f2_local0[13] = 18
            f2_local0[14] = 12
        else
            f2_local0[1] = 20
            f2_local0[2] = 30
            f2_local0[5] = 10
            f2_local0[7] = 10
            f2_local0[8] = 15
            f2_local0[9] = 15
            f2_local0[10] = 10
            f2_local0[13] = 18
            f2_local0[14] = 12
            f2_local0[15] = 20
            f2_local0[20] = 15
        end
    else
        f2_local0[1] = 20
        f2_local0[2] = 20
        f2_local0[8] = 15
        f2_local0[9] = 15
        f2_local0[10] = 15
        f2_local0[13] = 30
        f2_local0[14] = 20
        f2_local0[20] = 10
    end
    f2_local0[8] = SetCoolTime(f2_arg1, f2_arg2, 3013, 30, f2_local0[8], 0)
    f2_local0[9] = SetCoolTime(f2_arg1, f2_arg2, 3017, f2_arg1:GetRandam_Int(10, 15), f2_local0[9], 0)
    f2_local0[10] = SetCoolTime(f2_arg1, f2_arg2, 3004, 15, f2_local0[10], 1)
    f2_local0[13] = SetCoolTime(f2_arg1, f2_arg2, 6002, 10, f2_local0[13], 1)
    f2_local0[13] = SetCoolTime(f2_arg1, f2_arg2, 6003, 10, f2_local0[13], 1)
    f2_local0[13] = SetCoolTime(f2_arg1, f2_arg2, 6002, 10, f2_local0[14], 1)
    f2_local0[13] = SetCoolTime(f2_arg1, f2_arg2, 6003, 10, f2_local0[14], 1)
    f2_local0[14] = SetCoolTime(f2_arg1, f2_arg2, 6002, 10, f2_local0[13], 1)
    f2_local0[14] = SetCoolTime(f2_arg1, f2_arg2, 6003, 10, f2_local0[13], 1)
    f2_local0[14] = SetCoolTime(f2_arg1, f2_arg2, 6002, 10, f2_local0[14], 1)
    f2_local0[14] = SetCoolTime(f2_arg1, f2_arg2, 6003, 10, f2_local0[14], 1)
    if f2_local6 == false then
        f2_local0[9] = 0
    else
        f2_local0[8] = f2_local0[8] / 5
        f2_local0[9] = f2_local0[9] * 7
    end
    f2_local1[1] = REGIST_FUNC(f2_arg1, f2_arg2, HorriblenessGrub402000_Act01)
    f2_local1[2] = REGIST_FUNC(f2_arg1, f2_arg2, HorriblenessGrub402000_Act02)
    f2_local1[3] = REGIST_FUNC(f2_arg1, f2_arg2, HorriblenessGrub402000_Act03)
    f2_local1[4] = REGIST_FUNC(f2_arg1, f2_arg2, HorriblenessGrub402000_Act04)
    f2_local1[5] = REGIST_FUNC(f2_arg1, f2_arg2, HorriblenessGrub402000_Act05)
    f2_local1[7] = REGIST_FUNC(f2_arg1, f2_arg2, HorriblenessGrub402000_Act07)
    f2_local1[8] = REGIST_FUNC(f2_arg1, f2_arg2, HorriblenessGrub402000_Act08)
    f2_local1[9] = REGIST_FUNC(f2_arg1, f2_arg2, HorriblenessGrub402000_Act09)
    f2_local1[10] = REGIST_FUNC(f2_arg1, f2_arg2, HorriblenessGrub402000_Act10)
    f2_local1[13] = REGIST_FUNC(f2_arg1, f2_arg2, HorriblenessGrub402000_Act13)
    f2_local1[14] = REGIST_FUNC(f2_arg1, f2_arg2, HorriblenessGrub402000_Act14)
    f2_local1[15] = REGIST_FUNC(f2_arg1, f2_arg2, HorriblenessGrub402000_Act15)
    f2_local1[16] = REGIST_FUNC(f2_arg1, f2_arg2, HorriblenessGrub402000_Act16)
    f2_local1[17] = REGIST_FUNC(f2_arg1, f2_arg2, HorriblenessGrub402000_Act17)
    f2_local1[20] = REGIST_FUNC(f2_arg1, f2_arg2, HorriblenessGrub402000_Act20)
    f2_local1[30] = REGIST_FUNC(f2_arg1, f2_arg2, HorriblenessGrub402000_Act30)
    local f2_local7 = REGIST_FUNC(f2_arg1, f2_arg2, HorriblenessGrub402000_ActAfter_AdjustSpace)
    Common_Battle_Activate(f2_arg1, f2_arg2, f2_local0, f2_local1, f2_local7, f2_local2)
    
end

function HorriblenessGrub402000_Act01(f3_arg0, f3_arg1, f3_arg2)
    local f3_local0 = 6
    local f3_local1 = 15
    local f3_local2 = 30
    local f3_local3 = 30
    local f3_local4 = 0
    local f3_local5 = 4
    local f3_local6 = 8
    Approach_Act_Flex(f3_arg0, f3_arg1, f3_local0, f3_local1, f3_local2, f3_local3, f3_local4, f3_local5, f3_local6)
    local f3_local7 = 5
    local f3_local8 = 3000
    local f3_local9 = 6
    local f3_local10 = 2
    local f3_local11 = 90
    local f3_local12 = f3_arg0:GetRandam_Int(1, 100)
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f3_local7, f3_local8, TARGET_ENE_0, f3_local9, f3_local10, f3_local11, 0, 0)
    if InsideRange(f3_arg0, f3_arg1, 135, 60, 0, 6) then
        actPerArr[3] = 50
    end
    if InsideRange(f3_arg0, f3_arg1, 135, 60, 0, 6) then
        actPerArr[4] = 50
    end
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function HorriblenessGrub402000_Act02(f4_arg0, f4_arg1, f4_arg2)
    local f4_local0 = 8
    local f4_local1 = 15
    local f4_local2 = 30
    local f4_local3 = 30
    local f4_local4 = 0
    local f4_local5 = 4
    local f4_local6 = 8
    Approach_Act_Flex(f4_arg0, f4_arg1, f4_local0, f4_local1, f4_local2, f4_local3, f4_local4, f4_local5, f4_local6)
    local f4_local7 = f4_arg0:GetDist(TARGET_ENE_0)
    local f4_local8 = 5
    local f4_local9 = 3006
    local f4_local10 = 6
    local f4_local11 = 3
    local f4_local12 = 90
    local f4_local13 = f4_arg0:GetRandam_Int(1, 100)
    f4_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f4_local8, f4_local9, TARGET_ENE_0, f4_local10, f4_local11, f4_local12, 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function HorriblenessGrub402000_Act03(f5_arg0, f5_arg1, f5_arg2)
    local f5_local0 = f5_arg0:GetDist(TARGET_ENE_0)
    local f5_local1 = 5
    local f5_local2 = 3007
    local f5_local3 = 6
    local f5_local4 = 9
    local f5_local5 = 180
    local f5_local6 = f5_arg0:GetRandam_Int(1, 100)
    f5_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, f5_local1, f5_local2, TARGET_ENE_0, 0, 0, 0, 0, 0)
    if InsideRange(f5_arg0, f5_arg1, 135, 60, 0, 6) then
        actPerArr[3] = 50
    end
    if InsideRange(f5_arg0, f5_arg1, 135, 60, 0, 6) then
        actPerArr[4] = 50
    end
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function HorriblenessGrub402000_Act04(f6_arg0, f6_arg1, f6_arg2)
    local f6_local0 = f6_arg0:GetDist(TARGET_ENE_0)
    local f6_local1 = 5
    local f6_local2 = 3008
    local f6_local3 = 6
    local f6_local4 = 9
    local f6_local5 = 180
    local f6_local6 = f6_arg0:GetRandam_Int(1, 100)
    f6_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, f6_local1, f6_local2, TARGET_ENE_0, 0, 0, 0, 0, 0)
    if InsideRange(f6_arg0, f6_arg1, 135, 60, 0, 6) then
        actPerArr[3] = 50
    end
    if InsideRange(f6_arg0, f6_arg1, 135, 60, 0, 6) then
        actPerArr[4] = 50
    end
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function HorriblenessGrub402000_Act05(f7_arg0, f7_arg1, f7_arg2)
    local f7_local0 = f7_arg0:GetRandam_Int(1, 100)
    local f7_local1 = 15
    local f7_local2 = 3005
    local f7_local3 = 999 - f7_arg0:GetMapHitRadius(TARGET_SELF)
    local f7_local4 = 2
    local f7_local5 = 60
    f7_arg0:SetTimer(5, 0)
    f7_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f7_local1, f7_local2, TARGET_ENE_0, f7_local3, f7_local4, f7_local5, 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function HorriblenessGrub402000_Act07(f8_arg0, f8_arg1, f8_arg2)
    local f8_local0 = 10
    local f8_local1 = 3
    local f8_local2 = 30
    local f8_local3 = 3011
    local f8_local4 = f8_arg0:GetRandam_Int(1, 100)
    f8_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, Life, f8_local3, TARGET_ENE_0, f8_local0, f8_local1, f8_local2, 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function HorriblenessGrub402000_Act08(f9_arg0, f9_arg1, f9_arg2)
    f9_arg0:SetNumber(1, 1)
    local f9_local0 = 5
    local f9_local1 = 3015
    local f9_local2 = 6
    local f9_local3 = 0
    local f9_local4 = 180
    local f9_local5 = f9_arg0:GetRandam_Int(1, 100)
    f9_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, f9_local1, TARGET_ENE_0, 999, f9_local3, f9_local4, 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function HorriblenessGrub402000_Act09(f10_arg0, f10_arg1, f10_arg2)
    f10_arg0:SetNumber(1, 1)
    local f10_local0 = 5
    local f10_local1 = 3015
    local f10_local2 = 6
    local f10_local3 = 0
    local f10_local4 = 180
    local f10_local5 = f10_arg0:GetRandam_Int(1, 100)
    f10_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, f10_local1, TARGET_ENE_0, 999, f10_local3, f10_local4, 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function HorriblenessGrub402000_Act10(f11_arg0, f11_arg1, f11_arg2)
    local f11_local0 = f11_arg0:GetDist(TARGET_ENE_0)
    local f11_local1 = 3004
    if f11_local0 <= 3 then
        local f11_local2 = 5
        local f11_local3 = -1
        local f11_local4 = 1
        local f11_local5 = -1
        local f11_local6 = -1
        local f11_local7 = TARGET_ENE_0
        local f11_local8 = 3
        local f11_local9 = 0
        local f11_local10 = true
        f11_arg1:AddSubGoal(GOAL_COMMON_StepSafety, f11_local2, f11_local3, f11_local4, f11_local5, f11_local6, f11_local7, f11_local8, f11_local9, f11_local10)
    end
    f11_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f11_local1, TARGET_ENE_0, DIST_None, 5, 90)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function HorriblenessGrub402000_Act13(f12_arg0, f12_arg1, f12_arg2)
    local f12_local0 = f12_arg0:GetRandam_Int(1, 100)
    local f12_local1 = 5
    local f12_local2 = -1
    local f12_local3 = -1
    local f12_local4 = 1
    local f12_local5 = -1
    local f12_local6 = TARGET_ENE_0
    local f12_local7 = 3
    local f12_local8 = 0
    local f12_local9 = false
    f12_arg1:AddSubGoal(GOAL_COMMON_StepSafety, f12_local1, f12_local2, f12_local3, f12_local4, f12_local5, f12_local6, f12_local7, f12_local8, f12_local9)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function HorriblenessGrub402000_Act14(f13_arg0, f13_arg1, f13_arg2)
    local f13_local0 = f13_arg0:GetRandam_Int(1, 100)
    local f13_local1 = 5
    local f13_local2 = -1
    local f13_local3 = -1
    local f13_local4 = -1
    local f13_local5 = 1
    local f13_local6 = TARGET_ENE_0
    local f13_local7 = 3
    local f13_local8 = 0
    local f13_local9 = false
    f13_arg1:AddSubGoal(GOAL_COMMON_StepSafety, f13_local1, f13_local2, f13_local3, f13_local4, f13_local5, f13_local6, f13_local7, f13_local8, f13_local9)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function HorriblenessGrub402000_Act15(f14_arg0, f14_arg1, f14_arg2)
    local f14_local0 = f14_arg0:GetDist(TARGET_ENE_0)
    local f14_local1 = 10
    local f14_local2 = 12
    local f14_local3 = 0
    local f14_local4 = f14_arg0:GetRandam_Int(1, 100)
    local f14_local5 = -1
    if f14_local4 <= f14_local3 then
        f14_local5 = 9910
    end
    if f14_local1 <= f14_local0 then
        Approach_Act(f14_arg0, f14_arg1, f14_local1, f14_local2, f14_local3, 3)
    end
    f14_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 2, TARGET_ENE_0, f14_local1, TARGET_ENE_0, true, f14_local5)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function HorriblenessGrub402000_Act16(f15_arg0, f15_arg1, f15_arg2)
    local f15_local0 = f15_arg0:GetRandam_Int(1, 100)
    f15_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f15_arg0:GetRandam_Int(1.5, 3.5), TARGET_ENE_0, 7, TARGET_SELF, true, -1, AI_DIR_TYPE_ToL, f15_arg0:GetRandam_Int(3, 8))
    f15_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, f15_arg0:GetRandam_Int(1.5, 3.5), TARGET_ENE_0, 7, TARGET_SELF, true, -1, AI_DIR_TYPE_ToR, f15_arg0:GetRandam_Int(3, 8))
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function HorriblenessGrub402000_Act17(f16_arg0, f16_arg1, f16_arg2)
    f16_arg1:AddSubGoal(GOAL_COMMON_Turn, 2, TARGET_ENE_0, 90, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function HorriblenessGrub402000_Act20(f17_arg0, f17_arg1, f17_arg2)
    local f17_local0 = 5
    local f17_local1 = -1
    local f17_local2 = 1
    local f17_local3 = -1
    local f17_local4 = -1
    local f17_local5 = TARGET_ENE_0
    local f17_local6 = 3
    local f17_local7 = 0
    local f17_local8 = true
    f17_arg1:AddSubGoal(GOAL_COMMON_StepSafety, f17_local0, f17_local1, f17_local2, f17_local3, f17_local4, f17_local5, f17_local6, f17_local7, f17_local8)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function HorriblenessGrub402000_Act30(f18_arg0, f18_arg1, f18_arg2)
    f18_arg0:SetNumber(5, 1)
    local f18_local0 = 5
    local f18_local1 = 20016
    local f18_local2 = 6
    local f18_local3 = 0
    local f18_local4 = 180
    local f18_local5 = f18_arg0:GetRandam_Int(1, 100)
    f18_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, f18_local1, TARGET_SELF, 999, f18_local3, f18_local4, 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function HorriblenessGrub402000_ActAfter_AdjustSpace(f19_arg0, f19_arg1, f19_arg2)
    f19_arg1:AddSubGoal(GOAL_HorriblenessGrub402000_AfterAttackAct, 10)
    
end

Goal.Update = function (f20_arg0, f20_arg1, f20_arg2)
    return Update_Default_NoSubGoal(f20_arg0, f20_arg1, f20_arg2)
    
end

Goal.Terminate = function (f21_arg0, f21_arg1, f21_arg2)
    
end

Goal.Interrupt = function (f22_arg0, f22_arg1, f22_arg2)
    local f22_local0 = f22_arg1:GetRandam_Int(1, 100)
    local f22_local1 = f22_arg1:GetDist(TARGET_ENE_0)
    f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16650)
    f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16651)
    f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16652)
    f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16653)
    f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16654)
    f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16655)
    f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16656)
    f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16657)
    f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16658)
    f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16659)
    f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16660)
    f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16661)
    f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16652)
    f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16663)
    f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16664)
    f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16665)
    f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16666)
    f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16667)
    f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16668)
    f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16669)
    f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16670)
    f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16671)
    f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16672)
    f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16673)
    f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16674)
    f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16675)
    local f22_local2 = f22_arg1:HasSpecialEffectId(TARGET_SELF, 16683)
    if f22_arg1:IsLadderAct(TARGET_SELF) then
        return false
    end
    if f22_arg1:HasSpecialEffectId(TARGET_SELF, 5110) == true or f22_arg1:HasSpecialEffectAttribute(TARGET_SELF, SP_EFFECT_TYPE_SLEEP) == true then
        return false
    end
    if f22_arg1:HasSpecialEffectId(TARGET_SELF, 16666) or f22_arg1:HasSpecialEffectId(TARGET_SELF, 16658) then
        if f22_arg1:HasSpecialEffectId(TARGET_SELF, 16666) then
            f22_arg1:SetNumber(10, 1)
        end
        if f22_arg1:HasSpecialEffectId(TARGET_SELF, 16658) then
            f22_arg1:SetNumber(10, 2)
        end
        local f22_local3 = 3
        local f22_local4 = f22_arg1:GetRandam_Int(1, 100)
        local f22_local5 = 999 - f22_arg1:GetMapHitRadius(TARGET_SELF)
        local f22_local6 = 0
        local f22_local7 = 0
        local f22_local8 = f22_arg1:GetMapHitRadius(TARGET_SELF)
        local f22_local9 = f22_arg1:GetDist(TARGET_ENE_0)
        local f22_local10 = f22_arg1:GetRelativeAngleFromTarget(TARGET_ENE_0)
        if f22_local3 < f22_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToL, f22_local3 + f22_local8, f22_local8, 0) and f22_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_L, 180, 90, 999) == false and f22_arg1:GetNumber(7) ~= 1 and f22_local4 > 50 then
            f22_arg2:ClearSubGoal()
            local f22_local11 = f22_arg1:GetRandam_Int(1, 100)
            local f22_local12 = 5
            local f22_local13 = -1
            local f22_local14 = -1
            local f22_local15 = 1
            local f22_local16 = -1
            local f22_local17 = TARGET_ENE_0
            local f22_local18 = 3
            local f22_local19 = 0
            local f22_local20 = false
            f22_arg2:AddSubGoal(GOAL_COMMON_StepSafety, f22_local12, f22_local13, f22_local14, f22_local15, f22_local16, f22_local17, f22_local18, f22_local19, f22_local20)
            f22_arg1:SetNumber(7, 1)
            local f22_local21 = f22_arg1:GetDist(TARGET_ENE_0)
            local f22_local22 = f22_arg1:GetRandam_Int(1, 100)
            select_Attack1 = 3031
            select_Attack2 = 3033
            select_Attack3 = 3000
            select_Attack4 = 3016
            selectFate_1 = 5
            selectFate_2 = 5
            selectFate_3 = 0
            selectFate_4 = 5
            warpDist_1 = 3
            warpDist_2 = 7
            warpDist_3 = 3
            warpDist_4 = 3
            local f22_local23 = 999 - f22_arg1:GetMapHitRadius(TARGET_SELF)
            local f22_local24 = 0
            local f22_local25 = 0
            local f22_local26 = f22_arg1:GetMapHitRadius(TARGET_SELF)
            local f22_local27 = f22_arg1:GetDist(TARGET_ENE_0)
            local f22_local28 = f22_arg1:GetRelativeAngleFromTarget(TARGET_ENE_0)
            if warpDist_1 >= f22_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToBL, warpDist_1 + f22_local26, f22_local26, 0) then
                selectFate_1 = 0
            end
            if warpDist_2 >= f22_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToBL, warpDist_2 + f22_local26, f22_local26, 0) then
                selectFate_2 = 0
            end
            if warpDist_3 >= f22_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToBL, warpDist_3 + f22_local26, f22_local26, 0) then
                selectFate_3 = 0
            end
            if warpDist_4 >= f22_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToBL, warpDist_4 + f22_local26, f22_local26, 0) then
                selectFate_4 = 0
            end
            local f22_local29 = f22_arg1:GetRandam_Int(0, selectFate_1 + selectFate_2 + selectFate_3 + selectFate_4)
            local f22_local30 = AI_DIR_TYPE_ToL
            local f22_local31 = 0
            local f22_local32 = fall_Attack
            local f22_local33 = TARGET_ENE_0
            if selectFate_1 + selectFate_2 + selectFate_3 + selectFate_4 == 0 then
                f22_arg1:SetNumber(6, 1)
            elseif selectFate_1 ~= 0 and f22_local29 <= selectFate_1 then
                f22_local30 = AI_DIR_TYPE_ToBL
                f22_local31 = warpDist_1
                f22_local32 = select_Attack1
                f22_local33 = TARGET_ENE_0
            elseif selectFate_2 ~= 0 and f22_local29 <= selectFate_1 + selectFate_2 then
                f22_local30 = AI_DIR_TYPE_ToBL
                f22_local31 = warpDist_2
                f22_local32 = select_Attack2
                f22_local33 = TARGET_ENE_0
            elseif selectFate_3 ~= 0 and f22_local29 <= selectFate_1 + selectFate_2 + selectFate_3 then
                f22_local30 = AI_DIR_TYPE_ToBL
                f22_local31 = warpDist_3
                f22_local32 = select_Attack3
                f22_local33 = TARGET_ENE_0
            elseif selectFate_4 ~= 0 and f22_local29 <= selectFate_1 + selectFate_2 + selectFate_3 + selectFate_4 then
                f22_local30 = AI_DIR_TYPE_ToBL
                f22_local31 = warpDist_4
                f22_local32 = select_Attack4
                f22_local33 = TARGET_ENE_0
            end
            if f22_arg1:GetNumber(6) ~= 0 then
                f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat_SuccessAngle180, 10, 3014, TARGET_ENE_0, f22_local23, 0, 0)
            else
                f22_arg2:AddSubGoal(GOAL_COMMON_ToTargetWarp, 10, TARGET_ENE_0, f22_local30, f22_local31, f22_local33, 5, -2)
                f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat_SuccessAngle180, 10, f22_local32, TARGET_ENE_0, 999, 0, 0)
                if f22_local32 == select_Attack4 then
                    f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat_SuccessAngle180, 10, 3004, TARGET_ENE_0, 999, 0, 0)
                end
            end
        elseif f22_local3 < f22_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToR, f22_local3 + f22_local8, f22_local8, 0) and f22_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_R, 180, 90, 999) == false and f22_arg1:GetNumber(7) ~= 1 and f22_local4 > 50 then
            f22_arg2:ClearSubGoal()
            local f22_local11 = f22_arg1:GetRandam_Int(1, 100)
            local f22_local12 = 5
            local f22_local13 = -1
            local f22_local14 = -1
            local f22_local15 = -1
            local f22_local16 = 1
            local f22_local17 = TARGET_ENE_0
            local f22_local18 = 3
            local f22_local19 = 0
            local f22_local20 = false
            f22_arg2:AddSubGoal(GOAL_COMMON_StepSafety, f22_local12, f22_local13, f22_local14, f22_local15, f22_local16, f22_local17, f22_local18, f22_local19, f22_local20)
            f22_arg1:SetNumber(7, 1)
            local f22_local21 = f22_arg1:GetDist(TARGET_ENE_0)
            local f22_local22 = f22_arg1:GetRandam_Int(1, 100)
            select_Attack1 = 3030
            select_Attack2 = 3035
            select_Attack3 = 3000
            select_Attack4 = 3016
            selectFate_1 = 5
            selectFate_2 = 0
            selectFate_3 = 0
            selectFate_4 = 5
            warpDist_1 = 3
            warpDist_2 = 7
            warpDist_3 = 3
            warpDist_4 = 3
            local f22_local23 = 999 - f22_arg1:GetMapHitRadius(TARGET_SELF)
            local f22_local24 = 0
            local f22_local25 = 0
            local f22_local26 = f22_arg1:GetMapHitRadius(TARGET_SELF)
            local f22_local27 = f22_arg1:GetDist(TARGET_ENE_0)
            local f22_local28 = f22_arg1:GetRelativeAngleFromTarget(TARGET_ENE_0)
            if warpDist_1 >= f22_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToBR, warpDist_1 + f22_local26, f22_local26, 0) then
                selectFate_1 = 0
            end
            if warpDist_2 >= f22_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToBR, warpDist_2 + f22_local26, f22_local26, 0) then
                selectFate_2 = 0
            end
            if warpDist_3 >= f22_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToBR, warpDist_3 + f22_local26, f22_local26, 0) then
                selectFate_3 = 0
            end
            if warpDist_4 >= f22_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToBR, warpDist_4 + f22_local26, f22_local26, 0) then
                selectFate_4 = 0
            end
            local f22_local29 = f22_arg1:GetRandam_Int(0, selectFate_1 + selectFate_2 + selectFate_3 + selectFate_4)
            local f22_local30 = AI_DIR_TYPE_ToR
            local f22_local31 = 0
            local f22_local32 = fall_Attack
            local f22_local33 = TARGET_ENE_0
            if selectFate_1 + selectFate_2 + selectFate_3 + selectFate_4 == 0 then
                f22_arg1:SetNumber(6, 1)
            elseif selectFate_1 ~= 0 and f22_local29 <= selectFate_1 then
                f22_local30 = AI_DIR_TYPE_ToBR
                f22_local31 = warpDist_1
                f22_local32 = select_Attack1
                f22_local33 = TARGET_ENE_0
            elseif selectFate_2 ~= 0 and f22_local29 <= selectFate_1 + selectFate_2 then
                f22_local30 = AI_DIR_TYPE_ToBR
                f22_local31 = warpDist_2
                f22_local32 = select_Attack2
                f22_local33 = TARGET_ENE_0
            elseif selectFate_3 ~= 0 and f22_local29 <= selectFate_1 + selectFate_2 + selectFate_3 then
                f22_local30 = AI_DIR_TYPE_ToBR
                f22_local31 = warpDist_3
                f22_local32 = select_Attack3
                f22_local33 = TARGET_ENE_0
            elseif selectFate_4 ~= 0 and f22_local29 <= selectFate_1 + selectFate_2 + selectFate_3 + selectFate_4 then
                f22_local30 = AI_DIR_TYPE_ToBR
                f22_local31 = warpDist_4
                f22_local32 = select_Attack4
                f22_local33 = TARGET_ENE_0
            end
            if f22_arg1:GetNumber(6) ~= 0 then
                f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat_SuccessAngle180, 10, 3014, TARGET_ENE_0, f22_local23, 0, 0)
            else
                f22_arg2:AddSubGoal(GOAL_COMMON_ToTargetWarp, 10, TARGET_ENE_0, f22_local30, f22_local31, f22_local33, 5, -2)
                f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat_SuccessAngle180, 10, f22_local32, TARGET_ENE_0, 999, 0, 0)
                if f22_local32 == 3016 then
                    f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat_SuccessAngle180, 10, 3004, TARGET_ENE_0, 999, 0, 0)
                end
            end
        elseif f22_arg1:GetNumber(10) == 1 then
            if f22_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_F, 200) then
                local f22_local11 = f22_arg1:GetRandam_Int(1, 100)
                local f22_local12 = f22_arg1:GetDist(TARGET_ENE_0)
                f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16666)
                f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16658)
                f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16655)
                f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16662)
                if f22_local12 <= 5 then
                    if f22_local11 > 65 then
                        f22_arg2:ClearSubGoal()
                        f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16655)
                        f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16658)
                        f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3001, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    elseif f22_local11 > 40 then
                        f22_arg2:ClearSubGoal()
                        f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16655)
                        f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16658)
                        f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3002, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    elseif f22_local11 > 25 then
                        f22_arg2:ClearSubGoal()
                        f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3038, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    else
                        f22_arg2:ClearSubGoal()
                        f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3004, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    end
                elseif f22_local12 <= 9 then
                    if f22_local11 > 30 then
                        f22_arg2:ClearSubGoal()
                        f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3023, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    else
                        f22_arg2:ClearSubGoal()
                        f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3004, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    end
                elseif f22_local12 <= 13 then
                    f22_arg2:ClearSubGoal()
                    f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16655)
                    f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16658)
                    f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3005, TARGET_ENE_0, 0, 0, 0, 0, 0)
                    return true
                end
            end
        elseif f22_arg1:GetNumber(10) == 2 then
            f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16666)
            f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16658)
            f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16662)
            local f22_local11 = f22_arg1:GetRandam_Int(1, 100)
            local f22_local12 = f22_arg1:GetDist(TARGET_ENE_0)
            if f22_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_F, 200) then
                if f22_local12 <= 5 then
                    if f22_local11 > 70 then
                        f22_arg2:ClearSubGoal()
                        f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16655)
                        f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16658)
                        f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3021, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    elseif f22_local11 > 40 then
                        f22_arg2:ClearSubGoal()
                        f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16655)
                        f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16658)
                        f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3024, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    elseif f22_local11 > 30 then
                        f22_arg2:ClearSubGoal()
                        f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16655)
                        f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16658)
                        f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3002, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    elseif f22_local11 > 15 then
                        f22_arg2:ClearSubGoal()
                        f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3038, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    else
                        f22_arg2:ClearSubGoal()
                        f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3004, TARGET_ENE_0, 0, 0, 0, 0, 0)
                        return true
                    end
                elseif f22_local12 <= 9 then
                    f22_arg2:ClearSubGoal()
                    f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16655)
                    f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16658)
                    f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3024, TARGET_ENE_0, 0, 0, 0, 0, 0)
                    return true
                elseif f22_local12 <= 13 then
                    f22_arg2:ClearSubGoal()
                    f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3011, TARGET_ENE_0, 0, 0, 0, 0, 0)
                    return true
                end
            end
        end
    end
    if f22_arg1:HasSpecialEffectId(TARGET_SELF, 16655) then
        local f22_local3 = f22_arg1:GetDist(TARGET_ENE_0)
        local f22_local4 = f22_arg1:GetRandam_Int(1, 100)
        f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16666)
        f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16658)
        f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16655)
        f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16662)
        if f22_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_F, 200) then
            if f22_local3 < 5 then
                if f22_local4 > 70 then
                    f22_arg2:ClearSubGoal()
                    f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3002, TARGET_ENE_0, 0, 0, 0, 0, 0)
                    return true
                elseif f22_local4 > 40 then
                    f22_arg2:ClearSubGoal()
                    f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3038, TARGET_ENE_0, 0, 0, 0, 0, 0)
                    return true
                else
                    f22_arg2:ClearSubGoal()
                    f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3024, TARGET_ENE_0, 0, 0, 0, 0, 0)
                    return true
                end
            elseif f22_local3 < 9 then
                f22_arg2:ClearSubGoal()
                f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3024, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            end
        end
    end
    if f22_arg1:HasSpecialEffectId(TARGET_SELF, 16657) then
        local f22_local3 = f22_arg1:GetRandam_Int(1, 100)
        local f22_local4 = f22_arg1:GetDist(TARGET_ENE_0)
        f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16666)
        f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16658)
        f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16655)
        f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16662)
        if f22_local4 <= 5 then
            f22_arg2:ClearSubGoal()
            f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16655)
            f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16658)
            f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3006, TARGET_ENE_0, 0, 0, 0, 0, 0)
            return true
        end
    end
    if f22_arg1:HasSpecialEffectId(TARGET_SELF, 16659) then
        local f22_local3 = f22_arg1:GetRandam_Int(1, 100)
        local f22_local4 = f22_arg1:GetDist(TARGET_ENE_0)
        if f22_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_F, 200) and f22_local4 <= 9 then
            if f22_local3 > 60 then
                f22_arg2:ClearSubGoal()
                f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16655)
                f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16658)
                f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3024, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            else
                f22_arg2:ClearSubGoal()
                f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16655)
                f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16658)
                f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3006, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            end
        end
    end
    if f22_arg1:HasSpecialEffectId(TARGET_SELF, 16665) then
        local f22_local3 = f22_arg1:GetRandam_Int(1, 100)
        local f22_local4 = f22_arg1:GetDist(TARGET_ENE_0)
        if f22_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_F, 200) and f22_local4 <= 6 then
            f22_arg2:ClearSubGoal()
            f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3028, TARGET_ENE_0, 0, 0, 0, 0, 0)
            return true
        end
    end
    if f22_arg1:HasSpecialEffectId(TARGET_SELF, 16653) then
        f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16666)
        f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16658)
        f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16655)
        f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16662)
        local f22_local3 = f22_arg1:GetDist(TARGET_ENE_0)
        local f22_local4 = f22_arg1:GetRandam_Int(1, 100)
        if f22_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_F, 200) then
            f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16666)
            f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16655)
            if f22_local3 < 5 then
                if f22_local4 > 60 then
                    f22_arg2:ClearSubGoal()
                    f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3001, TARGET_ENE_0, 0, 0, 0, 0, 0)
                    return true
                elseif f22_local4 > 45 then
                    f22_arg2:ClearSubGoal()
                    f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3002, TARGET_ENE_0, 0, 0, 0, 0, 0)
                    return true
                elseif f22_local4 > 30 then
                    f22_arg2:ClearSubGoal()
                    f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3024, TARGET_ENE_0, 0, 0, 0, 0, 0)
                    return true
                elseif f22_local4 > 20 then
                    f22_arg2:ClearSubGoal()
                    f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3038, TARGET_ENE_0, 0, 0, 0, 0, 0)
                    return true
                end
            elseif f22_local3 < 8 then
                f22_arg2:ClearSubGoal()
                f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3024, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            end
        elseif f22_local3 <= 3 and f22_local4 > 80 then
            if f22_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_R, 180) then
                f22_arg2:ClearSubGoal()
                f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3007, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            else
                f22_arg2:ClearSubGoal()
                f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3008, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            end
        end
    end
    if f22_arg1:HasSpecialEffectId(TARGET_SELF, 16663) then
        f22_arg2:ClearSubGoal()
        local f22_local3 = 5
        local f22_local4 = -1
        local f22_local5 = 1
        local f22_local6 = -1
        local f22_local7 = -1
        local f22_local8 = TARGET_ENE_0
        local f22_local9 = 3
        local f22_local10 = 0
        local f22_local11 = false
        f22_arg2:AddSubGoal(GOAL_COMMON_StepSafety, f22_local3, f22_local4, f22_local5, f22_local6, f22_local7, f22_local8, f22_local9, f22_local10, f22_local11)
        return true
    end
    if f22_arg1:HasSpecialEffectId(TARGET_SELF, 16662) then
        local f22_local3 = f22_arg1:GetDist(TARGET_ENE_0)
        local f22_local4 = f22_arg1:GetRandam_Int(1, 100)
        f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16666)
        f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16658)
        f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16655)
        f22_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 16662)
        if f22_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_F, 200) and f22_local3 < 5 then
            if f22_local4 > 40 then
                f22_arg2:ClearSubGoal()
                f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3002, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            elseif f22_local4 > 15 then
                f22_arg2:ClearSubGoal()
                f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 3, 3038, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            end
        end
    end
    if f22_arg1:HasSpecialEffectId(TARGET_SELF, 16656) then
        f22_arg2:ClearSubGoal()
        local f22_local3 = 5
        local f22_local4 = 3011
        local f22_local5 = 6
        local f22_local6 = 2
        local f22_local7 = 120
        local f22_local8 = f22_arg1:GetRandam_Int(1, 100)
        f22_arg2:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f22_local3, f22_local4, TARGET_ENE_0, f22_local5, f22_local6, f22_local7, 0, 0)
        return true
    end
    if f22_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and (f22_arg1:GetSpecialEffectActivateInterruptId(5030) or f22_arg1:GetSpecialEffectActivateInterruptId(5031) or f22_arg1:GetSpecialEffectActivateInterruptId(5032)) then
        f22_arg2:ClearSubGoal()
        if f22_arg1:GetSpecialEffectActivateInterruptId(5030) then
            if f22_local2 == true and f22_local0 > 50 then
                local f22_local3 = f22_arg1:GetDist(TARGET_ENE_0)
                local f22_local4 = f22_arg1:GetRandam_Int(1, 100)
                select_Attack1 = 3017
                selectFate_1F = 70
                selectFate_1B = 10
                selectFate_1L = 10
                selectFate_1R = 10
                selectFate_2F = 0
                selectFate_2B = 0
                selectFate_2L = 0
                selectFate_2R = 0
                warpDist_1F = 2.5
                warpDist_1B = 2.5
                warpDist_1L = 2.5
                warpDist_1R = 2.5
                warpDist_2F = 0
                warpDist_2B = 0
                warpDist_2L = 0
                warpDist_2R = 0
                same_Angle = 0
                local f22_local5 = 999 - f22_arg1:GetMapHitRadius(TARGET_SELF)
                local f22_local6 = 0
                local f22_local7 = 0
                local f22_local8 = f22_arg1:GetMapHitRadius(TARGET_SELF)
                local f22_local9 = f22_arg1:GetDist(TARGET_ENE_0)
                local f22_local10 = f22_arg1:GetRelativeAngleFromTarget(TARGET_ENE_0)
                local f22_local11 = 3027
                if warpDist_1F >= f22_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_F, warpDist_1F + f22_local8, f22_local8, 0) then
                    selectFate_1F = 0
                end
                if warpDist_1B >= f22_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_B, warpDist_1B + f22_local8, f22_local8, 0) then
                    selectFate_1B = 0
                end
                if warpDist_1L >= f22_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_L, warpDist_1L + f22_local8, f22_local8, 0) then
                    selectFate_1L = 0
                end
                if warpDist_1R >= f22_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_R, warpDist_1R + f22_local8, f22_local8, 0) then
                    selectFate_1R = 0
                end
                if warpDist_2F >= f22_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_F, warpDist_2F + f22_local8, f22_local8, 0) then
                    selectFate_2F = 0
                end
                if warpDist_2B >= f22_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_B, warpDist_2B + f22_local8, f22_local8, 0) then
                    selectFate_2B = 0
                end
                if warpDist_2L >= f22_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_L, warpDist_2L + f22_local8, f22_local8, 0) then
                    selectFate_2L = 0
                end
                if warpDist_2R >= f22_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_R, warpDist_2R + f22_local8, f22_local8, 0) then
                    selectFate_2B = 0
                end
                local f22_local12 = f22_arg1:GetRandam_Int(0, selectFate_1F + selectFate_1B + selectFate_1L + selectFate_1R + selectFate_2F + selectFate_2B + selectFate_2L + selectFate_2R)
                local f22_local13 = AI_DIR_TYPE_F
                local f22_local14 = 0
                local f22_local15 = f22_local11
                local f22_local16 = TARGET_ENE_0
                if selectFate_1F + selectFate_1B + selectFate_1L + selectFate_1R + selectFate_2F + selectFate_2B + selectFate_2L + selectFate_2R == 0 then
                    f22_arg1:SetNumber(6, 1)
                    f22_local13 = AI_DIR_TYPE_F
                    f22_local14 = 0
                    f22_local15 = 3027
                elseif selectFate_1F ~= 0 and f22_local12 <= selectFate_1F then
                    f22_local13 = AI_DIR_TYPE_F
                    f22_local14 = warpDist_1F
                    f22_local15 = select_Attack1
                    f22_local16 = TARGET_ENE_0
                elseif selectFate_1B ~= 0 and f22_local12 <= selectFate_1F + selectFate_1B then
                    f22_local13 = AI_DIR_TYPE_B
                    f22_local14 = warpDist_1B
                    f22_local15 = select_Attack1
                    f22_local16 = TARGET_ENE_0
                elseif selectFate_1L ~= 0 and f22_local12 <= selectFate_1F + selectFate_1B + selectFate_1L then
                    f22_local13 = AI_DIR_TYPE_L
                    f22_local14 = warpDist_1L
                    f22_local15 = select_Attack1
                    f22_local16 = TARGET_ENE_0
                elseif selectFate_1R ~= 0 and f22_local12 <= selectFate_1F + selectFate_1B + selectFate_1L + selectFate_1R then
                    f22_local13 = AI_DIR_TYPE_R
                    f22_local14 = warpDist_1R
                    f22_local15 = select_Attack1
                    f22_local16 = TARGET_ENE_0
                end
                if f22_arg1:GetNumber(6) ~= 0 then
                    f22_arg2:AddSubGoal(GOAL_COMMON_ToTargetWarp, 10, TARGET_ENE_0, AI_DIR_TYPE_F, 2.5, TARGET_ENE_0)
                else
                    f22_arg2:AddSubGoal(GOAL_COMMON_ToTargetWarp, 10, TARGET_ENE_0, f22_local13, f22_local14, f22_local16)
                    f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3017, TARGET_ENE_0, f22_local5, 0, 0, 0, 0)
                end
            else
                local f22_local3 = f22_arg1:GetDist(TARGET_ENE_0)
                local f22_local4 = f22_arg1:GetRandam_Int(1, 100)
                select_Attack1 = 3013
                selectFate_1F = 0
                selectFate_1B = 25
                selectFate_1L = 25
                selectFate_1R = 25
                selectFate_2F = 0
                selectFate_2B = 0
                selectFate_2L = 0
                selectFate_2R = 0
                warpDist_1F = 6
                warpDist_1B = 6
                warpDist_1L = 6
                warpDist_1R = 6
                warpDist_2F = 0
                warpDist_2B = 0
                warpDist_2L = 0
                warpDist_2R = 0
                same_Angle = 0
                local f22_local5 = 999 - f22_arg1:GetMapHitRadius(TARGET_SELF)
                local f22_local6 = 0
                local f22_local7 = 0
                local f22_local8 = f22_arg1:GetMapHitRadius(TARGET_SELF)
                local f22_local9 = f22_arg1:GetDist(TARGET_ENE_0)
                local f22_local10 = f22_arg1:GetRelativeAngleFromTarget(TARGET_ENE_0)
                local f22_local11 = 3027
                if warpDist_1F >= f22_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_F, warpDist_1F + f22_local8, f22_local8, 0) then
                    selectFate_1F = 0
                end
                if warpDist_1B >= f22_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_B, warpDist_1B + f22_local8, f22_local8, 0) then
                    selectFate_1B = 0
                end
                if warpDist_1L >= f22_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_L, warpDist_1L + f22_local8, f22_local8, 0) then
                    selectFate_1L = 0
                end
                if warpDist_1R >= f22_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_R, warpDist_1R + f22_local8, f22_local8, 0) then
                    selectFate_1R = 0
                end
                if warpDist_2F >= f22_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_F, warpDist_2F + f22_local8, f22_local8, 0) then
                    selectFate_2F = 0
                end
                if warpDist_2B >= f22_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_B, warpDist_2B + f22_local8, f22_local8, 0) then
                    selectFate_2B = 0
                end
                if warpDist_2L >= f22_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_L, warpDist_2L + f22_local8, f22_local8, 0) then
                    selectFate_2L = 0
                end
                if warpDist_2R >= f22_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_R, warpDist_2R + f22_local8, f22_local8, 0) then
                    selectFate_2B = 0
                end
                local f22_local12 = f22_arg1:GetRandam_Int(0, selectFate_1F + selectFate_1B + selectFate_1L + selectFate_1R + selectFate_2F + selectFate_2B + selectFate_2L + selectFate_2R)
                local f22_local13 = AI_DIR_TYPE_F
                local f22_local14 = 0
                local f22_local15 = f22_local11
                local f22_local16 = TARGET_ENE_0
                if selectFate_1F + selectFate_1B + selectFate_1L + selectFate_1R + selectFate_2F + selectFate_2B + selectFate_2L + selectFate_2R == 0 then
                    f22_arg1:SetNumber(6, 1)
                    f22_local13 = AI_DIR_TYPE_F
                    f22_local14 = 0
                    f22_local15 = 3027
                elseif selectFate_1F ~= 0 and f22_local12 <= selectFate_1F then
                    f22_local13 = AI_DIR_TYPE_F
                    f22_local14 = warpDist_1F
                    f22_local15 = select_Attack1
                    f22_local16 = TARGET_ENE_0
                elseif selectFate_1B ~= 0 and f22_local12 <= selectFate_1F + selectFate_1B then
                    f22_local13 = AI_DIR_TYPE_B
                    f22_local14 = warpDist_1B
                    f22_local15 = select_Attack1
                    f22_local16 = TARGET_ENE_0
                elseif selectFate_1L ~= 0 and f22_local12 <= selectFate_1F + selectFate_1B + selectFate_1L then
                    f22_local13 = AI_DIR_TYPE_L
                    f22_local14 = warpDist_1L
                    f22_local15 = select_Attack1
                    f22_local16 = TARGET_ENE_0
                elseif selectFate_1R ~= 0 and f22_local12 <= selectFate_1F + selectFate_1B + selectFate_1L + selectFate_1R then
                    f22_local13 = AI_DIR_TYPE_R
                    f22_local14 = warpDist_1R
                    f22_local15 = select_Attack1
                    f22_local16 = TARGET_ENE_0
                end
                if f22_arg1:GetNumber(6) ~= 0 then
                    f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3014, TARGET_ENE_0, f22_local5, 0, 0, 0, 0)
                else
                    f22_arg2:AddSubGoal(GOAL_COMMON_ToTargetWarp, 10, TARGET_ENE_0, f22_local13, f22_local14, f22_local16, 5, -2)
                    f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, f22_local15, TARGET_ENE_0, f22_local5, 0, 0, 0, 0)
                end
            end
        elseif f22_arg1:GetSpecialEffectActivateInterruptId(5031) then
            local f22_local3 = f22_arg1:GetDist(TARGET_ENE_0)
            local f22_local4 = f22_arg1:GetRandam_Int(1, 100)
            select_Attack1 = 3031
            select_Attack2 = 3033
            select_Attack3 = 3000
            select_Attack4 = 3016
            selectFate_1 = 5
            selectFate_2 = 5
            selectFate_3 = 0
            selectFate_4 = 5
            warpDist_1 = 3
            warpDist_2 = 7
            warpDist_3 = 3
            warpDist_4 = 3
            local f22_local5 = 999 - f22_arg1:GetMapHitRadius(TARGET_SELF)
            local f22_local6 = 0
            local f22_local7 = 0
            local f22_local8 = f22_arg1:GetMapHitRadius(TARGET_SELF)
            local f22_local9 = f22_arg1:GetDist(TARGET_ENE_0)
            local f22_local10 = f22_arg1:GetRelativeAngleFromTarget(TARGET_ENE_0)
            if warpDist_1 >= f22_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToBL, warpDist_1 + f22_local8, f22_local8, 0) then
                selectFate_1 = 0
            end
            if warpDist_2 >= f22_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToBL, warpDist_2 + f22_local8, f22_local8, 0) then
                selectFate_2 = 0
            end
            if warpDist_3 >= f22_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToBL, warpDist_3 + f22_local8, f22_local8, 0) then
                selectFate_3 = 0
            end
            if warpDist_4 >= f22_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToBL, warpDist_4 + f22_local8, f22_local8, 0) then
                selectFate_4 = 0
            end
            local f22_local11 = f22_arg1:GetRandam_Int(0, selectFate_1 + selectFate_2 + selectFate_3 + selectFate_4)
            local f22_local12 = AI_DIR_TYPE_ToL
            local f22_local13 = 0
            local f22_local14 = fall_Attack
            local f22_local15 = TARGET_ENE_0
            if selectFate_1 + selectFate_2 + selectFate_3 + selectFate_4 == 0 then
                f22_arg1:SetNumber(6, 1)
            elseif selectFate_1 ~= 0 and f22_local11 <= selectFate_1 then
                f22_local12 = AI_DIR_TYPE_ToBL
                f22_local13 = warpDist_1
                f22_local14 = select_Attack1
                f22_local15 = TARGET_ENE_0
            elseif selectFate_2 ~= 0 and f22_local11 <= selectFate_1 + selectFate_2 then
                f22_local12 = AI_DIR_TYPE_ToBL
                f22_local13 = warpDist_2
                f22_local14 = select_Attack2
                f22_local15 = TARGET_ENE_0
            elseif selectFate_3 ~= 0 and f22_local11 <= selectFate_1 + selectFate_2 + selectFate_3 then
                f22_local12 = AI_DIR_TYPE_ToBL
                f22_local13 = warpDist_3
                f22_local14 = select_Attack3
                f22_local15 = TARGET_ENE_0
            elseif selectFate_4 ~= 0 and f22_local11 <= selectFate_1 + selectFate_2 + selectFate_3 + selectFate_4 then
                f22_local12 = AI_DIR_TYPE_ToBL
                f22_local13 = warpDist_4
                f22_local14 = select_Attack4
                f22_local15 = TARGET_ENE_0
            end
            if f22_arg1:GetNumber(6) ~= 0 then
                f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat_SuccessAngle180, 10, 3014, TARGET_ENE_0, f22_local5, 0, 0)
            else
                f22_arg2:AddSubGoal(GOAL_COMMON_ToTargetWarp, 10, TARGET_ENE_0, f22_local12, f22_local13, f22_local15, 5, -2)
                f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat_SuccessAngle180, 10, f22_local14, TARGET_ENE_0, f22_local5, 0, 0)
            end
        elseif f22_arg1:GetSpecialEffectActivateInterruptId(5032) then
            local f22_local3 = f22_arg1:GetDist(TARGET_ENE_0)
            local f22_local4 = f22_arg1:GetRandam_Int(1, 100)
            select_Attack1 = 3030
            select_Attack2 = 3035
            select_Attack3 = 3000
            select_Attack4 = 3016
            selectFate_1 = 5
            selectFate_2 = 0
            selectFate_3 = 0
            selectFate_4 = 5
            warpDist_1 = 3
            warpDist_2 = 5
            warpDist_3 = 3
            warpDist_4 = 3
            local f22_local5 = 999 - f22_arg1:GetMapHitRadius(TARGET_SELF)
            local f22_local6 = 0
            local f22_local7 = 0
            local f22_local8 = f22_arg1:GetMapHitRadius(TARGET_SELF)
            local f22_local9 = f22_arg1:GetDist(TARGET_ENE_0)
            local f22_local10 = f22_arg1:GetRelativeAngleFromTarget(TARGET_ENE_0)
            if warpDist_1 >= f22_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToBR, warpDist_1 + f22_local8, f22_local8, 0) then
                selectFate_1 = 0
            end
            if warpDist_2 >= f22_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToBR, warpDist_2 + f22_local8, f22_local8, 0) then
                selectFate_2 = 0
            end
            if warpDist_3 >= f22_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToBR, warpDist_3 + f22_local8, f22_local8, 0) then
                selectFate_3 = 0
            end
            if warpDist_4 >= f22_arg1:GetExistMeshOnLineDistEx(TARGET_ENE_0, AI_DIR_TYPE_ToBR, warpDist_4 + f22_local8, f22_local8, 0) then
                selectFate_4 = 0
            end
            local f22_local11 = f22_arg1:GetRandam_Int(0, selectFate_1 + selectFate_2 + selectFate_3 + selectFate_4)
            local f22_local12 = AI_DIR_TYPE_ToR
            local f22_local13 = 0
            local f22_local14 = fall_Attack
            local f22_local15 = TARGET_ENE_0
            if selectFate_1 + selectFate_2 + selectFate_3 + selectFate_4 == 0 then
                f22_arg1:SetNumber(6, 1)
            elseif selectFate_1 ~= 0 and f22_local11 <= selectFate_1 then
                f22_local12 = AI_DIR_TYPE_ToBR
                f22_local13 = warpDist_1
                f22_local14 = select_Attack1
                f22_local15 = TARGET_ENE_0
            elseif selectFate_2 ~= 0 and f22_local11 <= selectFate_1 + selectFate_2 then
                f22_local12 = AI_DIR_TYPE_ToBR
                f22_local13 = warpDist_2
                f22_local14 = select_Attack2
                f22_local15 = TARGET_ENE_0
            elseif selectFate_3 ~= 0 and f22_local11 <= selectFate_1 + selectFate_2 + selectFate_3 then
                f22_local12 = AI_DIR_TYPE_ToBR
                f22_local13 = warpDist_3
                f22_local14 = select_Attack3
                f22_local15 = TARGET_ENE_0
            elseif selectFate_4 ~= 0 and f22_local11 <= selectFate_1 + selectFate_2 + selectFate_3 + selectFate_4 then
                f22_local12 = AI_DIR_TYPE_ToBR
                f22_local13 = warpDist_4
                f22_local14 = select_Attack4
                f22_local15 = TARGET_ENE_0
            end
            if f22_arg1:GetNumber(6) ~= 0 then
                f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat_SuccessAngle180, 10, 3014, TARGET_ENE_0, f22_local5, 0, 0)
            else
                f22_arg2:AddSubGoal(GOAL_COMMON_ToTargetWarp, 10, TARGET_ENE_0, f22_local12, f22_local13, f22_local15, 5, -2)
                f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat_SuccessAngle180, 10, f22_local14, TARGET_ENE_0, f22_local5, 0, 0)
            end
        end
    end
    return false
    
end

RegisterTableGoal(GOAL_HorriblenessGrub402000_AfterAttackAct, "HorriblenessGrub402000_AfterAttackAct")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_HorriblenessGrub402000_AfterAttackAct, true)

Goal.Activate = function (f23_arg0, f23_arg1, f23_arg2)
    
end

Goal.Update = function (f24_arg0, f24_arg1, f24_arg2)
    return Update_Default_NoSubGoal(f24_arg0, f24_arg1, f24_arg2)
    
end


