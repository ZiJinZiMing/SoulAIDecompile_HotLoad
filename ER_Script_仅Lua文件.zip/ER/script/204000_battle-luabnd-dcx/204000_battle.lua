﻿RegisterTableGoal(GOAL_RenalaChildren204000_Battle, "RenalaChildren204000_Battle")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_RenalaChildren204000_Battle, true)

Goal.Initialize = function (f1_arg0, f1_arg1, f1_arg2, f1_arg3)
    f1_arg1:GetStringIndexedNumber("Poltergeist_LoopCnt")
    f1_arg1:SetStringIndexedNumber("Poltergeist_LoopCnt", 0)
    f1_arg1:SetStringIndexedNumber("FirstAttack", 0)
    
end

Goal.Activate = function (f2_arg0, f2_arg1, f2_arg2)
    Init_Pseudo_Global(f2_arg1, f2_arg2)
    f2_arg1:SetStringIndexedNumber("Dist_SideStep", 5)
    f2_arg1:SetStringIndexedNumber("Dist_BackStep", 5)
    local f2_local0 = {}
    local f2_local1 = {}
    local f2_local2 = {}
    Common_Clear_Param(f2_local0, f2_local1, f2_local2)
    local f2_local3 = f2_arg1:GetDist(TARGET_ENE_0)
    local f2_local4 = f2_arg1:GetRandam_Int(1, 100)
    local f2_local5 = f2_arg1:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__thinkAttr_doAdmirer)
    local f2_local6 = f2_arg1:GetEventRequest()
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5028)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5029)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 14351)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 14353)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 14355)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 14394)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 14367)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 14394)
    if f2_arg1:GetNumber(0) > 0 then
        f2_arg1:SetNumber(0, 0)
    end
    if f2_arg1:GetStringIndexedNumber("FirstAttack") == 0 then
        f2_arg1:SetStringIndexedNumber("FirstAttack", 1)
        f2_arg1:SetTimer(0, 10)
    end
    if f2_arg1:HasSpecialEffectId(TARGET_SELF, 14351) then
        f2_local0[4] = 100
    elseif f2_arg1:HasSpecialEffectId(TARGET_SELF, 14394) then
        f2_local0[5] = 100
    elseif f2_arg1:HasSpecialEffectId(TARGET_SELF, 14384) then
        f2_local0[7] = 100
    elseif f2_arg1:HasSpecialEffectId(TARGET_SELF, 14367) then
        f2_local0[3] = 100
    elseif f2_arg1:HasSpecialEffectId(TARGET_SELF, 14382) and f2_local3 > 10 then
        f2_local0[20] = 100
    elseif f2_arg1:HasSpecialEffectId(TARGET_SELF, 14381) then
        f2_local0[3] = 99999
    else
        if f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 240, -1, 999) then
            if f2_local3 > 30 then
                f2_local0[40] = 100
            elseif f2_local3 > 10 then
                if f2_arg1:HasSpecialEffectId(TARGET_SELF, 14392) then
                    if f2_arg1:HasSpecialEffectId(TARGET_SELF, 14380) then
                        f2_local0[47] = 10
                    else
                        f2_local0[3] = 60
                        f2_local0[40] = 40
                    end
                else
                    f2_local0[40] = 100
                end
            elseif f2_local3 > 4 then
                if f2_arg1:HasSpecialEffectId(TARGET_SELF, 14391) then
                    f2_local0[2] = 90
                    f2_local0[47] = 10
                else
                    f2_local0[47] = 100
                end
            elseif f2_arg1:HasSpecialEffectId(TARGET_SELF, 14391) then
                f2_local0[1] = 50
                f2_local0[2] = 40
                f2_local0[47] = 10
            else
                f2_local0[1] = 70
                f2_local0[47] = 30
            end
        else
            f2_local0[42] = 100
        end
        if f2_arg1:HasSpecialEffectId(TARGET_SELF, 14379) or f2_arg1:HasSpecialEffectId(TARGET_SELF, 14390) then
            if f2_arg1:HasSpecialEffectId(TARGET_SELF, 14386) and not f2_arg1:HasSpecialEffectId(TARGET_SELF, 14384) then
                f2_local0[3] = 1E+24
            else
                f2_local0[3] = 0
            end
        end
        if f2_arg1:GetTimer(0) > 0 then
            f2_local0[2] = 0
        end
    end
    f2_local0[2] = SetCoolTime(f2_arg1, f2_arg2, 3001, 20, f2_local0[2], 0)
    f2_local0[3] = SetCoolTime(f2_arg1, f2_arg2, 3014, 20, f2_local0[3], 1)
    f2_local0[3] = SetCoolTime(f2_arg1, f2_arg2, 3017, 5, f2_local0[3], 1)
    f2_local1[1] = REGIST_FUNC(f2_arg1, f2_arg2, RenalaChildren204000_Act01)
    f2_local1[2] = REGIST_FUNC(f2_arg1, f2_arg2, RenalaChildren204000_Act02)
    f2_local1[3] = REGIST_FUNC(f2_arg1, f2_arg2, RenalaChildren204000_Act03)
    f2_local1[4] = REGIST_FUNC(f2_arg1, f2_arg2, RenalaChildren204000_Act04)
    f2_local1[5] = REGIST_FUNC(f2_arg1, f2_arg2, RenalaChildren204000_Act05)
    f2_local1[6] = REGIST_FUNC(f2_arg1, f2_arg2, RenalaChildren204000_Act06)
    f2_local1[7] = REGIST_FUNC(f2_arg1, f2_arg2, RenalaChildren204000_Act07)
    f2_local1[20] = REGIST_FUNC(f2_arg1, f2_arg2, RenalaChildren204000_Act20)
    f2_local1[40] = REGIST_FUNC(f2_arg1, f2_arg2, RenalaChildren204000_Act40)
    f2_local1[41] = REGIST_FUNC(f2_arg1, f2_arg2, RenalaChildren204000_Act41)
    f2_local1[42] = REGIST_FUNC(f2_arg1, f2_arg2, RenalaChildren204000_Act42)
    f2_local1[43] = REGIST_FUNC(f2_arg1, f2_arg2, RenalaChildren204000_Act43)
    f2_local1[44] = REGIST_FUNC(f2_arg1, f2_arg2, RenalaChildren204000_Act44)
    f2_local1[45] = REGIST_FUNC(f2_arg1, f2_arg2, RenalaChildren204000_Act45)
    f2_local1[46] = REGIST_FUNC(f2_arg1, f2_arg2, RenalaChildren204000_Act46)
    f2_local1[47] = REGIST_FUNC(f2_arg1, f2_arg2, RenalaChildren204000_Act47)
    local f2_local7 = REGIST_FUNC(f2_arg1, f2_arg2, RenalaChildren204000_ActAfter_AdjustSpace)
    Common_Battle_Activate(f2_arg1, f2_arg2, f2_local0, f2_local1, f2_local7, f2_local2)
    
end

function RenalaChildren204000_Act01(f3_arg0, f3_arg1, f3_arg2)
    local f3_local0 = 2.5
    local f3_local1 = 0
    local f3_local2 = 999
    local f3_local3 = 0
    local f3_local4 = 0
    local f3_local5 = 20
    local f3_local6 = 2
    Approach_Act_Flex(f3_arg0, f3_arg1, f3_local0, f3_local1, f3_local2, f3_local3, f3_local4, f3_local5, f3_local6)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 14351)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 14367)
    local f3_local7 = 4
    local f3_local8 = 3000
    local f3_local9 = 5 - f3_arg0:GetMapHitRadius(TARGET_SELF)
    local f3_local10 = 0
    local f3_local11 = 0
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f3_local7, f3_local8, TARGET_ENE_0, f3_local9, f3_local10, f3_local11, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RenalaChildren204000_Act02(f4_arg0, f4_arg1, f4_arg2)
    local f4_local0 = 10
    local f4_local1 = 0
    local f4_local2 = 999
    local f4_local3 = 0
    local f4_local4 = 0
    local f4_local5 = 20
    local f4_local6 = 2
    Approach_Act_Flex(f4_arg0, f4_arg1, f4_local0, f4_local1, f4_local2, f4_local3, f4_local4, f4_local5, f4_local6)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 14351)
    local f4_local7 = 10
    local f4_local8 = 3001
    local f4_local9 = 5 - f4_arg0:GetMapHitRadius(TARGET_SELF)
    local f4_local10 = 15
    local f4_local11 = 180
    f4_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f4_local7, f4_local8, TARGET_ENE_0, f4_local9, f4_local10, f4_local11, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RenalaChildren204000_Act03(f5_arg0, f5_arg1, f5_arg2)
    if f5_arg0:HasSpecialEffectId(TARGET_SELF, 14379) or f5_arg0:HasSpecialEffectId(TARGET_SELF, 14390) then
        f5_arg0:SetStringIndexedNumber("Poltergeist_LoopCnt", 0)
        f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
        f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5029)
        f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
        f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 14351)
        local f5_local0 = 10
        local f5_local1 = 3015
        local f5_local2 = 5 - f5_arg0:GetMapHitRadius(TARGET_SELF)
        local f5_local3 = 0
        local f5_local4 = 0
        f5_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f5_local0, f5_local1, TARGET_ENE_0, f5_local2, f5_local3, f5_local4, 0, 0)
        GetWellSpace_Odds = 0
        return GetWellSpace_Odds
    elseif f5_arg0:HasSpecialEffectId(TARGET_SELF, 14381) then
        f5_arg0:SetStringIndexedNumber("Poltergeist_LoopCnt", 0)
        f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
        f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
        f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5032)
        f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 14351)
        local f5_local0 = 10
        local f5_local1 = 3018
        local f5_local2 = 5 - f5_arg0:GetMapHitRadius(TARGET_SELF)
        local f5_local3 = 15
        local f5_local4 = 80
        f5_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f5_local0, f5_local1, TARGET_ENE_0, f5_local2, f5_local3, f5_local4, 0, 0)
        GetWellSpace_Odds = 0
        return GetWellSpace_Odds
    else
        f5_arg0:SetStringIndexedNumber("Poltergeist_LoopCnt", 0)
        f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
        f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
        f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5028)
        f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 14351)
        local f5_local0 = 10
        local f5_local1 = 3002
        local f5_local2 = 5 - f5_arg0:GetMapHitRadius(TARGET_SELF)
        local f5_local3 = 0
        local f5_local4 = 0
        f5_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f5_local0, f5_local1, TARGET_ENE_0, f5_local2, f5_local3, f5_local4, 0, 0)
        GetWellSpace_Odds = 0
        return GetWellSpace_Odds
    end
    
end

function RenalaChildren204000_Act04(f6_arg0, f6_arg1, f6_arg2)
    local f6_local0 = f6_arg0:GetRandam_Int(-180, 180)
    f6_arg0:SetAIFixedMoveTargetSpecifyAngle(TARGET_SOUND, f6_local0, 5, AI_SPA_DIR_TYPE_TargetF)
    local f6_local1 = 25
    local f6_local2 = 3006
    local f6_local3 = 999
    local f6_local4 = 0
    local f6_local5 = 360
    f6_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, f6_local1, f6_local2, POINT_AI_FIXED_POS, 9999, 0, 360, 180, 180):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
    f6_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 60, POINT_AI_FIXED_POS, 3, TARGET_SELF, false, -1, -1, -1, -1)
    f6_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f6_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 14353)
    f6_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 14355)
    local f6_local6 = 10
    local f6_local7 = 3003
    local f6_local8 = 999
    local f6_local9 = 0
    local f6_local10 = 0
    f6_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f6_local6, f6_local7, POINT_AI_FIXED_POS, f6_local8, f6_local9, f6_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RenalaChildren204000_Act05(f7_arg0, f7_arg1, f7_arg2)
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    local f7_local0 = 25
    local f7_local1 = 3010
    local f7_local2 = 5 - f7_arg0:GetMapHitRadius(TARGET_SELF)
    local f7_local3 = 0
    local f7_local4 = 0
    f7_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, f7_local0, f7_local1, TARGET_ENE_0, f7_local2, f7_local3, f7_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RenalaChildren204000_Act06(f8_arg0, f8_arg1, f8_arg2)
    f8_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f8_arg1:AddSubGoal(GOAL_COMMON_Wait, 2, TARGET_TEAM_LEADER)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RenalaChildren204000_Act07(f9_arg0, f9_arg1, f9_arg2)
    f9_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f9_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5034)
    local f9_local0 = 25
    local f9_local1 = 3025
    local f9_local2 = 999
    local f9_local3 = 0
    local f9_local4 = 0
    f9_arg1:AddSubGoal(GOAL_COMMON_Turn, 20, TARGET_SOUND, 30, 0, 0)
    local f9_local5 = f9_arg0:GetRandam_Int(1, 100)
    if f9_local5 >= 50 then
        f9_local1 = 3022
    end
    f9_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f9_local0, f9_local1, TARGET_SOUND, f9_local2, f9_local3, f9_local4, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RenalaChildren204000_Act20(f10_arg0, f10_arg1, f10_arg2)
    local f10_local0 = 3
    local f10_local1 = 2
    local f10_local2 = true
    local f10_local3 = -1
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 14351)
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 14367)
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 14394)
    f10_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, f10_local0, TARGET_TEAM_LEADER, f10_local1, TARGET_SELF, f10_local2, f10_local3)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RenalaChildren204000_Act40(f11_arg0, f11_arg1, f11_arg2)
    local f11_local0 = 3
    local f11_local1 = 9
    local f11_local2 = true
    local f11_local3 = -1
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 14351)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 14394)
    f11_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, f11_local0, TARGET_ENE_0, f11_local1, TARGET_SELF, f11_local2, f11_local3)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RenalaChildren204000_Act41(f12_arg0, f12_arg1, f12_arg2)
    local f12_local0 = 2
    local f12_local1 = 8
    local f12_local2 = false
    local f12_local3 = -1
    f12_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, f12_local0, TARGET_ENE_0, f12_local1, TARGET_SELF, f12_local2, f12_local3)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RenalaChildren204000_Act42(f13_arg0, f13_arg1, f13_arg2)
    f13_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 14351)
    f13_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 14367)
    f13_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 14394)
    f13_arg1:AddSubGoal(GOAL_COMMON_Turn, 2, TARGET_ENE_0, f13_arg0:GetRandam_Int(15, 20), 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RenalaChildren204000_Act43(f14_arg0, f14_arg1, f14_arg2)
    local f14_local0 = 1
    local f14_local1 = 0
    local f14_local2 = 100
    local f14_local3 = 0
    local f14_local4 = 0
    local f14_local5 = TARGET_ENE_0
    local f14_local6 = 1
    local f14_local7 = 0
    local f14_local8 = true
    f14_arg1:AddSubGoal(GOAL_COMMON_StepSafety, f14_local0, f14_local1, f14_local2, f14_local3, f14_local4, f14_local5, f14_local6, f14_local7, f14_local8)
    local f14_local9 = f14_arg0:GetDist(TARGET_ENE_0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RenalaChildren204000_Act44(f15_arg0, f15_arg1, f15_arg2)
    local f15_local0 = f15_arg0:GetRandam_Int(0, 1)
    f15_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 14351)
    f15_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 14394)
    local f15_local1 = 2
    local f15_local2 = TARGET_ENE_0
    local f15_local3 = f15_local0
    local f15_local4 = 15
    local f15_local5 = true
    local f15_local6 = -1
    local f15_local7 = GUARD_GOAL_DESIRE_RET_Failed
    local f15_local8 = true
    f15_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, f15_local1, f15_local2, f15_local3, f15_local4, f15_local5, isLifeSuccess, f15_local6, f15_local7)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RenalaChildren204000_Act45(f16_arg0, f16_arg1, f16_arg2)
    local f16_local0 = 6
    local f16_local1 = 15
    local f16_local2 = true
    local f16_local3 = -1
    f16_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, f16_local0, TARGET_ENE_0, f16_local1, TARGET_SELF, f16_local2, f16_local3)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RenalaChildren204000_Act46(f17_arg0, f17_arg1, f17_arg2)
    f17_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 14351)
    local f17_local0 = 3
    local f17_local1 = TARGET_ENE_0
    local f17_local2 = 8
    local f17_local3 = TARGET_ENE_0
    local f17_local4 = true
    local f17_local5 = -1
    local f17_local6 = GUARD_GOAL_DESIRE_RET_Failed
    local f17_local7 = false
    local f17_local8 = 1
    f17_arg1:AddSubGoal(GOAL_COMMON_LeaveTargetToPathEnd, f17_local0, f17_local1, f17_local2, f17_local3, f17_local4, f17_local5, f17_local6, f17_local7, f17_local8)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RenalaChildren204000_Act47(f18_arg0, f18_arg1, f18_arg2)
    f18_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 14351)
    f18_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 14367)
    f18_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 14394)
    f18_arg1:AddSubGoal(GOAL_COMMON_WalkAround_Anywhere, 5, 0.2, 20, true, -1, 3, 4, false, false)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RenalaChildren204000_ActAfter_AdjustSpace(f19_arg0, f19_arg1, f19_arg2)
    f19_arg1:AddSubGoal(GOAL_RenalaChildren204000_AfterAttackAct, 10)
    
end

Goal.Update = function (f20_arg0, f20_arg1, f20_arg2)
    return Update_Default_NoSubGoal(f20_arg0, f20_arg1, f20_arg2)
    
end

Goal.Terminate = function (f21_arg0, f21_arg1, f21_arg2)
    
end

Goal.Interrupt = function (f22_arg0, f22_arg1, f22_arg2)
    if f22_arg1:IsLadderAct(TARGET_SELF) then
        return false
    end
    local f22_local0 = 5 - f22_arg1:GetMapHitRadius(TARGET_SELF)
    local f22_local1 = 0
    local f22_local2 = 20
    local f22_local3 = f22_arg1:GetDist(TARGET_ENE_0)
    local f22_local4 = f22_arg1:GetRandam_Int(1, 100)
    if f22_arg1:IsInterupt(INTERUPT_Damaged) then
        f22_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5025)
        f22_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5026)
        f22_arg2:ClearSubGoal()
        return true
    end
    if f22_arg1:HasSpecialEffectId(TARGET_SELF, 14394) then
        f22_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5033)
        f22_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5034)
    end
    if f22_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f22_arg1:GetSpecialEffectActivateInterruptId(14394) then
        f22_arg2:ClearSubGoal()
        return true
    end
    if f22_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) then
        if f22_arg1:HasSpecialEffectId(TARGET_SELF, 5026) then
            f22_arg2:ClearSubGoal()
            f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 20, 3012, TARGET_ENE_0, 0, 0, 0, 0, 0)
            return true
        elseif f22_arg1:HasSpecialEffectId(TARGET_SELF, 5025) then
            f22_arg2:ClearSubGoal()
            f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 20, 3011, TARGET_ENE_0, 0, 0, 0, 0, 0)
            return true
        elseif f22_arg1:HasSpecialEffectId(TARGET_SELF, 5033) then
            if f22_arg1:HasSpecialEffectId(TARGET_SELF, 14384) then
                f22_arg1:SetNumber(0, f22_arg1:GetNumber(0) + 1)
                f22_arg2:ClearSubGoal()
                f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 20, 3026, TARGET_TEAM_LEADER, 0, 0, 0, 0, 0)
                do
                    return true
                end
                if false then
                end
            end
        elseif f22_arg1:HasSpecialEffectId(TARGET_SELF, 5034) then
            if f22_arg1:HasSpecialEffectId(TARGET_SELF, 14384) then
                f22_arg1:SetNumber(0, f22_arg1:GetNumber(0) + 1)
                f22_arg2:ClearSubGoal()
                f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 20, 3023, TARGET_TEAM_LEADER, 0, 0, 0, 0, 0)
                do
                    return true
                end
                if false then
                end
            end
        elseif f22_arg1:HasSpecialEffectId(TARGET_SELF, 14353) and f22_arg1:HasSpecialEffectId(TARGET_SELF, 14354) then
            f22_arg2:ClearSubGoal()
            f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 20, 3004, TARGET_ENE_0, 0, 0, 0, 0, 0)
            return true
        elseif f22_arg1:HasSpecialEffectId(TARGET_SELF, 14355) and f22_arg1:HasSpecialEffectId(TARGET_SELF, 14377) then
            f22_arg2:ClearSubGoal()
            local f22_local5 = f22_arg1:GetRandam_Float(0, 1)
            f22_arg2:AddSubGoal(GOAL_COMMON_Wait, f22_local5, TARGET_ENE_0)
            f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 20, 20001, TARGET_ENE_0, 0, 0, 0, 0, 0)
            return true
        elseif f22_arg1:HasSpecialEffectId(TARGET_SELF, 5027) then
            f22_arg2:ClearSubGoal()
            f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3013, TARGET_ENE_0, 0, 0, 0, 0, 0)
            return true
        elseif f22_arg1:HasSpecialEffectId(TARGET_SELF, 5028) then
            f22_arg2:ClearSubGoal()
            f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3014, TARGET_ENE_0, 0, 0, 0, 0, 0)
            return true
        elseif f22_arg1:HasSpecialEffectId(TARGET_SELF, 5029) then
            f22_arg2:ClearSubGoal()
            f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3016, TARGET_ENE_0, 0, 0, 0, 0, 0)
            return true
        elseif f22_arg1:HasSpecialEffectId(TARGET_SELF, 5030) then
            f22_arg2:ClearSubGoal()
            f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3017, TARGET_ENE_0, 0, 0, 0, 0, 0)
            return true
        elseif f22_arg1:HasSpecialEffectId(TARGET_SELF, 5031) then
            f22_arg2:ClearSubGoal()
            f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3019, TARGET_ENE_0, 0, 0, 0, 0, 0)
            return true
        elseif f22_arg1:HasSpecialEffectId(TARGET_SELF, 5032) then
            f22_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5031)
            f22_arg2:ClearSubGoal()
            f22_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3020, TARGET_ENE_0, 0, 0, 0, 0, 0)
            return true
        elseif f22_arg1:HasSpecialEffectId(TARGET_SELF, 14351) then
            f22_arg2:ClearSubGoal()
            f22_arg1:Replaning()
            return true
        end
    end
    return false
    
end

RegisterTableGoal(GOAL_RenalaChildren204000_AfterAttackAct, "RenalaChildren204000_AfterAttackAct")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_RenalaChildren204000_AfterAttackAct, true)

Goal.Update = function (f23_arg0, f23_arg1, f23_arg2)
    return Update_Default_NoSubGoal(f23_arg0, f23_arg1, f23_arg2)
    
end


