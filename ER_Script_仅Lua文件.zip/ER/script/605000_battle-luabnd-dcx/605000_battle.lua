﻿RegisterTableGoal(GOAL_Wildboar605000_Battle, "Wildboar605000_Battle")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_Wildboar605000_Battle, true)

Goal.Initialize = function (f1_arg0, f1_arg1, f1_arg2, f1_arg3)
    Init_Pseudo_Global(f1_arg1, f1_arg2)
    f1_arg1:GetStringIndexedNumber("WalkBefore")
    f1_arg1:GetStringIndexedNumber("Alert_mode")
    f1_arg1:GetStringIndexedNumber("TURNING_RANGE")
    f1_arg1:GetStringIndexedNumber("Warp_Late")
    Warp_Late = f1_arg1:GetRandam_Int(1, 100)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3002)
    
end

Goal.Activate = function (f2_arg0, f2_arg1, f2_arg2)
    if FearOfFire(f2_arg1, f2_arg2, PLAN_SIDEWAYTYPE__NONE) == true then
        return
    end
    local f2_local0 = {}
    local f2_local1 = {}
    local f2_local2 = {}
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 11411)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 11412)
    Common_Clear_Param(f2_local0, f2_local1, f2_local2)
    local f2_local3 = f2_arg1:GetDist(TARGET_ENE_0)
    local f2_local4 = f2_arg1:GetDist(TARGET_FRI_0)
    local f2_local5 = f2_arg1:GetRandam_Int(1, 100)
    local f2_local6 = f2_arg1:GetPrevTargetState()
    local f2_local7 = f2_arg1:HasSpecialEffectId(TARGET_SELF, 11410)
    local f2_local8 = f2_arg1:HasSpecialEffectId(TARGET_ENE_0, 8110)
    local f2_local9 = f2_arg1:HasSpecialEffectId(TARGET_FRI_0, 8110)
    local f2_local10 = f2_arg1:GetRandam_Int(22, 22)
    local f2_local11 = f2_arg1:GetRandam_Int(25, 25)
    local f2_local12 = f2_arg1:GetRandam_Int(1, 100)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 13156)
    if f2_arg1:HasSpecialEffectId(TARGET_SELF, 13156) == true then
        f2_local0[1] = 70
    elseif f2_arg1:HasSpecialEffectId(TARGET_SELF, 11410) == true then
        f2_local0[13] = 100
    elseif f2_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_B, 270) then
        if f2_local3 >= 2 then
            f2_local0[3] = 100
        else
            f2_local0[4] = 100
        end
    elseif f2_local3 >= 9 then
        f2_local0[1] = 100
    elseif f2_local3 >= 5 then
        f2_local0[1] = 70
        f2_local0[2] = 30
    else
        f2_local0[1] = 100
        f2_local0[3] = 50
    end
    f2_local1[1] = REGIST_FUNC(f2_arg1, f2_arg2, Wildboar605000_Act01)
    f2_local1[2] = REGIST_FUNC(f2_arg1, f2_arg2, Wildboar605000_Act02)
    f2_local1[3] = REGIST_FUNC(f2_arg1, f2_arg2, Wildboar605000_Act03)
    f2_local1[4] = REGIST_FUNC(f2_arg1, f2_arg2, Wildboar605000_Act04)
    f2_local1[12] = REGIST_FUNC(f2_arg1, f2_arg2, Wildboar605000_Act12)
    f2_local1[13] = REGIST_FUNC(f2_arg1, f2_arg2, Wildboar605000_Act13)
    f2_local1[14] = REGIST_FUNC(f2_arg1, f2_arg2, Wildboar605000_Act14)
    f2_local1[15] = REGIST_FUNC(f2_arg1, f2_arg2, Wildboar605000_Act15)
    f2_local1[16] = REGIST_FUNC(f2_arg1, f2_arg2, Wildboar605000_Act16)
    f2_local1[17] = REGIST_FUNC(f2_arg1, f2_arg2, Wildboar605000_Act17)
    f2_local1[18] = REGIST_FUNC(f2_arg1, f2_arg2, Wildboar605000_Act18)
    local f2_local13 = REGIST_FUNC(f2_arg1, f2_arg2, Wildboar605000_ActAfter_AdjustSpace)
    Common_Battle_Activate(f2_arg1, f2_arg2, f2_local0, f2_local1, f2_local13, f2_local2)
    
end

function Wildboar605000_Act01(f3_arg0, f3_arg1, f3_arg2)
    local f3_local0 = 5
    local f3_local1 = 3000
    local f3_local2 = 3001
    local f3_local3 = TARGET_ENE_0
    local f3_local4 = 20
    local f3_local5 = 0
    local f3_local6 = 0
    local f3_local7 = 0
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f3_local0, f3_local1, f3_local3, f3_local4, 0, 0, 0)
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f3_local0, f3_local2, f3_local3, f3_local4, 0, 0, 0)
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f3_local0, f3_local2, f3_local3, f3_local4, 0, 0, 0)
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f3_local0, f3_local2, f3_local3, f3_local4, 0, 0, 0)
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f3_local0, f3_local2, f3_local3, f3_local4, 0, 0, 0)
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f3_local0, f3_local2, f3_local3, f3_local4, 0, 0, 0)
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f3_local0, f3_local2, f3_local3, f3_local4, 0, 0, 0)
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f3_local0, f3_local2, f3_local3, f3_local4, 0, 0, 0)
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, f3_local0, f3_local2, f3_local3, f3_local4, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wildboar605000_Act02(f4_arg0, f4_arg1, f4_arg2)
    f4_arg1:AddSubGoal(GOAL_COMMON_Wait, 3, TARGET_ENE_0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wildboar605000_Act03(f5_arg0, f5_arg1, f5_arg2)
    f5_arg0:AddObserveAreaCustom(0, TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 60, 180, 30)
    f5_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget_Escape, 2, TARGET_ENE_0, 20, TARGET_ENE_0, true, -1)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wildboar605000_Act04(f6_arg0, f6_arg1, f6_arg2)
    local f6_local0 = 4
    local f6_local1 = TARGET_ENE_0
    local f6_local2 = 7
    local f6_local3 = TARGET_SELF
    local f6_local4 = false
    local f6_local5 = f6_arg0:GetDist(TARGET_ENE_0)
    local f6_local6 = 0
    local f6_local7 = f6_arg0:GetRandam_Int(1, 100)
    local f6_local8 = -1
    if f6_local7 <= f6_local6 then
        f6_local8 = 9910
    end
    f6_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget_Escape, f6_local0, f6_local1, f6_local2, f6_local3, f6_local4, f6_local8)
    local f6_local9 = 2
    local f6_local10 = TARGET_ENE_0
    local f6_local11 = 45
    local f6_local12 = GUARD_GOAL_DESIRE_RET_Continue
    local f6_local13 = true
    local f6_local14 = 0
    local f6_local15 = f6_arg0:GetRandam_Int(1, 100)
    local f6_local16 = -1
    if f6_local15 <= f6_local14 then
        f6_local16 = 9910
    end
    f6_arg1:AddSubGoal(GOAL_COMMON_Turn, f6_local9, f6_local10, f6_local11, f6_local16, f6_local12, f6_local13)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wildboar605000_Act12(f7_arg0, f7_arg1, f7_arg2)
    local f7_local0 = 4 - f7_arg0:GetMapHitRadius(TARGET_SELF)
    local f7_local1 = -1
    local f7_local2 = 180
    local f7_local3 = f7_arg0:GetRandam_Int(1, 100)
    local f7_local4 = TARGET_ENE_0
    if f7_arg0:GetDist(TARGET_ENE_0) < 0 then
        f7_local4 = TARGET_SELF
    end
    f7_arg1:AddSubGoal(GOAL_COMMON_Turn, 10, TARGET_ENE_0, 10)
    f7_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 3, 20, TARGET_NONE)
    f7_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 3, 20, TARGET_NONE)
    f7_arg1:AddSubGoal(GOAL_COMMON_WaitWithAnime, 3, 20, TARGET_NONE)
    local f7_local5 = f7_arg0:GetDist(f7_local4)
    local f7_local6 = f7_arg0:GetMapHitRadius(TARGET_SELF)
    local f7_local7 = 15
    local f7_local8 = f7_arg0:GetExistMeshOnLineDistEx(TARGET_SELF, AI_DIR_TYPE_F, f7_local7 + f7_local6, f7_local6, 0)
    local f7_local9 = f7_arg0:GetRandam_Int(AI_DIR_TYPE_L, AI_DIR_TYPE_R)
    f7_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget_Escape, 10, f7_local4, 30, TARGET_SELF, false, -1, GUARD_GOAL_DESIRE_RET_Continue, false, 2)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wildboar605000_Act13(f8_arg0, f8_arg1, f8_arg2)
    if f8_arg0:HasSpecialEffectId(TARGET_SELF, 5160) then
        f8_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget_Continuous, 10, TARGET_ENE_0, 30, TARGET_SELF, false, -1, GUARD_GOAL_DESIRE_RET_Continue, false, 2)
    else
        f8_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget_Escape, 10, TARGET_ENE_0, 30, TARGET_SELF, false, 1.5)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wildboar605000_Act18(f9_arg0, f9_arg1, f9_arg2)
    f9_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 13161)
    f9_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 2, TARGET_SOUND, f9_arg0:GetRandam_Float(1, 6), TARGET_SELF, false, -1)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wildboar605000_ActAfter_AdjustSpace(f10_arg0, f10_arg1, f10_arg2)
    f10_arg1:AddSubGoal(GOAL_Wildboar605000_AfterAttackAct, 10)
    
end

Goal.Update = function (f11_arg0, f11_arg1, f11_arg2)
    return Update_Default_NoSubGoal(f11_arg0, f11_arg1, f11_arg2)
    
end

Goal.Terminate = function (f12_arg0, f12_arg1, f12_arg2)
    
end

Goal.Interrupt = function (f13_arg0, f13_arg1, f13_arg2)
    local f13_local0 = f13_arg1:GetRandam_Int(1, 100)
    local f13_local1 = f13_arg1:GetDist(TARGET_ENE_0)
    if f13_arg1:IsLadderAct(TARGET_SELF) then
        return false
    end
    if f13_arg1:IsInterupt(INTERUPT_Inside_ObserveArea) and f13_arg1:IsInsideObserveArea(0) then
        f13_arg2:ClearSubGoal()
        f13_arg1:DeleteObserve(0)
    end
    if f13_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) then
        if f13_arg1:GetSpecialEffectActivateInterruptId(11411) and f13_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 90, 100, 3.4) then
            f13_arg2:ClearSubGoal()
            f13_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 5, 3002, TARGET_ENE_0, 999, 0, 0)
            return true
        end
        if f13_arg1:HasSpecialEffectId(TARGET_SELF, 13161) then
            local f13_local2 = f13_arg1:GetRandam_Int(1, 8)
            local f13_local3 = f13_arg1:GetRandam_Int(0, 3)
            local f13_local4 = TARGET_ENE_0
            f13_arg2:ClearSubGoal()
            f13_arg2:AddSubGoal(GOAL_COMMON_ToTargetWarp, 5, TARGET_SOUND, f13_local2, f13_local3, f13_local4)
            f13_arg1:Replaning()
            return true
        elseif f13_arg1:HasSpecialEffectId(TARGET_SELF, 13156) then
            f13_arg1:Replaning()
            return true
        end
    end
    return false
    
end

RegisterTableGoal(GOAL_Wildboar605000_AfterAttackAct, "Wildboar605000_AfterAttackAct")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_Wildboar605000_AfterAttackAct, true)

Goal.Activate = function (f14_arg0, f14_arg1, f14_arg2)
    local f14_local0 = f14_arg1:GetDist(TARGET_ENE_0)
    local f14_local1 = f14_arg1:GetToTargetAngle(TARGET_ENE_0)
    f14_arg1:SetStringIndexedNumber("DistMin_AAA", -999)
    f14_arg1:SetStringIndexedNumber("DistMax_AAA", 7)
    f14_arg1:SetStringIndexedNumber("BaseDir_AAA", AI_DIR_TYPE_F)
    f14_arg1:SetStringIndexedNumber("Angle_AAA", 180)
    f14_arg1:SetStringIndexedNumber("DistMin_Inter_AAA", 1)
    f14_arg1:SetStringIndexedNumber("DistMax_Inter_AAA", 10)
    f14_arg1:SetStringIndexedNumber("BaseAng_Inter_AAA", 0)
    f14_arg1:SetStringIndexedNumber("Ang_Inter_AAA", 180)
    f14_arg2:AddSubGoal(GOAL_COMMON_AfterAttackAct, 10)
    
end

Goal.Update = function (f15_arg0, f15_arg1, f15_arg2)
    return Update_Default_NoSubGoal(f15_arg0, f15_arg1, f15_arg2)
    
end


