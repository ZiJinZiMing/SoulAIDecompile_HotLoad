﻿function GodSkinFatherFat357000_Logic(f1_arg0)
    COMMON_Initialize(f1_arg0)
    f1_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 15452)
    if COMMON_EasySetup_Initial(f1_arg0) == false then
        local f1_local0 = f1_arg0:GetEventRequest()
        local f1_local1 = f1_arg0:IsSearchTarget(TARGET_ENE_0)
        if f1_local0 == 100 then
            f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 5, POINT_INITIAL, 0.5, TARGET_SELF, true, -1)
        elseif f1_local0 == 110 then
            f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 5, POINT_INITIAL, 0.5, TARGET_SELF, false, -1)
        elseif RideRequest(f1_arg0, 10, -1) then
            f1_arg0:AddTopGoal(GOAL_COMMON_Mount, 10, 1.2)
        else
            COMMON_EasySetup3(f1_arg0)
        end
    end
    
end

function GodSkinFatherFat357000_Interupt(f2_arg0, f2_arg1)
    if f2_arg0:IsInterupt(INTERUPT_ActivateSpecialEffect) and f2_arg0:GetSpecialEffectActivateInterruptId(15452) and f2_arg0:HasSpecialEffectId(TARGET_SELF, PLAN_SP_EFFECT_ANIME_SLEEPING) == true then
        f2_arg1:ClearSubGoal()
        f2_arg0:AddTopGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, 12002, TARGET_SELF, 999, 0, 0, 0, 0)
        return true
    end
    return false
    
end


