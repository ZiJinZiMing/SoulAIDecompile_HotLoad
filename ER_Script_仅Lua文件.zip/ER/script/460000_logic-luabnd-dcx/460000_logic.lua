﻿function Troll460000_Logic(f1_arg0)
    COMMON_Initialize(f1_arg0)
    if COMMON_EasySetup_Initial(f1_arg0) == false then
        local f1_local0 = f1_arg0:GetEventRequest()
        local f1_local1 = f1_arg0:IsSearchTarget(TARGET_ENE_0)
        if f1_local0 == 100 then
            f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 5, POINT_INITIAL, 0.5, TARGET_SELF, true, -1)
        elseif f1_local0 == 110 then
            f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 5, POINT_INITIAL, 0.5, TARGET_SELF, false, -1)
        elseif RideRequest(f1_arg0, 10, -1) then
            f1_arg0:AddTopGoal(GOAL_COMMON_Mount, 10, 1.2)
        else
            COMMON_EasySetup3(f1_arg0)
        end
    end
    
end

function Troll460000_Interupt(f2_arg0, f2_arg1)
    
end


