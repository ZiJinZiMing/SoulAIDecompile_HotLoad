﻿RegisterTableGoal(GOAL_BalloonDoll_385010_Battle, "GOAL_BalloonDoll_385010_Battle")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_BalloonDoll_385010_Battle, true)

Goal.Initialize = function (f1_arg0, f1_arg1, f1_arg2, f1_arg3)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3000)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3001)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3002)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3003)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3004)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3005)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3006)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3007)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3008)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3009)
    
end

Goal.Activate = function (f2_arg0, f2_arg1, f2_arg2)
    Init_Pseudo_Global(f2_arg1, f2_arg2)
    local f2_local0 = {}
    local f2_local1 = {}
    local f2_local2 = {}
    Common_Clear_Param(f2_local0, f2_local1, f2_local2)
    local f2_local3 = f2_arg1:GetDist(TARGET_ENE_0)
    local f2_local4 = f2_arg1:GetRandam_Int(1, 100)
    local f2_local5 = f2_arg1:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__thinkAttr_doAdmirer)
    if f2_local5 == 1 and f2_arg1:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Kankyaku then
        if f2_local3 >= 15 then
            f2_local0[31] = 100
        else
            f2_local0[30] = 100
        end
    elseif f2_local5 == 1 and f2_arg1:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Torimaki then
        if f2_local3 >= 15 then
            f2_local0[31] = 100
        else
            f2_local0[4] = 30
            f2_local0[30] = 70
            if f2_arg1:HasSpecialEffectId(TARGET_SELF, 14052) then
                f2_local0[4] = 0
                f2_local0[9] = 30
            end
        end
    elseif f2_local3 >= 6 then
        f2_local0[4] = 20
        f2_local0[6] = 80
        f2_local0[9] = 0
        if f2_arg1:HasSpecialEffectId(TARGET_SELF, 14052) then
            f2_local0[6] = 0
            f2_local0[9] = 100
        end
    elseif f2_local3 >= 3 then
        f2_local0[4] = 40
        f2_local0[5] = 30
        f2_local0[6] = 30
        f2_local0[9] = 0
    elseif InsideRange(f2_arg1, f2_arg2, 180, 160, 0, 99) then
        f2_local0[4] = 20
        f2_local0[5] = 80
    else
        f2_local0[4] = 70
        f2_local0[5] = 30
    end
    if f2_arg1:GetHpRate(TARGET_SELF) < 0.5 then
        f2_local0[11] = 300
    elseif f2_arg1:GetHpRate(TARGET_SELF) < 0.8 then
        f2_local0[11] = 50
    elseif f2_arg1:GetHpRate(TARGET_SELF) < 1 then
        f2_local0[11] = 30
    end
    if f2_arg1:HasSpecialEffectId(TARGET_SELF, 14052) == false then
        f2_local0[9] = 0
    end
    f2_local0[6] = SetCoolTime(f2_arg1, f2_arg2, 3003, 10, f2_local0[6], 0)
    f2_local0[11] = SetCoolTime(f2_arg1, f2_arg2, 3009, 20, f2_local0[11], 0)
    f2_local0[5] = SetCoolTime(f2_arg1, f2_arg2, 3007, 10, f2_local0[5], 0)
    f2_local0[9] = SetCoolTime(f2_arg1, f2_arg2, 3010, 10, f2_local0[9], 1)
    f2_local1[1] = REGIST_FUNC(f2_arg1, f2_arg2, BalloonDoll_385010_Act01)
    f2_local1[2] = REGIST_FUNC(f2_arg1, f2_arg2, BalloonDoll_385010_Act02)
    f2_local1[3] = REGIST_FUNC(f2_arg1, f2_arg2, BalloonDoll_385010_Act03)
    f2_local1[4] = REGIST_FUNC(f2_arg1, f2_arg2, BalloonDoll_385010_Act04)
    f2_local1[5] = REGIST_FUNC(f2_arg1, f2_arg2, BalloonDoll_385010_Act05)
    f2_local1[6] = REGIST_FUNC(f2_arg1, f2_arg2, BalloonDoll_385010_Act06)
    f2_local1[7] = REGIST_FUNC(f2_arg1, f2_arg2, BalloonDoll_385010_Act07)
    f2_local1[8] = REGIST_FUNC(f2_arg1, f2_arg2, BalloonDoll_385010_Act08)
    f2_local1[9] = REGIST_FUNC(f2_arg1, f2_arg2, BalloonDoll_385010_Act09)
    f2_local1[10] = REGIST_FUNC(f2_arg1, f2_arg2, BalloonDoll_385010_Act10)
    f2_local1[11] = REGIST_FUNC(f2_arg1, f2_arg2, BalloonDoll_385010_Act11)
    f2_local1[30] = REGIST_FUNC(f2_arg1, f2_arg2, BalloonDoll_385010_Act30)
    f2_local1[31] = REGIST_FUNC(f2_arg1, f2_arg2, BalloonDoll_385010_Act31)
    local f2_local6 = REGIST_FUNC(f2_arg1, f2_arg2, BalloonDoll_385010_ActAfter_AdjustSpace)
    Common_Battle_Activate(f2_arg1, f2_arg2, f2_local0, f2_local1, f2_local6, f2_local2)
    
end

function BalloonDoll_385010_Act01(f3_arg0, f3_arg1, f3_arg2)
    local f3_local0 = 2.2 - f3_arg0:GetMapHitRadius(TARGET_SELF)
    local f3_local1 = f3_local0 + 0
    local f3_local2 = f3_local0 + 50
    local f3_local3 = 100
    local f3_local4 = 0
    local f3_local5 = 4
    local f3_local6 = 8
    Approach_Act_Flex(f3_arg0, f3_arg1, f3_local0, f3_local1, f3_local2, f3_local3, f3_local4, f3_local5, f3_local6)
    local f3_local7 = 3000
    local f3_local8 = 2.2 - f3_arg0:GetMapHitRadius(TARGET_SELF)
    local f3_local9 = 0
    local f3_local10 = 0
    f3_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f3_local7, TARGET_ENE_0, f3_local8, f3_local9, f3_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function BalloonDoll_385010_Act02(f4_arg0, f4_arg1, f4_arg2)
    local f4_local0 = 3 - f4_arg0:GetMapHitRadius(TARGET_SELF)
    local f4_local1 = f4_local0 + 0
    local f4_local2 = f4_local0 + 50
    local f4_local3 = 100
    local f4_local4 = 0
    local f4_local5 = 4
    local f4_local6 = 8
    Approach_Act_Flex(f4_arg0, f4_arg1, f4_local0, f4_local1, f4_local2, f4_local3, f4_local4, f4_local5, f4_local6)
    local f4_local7 = 3001
    local f4_local8 = 3 - f4_arg0:GetMapHitRadius(TARGET_SELF)
    local f4_local9 = 0
    local f4_local10 = 0
    f4_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f4_local7, TARGET_ENE_0, f4_local8, f4_local9, f4_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function BalloonDoll_385010_Act03(f5_arg0, f5_arg1, f5_arg2)
    local f5_local0 = 2.7 - f5_arg0:GetMapHitRadius(TARGET_SELF)
    local f5_local1 = f5_local0 + 0
    local f5_local2 = f5_local0 + 50
    local f5_local3 = 100
    local f5_local4 = 0
    local f5_local5 = 4
    local f5_local6 = 8
    Approach_Act_Flex(f5_arg0, f5_arg1, f5_local0, f5_local1, f5_local2, f5_local3, f5_local4, f5_local5, f5_local6)
    local f5_local7 = 3002
    local f5_local8 = 2.7 - f5_arg0:GetMapHitRadius(TARGET_SELF)
    local f5_local9 = 0
    local f5_local10 = 0
    f5_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f5_local7, TARGET_ENE_0, f5_local8, f5_local9, f5_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function BalloonDoll_385010_Act04(f6_arg0, f6_arg1, f6_arg2)
    local f6_local0 = 2.2 - f6_arg0:GetMapHitRadius(TARGET_SELF)
    local f6_local1 = f6_local0 + 0
    local f6_local2 = f6_local0 + 50
    local f6_local3 = 100
    local f6_local4 = 0
    local f6_local5 = 4
    local f6_local6 = 8
    Approach_Act_Flex(f6_arg0, f6_arg1, f6_local0, f6_local1, f6_local2, f6_local3, f6_local4, f6_local5, f6_local6)
    local f6_local7 = 3000
    local f6_local8 = 3001
    local f6_local9 = 3002
    local f6_local10 = 2
    local f6_local11 = 3
    local f6_local12 = 5 - f6_arg0:GetMapHitRadius(TARGET_SELF)
    local f6_local13 = 0
    local f6_local14 = 0
    f6_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5029)
    f6_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f6_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f6_local7, TARGET_ENE_0, f6_local10, 0, 0, 0, 0)
    f6_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, f6_local8, TARGET_ENE_0, f6_local11, 0, 0, 0, 0)
    f6_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 10, f6_local9, TARGET_ENE_0, f6_local12, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function BalloonDoll_385010_Act05(f7_arg0, f7_arg1, f7_arg2)
    local f7_local0 = 2.5 - f7_arg0:GetMapHitRadius(TARGET_SELF)
    local f7_local1 = f7_local0 + 0
    local f7_local2 = f7_local0 + 50
    local f7_local3 = 100
    local f7_local4 = 0
    local f7_local5 = 4
    local f7_local6 = 8
    Approach_Act_Flex(f7_arg0, f7_arg1, f7_local0, f7_local1, f7_local2, f7_local3, f7_local4, f7_local5, f7_local6)
    local f7_local7 = 3007
    local f7_local8 = 2.5 - f7_arg0:GetMapHitRadius(TARGET_SELF)
    local f7_local9 = 0
    local f7_local10 = 0
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5029)
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f7_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f7_local7, TARGET_ENE_0, f7_local8, f7_local9, f7_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function BalloonDoll_385010_Act06(f8_arg0, f8_arg1, f8_arg2)
    local f8_local0 = 3 - f8_arg0:GetMapHitRadius(TARGET_SELF)
    local f8_local1 = f8_local0 + 0
    local f8_local2 = f8_local0 + 50
    local f8_local3 = 100
    local f8_local4 = 0
    local f8_local5 = 4
    local f8_local6 = 8
    Approach_Act_Flex(f8_arg0, f8_arg1, f8_local0, f8_local1, f8_local2, f8_local3, f8_local4, f8_local5, f8_local6)
    local f8_local7 = 3003
    local f8_local8 = 3 - f8_arg0:GetMapHitRadius(TARGET_SELF)
    local f8_local9 = 0
    local f8_local10 = 0
    f8_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5029)
    f8_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f8_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f8_local7, TARGET_ENE_0, f8_local8, f8_local9, f8_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function BalloonDoll_385010_Act07(f9_arg0, f9_arg1, f9_arg2)
    local f9_local0 = 5 - f9_arg0:GetMapHitRadius(TARGET_SELF)
    local f9_local1 = f9_local0 + 0
    local f9_local2 = f9_local0 + 50
    local f9_local3 = 50
    local f9_local4 = 0
    local f9_local5 = 4
    local f9_local6 = 8
    Approach_Act_Flex(f9_arg0, f9_arg1, f9_local0, f9_local1, f9_local2, f9_local3, f9_local4, f9_local5, f9_local6)
    local f9_local7 = 3004
    local f9_local8 = 5 - f9_arg0:GetMapHitRadius(TARGET_SELF)
    local f9_local9 = 0
    local f9_local10 = 0
    f9_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f9_local7, TARGET_ENE_0, f9_local8, f9_local9, f9_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function BalloonDoll_385010_Act08(f10_arg0, f10_arg1, f10_arg2)
    local f10_local0 = 5 - f10_arg0:GetMapHitRadius(TARGET_SELF)
    local f10_local1 = f10_local0 + 0
    local f10_local2 = f10_local0 + 50
    local f10_local3 = 50
    local f10_local4 = 0
    local f10_local5 = 4
    local f10_local6 = 8
    Approach_Act_Flex(f10_arg0, f10_arg1, f10_local0, f10_local1, f10_local2, f10_local3, f10_local4, f10_local5, f10_local6)
    local f10_local7 = 3005
    local f10_local8 = 5 - f10_arg0:GetMapHitRadius(TARGET_SELF)
    local f10_local9 = 0
    local f10_local10 = 0
    f10_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f10_local7, TARGET_ENE_0, f10_local8, f10_local9, f10_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function BalloonDoll_385010_Act09(f11_arg0, f11_arg1, f11_arg2)
    local f11_local0 = 11 - f11_arg0:GetMapHitRadius(TARGET_SELF)
    local f11_local1 = f11_local0 + 0
    local f11_local2 = f11_local0 + 50
    local f11_local3 = 50
    local f11_local4 = 0
    local f11_local5 = 4
    local f11_local6 = 8
    Approach_Act_Flex(f11_arg0, f11_arg1, f11_local0, f11_local1, f11_local2, f11_local3, f11_local4, f11_local5, f11_local6)
    local f11_local7 = 3010
    local f11_local8 = 11 - f11_arg0:GetMapHitRadius(TARGET_SELF)
    local f11_local9 = 0
    local f11_local10 = 0
    if f11_arg0:HasSpecialEffectId(TARGET_SELF, 14053) then
        f11_local7 = 3011
    end
    f11_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f11_local7, TARGET_ENE_0, f11_local8, f11_local9, f11_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function BalloonDoll_385010_Act10(f12_arg0, f12_arg1, f12_arg2)
    local f12_local0 = 8.5 - f12_arg0:GetMapHitRadius(TARGET_SELF)
    local f12_local1 = f12_local0 + 0
    local f12_local2 = f12_local0 + 50
    local f12_local3 = 50
    local f12_local4 = 0
    local f12_local5 = 4
    local f12_local6 = 8
    Approach_Act_Flex(f12_arg0, f12_arg1, f12_local0, f12_local1, f12_local2, f12_local3, f12_local4, f12_local5, f12_local6)
    local f12_local7 = 3011
    local f12_local8 = 8.5 - f12_arg0:GetMapHitRadius(TARGET_SELF)
    local f12_local9 = 0
    local f12_local10 = 0
    f12_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f12_local7, TARGET_ENE_0, f12_local8, f12_local9, f12_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function BalloonDoll_385010_Act11(f13_arg0, f13_arg1, f13_arg2)
    local f13_local0 = 3009
    local f13_local1 = 99.5 - f13_arg0:GetMapHitRadius(TARGET_SELF)
    local f13_local2 = 0
    local f13_local3 = 0
    f13_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, f13_local0, TARGET_ENE_0, f13_local1, f13_local2, f13_local3, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function BalloonDoll_385010_Act15(f14_arg0, f14_arg1, f14_arg2)
    local f14_local0 = f14_arg0:GetDist(TARGET_ENE_0)
    local f14_local1 = 10
    local f14_local2 = 12
    local f14_local3 = 50
    local f14_local4 = f14_arg0:GetRandam_Int(1, 100)
    local f14_local5 = -1
    if f14_local4 <= f14_local3 then
        f14_local5 = 9910
    end
    if f14_local1 <= f14_local0 then
        Approach_Act(f14_arg0, f14_arg1, f14_local1, f14_local2, f14_local3, 3)
    end
    f14_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 2, TARGET_ENE_0, f14_local1, TARGET_ENE_0, true, f14_local5)
    
end

function BalloonDoll_385010_Act16(f15_arg0, f15_arg1, f15_arg2)
    local f15_local0 = 50
    local f15_local1 = f15_arg0:GetRandam_Int(1, 100)
    local f15_local2 = -1
    if f15_local1 <= f15_local0 then
        f15_local2 = 9910
    end
    f15_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, 2, TARGET_ENE_0, f15_arg0:GetRandam_Int(0, 1), f15_arg0:GetRandam_Int(30, 45), true, true, f15_local2)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function BalloonDoll_385010_Act17(f16_arg0, f16_arg1, f16_arg2)
    f16_arg1:AddSubGoal(GOAL_COMMON_Turn, 2, TARGET_ENE_0, 90, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function BalloonDoll_385010_Act30(f17_arg0, f17_arg1, f17_arg2)
    f17_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, f17_arg0:GetRandam_Float(2, 3), TARGET_ENE_0, f17_arg0:GetRandam_Int(0, 1), f17_arg0:GetRandam_Int(30, 45), true, true, -1)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function BalloonDoll_385010_Act31(f18_arg0, f18_arg1, f18_arg2)
    local f18_local0 = f18_arg0:GetDist(TARGET_ENE_0)
    local f18_local1 = f18_arg0:GetRandam_Float(2, 4)
    local f18_local2 = f18_arg0:GetRandam_Float(9, 14)
    local f18_local3 = -1
    f18_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, f18_local1, TARGET_ENE_0, f18_local2, TARGET_SELF, true, f18_local3)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function BalloonDoll_385010_ActAfter_AdjustSpace(f19_arg0, f19_arg1, f19_arg2)
    f19_arg1:AddSubGoal(GOAL_BalloonDoll_385010_AfterAttackAct, 10)
    
end

Goal.Update = function (f20_arg0, f20_arg1, f20_arg2)
    return Update_Default_NoSubGoal(f20_arg0, f20_arg1, f20_arg2)
    
end

Goal.Terminate = function (f21_arg0, f21_arg1, f21_arg2)
    
end

Goal.Interrupt = function (f22_arg0, f22_arg1, f22_arg2)
    if f22_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f22_arg1:GetSpecialEffectActivateInterruptId(5029) then
        if f22_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_L, 90, 140, 2) then
            f22_arg2:ClearSubGoal()
            f22_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 2, 3004, TARGET_ENE_0, 999, 0, 0)
            return true
        elseif f22_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_R, 90, 140, 2) then
            f22_arg2:ClearSubGoal()
            f22_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 2, 3005, TARGET_ENE_0, 999, 0, 0)
            return true
        else
        end
    end
    if f22_arg1:IsInterupt(INTERUPT_Damaged) then
        local f22_local0 = f22_arg1:GetRandam_Int(1, 100)
        if f22_local0 <= 25 and f22_arg1:GetRemainingAttackCoolTime(3009) == 0 then
            f22_arg2:ClearSubGoal()
            BalloonDoll_385010_Act11(f22_arg1, f22_arg2)
            return true
        end
    end
    return false
    
end

RegisterTableGoal(GOAL_BalloonDoll_385010_AfterAttackAct, "GOAL_BalloonDoll_385010_AfterAttackAct")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_BalloonDoll_385010_AfterAttackAct, true)

Goal.Activate = function (f23_arg0, f23_arg1, f23_arg2)
    
end

Goal.Update = function (f24_arg0, f24_arg1, f24_arg2)
    return Update_Default_NoSubGoal(f24_arg0, f24_arg1, f24_arg2)
    
end


