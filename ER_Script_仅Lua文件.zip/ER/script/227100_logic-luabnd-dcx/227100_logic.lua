﻿function CrabMini227100_Logic(f1_arg0)
    COMMON_Initialize(f1_arg0)
    if COMMON_EasySetup_Initial(f1_arg0) == false then
        local f1_local0 = f1_arg0:GetRandam_Int(1, 100)
        local f1_local1 = f1_arg0:GetRandam_Int(1, 100)
        local f1_local2 = f1_arg0:GetEventRequest()
        local f1_local3 = f1_arg0:IsSearchTarget(TARGET_ENE_0)
        local f1_local4 = f1_arg0:GetDist(POINT_INITIAL)
        local f1_local5 = GetCurrentTimeType(f1_arg0)
        local f1_local6 = f1_arg0:GetPrevTargetState()
        local f1_local7 = f1_arg0:GetCurrTargetState()
        local f1_local8 = f1_arg0:IsBattleState()
        local f1_local9 = f1_arg0:IsCautionState()
        local f1_local10 = f1_arg0:HasSpecialEffectId(TARGET_SELF, 12048)
        if f1_arg0:IsSearchLowState() == false and f1_arg0:IsSearchHighState() == false and f1_arg0:IsCautionState() == false and f1_arg0:IsBattleState() == false and f1_local10 == true then
            if f1_local0 > 70 or f1_arg0:GetNumber(3) >= 2 then
                f1_arg0:SetNumber(3, 0)
                f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, 3015, TARGET_NONE, DIST_None, 0, 0)
            elseif f1_local0 > 20 then
                f1_arg0:SetNumber(3, f1_arg0:GetNumber(3) + 1)
                COMMON_EasySetup3(f1_arg0)
            else
                f1_arg0:AddTopGoal(GOAL_COMMON_WalkAround_Anywhere, -1, 5, 10, true, -1, 3, 1, false, false)
            end
        else
            COMMON_EasySetup3(f1_arg0)
        end
    end
    
end

function CrabMini227100_Interupt(f2_arg0, f2_arg1)
    local f2_local0 = f2_arg0:GetDist(TARGET_ENE_0)
    local f2_local1 = f2_arg0:GetDist(TARGET_FRI_0)
    local f2_local2 = f2_arg0:GetRandam_Int(1, 100)
    local f2_local3 = f2_arg0:HasSpecialEffectId(TARGET_SELF, 10798)
    local f2_local4 = f2_arg0:GetPrevTargetState()
    local f2_local5 = f2_arg0:AddObserveSpecialEffectAttribute(TARGET_ENE_0, PLAN_SP_EFFECT_FALL_FROM_HORSE)
    if f2_arg0:IsLadderAct(TARGET_SELF) then
        return false
    end
    if f2_arg0:IsInterupt(INTERUPT_ActivateSpecialEffect) and battleCheck == false and f2_arg0:GetSpecialEffectActivateInterruptId(10798) then
        f2_arg0:Replanning()
        return true
    end
    return false
    
end


