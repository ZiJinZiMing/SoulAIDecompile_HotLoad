﻿RegisterTableGoal(GOAL_DosouSkeleton_PoleSword_306010_Battle, "DosouSkeleton_PoleSword_306010_Battle")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_DosouSkeleton_PoleSword_306010_Battle, true)

Goal.Initialize = function (f1_arg0, f1_arg1, f1_arg2, f1_arg3)
    f1_arg1:EnableUnfavorableAttackCheck(1000000, 3000)
    f1_arg1:EnableUnfavorableAttackCheck(1000000, 3001)
    f1_arg1:EnableUnfavorableAttackCheck(1000000, 3002)
    f1_arg1:EnableUnfavorableAttackCheck(1000000, 3003)
    f1_arg1:EnableUnfavorableAttackCheck(1000000, 3004)
    f1_arg1:EnableUnfavorableAttackCheck(1000000, 3005)
    f1_arg1:EnableUnfavorableAttackCheck(1000000, 3006)
    f1_arg1:EnableUnfavorableAttackCheck(1000000, 3007)
    f1_arg1:EnableUnfavorableAttackCheck(1000000, 3008)
    f1_arg1:EnableUnfavorableAttackCheck(1000000, 3009)
    f1_arg1:EnableUnfavorableAttackCheck(1000000, 3011)
    f1_arg1:EnableUnfavorableAttackCheck(1000000, 3012)
    f1_arg1:EnableUnfavorableAttackCheck(1000000, 3013)
    f1_arg1:EnableUnfavorableAttackCheck(1000000, 3020)
    
end

Goal.Activate = function (f2_arg0, f2_arg1, f2_arg2)
    local f2_local0 = {}
    local f2_local1 = {}
    local f2_local2 = {}
    Common_Clear_Param(f2_local0, f2_local1, f2_local2)
    Init_Pseudo_Global(f2_arg1, f2_arg2)
    f2_arg1:SetStringIndexedNumber("Dist_SideStep", 2.7 + 1)
    f2_arg1:SetStringIndexedNumber("Dist_BackStep", 2.5 + 1)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    local f2_local3 = f2_arg1:GetDist(TARGET_ENE_0)
    local f2_local4 = f2_arg1:GetEventRequest()
    local f2_local5 = f2_arg1:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__thinkAttr_doAdmirer)
    local f2_local6 = f2_arg1:GetRandam_Int(1, 100)
    local f2_local7 = f2_arg1:GetRandam_Int(1, 100)
    local f2_local8 = f2_arg1:HasSpecialEffectId(TARGET_SELF, 12540)
    if f2_local5 == 1 and f2_arg1:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Kankyaku then
        f2_local0[11] = 60
        f2_local0[12] = 40
    elseif f2_local5 == 1 and f2_arg1:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Torimaki then
        f2_local0[1] = 5
        f2_local0[2] = 5
        f2_local0[3] = 3
        f2_local0[4] = 2
        f2_local0[11] = 50
        f2_local0[12] = 35
    elseif f2_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_B, 240) and f2_local3 >= 2 and f2_local3 <= 10 then
        f2_local0[13] = 100
    elseif f2_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_B, 90) and f2_local3 <= 2 then
        f2_local0[13] = 100
    elseif f2_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_R, 90) and f2_local3 <= 2 then
        f2_local0[1] = 20
        f2_local0[7] = 20
        f2_local0[5] = 20
        f2_local0[10] = 80
        f2_local0[13] = 45
        f2_local0[14] = 15
    elseif f2_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_L, 90) and f2_local3 <= 2 then
        f2_local0[1] = 20
        f2_local0[8] = 20
        f2_local0[5] = 20
        f2_local0[10] = 80
        f2_local0[13] = 45
        f2_local0[14] = 15
    elseif f2_arg1:IsTargetGuard(TARGET_ENE_0) and f2_local3 > 1.7 and f2_local3 <= 5 and f2_local7 <= 40 then
        f2_local0[5] = 100
        f2_local0[9] = 20
        f2_local0[10] = 100
    elseif f2_arg1:IsTargetGuard(TARGET_ENE_0) and f2_local3 <= 1.7 and f2_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_F, 60) and f2_local7 <= 50 then
        f2_local0[5] = 100
        f2_local0[9] = 20
        f2_local0[10] = 100
    elseif f2_local3 >= 10 and f2_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_F, 60) and f2_local7 <= 70 then
        f2_local0[4] = 100
    elseif f2_local3 >= 8 then
        f2_local0[1] = 60
        f2_local0[2] = 30
        f2_local0[6] = 10
        f2_local0[10] = 100
    elseif f2_local3 >= 6 then
        f2_local0[1] = 60
        f2_local0[2] = 30
        f2_local0[6] = 20
        f2_local0[10] = 100
    elseif f2_local3 >= 4 then
        f2_local0[1] = 55
        f2_local0[2] = 35
        f2_local0[6] = 20
        f2_local0[14] = 0
        f2_local0[10] = 100
    elseif f2_local3 >= 3 then
        f2_local0[1] = 20
        f2_local0[2] = 35
        f2_local0[3] = 5
        f2_local0[14] = 70
        f2_local0[10] = 100
    elseif f2_local3 >= 2 then
        f2_local0[1] = 20
        f2_local0[2] = 20
        f2_local0[3] = 5
        f2_local0[14] = 70
        f2_local0[10] = 100
    else
        f2_local0[3] = 5
        f2_local0[5] = 75
        f2_local0[9] = 20
        f2_local0[14] = 20
        f2_local0[10] = 100
    end
    f2_local0[1] = SetCoolTime(f2_arg1, f2_arg2, 3000, 8, f2_local0[1], 1)
    f2_local0[2] = SetCoolTime(f2_arg1, f2_arg2, 3002, 8, f2_local0[2], 1)
    f2_local0[4] = SetCoolTime(f2_arg1, f2_arg2, 3004, 15, f2_local0[4], 1)
    f2_local0[5] = SetCoolTime(f2_arg1, f2_arg2, 3005, 8, f2_local0[5], 1)
    f2_local0[6] = SetCoolTime(f2_arg1, f2_arg2, 3006, 8, f2_local0[6], 1)
    f2_local0[7] = SetCoolTime(f2_arg1, f2_arg2, 3011, 8, f2_local0[7], 1)
    f2_local0[8] = SetCoolTime(f2_arg1, f2_arg2, 3012, 8, f2_local0[8], 1)
    f2_local0[9] = SetCoolTime(f2_arg1, f2_arg2, 3013, 8, f2_local0[9], 1)
    f2_local0[10] = SetCoolTime(f2_arg1, f2_arg2, 3035, f2_arg1:GetRandam_Int(10, 18), f2_local0[10], 1)
    if f2_arg1:IsFinishTimer(0) == false and f2_local0[13] > 0 then
        f2_local0[13] = 1
    end
    if f2_arg1:IsFinishTimer(1) == false and f2_local0[14] > 0 then
        f2_local0[14] = 1
    end
    if f2_local8 == false then
        f2_local0[10] = 0
    end
    f2_local1[1] = REGIST_FUNC(f2_arg1, f2_arg2, DosouSkeleton_PoleSword_306010_Act01)
    f2_local1[2] = REGIST_FUNC(f2_arg1, f2_arg2, DosouSkeleton_PoleSword_306010_Act02)
    f2_local1[3] = REGIST_FUNC(f2_arg1, f2_arg2, DosouSkeleton_PoleSword_306010_Act03)
    f2_local1[4] = REGIST_FUNC(f2_arg1, f2_arg2, DosouSkeleton_PoleSword_306010_Act04)
    f2_local1[5] = REGIST_FUNC(f2_arg1, f2_arg2, DosouSkeleton_PoleSword_306010_Act05)
    f2_local1[6] = REGIST_FUNC(f2_arg1, f2_arg2, DosouSkeleton_PoleSword_306010_Act06)
    f2_local1[7] = REGIST_FUNC(f2_arg1, f2_arg2, DosouSkeleton_PoleSword_306010_Act07)
    f2_local1[8] = REGIST_FUNC(f2_arg1, f2_arg2, DosouSkeleton_PoleSword_306010_Act08)
    f2_local1[9] = REGIST_FUNC(f2_arg1, f2_arg2, DosouSkeleton_PoleSword_306010_Act09)
    f2_local1[10] = REGIST_FUNC(f2_arg1, f2_arg2, DosouSkeleton_PoleSword_306010_Act10)
    f2_local1[11] = REGIST_FUNC(f2_arg1, f2_arg2, DosouSkeleton_PoleSword_306010_Act11)
    f2_local1[12] = REGIST_FUNC(f2_arg1, f2_arg2, DosouSkeleton_PoleSword_306010_Act12)
    f2_local1[13] = REGIST_FUNC(f2_arg1, f2_arg2, DosouSkeleton_PoleSword_306010_Act13)
    f2_local1[14] = REGIST_FUNC(f2_arg1, f2_arg2, DosouSkeleton_PoleSword_306010_Act14)
    f2_local1[20] = REGIST_FUNC(f2_arg1, f2_arg2, DosouSkeleton_PoleSword_306010_Act20)
    local f2_local9 = REGIST_FUNC(f2_arg1, f2_arg2, DosouSkeleton_PoleSword_306010_ActAfter_AdjustSpace)
    Common_Battle_Activate(f2_arg1, f2_arg2, f2_local0, f2_local1, f2_local9, f2_local2)
    
end

function DosouSkeleton_PoleSword_306010_Act01(f3_arg0, f3_arg1, f3_arg2)
    local f3_local0 = 5.8 - f3_arg0:GetMapHitRadius(TARGET_SELF)
    local f3_local1 = 5.8 - f3_arg0:GetMapHitRadius(TARGET_SELF) + 1
    local f3_local2 = 5.8 - f3_arg0:GetMapHitRadius(TARGET_SELF) + 2
    local f3_local3 = 75
    local f3_local4 = 0
    local f3_local5 = 3
    local f3_local6 = 8
    Approach_Act_Flex(f3_arg0, f3_arg1, f3_local0, f3_local1, f3_local2, f3_local3, f3_local4, f3_local5, f3_local6)
    local f3_local7 = 3000
    local f3_local8 = 3001
    local f3_local9 = 3002
    local f3_local10 = 3009
    local f3_local11 = 3007
    local f3_local12 = 4.5 - f3_arg0:GetMapHitRadius(TARGET_SELF) + 1
    local f3_local13 = 5.6 - f3_arg0:GetMapHitRadius(TARGET_SELF) + 1
    local f3_local14 = 6.8 - f3_arg0:GetMapHitRadius(TARGET_SELF) + 1
    local f3_local15 = 4.5 - f3_arg0:GetMapHitRadius(TARGET_SELF) + 1
    local f3_local16 = 5 - f3_arg0:GetMapHitRadius(TARGET_SELF)
    local f3_local17 = 0
    local f3_local18 = 0
    local f3_local19 = f3_arg0:GetRandam_Int(1, 100)
    local f3_local20 = f3_arg0:GetRandam_Int(1, 100)
    if f3_local19 <= 50 then
        f3_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f3_local7, TARGET_ENE_0, f3_local12, f3_local17, f3_local18, 0, 0)
        f3_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, f3_local8, TARGET_ENE_0, f3_local14, 0, 0)
        f3_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 10, f3_local10, TARGET_ENE_0, f3_local16, 0, 0)
    else
        f3_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f3_local7, TARGET_ENE_0, f3_local13, f3_local17, f3_local18, 0, 0)
        f3_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f3_local9, TARGET_ENE_0, f3_local15, 0, 0)
        f3_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 10, f3_local11, TARGET_ENE_0, f3_local16, 0, 0)
    end
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function DosouSkeleton_PoleSword_306010_Act02(f4_arg0, f4_arg1, f4_arg2)
    local f4_local0 = 5.6 - f4_arg0:GetMapHitRadius(TARGET_SELF)
    local f4_local1 = 5.6 - f4_arg0:GetMapHitRadius(TARGET_SELF) + 1
    local f4_local2 = 5.6 - f4_arg0:GetMapHitRadius(TARGET_SELF) + 2
    local f4_local3 = 75
    local f4_local4 = 0
    local f4_local5 = 3
    local f4_local6 = 8
    Approach_Act_Flex(f4_arg0, f4_arg1, f4_local0, f4_local1, f4_local2, f4_local3, f4_local4, f4_local5, f4_local6)
    local f4_local7 = 3002
    local f4_local8 = 3008
    local f4_local9 = 3007
    local f4_local10 = 6.8 - f4_arg0:GetMapHitRadius(TARGET_SELF) + 1
    local f4_local11 = 4.5 - f4_arg0:GetMapHitRadius(TARGET_SELF) + 1
    local f4_local12 = 5 - f4_arg0:GetMapHitRadius(TARGET_SELF)
    local f4_local13 = 0
    local f4_local14 = 0
    local f4_local15 = f4_arg0:GetRandam_Int(1, 100)
    if f4_local15 <= 50 then
        f4_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f4_local7, TARGET_ENE_0, f4_local10, f4_local13, f4_local14, 0, 0)
        f4_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 10, f4_local8, TARGET_ENE_0, f4_local12, 0, 0)
    else
        f4_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f4_local7, TARGET_ENE_0, f4_local11, f4_local13, f4_local14, 0, 0)
        f4_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 10, f4_local9, TARGET_ENE_0, f4_local12, 0, 0)
    end
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function DosouSkeleton_PoleSword_306010_Act03(f5_arg0, f5_arg1, f5_arg2)
    local f5_local0 = 3.8 - f5_arg0:GetMapHitRadius(TARGET_SELF)
    local f5_local1 = 3.8 - f5_arg0:GetMapHitRadius(TARGET_SELF) + 1
    local f5_local2 = 3.8 - f5_arg0:GetMapHitRadius(TARGET_SELF) + 2
    local f5_local3 = 75
    local f5_local4 = 0
    local f5_local5 = 3
    local f5_local6 = 8
    Approach_Act_Flex(f5_arg0, f5_arg1, f5_local0, f5_local1, f5_local2, f5_local3, f5_local4, f5_local5, f5_local6)
    local f5_local7 = 3003
    local f5_local8 = 3002
    local f5_local9 = 5.6 - f5_arg0:GetMapHitRadius(TARGET_SELF) + 1
    local f5_local10 = 5 - f5_arg0:GetMapHitRadius(TARGET_SELF)
    local f5_local11 = 0
    local f5_local12 = 0
    local f5_local13 = f5_arg0:GetRandam_Int(1, 100)
    f5_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f5_local7, TARGET_ENE_0, f5_local9, f5_local11, f5_local12, 0, 0)
    f5_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 10, f5_local8, TARGET_ENE_0, f5_local10, 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function DosouSkeleton_PoleSword_306010_Act04(f6_arg0, f6_arg1, f6_arg2)
    local f6_local0 = 10.5 - f6_arg0:GetMapHitRadius(TARGET_SELF)
    local f6_local1 = 10.5 - f6_arg0:GetMapHitRadius(TARGET_SELF) + 0
    local f6_local2 = 10.5 - f6_arg0:GetMapHitRadius(TARGET_SELF) + 0
    local f6_local3 = 100
    local f6_local4 = 0
    local f6_local5 = 2
    local f6_local6 = 8
    Approach_Act_Flex(f6_arg0, f6_arg1, f6_local0, f6_local1, f6_local2, f6_local3, f6_local4, f6_local5, f6_local6)
    local f6_local7 = 3004
    local f6_local8 = 5 - f6_arg0:GetMapHitRadius(TARGET_SELF)
    local f6_local9 = 0
    local f6_local10 = 0
    local f6_local11 = f6_arg0:GetRandam_Int(1, 100)
    f6_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f6_local7, TARGET_ENE_0, f6_local8, f6_local9, f6_local10, 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function DosouSkeleton_PoleSword_306010_Act05(f7_arg0, f7_arg1, f7_arg2)
    local f7_local0 = 1.7 - f7_arg0:GetMapHitRadius(TARGET_SELF)
    local f7_local1 = 1.7 - f7_arg0:GetMapHitRadius(TARGET_SELF) + 1
    local f7_local2 = 1.7 - f7_arg0:GetMapHitRadius(TARGET_SELF) + 2
    local f7_local3 = 75
    local f7_local4 = 0
    local f7_local5 = 3
    local f7_local6 = 8
    Approach_Act_Flex(f7_arg0, f7_arg1, f7_local0, f7_local1, f7_local2, f7_local3, f7_local4, f7_local5, f7_local6)
    local f7_local7 = 3005
    local f7_local8 = 3003
    local f7_local9 = 5 - f7_arg0:GetMapHitRadius(TARGET_SELF)
    local f7_local10 = 0
    local f7_local11 = 0
    local f7_local12 = f7_arg0:GetRandam_Int(1, 100)
    f7_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f7_local7, TARGET_ENE_0, 0, f7_local10, f7_local11, 0, 0)
    f7_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 10, f7_local8, TARGET_ENE_0, f7_local9, f7_local10, f7_local11, 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function DosouSkeleton_PoleSword_306010_Act06(f8_arg0, f8_arg1, f8_arg2)
    local f8_local0 = 6.8 - f8_arg0:GetMapHitRadius(TARGET_SELF)
    local f8_local1 = 6.8 - f8_arg0:GetMapHitRadius(TARGET_SELF) + 1
    local f8_local2 = 6.8 - f8_arg0:GetMapHitRadius(TARGET_SELF) + 2
    local f8_local3 = 75
    local f8_local4 = 0
    local f8_local5 = 3
    local f8_local6 = 8
    Approach_Act_Flex(f8_arg0, f8_arg1, f8_local0, f8_local1, f8_local2, f8_local3, f8_local4, f8_local5, f8_local6)
    local f8_local7 = 3006
    local f8_local8 = 5 - f8_arg0:GetMapHitRadius(TARGET_SELF)
    local f8_local9 = 0
    local f8_local10 = 0
    local f8_local11 = f8_arg0:GetRandam_Int(1, 100)
    f8_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f8_local7, TARGET_ENE_0, f8_local8, f8_local9, f8_local10, 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function DosouSkeleton_PoleSword_306010_Act07(f9_arg0, f9_arg1, f9_arg2)
    local f9_local0 = 3011
    local f9_local1 = 5 - f9_arg0:GetMapHitRadius(TARGET_SELF)
    local f9_local2 = 0
    local f9_local3 = 0
    local f9_local4 = f9_arg0:GetRandam_Int(1, 100)
    f9_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f9_local0, TARGET_ENE_0, f9_local1, f9_local2, f9_local3, 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function DosouSkeleton_PoleSword_306010_Act08(f10_arg0, f10_arg1, f10_arg2)
    local f10_local0 = 3012
    local f10_local1 = 5 - f10_arg0:GetMapHitRadius(TARGET_SELF)
    local f10_local2 = 0
    local f10_local3 = 0
    local f10_local4 = f10_arg0:GetRandam_Int(1, 100)
    f10_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f10_local0, TARGET_ENE_0, f10_local1, f10_local2, f10_local3, 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function DosouSkeleton_PoleSword_306010_Act09(f11_arg0, f11_arg1, f11_arg2)
    local f11_local0 = 3013
    local f11_local1 = 5 - f11_arg0:GetMapHitRadius(TARGET_SELF)
    local f11_local2 = 0
    local f11_local3 = 0
    local f11_local4 = f11_arg0:GetRandam_Int(1, 100)
    f11_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f11_local0, TARGET_ENE_0, f11_local1, f11_local2, f11_local3, 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function DosouSkeleton_PoleSword_306010_Act10(f12_arg0, f12_arg1, f12_arg2)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    local f12_local0 = 6 - f12_arg0:GetMapHitRadius(TARGET_SELF)
    local f12_local1 = 6 - f12_arg0:GetMapHitRadius(TARGET_SELF) + 1
    local f12_local2 = 6 - f12_arg0:GetMapHitRadius(TARGET_SELF) + 3
    local f12_local3 = 100
    local f12_local4 = 0
    local f12_local5 = 3
    local f12_local6 = 8
    Approach_Act_Flex(f12_arg0, f12_arg1, f12_local0, f12_local1, f12_local2, f12_local3, f12_local4, f12_local5, f12_local6)
    local f12_local7 = 3035
    local f12_local8 = 3036
    local f12_local9 = 5 - f12_arg0:GetMapHitRadius(TARGET_SELF)
    local f12_local10 = 2
    local f12_local11 = 150
    local f12_local12 = f12_arg0:GetRandam_Int(1, 100)
    f12_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f12_local7, TARGET_ENE_0, f12_local9, f12_local10, f12_local11, 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function DosouSkeleton_PoleSword_306010_Act11(f13_arg0, f13_arg1, f13_arg2)
    local f13_local0 = f13_arg0:GetDist(TARGET_ENE_0)
    local f13_local1 = 10
    local f13_local2 = 12
    local f13_local3 = 0
    local f13_local4 = f13_arg0:GetDist(TARGET_ENE_0)
    if f13_local1 <= f13_local4 then
        Approach_Act(f13_arg0, f13_arg1, f13_local1, f13_local2, f13_local3, 3)
    end
    f13_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 5, TARGET_ENE_0, 10, TARGET_ENE_0, true, -1)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DosouSkeleton_PoleSword_306010_Act12(f14_arg0, f14_arg1, f14_arg2)
    f14_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, 4, TARGET_ENE_0, f14_arg0:GetRandam_Int(0, 1), f14_arg0:GetRandam_Int(30, 45), true, true, -1):SetTargetRange(1, 0.5, 999)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DosouSkeleton_PoleSword_306010_Act13(f15_arg0, f15_arg1, f15_arg2)
    f15_arg0:SetTimer(0, 5)
    f15_arg1:AddSubGoal(GOAL_COMMON_Turn, 1.5, TARGET_ENE_0, f15_arg0:GetRandam_Int(15, 20))
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DosouSkeleton_PoleSword_306010_Act14(f16_arg0, f16_arg1, f16_arg2)
    f16_arg0:SetTimer(1, 6)
    local f16_local0 = f16_arg0:GetRandam_Float(1, 1.5)
    local f16_local1 = -1
    f16_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, f16_local0, TARGET_ENE_0, 4.5, TARGET_ENE_0, true, f16_local1):SetTargetRange(1, 1, 999)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DosouSkeleton_PoleSword_306010_Act20(f17_arg0, f17_arg1, f17_arg2)
    local f17_local0 = 3000
    local f17_local1 = 3001
    local f17_local2 = 3004
    local f17_local3 = 0
    local f17_local4 = 0
    f17_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f17_local0, TARGET_ENE_0, 999, f17_local3, f17_local4)
    f17_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, f17_local1, TARGET_ENE_0, 999)
    f17_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 10, f17_local2, TARGET_ENE_0, 999)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DosouSkeleton_PoleSword_306010_ActAfter_AdjustSpace(f18_arg0, f18_arg1, f18_arg2)
    f18_arg1:AddSubGoal(GOAL_DosouSkeleton_PoleSword_306010_AfterAttackAct, 10)
    
end

Goal.Update = function (f19_arg0, f19_arg1, f19_arg2)
    return Update_Default_NoSubGoal(f19_arg0, f19_arg1, f19_arg2)
    
end

Goal.Terminate = function (f20_arg0, f20_arg1, f20_arg2)
    
end

Goal.Interrupt = function (f21_arg0, f21_arg1, f21_arg2)
    if f21_arg1:IsInterupt(INTERUPT_TargetOutOfRange) then
        f21_arg2:ClearSubGoal()
        return true
    end
    local f21_local0 = 3.5
    local f21_local1 = 40
    if Damaged_Act(f21_arg1, f21_arg2, f21_local0, f21_local1) then
        f21_arg2:ClearSubGoal()
        return true
    end
    if f21_arg1:GetSpecialEffectActivateInterruptType(0) == 5026 and f21_arg1:IsInsideTarget(TARGET_ENE_0, AI_DIR_TYPE_F, 200) and targetDist <= 8 and TypeBeast == true then
        f21_arg2:ClearSubGoal()
        f21_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 10, 3036, TARGET_ENE_0, SuccessDist, TurnTime, FrontAngle, 0, 0)
        return true
    end
    return false
    
end

RegisterTableGoal(GOAL_DosouSkeleton_PoleSword_306010_AfterAttackAct, "DosouSkeleton_PoleSword_306010_AfterAttackAct")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_DosouSkeleton_PoleSword_306010_AfterAttackAct, true)

Goal.Activate = function (f22_arg0, f22_arg1, f22_arg2)
    local f22_local0 = f22_arg1:GetDist(TARGET_ENE_0)
    local f22_local1 = f22_arg1:GetRandam_Int(1, 100)
    local f22_local2 = f22_arg1:GetRandam_Int(1, 100)
    local f22_local3 = 0
    local f22_local4 = f22_arg1:GetRandam_Float(2.5, 4.5)
    local f22_local5 = f22_arg1:GetRandam_Int(0, 1)
    local f22_local6 = f22_arg1:GetRandam_Int(30, 45)
    local f22_local7 = f22_arg1:GetRandam_Float(2.5, 4.5)
    local f22_local8 = f22_local0 + f22_arg1:GetRandam_Float(2.5, 4.5)
    local f22_local9 = -1
    if f22_arg1:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Kankyaku then
        if f22_local0 <= 6 then
            f22_arg2:AddSubGoal(GOAL_COMMON_LeaveTarget, f22_local7, TARGET_ENE_0, 8, TARGET_ENE_0, true, f22_local9):SetTargetRange(1, 1, 999)
        else
            f22_arg2:AddSubGoal(GOAL_COMMON_SidewayMove, f22_local4, TARGET_ENE_0, f22_local5, f22_local6, true, true, f22_local9):SetTargetRange(1, 1, 999)
        end
    elseif f22_arg1:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Torimaki then
        if f22_local0 <= 6 then
            f22_arg2:AddSubGoal(GOAL_COMMON_LeaveTarget, f22_local7, TARGET_ENE_0, 8, TARGET_ENE_0, true, f22_local9):SetTargetRange(1, 1, 999)
        else
            f22_arg2:AddSubGoal(GOAL_COMMON_SidewayMove, f22_local4, TARGET_ENE_0, f22_local5, f22_local6, true, true, f22_local9):SetTargetRange(1, 1, 999)
        end
    elseif f22_local0 >= 6 then
        if f22_local2 <= 50 then
            f22_arg2:AddSubGoal(GOAL_COMMON_SidewayMove, f22_local4, TARGET_ENE_0, f22_local5, f22_local6, true, true, f22_local9):SetTargetRange(1, 1, 999)
            if false then
            end
        end
    elseif f22_local0 >= 4 then
        if f22_local2 <= 35 then
            f22_arg2:AddSubGoal(GOAL_COMMON_SidewayMove, f22_local4, TARGET_ENE_0, f22_local5, f22_local6, true, true, f22_local9):SetTargetRange(1, 1, 999)
            if false then
            end
        end
    elseif f22_local0 >= 2 then
        if f22_local2 <= 10 then
            f22_arg2:AddSubGoal(GOAL_COMMON_SidewayMove, f22_local4, TARGET_ENE_0, f22_local5, f22_local6, true, true, f22_local9):SetTargetRange(1, 1, 999)
        elseif f22_local2 <= 15 then
            f22_arg2:AddSubGoal(GOAL_COMMON_LeaveTarget, f22_local7, TARGET_ENE_0, f22_local8, TARGET_ENE_0, true, f22_local9):SetTargetRange(1, 1, 999)
            if false then
            end
        end
    elseif f22_local0 >= 0.5 then
        if f22_local2 <= 0 then
            f22_arg2:AddSubGoal(GOAL_COMMON_SidewayMove, f22_local4, TARGET_ENE_0, f22_local5, f22_local6, true, true, f22_local9):SetTargetRange(1, 1, 999)
        elseif f22_local2 <= 15 then
            f22_arg2:AddSubGoal(GOAL_COMMON_LeaveTarget, f22_local7, TARGET_ENE_0, f22_local8, TARGET_ENE_0, true, f22_local9):SetTargetRange(1, 1, 999)
            if false then
            end
        end
    elseif f22_local2 <= 0 then
        f22_arg2:AddSubGoal(GOAL_COMMON_SidewayMove, f22_local4, TARGET_ENE_0, f22_local5, f22_local6, true, true, f22_local9):SetTargetRange(1, 1, 999)
    elseif f22_local2 <= 15 then
        f22_arg2:AddSubGoal(GOAL_COMMON_LeaveTarget, f22_local7, TARGET_ENE_0, f22_local8, TARGET_ENE_0, true, f22_local9):SetTargetRange(1, 1, 999)
    else
    end
    
end

Goal.Update = function (f23_arg0, f23_arg1, f23_arg2)
    return Update_Default_NoSubGoal(f23_arg0, f23_arg1, f23_arg2)
    
end

Goal.Interrupt = function (f24_arg0, f24_arg1, f24_arg2)
    if f24_arg1:IsInterupt(INTERUPT_TargetOutOfRange) then
        f24_arg2:ClearSubGoal()
        return true
    end
    return false
    
end


