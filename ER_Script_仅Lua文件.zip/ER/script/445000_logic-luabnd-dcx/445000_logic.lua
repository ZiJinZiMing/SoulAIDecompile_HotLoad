﻿function WalkShrine445000_Logic(f1_arg0)
    local f1_local0 = f1_arg0:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__battleGoalID)
    local f1_local1 = nil
    f1_local1 = f1_arg0:AddTopGoal(f1_local0, -1)
    if f1_local1 then
        f1_local1:SetManagementGoal()
    end
    
end

function WalkShrine445000_Interupt(f2_arg0, f2_arg1)
    
end


