﻿function npc31000_Logic(f1_arg0)
    COMMON_Initialize(f1_arg0)
    if COMMON_EasySetup_Initial(f1_arg0) == false then
        local f1_local0 = f1_arg0:GetEventRequest()
        local f1_local1 = f1_arg0:GetEventRequest(1)
        local f1_local2 = f1_arg0:IsSearchTarget(TARGET_ENE_0)
        if f1_local0 == 100 then
            f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 5, POINT_INITIAL, 0.5, TARGET_SELF, true, -1)
        elseif f1_local0 == 110 then
            f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 5, POINT_INITIAL, 0.5, TARGET_SELF, false, -1)
        elseif f1_local0 == 80 then
            f1_arg0:AddTopGoal(GOAL_COMMON_Wait, 0.5, TARGET_NONE)
            f1_arg0:AddTopGoal(GOAL_COMMON_WaitWithAnime, 10, 1000 + f1_local1, TARGET_NONE)
        elseif f1_arg0:IsBattleState() == false and f1_arg0:IsSearchHighState() == false and f1_arg0:IsSearchLowState() == false and f1_arg0:IsCautionState() == false and f1_arg0:IsMemoryState() == false then
            if f1_arg0:GetDist(TARGET_HOSTPLAYER) > 2 then
                f1_arg0:AddTopGoal(GOAL_COMMON_ApproachTarget, 10, TARGET_HOSTPLAYER, 2, TARGET_SELF, false, -1)
            else
                f1_arg0:AddTopGoal(GOAL_COMMON_Wait, 2, TARGET_HOSTPLAYER)
            end
        else
            COMMON_EasySetup3(f1_arg0)
        end
    end
    
end

function npc31000_Interupt(f2_arg0, f2_arg1)
    return false
    
end


