﻿RegisterTableGoal(GOAL_TombShadow_366400_Battle, "TombShadow_366400_Battle")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_TombShadow_366400_Battle, true)

Goal.Initialize = function (f1_arg0, f1_arg1, f1_arg2, f1_arg3)
    f1_arg1:SetNumber(5, 0)
    
end

Goal.Activate = function (f2_arg0, f2_arg1, f2_arg2)
    Init_Pseudo_Global(f2_arg1, f2_arg2)
    local f2_local0 = {}
    local f2_local1 = {}
    local f2_local2 = {}
    Common_Clear_Param(f2_local0, f2_local1, f2_local2)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5028)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5029)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 17265)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_ENE_0, 17250)
    local f2_local3 = f2_arg1:GetDist(TARGET_ENE_0)
    local f2_local4 = f2_arg1:GetRandam_Int(1, 100)
    if f2_arg1:IsFinishTimer(0) then
        f2_arg1:SetNumber(1, 1)
    end
    if f2_arg1:GetNumber(1) >= 5 then
        f2_arg1:SetTimer(0, 0)
    end
    f2_arg1:SetNumber(7, 0)
    f2_arg1:SetNumber(8, 0)
    local f2_local5 = f2_arg1:HasSpecialEffectId(TARGET_SELF, 17270)
    local f2_local6 = 1
    if f2_arg1:GetNumber(5) >= 60 then
        f2_local6 = f2_arg1:GetRandam_Int(10, 120)
    elseif f2_arg1:GetNumber(5) >= 40 then
        f2_local6 = f2_arg1:GetRandam_Int(10, 100)
    elseif f2_arg1:GetNumber(5) >= 30 then
        f2_local6 = f2_arg1:GetRandam_Int(10, 80)
    elseif f2_arg1:GetNumber(5) >= 20 then
        f2_local6 = f2_arg1:GetRandam_Int(10, 45)
    elseif f2_arg1:GetNumber(5) >= 12 then
        f2_local6 = f2_arg1:GetRandam_Int(10, 30)
    else
        f2_local6 = f2_arg1:GetRandam_Int(1, 10)
    end
    if f2_local6 >= 20 then
        f2_local0[20] = 100
    elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_B, 90, 180, 999) then
        if f2_arg1:HasSpecialEffectId(TARGET_ENE_0, 17250) then
            f2_local0[17] = 100
        else
            f2_local0[17] = 1
            f2_local0[32] = 1000
            f2_local0[33] = 1000
        end
    elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_R, 90, 180, 999) then
        if f2_arg1:HasSpecialEffectId(TARGET_ENE_0, 17250) then
            f2_local0[17] = 100
        else
            f2_local0[17] = 1
            f2_local0[32] = 1000
        end
    elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_L, 90, 180, 999) then
        if f2_arg1:HasSpecialEffectId(TARGET_ENE_0, 17250) then
            f2_local0[17] = 100
        else
            f2_local0[17] = 1
            f2_local0[33] = 1000
        end
    elseif f2_local3 >= 10 then
        if f2_arg1:HasSpecialEffectId(TARGET_ENE_0, 17250) then
            f2_local0[16] = 1
            f2_local0[30] = 1000
        else
            f2_local0[16] = 100
            if f2_arg1:IsFinishTimer(1) then
                f2_local0[30] = 1000
            else
                f2_local0[32] = 400 / 1
                f2_local0[33] = 400 / 1
            end
        end
    elseif f2_local3 >= 6 then
        if f2_arg1:HasSpecialEffectId(TARGET_ENE_0, 17250) then
            f2_local0[1] = 0
            f2_local0[2] = 0
            f2_local0[3] = 0
            f2_local0[4] = 0
            f2_local0[5] = 0
            f2_local0[15] = 0
            f2_local0[16] = 1
            if f2_arg1:IsFinishTimer(1) then
                f2_local0[30] = 1000
            end
        else
            f2_local0[1] = 0
            f2_local0[2] = 0
            f2_local0[3] = 0
            f2_local0[4] = 400
            f2_local0[5] = 0
            f2_local0[15] = 0
            f2_local0[16] = 150
            if f2_arg1:IsFinishTimer(1) then
                f2_local0[30] = 450
            else
                f2_local0[32] = 400 / 1
                f2_local0[33] = 400 / 1
            end
        end
    elseif f2_local3 >= 3 then
        if f2_arg1:HasSpecialEffectId(TARGET_ENE_0, 17250) then
            f2_local0[1] = 0
            f2_local0[2] = 0
            f2_local0[3] = 0
            f2_local0[4] = 0
            f2_local0[5] = 0
            f2_local0[10] = 1000
            f2_local0[15] = 0
            f2_local0[16] = 1
            if f2_arg1:IsFinishTimer(1) then
                f2_local0[30] = 5
            end
        else
            f2_local0[1] = 150
            f2_local0[2] = 250
            f2_local0[3] = 300
            f2_local0[4] = 0
            f2_local0[5] = 200
            f2_local0[10] = 0
            f2_local0[15] = 0
            f2_local0[16] = 50
            if f2_arg1:IsFinishTimer(1) then
                f2_local0[30] = 5
            end
            if f2_arg1:IsFinishTimer(0) then
                f2_local0[32] = 400 / 1
                f2_local0[33] = 400 / 1
            end
        end
    elseif f2_arg1:HasSpecialEffectId(TARGET_ENE_0, 17250) then
        f2_local0[1] = 0
        f2_local0[2] = 0
        f2_local0[3] = 0
        f2_local0[4] = 0
        f2_local0[5] = 0
        f2_local0[10] = 1000
        f2_local0[15] = 0
        f2_local0[16] = 1
        f2_local0[31] = 0
        f2_local0[32] = 0
        f2_local0[33] = 0
    else
        f2_local0[1] = 200
        f2_local0[2] = 100
        f2_local0[3] = 150
        f2_local0[4] = 0
        f2_local0[5] = 150
        f2_local0[15] = 0
        f2_local0[16] = 0
        f2_local0[34] = 80
        f2_local0[35] = 40
        f2_local0[36] = 40
        if f2_arg1:IsFinishTimer(0) then
            f2_local0[31] = 80
            f2_local0[32] = 80
            f2_local0[33] = 80
        else
            f2_local0[31] = 300 / 1
            f2_local0[32] = 400 / 1
            f2_local0[33] = 400 / 1
        end
    end
    if SpaceCheck(f2_arg1, f2_arg2, 180, 7) == false then
        f2_local0[31] = 0
    end
    if SpaceCheck(f2_arg1, f2_arg2, -90, 5) == false then
        f2_local0[32] = 0
    end
    if SpaceCheck(f2_arg1, f2_arg2, 90, 5) == false then
        f2_local0[33] = 0
    end
    if SpaceCheck(f2_arg1, f2_arg2, 180, 13) == false then
        f2_local0[34] = 0
    end
    if SpaceCheck(f2_arg1, f2_arg2, -90, 8) == false then
        f2_local0[35] = 0
    end
    if SpaceCheck(f2_arg1, f2_arg2, 90, 8) == false then
        f2_local0[36] = 0
    end
    if f2_local3 <= 1.5 then
        f2_local0[32] = 0
        f2_local0[33] = 0
        f2_local0[35] = 0
        f2_local0[36] = 0
    end
    f2_local0[1] = SetCoolTime(f2_arg1, f2_arg2, 3000, 9, f2_local0[1], 1)
    f2_local0[1] = SetCoolTime(f2_arg1, f2_arg2, 3001, 8, f2_local0[1], 1)
    f2_local0[1] = SetCoolTime(f2_arg1, f2_arg2, 3002, 8, f2_local0[1], 1)
    f2_local0[1] = SetCoolTime(f2_arg1, f2_arg2, 3003, 8, f2_local0[1], 1)
    f2_local0[2] = SetCoolTime(f2_arg1, f2_arg2, 3010, 11, f2_local0[2], 1)
    f2_local0[2] = SetCoolTime(f2_arg1, f2_arg2, 3011, 10, f2_local0[2], 1)
    f2_local0[3] = SetCoolTime(f2_arg1, f2_arg2, 3020, 8, f2_local0[3], 1)
    f2_local0[3] = SetCoolTime(f2_arg1, f2_arg2, 3021, 8, f2_local0[3], 1)
    f2_local0[3] = SetCoolTime(f2_arg1, f2_arg2, 3022, 8, f2_local0[3], 1)
    f2_local0[4] = SetCoolTime(f2_arg1, f2_arg2, 3024, 15, f2_local0[4], 1)
    f2_local0[5] = SetCoolTime(f2_arg1, f2_arg2, 3030, 13, f2_local0[5], 1)
    f2_local0[16] = SetCoolTime(f2_arg1, f2_arg2, 6000, 5, f2_local0[16], 1)
    f2_local0[16] = SetCoolTime(f2_arg1, f2_arg2, 6002, 5, f2_local0[16], 1)
    f2_local0[16] = SetCoolTime(f2_arg1, f2_arg2, 6003, 5, f2_local0[16], 1)
    f2_local0[16] = SetCoolTime(f2_arg1, f2_arg2, 6010, 5, f2_local0[16], 1)
    f2_local0[31] = SetCoolTime(f2_arg1, f2_arg2, 6000, 1.5, f2_local0[31], 1)
    f2_local0[31] = SetCoolTime(f2_arg1, f2_arg2, 6010, 1.5, f2_local0[31], 1)
    f2_local0[31] = SetCoolTime(f2_arg1, f2_arg2, 6001, 2, f2_local0[31], 1)
    f2_local0[32] = SetCoolTime(f2_arg1, f2_arg2, 6002, 1.5, f2_local0[32], 1)
    f2_local0[33] = SetCoolTime(f2_arg1, f2_arg2, 6003, 1.5, f2_local0[33], 1)
    f2_local0[34] = SetCoolTime(f2_arg1, f2_arg2, 6000, 8, f2_local0[34], 1)
    f2_local0[34] = SetCoolTime(f2_arg1, f2_arg2, 6001, 8, f2_local0[34], 1)
    f2_local0[34] = SetCoolTime(f2_arg1, f2_arg2, 6010, 8, f2_local0[34], 1)
    f2_local0[34] = SetCoolTime(f2_arg1, f2_arg2, 6011, 10, f2_local0[34], 1)
    f2_local0[34] = SetCoolTime(f2_arg1, f2_arg2, 6012, 10, f2_local0[34], 1)
    f2_local0[34] = SetCoolTime(f2_arg1, f2_arg2, 6013, 10, f2_local0[34], 1)
    f2_local0[35] = SetCoolTime(f2_arg1, f2_arg2, 6000, 8, f2_local0[35], 1)
    f2_local0[35] = SetCoolTime(f2_arg1, f2_arg2, 6001, 8, f2_local0[35], 1)
    f2_local0[35] = SetCoolTime(f2_arg1, f2_arg2, 6002, 1.5, f2_local0[35], 1)
    f2_local0[35] = SetCoolTime(f2_arg1, f2_arg2, 6010, 8, f2_local0[35], 1)
    f2_local0[35] = SetCoolTime(f2_arg1, f2_arg2, 6011, 10, f2_local0[35], 1)
    f2_local0[35] = SetCoolTime(f2_arg1, f2_arg2, 6012, 10, f2_local0[35], 1)
    f2_local0[35] = SetCoolTime(f2_arg1, f2_arg2, 6013, 10, f2_local0[35], 1)
    f2_local0[36] = SetCoolTime(f2_arg1, f2_arg2, 6000, 8, f2_local0[36], 1)
    f2_local0[36] = SetCoolTime(f2_arg1, f2_arg2, 6001, 8, f2_local0[36], 1)
    f2_local0[36] = SetCoolTime(f2_arg1, f2_arg2, 6003, 1.5, f2_local0[36], 1)
    f2_local0[36] = SetCoolTime(f2_arg1, f2_arg2, 6010, 8, f2_local0[36], 1)
    f2_local0[36] = SetCoolTime(f2_arg1, f2_arg2, 6011, 10, f2_local0[36], 1)
    f2_local0[36] = SetCoolTime(f2_arg1, f2_arg2, 6012, 10, f2_local0[36], 1)
    f2_local0[36] = SetCoolTime(f2_arg1, f2_arg2, 6013, 10, f2_local0[36], 1)
    f2_local1[1] = REGIST_FUNC(f2_arg1, f2_arg2, TombShadow_366400_Act01)
    f2_local1[2] = REGIST_FUNC(f2_arg1, f2_arg2, TombShadow_366400_Act02)
    f2_local1[3] = REGIST_FUNC(f2_arg1, f2_arg2, TombShadow_366400_Act03)
    f2_local1[4] = REGIST_FUNC(f2_arg1, f2_arg2, TombShadow_366400_Act04)
    f2_local1[5] = REGIST_FUNC(f2_arg1, f2_arg2, TombShadow_366400_Act05)
    f2_local1[6] = REGIST_FUNC(f2_arg1, f2_arg2, TombShadow_366400_Act06)
    f2_local1[7] = REGIST_FUNC(f2_arg1, f2_arg2, TombShadow_366400_Act07)
    f2_local1[8] = REGIST_FUNC(f2_arg1, f2_arg2, TombShadow_366400_Act08)
    f2_local1[9] = REGIST_FUNC(f2_arg1, f2_arg2, TombShadow_366400_Act09)
    f2_local1[10] = REGIST_FUNC(f2_arg1, f2_arg2, TombShadow_366400_Act10)
    f2_local1[15] = REGIST_FUNC(f2_arg1, f2_arg2, TombShadow_366400_Act15)
    f2_local1[16] = REGIST_FUNC(f2_arg1, f2_arg2, TombShadow_366400_Act16)
    f2_local1[17] = REGIST_FUNC(f2_arg1, f2_arg2, TombShadow_366400_Act17)
    f2_local1[18] = REGIST_FUNC(f2_arg1, f2_arg2, TombShadow_366400_Act18)
    f2_local1[20] = REGIST_FUNC(f2_arg1, f2_arg2, TombShadow_366400_Act20)
    f2_local1[30] = REGIST_FUNC(f2_arg1, f2_arg2, TombShadow_366400_Act30)
    f2_local1[31] = REGIST_FUNC(f2_arg1, f2_arg2, TombShadow_366400_Act31)
    f2_local1[32] = REGIST_FUNC(f2_arg1, f2_arg2, TombShadow_366400_Act32)
    f2_local1[33] = REGIST_FUNC(f2_arg1, f2_arg2, TombShadow_366400_Act33)
    f2_local1[34] = REGIST_FUNC(f2_arg1, f2_arg2, TombShadow_366400_Act34)
    f2_local1[35] = REGIST_FUNC(f2_arg1, f2_arg2, TombShadow_366400_Act35)
    f2_local1[36] = REGIST_FUNC(f2_arg1, f2_arg2, TombShadow_366400_Act36)
    local f2_local7 = REGIST_FUNC(f2_arg1, f2_arg2, TombShadow_366400_ActAfter_AdjustSpace)
    Common_Battle_Activate(f2_arg1, f2_arg2, f2_local0, f2_local1, f2_local7, f2_local2)
    
end

function TombShadow_366400_Act01(f3_arg0, f3_arg1, f3_arg2)
    local f3_local0 = f3_arg0:GetDist(TARGET_ENE_0)
    local f3_local1 = 3.2 - f3_arg0:GetMapHitRadius(TARGET_SELF)
    local f3_local2 = 3.2 - f3_arg0:GetMapHitRadius(TARGET_SELF) + 0.9
    local f3_local3 = 3.2 - f3_arg0:GetMapHitRadius(TARGET_SELF) + 10
    local f3_local4 = 0
    local f3_local5 = 0
    local f3_local6 = 0.5
    local f3_local7 = 6
    local f3_local8 = 3000
    local f3_local9 = 3001
    local f3_local10 = 3002
    local f3_local11 = 2.8 - f3_arg0:GetMapHitRadius(TARGET_SELF) + 1
    local f3_local12 = 3.3 - f3_arg0:GetMapHitRadius(TARGET_SELF) + 1
    local f3_local13 = 5 - f3_arg0:GetMapHitRadius(TARGET_SELF)
    local f3_local14 = 0
    local f3_local15 = 0
    local f3_local16 = f3_arg0:GetRandam_Int(1, 100)
    if f3_arg0:HasSpecialEffectId(TARGET_SELF, 17252) and f3_local0 <= f3_local1 then
        f3_local8 = 3004
    end
    Approach_Act_Flex(f3_arg0, f3_arg1, f3_local1, f3_local2, f3_local3, f3_local4, f3_local5, f3_local6, f3_local7)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17265)
    f3_arg0:SetNumber(5, f3_arg0:GetNumber(5) + 4)
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f3_local8, TARGET_ENE_0, f3_local11, f3_local14, f3_local15, 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function TombShadow_366400_Act02(f4_arg0, f4_arg1, f4_arg2)
    local f4_local0 = f4_arg0:GetDist(TARGET_ENE_0)
    local f4_local1 = 4 - f4_arg0:GetMapHitRadius(TARGET_SELF)
    local f4_local2 = 4 - f4_arg0:GetMapHitRadius(TARGET_SELF) + 0.9
    local f4_local3 = 4 - f4_arg0:GetMapHitRadius(TARGET_SELF) + 10
    local f4_local4 = 0
    local f4_local5 = 0
    local f4_local6 = 0.5
    local f4_local7 = 6
    local f4_local8 = 3010
    local f4_local9 = 3011
    local f4_local10 = 5.5 - f4_arg0:GetMapHitRadius(TARGET_SELF) + 1
    local f4_local11 = 5 - f4_arg0:GetMapHitRadius(TARGET_SELF)
    local f4_local12 = 0
    local f4_local13 = 0
    local f4_local14 = f4_arg0:GetRandam_Int(1, 100)
    if f4_arg0:HasSpecialEffectId(TARGET_SELF, 17252) and f4_local0 <= f4_local1 then
        f4_local8 = 3005
    end
    Approach_Act_Flex(f4_arg0, f4_arg1, f4_local1, f4_local2, f4_local3, f4_local4, f4_local5, f4_local6, f4_local7)
    f4_arg0:SetNumber(5, f4_arg0:GetNumber(5) + 4)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17265)
    f4_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f4_local8, TARGET_ENE_0, f4_local10, f4_local12, f4_local13, 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function TombShadow_366400_Act03(f5_arg0, f5_arg1, f5_arg2)
    local f5_local0 = f5_arg0:GetDist(TARGET_ENE_0)
    local f5_local1 = 6.5 - f5_arg0:GetMapHitRadius(TARGET_SELF)
    local f5_local2 = 6.5 - f5_arg0:GetMapHitRadius(TARGET_SELF) + 0.9
    local f5_local3 = 6.5 - f5_arg0:GetMapHitRadius(TARGET_SELF) + 10
    local f5_local4 = 0
    local f5_local5 = 0
    local f5_local6 = 0.5
    local f5_local7 = 6
    local f5_local8 = 3020
    local f5_local9 = 5.5 - f5_arg0:GetMapHitRadius(TARGET_SELF) + 1
    local f5_local10 = 5 - f5_arg0:GetMapHitRadius(TARGET_SELF)
    local f5_local11 = 0
    local f5_local12 = 0
    local f5_local13 = f5_arg0:GetRandam_Int(1, 100)
    if f5_arg0:HasSpecialEffectId(TARGET_SELF, 17252) and f5_local0 <= f5_local1 then
        f5_local8 = 3006
    end
    f5_arg0:SetNumber(2, 0)
    Approach_Act_Flex(f5_arg0, f5_arg1, f5_local1, f5_local2, f5_local3, f5_local4, f5_local5, f5_local6, f5_local7)
    f5_arg0:SetNumber(5, f5_arg0:GetNumber(5) + 4)
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5028)
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5029)
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17265)
    f5_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f5_local8, TARGET_ENE_0, 10, f5_local11, f5_local12, 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function TombShadow_366400_Act04(f6_arg0, f6_arg1, f6_arg2)
    local f6_local0 = 12 - f6_arg0:GetMapHitRadius(TARGET_SELF)
    local f6_local1 = 12 - f6_arg0:GetMapHitRadius(TARGET_SELF) + 0.9
    local f6_local2 = 12 - f6_arg0:GetMapHitRadius(TARGET_SELF) + 10
    local f6_local3 = 0
    local f6_local4 = 0
    local f6_local5 = 0.5
    local f6_local6 = 6
    Approach_Act_Flex(f6_arg0, f6_arg1, f6_local0, f6_local1, f6_local2, f6_local3, f6_local4, f6_local5, f6_local6)
    local f6_local7 = 3024
    local f6_local8 = 5.5 - f6_arg0:GetMapHitRadius(TARGET_SELF) + 1
    local f6_local9 = 5 - f6_arg0:GetMapHitRadius(TARGET_SELF)
    local f6_local10 = 0
    local f6_local11 = 0
    local f6_local12 = f6_arg0:GetRandam_Int(1, 100)
    f6_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f6_local7, TARGET_ENE_0, 10, f6_local10, f6_local11, 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function TombShadow_366400_Act05(f7_arg0, f7_arg1, f7_arg2)
    local f7_local0 = f7_arg0:GetDist(TARGET_ENE_0)
    local f7_local1 = 3.8 - f7_arg0:GetMapHitRadius(TARGET_SELF)
    local f7_local2 = 3.8 - f7_arg0:GetMapHitRadius(TARGET_SELF) + 0.9
    local f7_local3 = 3.8 - f7_arg0:GetMapHitRadius(TARGET_SELF) + 10
    local f7_local4 = 0
    local f7_local5 = 0
    local f7_local6 = 0.5
    local f7_local7 = 6
    local f7_local8 = 3030
    local f7_local9 = 5.5 - f7_arg0:GetMapHitRadius(TARGET_SELF) + 1
    local f7_local10 = 5 - f7_arg0:GetMapHitRadius(TARGET_SELF)
    local f7_local11 = 0
    local f7_local12 = 0
    local f7_local13 = f7_arg0:GetRandam_Int(1, 100)
    Approach_Act_Flex(f7_arg0, f7_arg1, f7_local1, f7_local2, f7_local3, f7_local4, f7_local5, f7_local6, f7_local7)
    f7_arg0:SetNumber(5, f7_arg0:GetNumber(5) + 4)
    if f7_arg0:HasSpecialEffectId(TARGET_SELF, 17252) and f7_local0 <= f7_local1 then
        f7_local8 = 3007
    end
    f7_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f7_local8, TARGET_ENE_0, 10, f7_local11, f7_local12, 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function TombShadow_366400_Act06(f8_arg0, f8_arg1, f8_arg2)
    local f8_local0 = 3.2 - f8_arg0:GetMapHitRadius(TARGET_SELF)
    local f8_local1 = 3.2 - f8_arg0:GetMapHitRadius(TARGET_SELF) + 0.9
    local f8_local2 = 3.2 - f8_arg0:GetMapHitRadius(TARGET_SELF) + 2
    local f8_local3 = 50
    local f8_local4 = 0
    local f8_local5 = 4
    local f8_local6 = 6
    Approach_Act_Flex(f8_arg0, f8_arg1, f8_local0, f8_local1, f8_local2, f8_local3, f8_local4, f8_local5, f8_local6)
    f8_arg0:SetNumber(5, f8_arg0:GetNumber(5) + 4)
    local f8_local7 = 3000
    local f8_local8 = 3001
    local f8_local9 = 3002
    local f8_local10 = 999
    local f8_local11 = 999
    local f8_local12 = 5 - f8_arg0:GetMapHitRadius(TARGET_SELF)
    local f8_local13 = 0
    local f8_local14 = 0
    local f8_local15 = f8_arg0:GetRandam_Int(1, 100)
    f8_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f8_local7, TARGET_ENE_0, f8_local10, f8_local13, f8_local14, 0, 0)
    f8_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, f8_local8, TARGET_ENE_0, f8_local11, 0, 0, 0, 0)
    f8_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 10, f8_local9, TARGET_ENE_0, f8_local12, 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function TombShadow_366400_Act07(f9_arg0, f9_arg1, f9_arg2)
    local f9_local0 = 3.2 - f9_arg0:GetMapHitRadius(TARGET_SELF)
    local f9_local1 = 3.2 - f9_arg0:GetMapHitRadius(TARGET_SELF) + 0.9
    local f9_local2 = 3.2 - f9_arg0:GetMapHitRadius(TARGET_SELF) + 2
    local f9_local3 = 50
    local f9_local4 = 0
    local f9_local5 = 4
    local f9_local6 = 6
    Approach_Act_Flex(f9_arg0, f9_arg1, f9_local0, f9_local1, f9_local2, f9_local3, f9_local4, f9_local5, f9_local6)
    f9_arg0:SetNumber(5, f9_arg0:GetNumber(5) + 4)
    local f9_local7 = 3000
    local f9_local8 = 3001
    local f9_local9 = 3003
    local f9_local10 = 999
    local f9_local11 = 999
    local f9_local12 = 5 - f9_arg0:GetMapHitRadius(TARGET_SELF)
    local f9_local13 = 0
    local f9_local14 = 0
    local f9_local15 = f9_arg0:GetRandam_Int(1, 100)
    f9_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f9_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5026)
    f9_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 17265)
    f9_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f9_local7, TARGET_ENE_0, f9_local10, f9_local13, f9_local14, 0, 0)
    f9_arg1:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, f9_local8, TARGET_ENE_0, f9_local11, 0, 0, 0, 0)
    f9_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 10, f9_local9, TARGET_ENE_0, f9_local12, 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function TombShadow_366400_Act08(f10_arg0, f10_arg1, f10_arg2)
    local f10_local0 = 15 - f10_arg0:GetMapHitRadius(TARGET_SELF)
    local f10_local1 = 15 - f10_arg0:GetMapHitRadius(TARGET_SELF) + 0.9
    local f10_local2 = 15 - f10_arg0:GetMapHitRadius(TARGET_SELF) + 2
    local f10_local3 = 50
    local f10_local4 = 0
    local f10_local5 = 4
    local f10_local6 = 6
    Approach_Act_Flex(f10_arg0, f10_arg1, f10_local0, f10_local1, f10_local2, f10_local3, f10_local4, f10_local5, f10_local6)
    local f10_local7 = 3023
    local f10_local8 = 5.5 - f10_arg0:GetMapHitRadius(TARGET_SELF) + 1
    local f10_local9 = 5 - f10_arg0:GetMapHitRadius(TARGET_SELF)
    local f10_local10 = 0
    local f10_local11 = 0
    local f10_local12 = f10_arg0:GetRandam_Int(1, 100)
    f10_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f10_local7, TARGET_ENE_0, 10, f10_local10, f10_local11, 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function TombShadow_366400_Act09(f11_arg0, f11_arg1, f11_arg2)
    local f11_local0 = 12 - f11_arg0:GetMapHitRadius(TARGET_SELF)
    local f11_local1 = 12 - f11_arg0:GetMapHitRadius(TARGET_SELF)
    local f11_local2 = 100
    local f11_local3 = 0
    local f11_local4 = 0
    local f11_local5 = 4
    local f11_local6 = 6
    Approach_Act_Flex(f11_arg0, f11_arg1, f11_local0, f11_local1, f11_local2, f11_local3, f11_local4, f11_local5, f11_local6)
    local f11_local7 = 3024
    local f11_local8 = 5.5 - f11_arg0:GetMapHitRadius(TARGET_SELF) + 1
    local f11_local9 = 5 - f11_arg0:GetMapHitRadius(TARGET_SELF)
    local f11_local10 = 0
    local f11_local11 = 0
    local f11_local12 = f11_arg0:GetRandam_Int(1, 100)
    f11_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f11_local7, TARGET_ENE_0, 10, f11_local10, f11_local11, 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function TombShadow_366400_Act10(f12_arg0, f12_arg1, f12_arg2)
    local f12_local0 = f12_arg0:GetDist(TARGET_ENE_0)
    if f12_local0 > 10 then
        local f12_local1 = 6000
        local f12_local2 = f12_arg0:GetRandam_Int(1, 100)
        if f12_arg0:GetNumber(0) == 0 then
            f12_arg0:SetNumber(0, 1)
            f12_local1 = 6010
        else
            f12_arg0:SetNumber(0, 0)
        end
        local f12_local3 = 3012
        local f12_local4 = 999
        local f12_local5 = 5 - f12_arg0:GetMapHitRadius(TARGET_SELF)
        local f12_local6 = 0
        local f12_local7 = 0
        local f12_local8 = f12_arg0:GetRandam_Int(1, 100)
        f12_arg0:SetTimer(0, 0)
        f12_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, f12_local1, TARGET_ENE_0, 0, AI_DIR_TYPE_F, 3)
    end
    local f12_local1 = 2 - f12_arg0:GetMapHitRadius(TARGET_SELF)
    local f12_local2 = 2 - f12_arg0:GetMapHitRadius(TARGET_SELF) + 0.9
    local f12_local3 = 999
    local f12_local4 = 0
    local f12_local5 = 0
    local f12_local6 = 5
    local f12_local7 = 6
    Approach_Act_Flex(f12_arg0, f12_arg1, f12_local1, f12_local2, f12_local3, f12_local4, f12_local5, f12_local6, f12_local7)
    local f12_local8 = 3033
    local f12_local9 = 5.5 - f12_arg0:GetMapHitRadius(TARGET_SELF) + 1
    local f12_local10 = 5 - f12_arg0:GetMapHitRadius(TARGET_SELF)
    local f12_local11 = 0
    local f12_local12 = 0
    local f12_local13 = f12_arg0:GetRandam_Int(1, 100)
    f12_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f12_local8, TARGET_ENE_0, 10, f12_local11, f12_local12, 0, 0)
    GetWellSpace_Odds = 100
    return GetWellSpace_Odds
    
end

function TombShadow_366400_Act15(f13_arg0, f13_arg1, f13_arg2)
    local f13_local0 = f13_arg0:GetDist(TARGET_ENE_0)
    local f13_local1 = f13_arg0:GetRandam_Float(6, 8)
    local f13_local2 = 999
    local f13_local3 = 0
    local f13_local4 = f13_arg0:GetRandam_Int(1, 100)
    local f13_local5 = f13_arg0:GetRandam_Float(1, 1.8)
    if f13_local1 <= f13_local0 then
        Approach_Act(f13_arg0, f13_arg1, f13_local1, f13_local2, f13_local3, f13_local5)
    end
    f13_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, f13_local5, TARGET_ENE_0, f13_local1, TARGET_ENE_0, true, IsGuard)
    
end

function TombShadow_366400_Act16(f14_arg0, f14_arg1, f14_arg2)
    local f14_local0 = 0
    local f14_local1 = f14_arg0:GetRandam_Int(1, 100)
    local f14_local2 = f14_arg0:GetRandam_Float(1, 1.9)
    local f14_local3 = -1
    f14_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, f14_local2, TARGET_ENE_0, f14_arg0:GetRandam_Int(0, 1), f14_arg0:GetRandam_Int(30, 45), true, true, f14_local3)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function TombShadow_366400_Act17(f15_arg0, f15_arg1, f15_arg2)
    f15_arg1:AddSubGoal(GOAL_COMMON_Turn, 2, TARGET_ENE_0, 30, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function TombShadow_366400_Act18(f16_arg0, f16_arg1, f16_arg2)
    local f16_local0 = 0
    local f16_local1 = f16_arg0:GetRandam_Int(1, 100)
    local f16_local2 = f16_arg0:GetRandam_Float(1, 2.5)
    local f16_local3 = f16_arg0:GetRandam_Float(3, 5)
    local f16_local4 = -1
    f16_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, f16_local2, TARGET_ENE_0, f16_local3, TARGET_SELF, true, f16_local4)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function TombShadow_366400_Act20(f17_arg0, f17_arg1, f17_arg2)
    local f17_local0 = 6001
    if SpaceCheck(f17_arg0, f17_arg1, 180, 10) == true then
        local f17_local1 = 6011
    end
    local f17_local1 = 3013
    local f17_local2 = 999
    local f17_local3 = 5 - f17_arg0:GetMapHitRadius(TARGET_SELF)
    local f17_local4 = 0
    local f17_local5 = 0
    local f17_local6 = f17_arg0:GetRandam_Int(1, 100)
    f17_arg0:SetNumber(5, 4)
    f17_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, f17_local0, TARGET_ENE_0, 0, AI_DIR_TYPE_B, 3)
    local f17_local7 = 0
    local f17_local8 = f17_arg0:GetRandam_Int(1, 100)
    local f17_local9 = f17_arg0:GetRandam_Float(4, 6)
    local f17_local10 = -1
    if f17_local8 > 85 then
        f17_arg1:AddSubGoal(GOAL_COMMON_ApproachAround, f17_local9, TARGET_ENE_0, 0, TARGET_SELF, true, -1, AI_DIR_TYPE_ToBL, f17_arg0:GetRandam_Int(6, 10))
    elseif f17_local8 > 70 then
        f17_arg1:AddSubGoal(GOAL_COMMON_ApproachAround, f17_local9, TARGET_ENE_0, 0, TARGET_SELF, true, -1, AI_DIR_TYPE_ToBR, f17_arg0:GetRandam_Int(6, 10))
    elseif f17_local8 > 35 then
        f17_arg1:AddSubGoal(GOAL_COMMON_ApproachAround, f17_local9, TARGET_ENE_0, 0, TARGET_SELF, true, -1, AI_DIR_TYPE_ToL, f17_arg0:GetRandam_Int(8, 12))
    else
        f17_arg1:AddSubGoal(GOAL_COMMON_ApproachAround, f17_local9, TARGET_ENE_0, 0, TARGET_SELF, true, -1, AI_DIR_TYPE_ToR, f17_arg0:GetRandam_Int(8, 12))
    end
    
end

function TombShadow_366400_Act30(f18_arg0, f18_arg1, f18_arg2)
    local f18_local0 = 6000
    local f18_local1 = f18_arg0:GetRandam_Int(1, 100)
    if f18_arg0:GetNumber(0) == 0 then
        f18_arg0:SetNumber(0, 1)
        f18_local0 = 6010
    else
        f18_arg0:SetNumber(0, 0)
    end
    local f18_local2 = 3012
    local f18_local3 = 999
    local f18_local4 = 5 - f18_arg0:GetMapHitRadius(TARGET_SELF)
    local f18_local5 = 0
    local f18_local6 = 0
    local f18_local7 = f18_arg0:GetRandam_Int(1, 100)
    f18_arg0:SetTimer(0, 0)
    f18_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, f18_local0, TARGET_ENE_0, 0, AI_DIR_TYPE_F, 3)
    
end

function TombShadow_366400_Act31(f19_arg0, f19_arg1, f19_arg2)
    local f19_local0 = 6001
    local f19_local1 = 3013
    local f19_local2 = 999
    local f19_local3 = 5 - f19_arg0:GetMapHitRadius(TARGET_SELF)
    local f19_local4 = 0
    local f19_local5 = 0
    local f19_local6 = f19_arg0:GetRandam_Int(1, 100)
    if f19_arg0:IsFinishTimer(0) then
        f19_arg0:SetTimer(0, 2)
    end
    f19_arg0:SetTimer(1, 1.5)
    f19_arg0:SetNumber(1, f19_arg0:GetNumber(1) + 1)
    f19_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, f19_local0, TARGET_ENE_0, 0, AI_DIR_TYPE_B, 3)
    
end

function TombShadow_366400_Act32(f20_arg0, f20_arg1, f20_arg2)
    local f20_local0 = 6002
    local f20_local1 = 3014
    local f20_local2 = 999
    local f20_local3 = 5 - f20_arg0:GetMapHitRadius(TARGET_SELF)
    local f20_local4 = 0
    local f20_local5 = 0
    local f20_local6 = f20_arg0:GetRandam_Int(1, 100)
    if f20_arg0:IsFinishTimer(0) then
        f20_arg0:SetTimer(0, 3)
    end
    f20_arg0:SetNumber(1, f20_arg0:GetNumber(1) + 1)
    f20_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, f20_local0, TARGET_ENE_0, 0, AI_DIR_TYPE_L, 3)
    
end

function TombShadow_366400_Act33(f21_arg0, f21_arg1, f21_arg2)
    local f21_local0 = 6003
    local f21_local1 = 3015
    local f21_local2 = 999
    local f21_local3 = 5 - f21_arg0:GetMapHitRadius(TARGET_SELF)
    local f21_local4 = 0
    local f21_local5 = 0
    local f21_local6 = f21_arg0:GetRandam_Int(1, 100)
    if f21_arg0:IsFinishTimer(0) then
        f21_arg0:SetTimer(0, 3)
    end
    f21_arg0:SetNumber(1, f21_arg0:GetNumber(1) + 1)
    f21_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, f21_local0, TARGET_ENE_0, 0, AI_DIR_TYPE_R, 3)
    
end

function TombShadow_366400_Act34(f22_arg0, f22_arg1, f22_arg2)
    local f22_local0 = 6011
    local f22_local1 = 3017
    local f22_local2 = 999
    local f22_local3 = 5 - f22_arg0:GetMapHitRadius(TARGET_SELF)
    local f22_local4 = 0
    local f22_local5 = 0
    local f22_local6 = f22_arg0:GetRandam_Int(1, 100)
    f22_arg0:SetTimer(0, 0)
    f22_arg0:SetTimer(1, 1.5)
    f22_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, f22_local0, TARGET_ENE_0, 0, AI_DIR_TYPE_B, 3)
    
end

function TombShadow_366400_Act35(f23_arg0, f23_arg1, f23_arg2)
    local f23_local0 = 6012
    local f23_local1 = 3018
    local f23_local2 = 999
    local f23_local3 = 5 - f23_arg0:GetMapHitRadius(TARGET_SELF)
    local f23_local4 = 0
    local f23_local5 = 0
    local f23_local6 = f23_arg0:GetRandam_Int(1, 100)
    f23_arg0:SetTimer(0, 0)
    f23_arg0:SetTimer(1, 1.5)
    f23_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, f23_local0, TARGET_ENE_0, 0, AI_DIR_TYPE_L, 3)
    
end

function TombShadow_366400_Act36(f24_arg0, f24_arg1, f24_arg2)
    local f24_local0 = 6013
    local f24_local1 = 3019
    local f24_local2 = 999
    local f24_local3 = 5 - f24_arg0:GetMapHitRadius(TARGET_SELF)
    local f24_local4 = 0
    local f24_local5 = 0
    local f24_local6 = f24_arg0:GetRandam_Int(1, 100)
    f24_arg0:SetTimer(0, 0)
    f24_arg0:SetTimer(1, 1.5)
    f24_arg1:AddSubGoal(GOAL_COMMON_SpinStep, 5, f24_local0, TARGET_ENE_0, 0, AI_DIR_TYPE_R, 3)
    
end

function TombShadow_366400_ActAfter_AdjustSpace(f25_arg0, f25_arg1, f25_arg2)
    f25_arg1:AddSubGoal(GOAL_TombShadow_366400_AfterAttackAct, 10)
    
end

Goal.Update = function (f26_arg0, f26_arg1, f26_arg2)
    return Update_Default_NoSubGoal(f26_arg0, f26_arg1, f26_arg2)
    
end

Goal.Terminate = function (f27_arg0, f27_arg1, f27_arg2)
    
end

Goal.Interrupt = function (f28_arg0, f28_arg1, f28_arg2)
    local f28_local0 = f28_arg1:GetDist(TARGET_ENE_0)
    local f28_local1 = 5 - f28_arg1:GetMapHitRadius(TARGET_SELF)
    local f28_local2 = f28_arg1:GetRandam_Int(1, 100)
    local f28_local3 = f28_arg1:GetRandam_Int(1, 100)
    local f28_local4 = f28_arg1:GetRandam_Int(1, 100)
    local f28_local5 = f28_arg1:GetHpRate(TARGET_SELF)
    local f28_local6 = 5
    local f28_local7 = 100
    local f28_local8 = f28_arg1:HasSpecialEffectId(TARGET_SELF, 17270)
    if f28_arg1:IsInterupt(INTERUPT_FindAttack) and f28_local8 == true and f28_local0 < 5 then
        f28_arg2:ClearSubGoal()
        return true
    end
    if f28_arg1:HasSpecialEffectId(TARGET_SELF, 5025) or f28_arg1:HasSpecialEffectId(TARGET_SELF, 5026) or f28_arg1:HasSpecialEffectId(TARGET_SELF, 5027) or f28_arg1:HasSpecialEffectId(TARGET_SELF, 5028) or f28_arg1:HasSpecialEffectId(TARGET_SELF, 5029) or f28_arg1:HasSpecialEffectId(TARGET_SELF, 17265) and f28_arg1:GetNumber(8) == 1 then
        if f28_arg1:HasSpecialEffectId(TARGET_SELF, 5025) then
            f28_arg1:SetNumber(10, 1)
        end
        if f28_arg1:HasSpecialEffectId(TARGET_SELF, 5026) then
            f28_arg1:SetNumber(10, 2)
        end
        if f28_arg1:HasSpecialEffectId(TARGET_SELF, 5027) then
            f28_arg1:SetNumber(10, 3)
        end
        if f28_arg1:HasSpecialEffectId(TARGET_SELF, 5028) then
            f28_arg1:SetNumber(10, 2)
        end
        if f28_arg1:HasSpecialEffectId(TARGET_SELF, 5029) then
            f28_arg1:SetNumber(10, 3)
        end
        if f28_arg1:HasSpecialEffectId(TARGET_SELF, 17265) then
            f28_arg1:SetNumber(10, 4)
        end
        if f28_arg1:GetNumber(7) == 0 or f28_arg1:GetNumber(7) == 1 and f28_local3 > 40 then
            if f28_arg1:GetNumber(10) == 3 then
                if f28_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 210, 180, 5.5 - f28_arg1:GetMapHitRadius(TARGET_SELF) - 0.5) then
                    f28_arg2:ClearSubGoal()
                    f28_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 3, 3011, TARGET_ENE_0, 999, 0, 0)
                    return true
                end
            else
                f28_arg2:ClearSubGoal()
                local f28_local9 = f28_arg1:GetDist(TARGET_ENE_0)
                local f28_local10 = f28_arg1:GetRandam_Int(1, 100)
                local f28_local11 = 6000
                local f28_local12 = AI_DIR_TYPE_F
                local f28_local13 = 6000
                local f28_local14 = 6001
                local f28_local15 = 6002
                local f28_local16 = 6003
                local f28_local17 = 6010
                local f28_local18 = 6012
                local f28_local19 = 6013
                local f28_local20 = 5
                local f28_local21 = 5
                local f28_local22 = 5
                local f28_local23 = 5
                local f28_local24 = 5
                local f28_local25 = 5
                local f28_local26 = 5
                local f28_local27 = 5 - f28_arg1:GetMapHitRadius(TARGET_SELF)
                local f28_local28 = 0
                local f28_local29 = 0
                local f28_local30 = f28_arg1:GetMapHitRadius(TARGET_SELF)
                local f28_local31 = f28_arg1:GetDist(TARGET_ENE_0)
                local f28_local32 = f28_arg1:GetRelativeAngleFromTarget(TARGET_ENE_0)
                if SpaceCheck(f28_arg1, f28_arg2, 180, 7) == false then
                    f28_local21 = 0
                end
                if SpaceCheck(f28_arg1, f28_arg2, -90, 5) == false then
                    f28_local22 = 0
                    if SpaceCheck(f28_arg1, f28_arg2, -90, 8) == false then
                        f28_local25 = 0
                    end
                end
                if SpaceCheck(f28_arg1, f28_arg2, 90, 5) == false then
                    f28_local23 = 0
                    if SpaceCheck(f28_arg1, f28_arg2, 90, 8) == false then
                        f28_local26 = 0
                    end
                end
                local f28_local33 = f28_arg1:GetRandam_Int(0, f28_local20 + f28_local21 + f28_local22 + f28_local23 + f28_local24 + f28_local25 + f28_local26)
                local f28_local34 = TARGET_ENE_0
                if f28_local20 + f28_local21 + f28_local22 + f28_local23 + f28_local24 + f28_local25 + f28_local26 == 0 then
                    f28_arg1:SetNumber(6, 1)
                    f28_arg2:ClearSubGoal()
                    f28_arg1:Replaning()
                    return true
                elseif f28_local20 ~= 0 and f28_local33 <= f28_local20 then
                    f28_local11 = f28_local13
                    f28_local12 = AI_DIR_TYPE_F
                elseif f28_local21 ~= 0 and f28_local33 <= f28_local21 then
                    f28_local11 = f28_local14
                    f28_local12 = AI_DIR_TYPE_B
                elseif f28_local22 ~= 0 and f28_local33 <= f28_local22 then
                    f28_local11 = f28_local15
                    f28_local12 = AI_DIR_TYPE_L
                elseif f28_local23 ~= 0 and f28_local33 <= f28_local23 then
                    f28_local11 = f28_local16
                    f28_local12 = AI_DIR_TYPE_R
                elseif f28_local24 ~= 0 and f28_local33 <= f28_local24 then
                    f28_local11 = f28_local17
                    f28_local12 = AI_DIR_TYPE_F
                elseif f28_local25 ~= 0 and f28_local33 <= f28_local25 then
                    f28_local11 = f28_local18
                    f28_local12 = AI_DIR_TYPE_L
                elseif f28_local26 ~= 0 and f28_local33 <= f28_local26 then
                    f28_local11 = f28_local19
                    f28_local12 = AI_DIR_TYPE_R
                end
                f28_arg2:ClearSubGoal()
                f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, f28_local11, TARGET_ENE_0, 0, f28_local12, 0)
                f28_arg1:SetNumber(8, 1)
                if f28_arg1:GetNumber(7) == 0 then
                    f28_arg1:SetNumber(7, 1)
                elseif f28_arg1:GetNumber(7) == 1 then
                    f28_arg1:SetNumber(7, 2)
                end
                return true
            end
        elseif f28_arg1:GetNumber(10) == 4 then
            f28_arg1:SetNumber(8, 1)
            if f28_local0 < 3.2 and f28_local2 > 70 then
                f28_arg2:ClearSubGoal()
                TombShadow_366400_Act01(f28_arg1, f28_arg2)
                return true
            elseif f28_local0 < 3.8 and f28_local2 > 40 then
                f28_arg2:ClearSubGoal()
                TombShadow_366400_Act05(f28_arg1, f28_arg2)
                return true
            elseif f28_local0 < 4 and f28_local2 > 10 then
                f28_arg2:ClearSubGoal()
                TombShadow_366400_Act03(f28_arg1, f28_arg2)
                return true
            elseif f28_local0 < 6.5 then
                f28_arg2:ClearSubGoal()
                TombShadow_366400_Act02(f28_arg1, f28_arg2)
                return true
            end
        elseif f28_arg1:GetNumber(10) == 1 then
            if f28_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 160, 180, 2.8 - f28_arg1:GetMapHitRadius(TARGET_SELF)) then
                f28_arg2:ClearSubGoal()
                f28_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 3, 3001, TARGET_ENE_0, 999, 0, 0)
                return true
            end
        elseif f28_arg1:GetNumber(10) == 2 then
            if f28_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 160, 180, 3.3 - f28_arg1:GetMapHitRadius(TARGET_SELF)) then
                f28_arg2:ClearSubGoal()
                f28_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 3, 3002, TARGET_ENE_0, 999, 0, 0)
                return true
            elseif f28_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 160, 180, 6.5 - f28_arg1:GetMapHitRadius(TARGET_SELF) - 0.5) then
                f28_arg2:ClearSubGoal()
                f28_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 3, 3003, TARGET_ENE_0, 999, 0, 0)
                return true
            end
        elseif f28_arg1:GetNumber(10) == 3 then
            if f28_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 210, 180, 5.5 - f28_arg1:GetMapHitRadius(TARGET_SELF) - 0.5) then
                f28_arg2:ClearSubGoal()
                f28_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 3, 3011, TARGET_ENE_0, 999, 0, 0)
                return true
            end
        elseif f28_arg1:GetNumber(10) == 4 then
            if f28_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 160, 180, 4.5 - f28_arg1:GetMapHitRadius(TARGET_SELF) - 0.5) then
                f28_arg2:ClearSubGoal()
                f28_arg1:SetNumber(2, f28_arg1:GetNumber(2) + 1)
                f28_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 3, 3021, TARGET_ENE_0, 999, 0, 0)
                return true
            end
        elseif f28_arg1:GetNumber(10) == 5 then
            if f28_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 160, 180, 2 - f28_arg1:GetMapHitRadius(TARGET_SELF)) then
                f28_arg2:ClearSubGoal()
                f28_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 3, 3022, TARGET_ENE_0, 999, 0, 0)
                return true
            elseif f28_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 160, 180, 4.5 - f28_arg1:GetMapHitRadius(TARGET_SELF)) and f28_arg1:GetNumber(2) <= 3 then
                f28_arg2:ClearSubGoal()
                f28_arg1:SetNumber(2, f28_arg1:GetNumber(2) + 1)
                f28_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 3, 3021, TARGET_ENE_0, 999, 0, 0)
                return true
            end
        end
    end
    if f28_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f28_arg1:GetSpecialEffectActivateInterruptId(5030) then
        if f28_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 100) and f28_local0 >= 4 and not f28_arg1:HasSpecialEffectId(TARGET_ENE_0, 17250) then
            if SpaceCheck(f28_arg1, f28_arg2, 180, 7) == true then
                if SpaceCheck(f28_arg1, f28_arg2, -90, 5) == true then
                    if SpaceCheck(f28_arg1, f28_arg2, 90, 5) == true then
                        if f28_local3 >= 81 then
                            f28_arg1:SetTimer(1, 1)
                            f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                            f28_arg2:ClearSubGoal()
                            f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6001, TARGET_ENE_0, 0, AI_DIR_TYPE_B, 3)
                            return true
                        elseif f28_local3 >= 41 then
                            f28_arg1:SetTimer(0, 2)
                            f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                            f28_arg2:ClearSubGoal()
                            f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6002, TARGET_ENE_0, 0, AI_DIR_TYPE_L, 3)
                            return true
                        else
                            f28_arg1:SetTimer(0, 2)
                            f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                            f28_arg2:ClearSubGoal()
                            f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6003, TARGET_ENE_0, 0, AI_DIR_TYPE_R, 3)
                            return true
                        end
                    elseif f28_local3 >= 71 then
                        f28_arg1:SetTimer(1, 1)
                        f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                        f28_arg2:ClearSubGoal()
                        f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6001, TARGET_ENE_0, 0, AI_DIR_TYPE_B, 3)
                        return true
                    else
                        f28_arg1:SetTimer(0, 2)
                        f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                        f28_arg2:ClearSubGoal()
                        f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6002, TARGET_ENE_0, 0, AI_DIR_TYPE_L, 3)
                        return true
                    end
                elseif SpaceCheck(f28_arg1, f28_arg2, 90, 5) == true then
                    if f28_local3 >= 71 then
                        f28_arg1:SetTimer(1, 1)
                        f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                        f28_arg2:ClearSubGoal()
                        f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6001, TARGET_ENE_0, 0, AI_DIR_TYPE_B, 3)
                        return true
                    else
                        f28_arg1:SetTimer(0, 2)
                        f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                        f28_arg2:ClearSubGoal()
                        f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6003, TARGET_ENE_0, 0, AI_DIR_TYPE_R, 3)
                        return true
                    end
                else
                    f28_arg1:SetTimer(1, 1)
                    f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                    f28_arg2:ClearSubGoal()
                    f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6001, TARGET_ENE_0, 0, AI_DIR_TYPE_B, 3)
                    return true
                end
            elseif SpaceCheck(f28_arg1, f28_arg2, -90, 5) == true then
                if SpaceCheck(f28_arg1, f28_arg2, 90, 5) == true then
                    if f28_local3 >= 51 then
                        f28_arg1:SetTimer(0, 2)
                        f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                        f28_arg2:ClearSubGoal()
                        f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6002, TARGET_ENE_0, 0, AI_DIR_TYPE_L, 3)
                        return true
                    else
                        f28_arg1:SetTimer(0, 2)
                        f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                        f28_arg2:ClearSubGoal()
                        f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6003, TARGET_ENE_0, 0, AI_DIR_TYPE_R, 3)
                        return true
                    end
                else
                    f28_arg1:SetTimer(0, 2)
                    f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                    f28_arg2:ClearSubGoal()
                    f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6002, TARGET_ENE_0, 0, AI_DIR_TYPE_L, 3)
                    return true
                end
            elseif SpaceCheck(f28_arg1, f28_arg2, 90, 5) == true then
                f28_arg1:SetTimer(0, 2)
                f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                f28_arg2:ClearSubGoal()
                f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6003, TARGET_ENE_0, 0, AI_DIR_TYPE_R, 3)
                return true
            else
                f28_arg2:ClearSubGoal()
                f28_arg1:Replaning()
                return true
            end
        elseif f28_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_R, 60, 180, 100) then
            if SpaceCheck(f28_arg1, f28_arg2, 180, 7) == true then
                if SpaceCheck(f28_arg1, f28_arg2, -90, 5) == true then
                    if SpaceCheck(f28_arg1, f28_arg2, 0, 5) == true then
                        if f28_local3 >= 61 and f28_local0 >= 2 then
                            f28_arg1:SetTimer(0, 2)
                            f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                            f28_arg2:ClearSubGoal()
                            f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6000, TARGET_ENE_0, 0, AI_DIR_TYPE_F, 3)
                            return true
                        elseif f28_local3 >= 21 and f28_local0 >= 2 then
                            f28_arg1:SetTimer(0, 2)
                            f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                            f28_arg2:ClearSubGoal()
                            f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6001, TARGET_ENE_0, 0, AI_DIR_TYPE_B, 3)
                            return true
                        elseif SpaceCheck(f28_arg1, f28_arg2, -90, 8) == true and f28_local4 >= 71 then
                            f28_arg1:SetTimer(1, 1.5)
                            f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                            f28_arg2:ClearSubGoal()
                            f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6012, TARGET_ENE_0, 0, AI_DIR_TYPE_L, 3)
                            return true
                        else
                            f28_arg1:SetTimer(1, 1)
                            f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                            f28_arg2:ClearSubGoal()
                            f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6002, TARGET_ENE_0, 0, AI_DIR_TYPE_L, 3)
                            return true
                        end
                    elseif f28_local3 >= 31 and f28_local0 >= 2 then
                        f28_arg1:SetTimer(0, 2)
                        f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                        f28_arg2:ClearSubGoal()
                        f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6001, TARGET_ENE_0, 0, AI_DIR_TYPE_B, 3)
                        return true
                    elseif SpaceCheck(f28_arg1, f28_arg2, -90, 8) == true and f28_local4 >= 71 then
                        f28_arg1:SetTimer(1, 1.5)
                        f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                        f28_arg2:ClearSubGoal()
                        f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6012, TARGET_ENE_0, 0, AI_DIR_TYPE_L, 3)
                        return true
                    else
                        f28_arg1:SetTimer(1, 1)
                        f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                        f28_arg2:ClearSubGoal()
                        f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6002, TARGET_ENE_0, 0, AI_DIR_TYPE_L, 3)
                        return true
                    end
                elseif SpaceCheck(f28_arg1, f28_arg2, 0, 5) == true then
                    if f28_local3 >= 51 then
                        f28_arg1:SetTimer(0, 2)
                        f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                        f28_arg2:ClearSubGoal()
                        f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6001, TARGET_ENE_0, 0, AI_DIR_TYPE_B, 3)
                        return true
                    else
                        f28_arg1:SetTimer(0, 2)
                        f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                        f28_arg2:ClearSubGoal()
                        f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6000, TARGET_ENE_0, 0, AI_DIR_TYPE_F, 3)
                        return true
                    end
                else
                    f28_arg1:SetTimer(0, 2)
                    f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                    f28_arg2:ClearSubGoal()
                    f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6000, TARGET_ENE_0, 0, AI_DIR_TYPE_F, 3)
                    return true
                end
            elseif SpaceCheck(f28_arg1, f28_arg2, -90, 5) == true then
                if SpaceCheck(f28_arg1, f28_arg2, 0, 5) == true then
                    if f28_local3 >= 31 and f28_local0 >= 2 then
                        f28_arg1:SetTimer(0, 2)
                        f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                        f28_arg2:ClearSubGoal()
                        f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6000, TARGET_ENE_0, 0, AI_DIR_TYPE_F, 3)
                        return true
                    elseif SpaceCheck(f28_arg1, f28_arg2, -90, 8) == true and f28_local4 >= 71 then
                        f28_arg1:SetTimer(1, 1.5)
                        f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                        f28_arg2:ClearSubGoal()
                        f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6012, TARGET_ENE_0, 0, AI_DIR_TYPE_L, 3)
                        return true
                    else
                        f28_arg1:SetTimer(1, 1)
                        f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                        f28_arg2:ClearSubGoal()
                        f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6002, TARGET_ENE_0, 0, AI_DIR_TYPE_L, 3)
                        return true
                    end
                elseif SpaceCheck(f28_arg1, f28_arg2, -90, 8) == true and f28_local4 >= 71 then
                    f28_arg1:SetTimer(1, 1.5)
                    f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                    f28_arg2:ClearSubGoal()
                    f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6012, TARGET_ENE_0, 0, AI_DIR_TYPE_L, 3)
                    return true
                else
                    f28_arg1:SetTimer(1, 1)
                    f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                    f28_arg2:ClearSubGoal()
                    f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6002, TARGET_ENE_0, 0, AI_DIR_TYPE_L, 3)
                    return true
                end
            elseif SpaceCheck(f28_arg1, f28_arg2, 0, 5) == true then
                f28_arg1:SetTimer(0, 2)
                f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                f28_arg2:ClearSubGoal()
                f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6000, TARGET_ENE_0, 0, AI_DIR_TYPE_F, 3)
                return true
            else
                f28_arg2:ClearSubGoal()
                f28_arg1:Replaning()
                return true
            end
        elseif f28_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_L, 60, 180, 100) then
            if SpaceCheck(f28_arg1, f28_arg2, 180, 7) == true then
                if SpaceCheck(f28_arg1, f28_arg2, 90, 5) == true then
                    if SpaceCheck(f28_arg1, f28_arg2, 0, 5) == true then
                        if f28_local3 >= 61 and f28_local0 >= 2 then
                            f28_arg1:SetTimer(0, 2)
                            f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                            f28_arg2:ClearSubGoal()
                            f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6010, TARGET_ENE_0, 0, AI_DIR_TYPE_F, 3)
                            return true
                        elseif f28_local3 >= 21 and f28_local0 >= 2 then
                            f28_arg1:SetTimer(0, 2)
                            f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                            f28_arg2:ClearSubGoal()
                            f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6001, TARGET_ENE_0, 0, AI_DIR_TYPE_B, 3)
                            return true
                        elseif SpaceCheck(f28_arg1, f28_arg2, 90, 8) == true and f28_local4 >= 71 then
                            f28_arg1:SetTimer(1, 1.5)
                            f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                            f28_arg2:ClearSubGoal()
                            f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6013, TARGET_ENE_0, 0, AI_DIR_TYPE_R, 3)
                            return true
                        else
                            f28_arg1:SetTimer(1, 1)
                            f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                            f28_arg2:ClearSubGoal()
                            f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6003, TARGET_ENE_0, 0, AI_DIR_TYPE_R, 3)
                            return true
                        end
                    elseif f28_local3 >= 31 and f28_local0 >= 2 then
                        f28_arg1:SetTimer(0, 2)
                        f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                        f28_arg2:ClearSubGoal()
                        f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6001, TARGET_ENE_0, 0, AI_DIR_TYPE_B, 3)
                        return true
                    elseif SpaceCheck(f28_arg1, f28_arg2, 90, 8) == true and f28_local4 >= 71 then
                        f28_arg1:SetTimer(1, 1.5)
                        f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                        f28_arg2:ClearSubGoal()
                        f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6013, TARGET_ENE_0, 0, AI_DIR_TYPE_R, 3)
                        return true
                    else
                        f28_arg1:SetTimer(1, 1)
                        f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                        f28_arg2:ClearSubGoal()
                        f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6003, TARGET_ENE_0, 0, AI_DIR_TYPE_R, 3)
                        return true
                    end
                elseif SpaceCheck(f28_arg1, f28_arg2, 0, 5) == true then
                    if f28_local3 >= 51 then
                        f28_arg1:SetTimer(0, 2)
                        f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                        f28_arg2:ClearSubGoal()
                        f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6001, TARGET_ENE_0, 0, AI_DIR_TYPE_B, 3)
                        return true
                    else
                        f28_arg1:SetTimer(0, 2)
                        f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                        f28_arg2:ClearSubGoal()
                        f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6000, TARGET_ENE_0, 0, AI_DIR_TYPE_F, 3)
                        return true
                    end
                else
                    f28_arg1:SetTimer(0, 2)
                    f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                    f28_arg2:ClearSubGoal()
                    f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6000, TARGET_ENE_0, 0, AI_DIR_TYPE_F, 3)
                    return true
                end
            elseif SpaceCheck(f28_arg1, f28_arg2, 90, 5) == true then
                if SpaceCheck(f28_arg1, f28_arg2, 0, 5) == true then
                    if f28_local3 >= 31 and f28_local0 >= 2 then
                        f28_arg1:SetTimer(0, 2)
                        f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                        f28_arg2:ClearSubGoal()
                        f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6010, TARGET_ENE_0, 0, AI_DIR_TYPE_F, 3)
                        return true
                    elseif SpaceCheck(f28_arg1, f28_arg2, 90, 8) == true and f28_local4 >= 71 then
                        f28_arg1:SetTimer(1, 1.5)
                        f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                        f28_arg2:ClearSubGoal()
                        f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6013, TARGET_ENE_0, 0, AI_DIR_TYPE_R, 3)
                        return true
                    else
                        f28_arg1:SetTimer(1, 1)
                        f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                        f28_arg2:ClearSubGoal()
                        f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6003, TARGET_ENE_0, 0, AI_DIR_TYPE_R, 3)
                        return true
                    end
                elseif SpaceCheck(f28_arg1, f28_arg2, 90, 8) == true and f28_local4 >= 71 then
                    f28_arg1:SetTimer(1, 1.5)
                    f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                    f28_arg2:ClearSubGoal()
                    f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6013, TARGET_ENE_0, 0, AI_DIR_TYPE_R, 3)
                    return true
                else
                    f28_arg1:SetTimer(1, 1)
                    f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                    f28_arg2:ClearSubGoal()
                    f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6003, TARGET_ENE_0, 0, AI_DIR_TYPE_R, 3)
                    return true
                end
            elseif SpaceCheck(f28_arg1, f28_arg2, 0, 5) == true then
                f28_arg1:SetTimer(0, 2)
                f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                f28_arg2:ClearSubGoal()
                f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6010, TARGET_ENE_0, 0, AI_DIR_TYPE_F, 3)
                return true
            else
                f28_arg2:ClearSubGoal()
                f28_arg1:Replaning()
                return true
            end
        elseif f28_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_B, 120, 180, 100) then
            if SpaceCheck(f28_arg1, f28_arg2, 0, 5) == true then
                if SpaceCheck(f28_arg1, f28_arg2, -90, 5) == true then
                    if SpaceCheck(f28_arg1, f28_arg2, 90, 5) == true then
                        if f28_local3 >= 61 and f28_local0 >= 2 then
                            f28_arg1:SetTimer(0, 2)
                            f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                            f28_arg2:ClearSubGoal()
                            f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6002, TARGET_ENE_0, 0, AI_DIR_TYPE_L, 3)
                            return true
                        elseif f28_local3 >= 21 and f28_local0 >= 2 then
                            f28_arg1:SetTimer(0, 2)
                            f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                            f28_arg2:ClearSubGoal()
                            f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6003, TARGET_ENE_0, 0, AI_DIR_TYPE_R, 3)
                            return true
                        elseif f28_local4 >= 51 then
                            f28_arg1:SetTimer(1, 1)
                            f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                            f28_arg2:ClearSubGoal()
                            f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6000, TARGET_ENE_0, 0, AI_DIR_TYPE_F, 3)
                            return true
                        else
                            f28_arg1:SetTimer(1, 1)
                            f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                            f28_arg2:ClearSubGoal()
                            f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6010, TARGET_ENE_0, 0, AI_DIR_TYPE_F, 3)
                            return true
                        end
                    elseif f28_local3 >= 31 and f28_local0 >= 2 then
                        f28_arg1:SetTimer(0, 2)
                        f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                        f28_arg2:ClearSubGoal()
                        f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6002, TARGET_ENE_0, 0, AI_DIR_TYPE_L, 3)
                        return true
                    else
                        f28_arg1:SetTimer(1, 1)
                        f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                        f28_arg2:ClearSubGoal()
                        f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6000, TARGET_ENE_0, 0, AI_DIR_TYPE_F, 3)
                        return true
                    end
                elseif SpaceCheck(f28_arg1, f28_arg2, 90, 5) == true then
                    if f28_local3 >= 31 and f28_local0 >= 2 then
                        f28_arg1:SetTimer(0, 2)
                        f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                        f28_arg2:ClearSubGoal()
                        f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6003, TARGET_ENE_0, 0, AI_DIR_TYPE_R, 3)
                        return true
                    else
                        f28_arg1:SetTimer(1, 1)
                        f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                        f28_arg2:ClearSubGoal()
                        f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6010, TARGET_ENE_0, 0, AI_DIR_TYPE_F, 3)
                        return true
                    end
                elseif f28_local4 >= 51 then
                    f28_arg1:SetTimer(1, 1)
                    f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                    f28_arg2:ClearSubGoal()
                    f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6000, TARGET_ENE_0, 0, AI_DIR_TYPE_F, 3)
                    return true
                else
                    f28_arg1:SetTimer(1, 1)
                    f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                    f28_arg2:ClearSubGoal()
                    f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6010, TARGET_ENE_0, 0, AI_DIR_TYPE_F, 3)
                    return true
                end
            elseif SpaceCheck(f28_arg1, f28_arg2, -90, 5) == true then
                if SpaceCheck(f28_arg1, f28_arg2, 90, 5) == true then
                    if f28_local3 >= 51 then
                        f28_arg1:SetTimer(0, 2)
                        f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                        f28_arg2:ClearSubGoal()
                        f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6002, TARGET_ENE_0, 0, AI_DIR_TYPE_L, 3)
                        return true
                    else
                        f28_arg1:SetTimer(0, 2)
                        f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                        f28_arg2:ClearSubGoal()
                        f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6003, TARGET_ENE_0, 0, AI_DIR_TYPE_R, 3)
                        return true
                    end
                else
                    f28_arg1:SetTimer(0, 2)
                    f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                    f28_arg2:ClearSubGoal()
                    f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6002, TARGET_ENE_0, 0, AI_DIR_TYPE_L, 3)
                    return true
                end
            elseif SpaceCheck(f28_arg1, f28_arg2, 90, 5) == true then
                f28_arg1:SetTimer(0, 2)
                f28_arg1:SetNumber(1, f28_arg1:GetNumber(1) + 1)
                f28_arg2:ClearSubGoal()
                f28_arg2:AddSubGoal(GOAL_COMMON_SpinStep, 5, 6003, TARGET_ENE_0, 0, AI_DIR_TYPE_R, 3)
                return true
            else
                f28_arg2:ClearSubGoal()
                f28_arg1:Replaning()
                return true
            end
        else
            f28_arg2:ClearSubGoal()
            f28_arg1:Replaning()
            return true
        end
    end
    return false
    
end

RegisterTableGoal(GOAL_TombShadow_366400_AfterAttackAct, "TombShadow_366400_AfterAttackAct")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_TombShadow_366400_AfterAttackAct, true)

Goal.Activate = function (f29_arg0, f29_arg1, f29_arg2)
    
end

Goal.Update = function (f30_arg0, f30_arg1, f30_arg2)
    return Update_Default_NoSubGoal(f30_arg0, f30_arg1, f30_arg2)
    
end


