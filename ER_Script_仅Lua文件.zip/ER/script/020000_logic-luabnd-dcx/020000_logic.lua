﻿function PatrolLeader20000_Logic(f1_arg0)
    COMMON_Initialize(f1_arg0)
    f1_arg0:AddTopGoal(GOAL_COMMON_NonBattleAct, 10, 100, false, false, TARGET_SELF, 1)
    
end

function PatrolLeader20000_Interupt(f2_arg0, f2_arg1)
    return false
    
end


