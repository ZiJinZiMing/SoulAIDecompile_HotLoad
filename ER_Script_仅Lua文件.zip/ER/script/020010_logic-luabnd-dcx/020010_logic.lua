﻿function NonActPatrolMember20010_Logic(f1_arg0)
    COMMON_Initialize(f1_arg0)
    if COMMON_EasySetup_Initial(f1_arg0) == false then
        if f1_arg0:IsValidPlatoon() == true then
            local f1_local0 = f1_arg0:GetPlatoonCommand()
            local f1_local1 = f1_local0:GetCommandNo()
            local f1_local2 = f1_arg0:GetDist(TARGET_TEAM_FORMATION)
            local f1_local3 = 20000
            f1_arg0:SetEnableUsePath(true)
            if f1_local1 == PLAN_PLATOON_COMMAND__STOP or f1_local1 == PLAN_PLATOON_COMMAND__WAIT or f1_local1 == PLAN_PLATOON_COMMAND__PATROLEND then
                if f1_arg0:HasSpecialEffectId(TARGET_SELF, 11500) == false then
                    f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, f1_local3, TARGET_SELF, 0, 0, 0)
                else
                    f1_arg0:AddTopGoal(GOAL_COMMON_Stay, 2, 0, TARGET_SELF)
                end
            elseif f1_local2 < 2 then
                f1_arg0:AddTopGoal(GOAL_COMMON_Stay, 0.5, 0, TARGET_SELF)
            elseif f1_arg0:HasSpecialEffectId(TARGET_SELF, 11501) then
                if f1_arg0:GetDist(TARGET_TEAM_LEADER) < 10 then
                    f1_arg0:AddTopGoal(GOAL_COMMON_Stay, 0.5, 0, TARGET_SELF)
                else
                    f1_arg0:SetEnableUsePath(false)
                    f1_arg0:AddTopGoal(GOAL_COMMON_ApproachSettingDirection, 0.3, TARGET_SELF, 0, TARGET_SELF, true, -1, AI_DIR_TYPE_F, 3)
                end
            else
                f1_arg0:AddTopGoal(GOAL_COMMON_MoveToSomewhere, 2, TARGET_TEAM_FORMATION, AI_DIR_TYPE_CENTER, 0.1, TARGET_SELF, true)
            end
        else
            f1_arg0:AddTopGoal(GOAL_COMMON_Wait, 20, TARGET_SELF)
        end
    end
    
end

function NonActPatrolMember20010_Interupt(f2_arg0, f2_arg1)
    if f2_arg0:IsValidPlatoon() == true then
        isChangedOrder = f2_arg0:IsInterupt(INTERUPT_PlatoonAiOrder)
        if isChangedOrder then
            f2_arg1:ClearSubGoal()
            f2_arg0:Replaning()
        end
    end
    
end


