﻿RegisterTableGoal(GOAL_DaemonBloodLaity355000_Battle, "DaemonBloodLaity355000_Battle")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_DaemonBloodLaity355000_Battle, true)

Goal.Initialize = function (f1_arg0, f1_arg1, f1_arg2, f1_arg3)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3000)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3001)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3002)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3004)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3005)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3006)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3007)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3008)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3009)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3010)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3013)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3014)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3015)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3016)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3017)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3018)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3025)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3026)
    f1_arg1:EnableUnfavorableAttackCheck(0, 3028)
    
end

Goal.Activate = function (f2_arg0, f2_arg1, f2_arg2)
    Init_Pseudo_Global(f2_arg1, f2_arg2)
    f2_arg1:SetStringIndexedNumber("Dist_SideStep", 5)
    f2_arg1:SetStringIndexedNumber("Dist_BackStep", 5)
    local f2_local0 = {}
    local f2_local1 = {}
    local f2_local2 = {}
    Common_Clear_Param(f2_local0, f2_local1, f2_local2)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 11705)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 5037)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 5038)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_ENE_0, 51)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5028)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5034)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5035)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5036)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 5036)
    local f2_local3 = f2_arg1:GetDist(TARGET_ENE_0)
    local f2_local4 = f2_arg1:GetRandam_Int(1, 100)
    local f2_local5 = f2_arg1:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__thinkAttr_doAdmirer)
    local f2_local6 = f2_arg1:GetEventRequest()
    if f2_arg1:HasSpecialEffectId(TARGET_SELF, 11702) == true and f2_arg1:HasSpecialEffectId(TARGET_SELF, 11703) == false then
        f2_local0[22] = 100
    elseif f2_arg1:HasSpecialEffectId(TARGET_SELF, 11704) then
        f2_local0[27] = 100
        f2_local0[48] = 1
    elseif f2_arg1:HasSpecialEffectId(TARGET_SELF, 11702) == false or f2_arg1:HasSpecialEffectId(TARGET_SELF, 11703) == true then
        if f2_local3 < 1.5 then
            if f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_BL, 160, 50, 4) then
                f2_local0[21] = 100
            elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_BR, 160, 50, 4) then
                f2_local0[20] = 100
            else
                f2_local0[20] = 10
                f2_local0[21] = 10
                f2_local0[23] = 30
                f2_local0[43] = 50
            end
        elseif f2_local3 < 3 then
            if f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_L, 160, 50, 6) then
                f2_local0[21] = 100
            elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_R, 160, 50, 6) then
                f2_local0[20] = 100
            elseif f2_arg1:IsTargetGuard(TARGET_ENE_0) then
                f2_local0[23] = 30
                f2_local0[25] = 30
                f2_local0[43] = 40
            else
                f2_local0[23] = 30
                f2_local0[43] = 70
            end
        elseif f2_local3 < 5 then
            f2_local0[1] = 60
            f2_local0[24] = 30
            f2_local0[40] = 5
            f2_local0[41] = 5
        elseif f2_local3 < 8 then
            f2_local0[2] = 30
            f2_local0[24] = 30
            f2_local0[26] = 20
            f2_local0[40] = 5
            f2_local0[41] = 15
        elseif f2_local3 < 15 then
            f2_local0[24] = 50
            f2_local0[26] = 30
            f2_local0[41] = 20
        else
            f2_local0[42] = 75
            f2_local0[48] = 10
        end
    else
        f2_local0[48] = 0
    end
    f2_local0[2] = SetCoolTime(f2_arg1, f2_arg2, 3004, 5 + f2_arg1:GetRandam_Int(0, 5), f2_local0[2], 0)
    f2_local0[4] = SetCoolTime(f2_arg1, f2_arg2, 3003, 5 + f2_arg1:GetRandam_Int(0, 5), f2_local0[4], 0)
    f2_local0[23] = SetCoolTime(f2_arg1, f2_arg2, 3019, 20 + f2_arg1:GetRandam_Int(0, 5), f2_local0[23], 0)
    f2_local0[25] = SetCoolTime(f2_arg1, f2_arg2, 3011, 20 + f2_arg1:GetRandam_Int(0, 5), f2_local0[25], 0)
    f2_local0[24] = SetCoolTime(f2_arg1, f2_arg2, 3018, 15 + f2_arg1:GetRandam_Int(0, 5), f2_local0[24], 0)
    f2_local0[26] = SetCoolTime(f2_arg1, f2_arg2, 3020, 15 + f2_arg1:GetRandam_Int(0, 5), f2_local0[26], 0)
    f2_local0[27] = SetCoolTime(f2_arg1, f2_arg2, 3021, 5 + f2_arg1:GetRandam_Int(0, 5), f2_local0[27], 0)
    f2_local1[1] = REGIST_FUNC(f2_arg1, f2_arg2, DaemonBloodLaity355000_Act01)
    f2_local1[2] = REGIST_FUNC(f2_arg1, f2_arg2, DaemonBloodLaity355000_Act02)
    f2_local1[3] = REGIST_FUNC(f2_arg1, f2_arg2, DaemonBloodLaity355000_Act03)
    f2_local1[19] = REGIST_FUNC(f2_arg1, f2_arg2, DaemonBloodLaity355000_Act19)
    f2_local1[20] = REGIST_FUNC(f2_arg1, f2_arg2, DaemonBloodLaity355000_Act20)
    f2_local1[21] = REGIST_FUNC(f2_arg1, f2_arg2, DaemonBloodLaity355000_Act21)
    f2_local1[22] = REGIST_FUNC(f2_arg1, f2_arg2, DaemonBloodLaity355000_Act22)
    f2_local1[23] = REGIST_FUNC(f2_arg1, f2_arg2, DaemonBloodLaity355000_Act23)
    f2_local1[24] = REGIST_FUNC(f2_arg1, f2_arg2, DaemonBloodLaity355000_Act24)
    f2_local1[25] = REGIST_FUNC(f2_arg1, f2_arg2, DaemonBloodLaity355000_Act25)
    f2_local1[26] = REGIST_FUNC(f2_arg1, f2_arg2, DaemonBloodLaity355000_Act26)
    f2_local1[27] = REGIST_FUNC(f2_arg1, f2_arg2, DaemonBloodLaity355000_Act27)
    f2_local1[40] = REGIST_FUNC(f2_arg1, f2_arg2, DaemonBloodLaity355000_Act40)
    f2_local1[41] = REGIST_FUNC(f2_arg1, f2_arg2, DaemonBloodLaity355000_Act41)
    f2_local1[42] = REGIST_FUNC(f2_arg1, f2_arg2, DaemonBloodLaity355000_Act42)
    f2_local1[43] = REGIST_FUNC(f2_arg1, f2_arg2, DaemonBloodLaity355000_Act43)
    f2_local1[48] = REGIST_FUNC(f2_arg1, f2_arg2, DaemonBloodLaity355000_Act48)
    local f2_local7 = REGIST_FUNC(f2_arg1, f2_arg2, DaemonBloodLaity355000_ActAfter_AdjustSpace)
    Common_Battle_Activate(f2_arg1, f2_arg2, f2_local0, f2_local1, f2_local7, f2_local2)
    
end

function DaemonBloodLaity355000_Act01(f3_arg0, f3_arg1, f3_arg2)
    local f3_local0 = f3_arg0:GetDist(TARGET_ENE_0)
    local f3_local1 = 3.5
    local f3_local2 = 0
    local f3_local3 = 999
    local f3_local4 = 0
    local f3_local5 = 0
    local f3_local6 = 1
    local f3_local7 = 1
    Approach_Act_Flex(f3_arg0, f3_arg1, f3_local1, f3_local2, f3_local3, f3_local4, f3_local5, f3_local6, f3_local7)
    local f3_local8 = 3013
    local f3_local9 = 3
    local f3_local10 = 0
    local f3_local11 = 0
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5028)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5034)
    f3_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5035)
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f3_local8, TARGET_ENE_0, f3_local9, 0, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DaemonBloodLaity355000_Act02(f4_arg0, f4_arg1, f4_arg2)
    local f4_local0 = f4_arg0:GetDist(TARGET_ENE_0)
    local f4_local1 = 7
    local f4_local2 = 0
    local f4_local3 = 999
    local f4_local4 = 0
    local f4_local5 = 0
    local f4_local6 = 0.5
    local f4_local7 = 0.5
    Approach_Act_Flex(f4_arg0, f4_arg1, f4_local1, f4_local2, f4_local3, f4_local4, f4_local5, f4_local6, f4_local7)
    local f4_local8 = 3004
    local f4_local9 = 5 - f4_arg0:GetMapHitRadius(TARGET_SELF)
    local f4_local10 = 0
    local f4_local11 = 0
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5028)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5034)
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5035)
    f4_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f4_local8, TARGET_ENE_0, f4_local9, 0, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DaemonBloodLaity355000_Act03(f5_arg0, f5_arg1, f5_arg2)
    local f5_local0 = f5_arg0:GetDist(TARGET_ENE_0)
    local f5_local1 = 7
    local f5_local2 = 0
    local f5_local3 = 999
    local f5_local4 = 0
    local f5_local5 = 0
    local f5_local6 = 0.5
    local f5_local7 = 0.5
    Approach_Act_Flex(f5_arg0, f5_arg1, f5_local1, f5_local2, f5_local3, f5_local4, f5_local5, f5_local6, f5_local7)
    local f5_local8 = 3017
    local f5_local9 = 5 - f5_arg0:GetMapHitRadius(TARGET_SELF)
    local f5_local10 = 0
    local f5_local11 = 0
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5028)
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5034)
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5035)
    f5_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f5_local8, TARGET_ENE_0, f5_local9, 0, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DaemonBloodLaity355000_Act19(f6_arg0, f6_arg1, f6_arg2)
    local f6_local0 = 3000
    local f6_local1 = 5 - f6_arg0:GetMapHitRadius(TARGET_SELF)
    local f6_local2 = 0
    local f6_local3 = 0
    f6_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 5, TARGET_ENE_0, 1, TARGET_SELF, true, 9920)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DaemonBloodLaity355000_Act20(f7_arg0, f7_arg1, f7_arg2)
    local f7_local0 = 3005
    local f7_local1 = 3008
    local f7_local2 = 4
    local f7_local3 = 0
    local f7_local4 = 0
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5028)
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5034)
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5035)
    f7_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, f7_local0, TARGET_ENE_0, f7_local2, 0, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DaemonBloodLaity355000_Act21(f8_arg0, f8_arg1, f8_arg2)
    local f8_local0 = 3006
    local f8_local1 = 3009
    local f8_local2 = 4
    local f8_local3 = 0
    local f8_local4 = 0
    f8_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f8_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f8_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5028)
    f8_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f8_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f8_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f8_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f8_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5034)
    f8_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5035)
    f8_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, f8_local0, TARGET_ENE_0, f8_local2, 0, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DaemonBloodLaity355000_Act22(f9_arg0, f9_arg1, f9_arg2)
    local f9_local0 = 3010
    local f9_local1 = 5 - f9_arg0:GetMapHitRadius(TARGET_SELF)
    local f9_local2 = 0
    local f9_local3 = 0
    f9_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f9_local0, TARGET_ENE_0, f9_local1, f9_local2, f9_local3, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DaemonBloodLaity355000_Act23(f10_arg0, f10_arg1, f10_arg2)
    local f10_local0 = 3019
    local f10_local1 = 5 - f10_arg0:GetMapHitRadius(TARGET_SELF)
    local f10_local2 = 0
    local f10_local3 = 0
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5028)
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5034)
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5035)
    f10_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f10_local0, TARGET_ENE_0, f10_local1, f10_local2, f10_local3, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DaemonBloodLaity355000_Act24(f11_arg0, f11_arg1, f11_arg2)
    local f11_local0 = 3018
    local f11_local1 = 5 - f11_arg0:GetMapHitRadius(TARGET_SELF)
    local f11_local2 = 0
    local f11_local3 = 0
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5028)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5034)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5035)
    f11_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f11_local0, TARGET_ENE_0, f11_local1, f11_local2, f11_local3, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DaemonBloodLaity355000_Act25(f12_arg0, f12_arg1, f12_arg2)
    local f12_local0 = 3011
    local f12_local1 = 5 - f12_arg0:GetMapHitRadius(TARGET_SELF)
    local f12_local2 = 0
    local f12_local3 = 0
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5028)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5034)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5035)
    f12_arg1:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, f12_local0, TARGET_ENE_0, f12_local1, f12_local2, f12_local3, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DaemonBloodLaity355000_Act26(f13_arg0, f13_arg1, f13_arg2)
    local f13_local0 = 3020
    local f13_local1 = 5 - f13_arg0:GetMapHitRadius(TARGET_SELF)
    local f13_local2 = 0
    local f13_local3 = 0
    f13_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f13_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f13_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5028)
    f13_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f13_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f13_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f13_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f13_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5034)
    f13_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5035)
    f13_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f13_local0, TARGET_ENE_0, f13_local1, 0, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DaemonBloodLaity355000_Act27(f14_arg0, f14_arg1, f14_arg2)
    local f14_local0 = 3020
    local f14_local1 = 3021
    local f14_local2 = 5 - f14_arg0:GetMapHitRadius(TARGET_SELF)
    local f14_local3 = 0
    local f14_local4 = 0
    f14_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f14_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f14_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5028)
    f14_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f14_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f14_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f14_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f14_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5034)
    f14_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5035)
    f14_arg1:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 10, f14_local0, TARGET_ENE_0, f14_local2, 0, 0, 0, 0)
    f14_arg1:AddSubGoal(GOAL_COMMON_ComboFinal, 10, f14_local1, TARGET_ENE_0, 6, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DaemonBloodLaity355000_Act40(f15_arg0, f15_arg1, f15_arg2)
    f15_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, 1.5, TARGET_ENE_0, f15_arg0:GetRandam_Int(0, 1), f15_arg0:GetRandam_Int(30, 45), true, true, -1)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DaemonBloodLaity355000_Act41(f16_arg0, f16_arg1, f16_arg2)
    f16_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 1, TARGET_ENE_0, 3, TARGET_SELF, true, -1)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DaemonBloodLaity355000_Act42(f17_arg0, f17_arg1, f17_arg2)
    f17_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, 10, TARGET_ENE_0, 4, TARGET_SELF, false, -1)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DaemonBloodLaity355000_Act43(f18_arg0, f18_arg1, f18_arg2)
    f18_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f18_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5027)
    f18_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5028)
    f18_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5030)
    f18_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5031)
    f18_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5032)
    f18_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5033)
    f18_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5034)
    f18_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5035)
    if f18_arg0:IsFinishTimer(0) == true then
        f18_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 2, TARGET_ENE_0, 4, TARGET_ENE_0, true, -1)
    else
        f18_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 2, TARGET_ENE_0, 4, TARGET_ENE_0, true, 9920)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DaemonBloodLaity355000_Act48(f19_arg0, f19_arg1, f19_arg2)
    f19_arg1:AddSubGoal(GOAL_COMMON_Wait, 3, TARGET_ENE_0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function DaemonBloodLaity355000_ActAfter_AdjustSpace(f20_arg0, f20_arg1, f20_arg2)
    f20_arg1:AddSubGoal(GOAL_DaemonBloodLaity355001_AfterAttackAct, 10)
    
end

Goal.Update = function (f21_arg0, f21_arg1, f21_arg2)
    return Update_Default_NoSubGoal(f21_arg0, f21_arg1, f21_arg2)
    
end

Goal.Terminate = function (f22_arg0, f22_arg1, f22_arg2)
    
end

Goal.Interrupt = function (f23_arg0, f23_arg1, f23_arg2)
    local f23_local0 = f23_arg1:GetRandam_Int(1, 100)
    local f23_local1 = f23_arg1:GetRandam_Int(1, 100)
    local f23_local2 = f23_arg1:GetDist(TARGET_ENE_0)
    local f23_local3 = f23_arg1:GetHpRate(TARGET_SELF)
    local f23_local4 = f23_arg1:GetNumber(0)
    local f23_local5 = f23_arg1:GetNumber(1)
    local f23_local6 = f23_arg1:GetRandam_Int(0, 10)
    local f23_local7 = f23_arg1:GetRandam_Int(0, 5)
    if f23_arg1:IsLadderAct(TARGET_SELF) then
        return false
    end
    f23_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 5036)
    f23_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 5037)
    f23_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 5038)
    if f23_arg1:IsInterupt(INTERUPT_Damaged) and f23_arg1:GetHpRate(TARGET_SELF) < 0.9 and f23_local2 < 2.5 then
        f23_arg1:SetNumber(0, f23_local4 + 1)
        if f23_arg1:GetAttackPassedTime(3007) >= 10 then
            f23_arg1:SetNumber(0, 0)
            f23_arg2:ClearSubGoal()
            f23_arg2:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 2, 3007, TARGET_ENE_0, 0, 0, 0, 0, 0)
            return true
        elseif f23_local0 <= 40 and f23_arg1:GetNumber(0) >= 4 then
            f23_arg1:SetNumber(0, 0)
            f23_arg2:ClearSubGoal()
            f23_arg2:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 2, 3007, TARGET_ENE_0, 0, 0, 0, 0, 0)
            return true
        elseif f23_local2 < 3 and f23_arg1:GetAttackPassedTime(3005) >= 5 and f23_arg1:GetAttackPassedTime(3006) >= 5 then
            if f23_local0 <= 50 then
                f23_arg2:ClearSubGoal()
                f23_arg2:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 2, 3005, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            else
                f23_arg2:ClearSubGoal()
                f23_arg2:AddSubGoal(GOAL_COMMON_ComboAttackTunableSpin, 2, 3006, TARGET_ENE_0, 0, 0, 0, 0, 0)
                return true
            end
        end
    end
    local f23_local8 = 7
    local f23_local9 = 180
    local f23_local10 = 5.5
    local f23_local11 = 180
    if Parry_Act(f23_arg1, f23_arg2, f23_local8, f23_local9, f23_local10, f23_local11) then
        return true
    end
    if f23_arg1:IsInterupt(INTERUPT_Shoot) then
        if f23_local2 < 5 then
            f23_arg2:ClearSubGoal()
            f23_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3004, TARGET_ENE_0, 0, 0, 0)
            return true
        elseif f23_local2 > 5 then
            if f23_arg1:GetAttackPassedTime(3018) >= 10 then
                f23_arg2:ClearSubGoal()
                f23_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3018, TARGET_ENE_0, 0, 0, 0)
                return true
            elseif f23_arg1:GetAttackPassedTime(3017) >= 10 then
                f23_arg2:ClearSubGoal()
                f23_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3017, TARGET_ENE_0, 0, 0, 0)
                return true
            else
                f23_arg2:ClearSubGoal()
                f23_arg2:AddSubGoal(GOAL_COMMON_ApproachTarget, 5, TARGET_ENE_0, 3, TARGET_SELF, false, -1)
                return true
            end
        end
    end
    if f23_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f23_arg1:HasSpecialEffectId(TARGET_SELF, 5027) then
        if f23_local2 < 3 then
            if f23_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 30, 50, 6) then
                if f23_local2 < 1.5 and f23_arg1:GetAttackPassedTime(3019) >= 20 and f23_arg1:HasSpecialEffectId(TARGET_ENE_0, 51) == false then
                    f23_arg2:ClearSubGoal()
                    f23_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3019, TARGET_ENE_0, 999, 0, 0, 0, 0)
                    f23_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3015, TARGET_ENE_0, 999, 0, 0, 0, 0)
                    return true
                elseif f23_arg1:GetAttackPassedTime(3011) >= 5 and f23_arg1:IsTargetGuard(TARGET_ENE_0) then
                    f23_arg2:ClearSubGoal()
                    f23_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3011, TARGET_ENE_0, 999, 0, 0, 0, 0)
                    return true
                else
                    f23_arg2:ClearSubGoal()
                    f23_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3014, TARGET_ENE_0, 999, 0, 0, 0, 0)
                    f23_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3015, TARGET_ENE_0, 999, 0, 0, 0, 0)
                    return true
                end
            elseif f23_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_B, 330, 50, 6) and f23_arg1:GetAttackPassedTime(3005) >= 8 and f23_arg1:GetAttackPassedTime(3006) >= 8 then
                if f23_local0 <= 50 then
                    f23_arg2:ClearSubGoal()
                    f23_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3005, TARGET_ENE_0, 4, 0, 0, 0, 0)
                    return true
                else
                    f23_arg2:ClearSubGoal()
                    f23_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3006, TARGET_ENE_0, 4, 0, 0, 0, 0)
                    return true
                end
            end
        elseif f23_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 180, 50, 10) then
            if f23_arg1:GetAttackPassedTime(3004) >= 10 then
                f23_arg2:ClearSubGoal()
                f23_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3004, TARGET_ENE_0, 999, 0, 0, 0, 0)
                return true
            elseif f23_arg1:GetAttackPassedTime(3018) >= 10 then
                f23_arg2:ClearSubGoal()
                f23_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3018, TARGET_ENE_0, 999, 0, 0, 0, 0)
                return true
            elseif f23_arg1:GetAttackPassedTime(3017) >= 30 then
                f23_arg2:ClearSubGoal()
                f23_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3017, TARGET_ENE_0, 999, 0, 0, 0, 0)
                return true
            end
        end
    end
    if f23_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f23_arg1:HasSpecialEffectId(TARGET_SELF, 5028) then
        if f23_local2 < 3.5 then
            if f23_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 30, 50, 6) then
                if f23_local2 < 1.5 and f23_arg1:GetAttackPassedTime(3019) >= 20 and f23_arg1:HasSpecialEffectId(TARGET_ENE_0, 51) == false then
                    f23_arg2:ClearSubGoal()
                    f23_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3019, TARGET_ENE_0, 999, 0, 0, 0, 0)
                    f23_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3015, TARGET_ENE_0, 999, 0, 0, 0, 0)
                    return true
                elseif f23_arg1:GetAttackPassedTime(3011) >= 5 and f23_arg1:IsTargetGuard(TARGET_ENE_0) then
                    f23_arg2:ClearSubGoal()
                    f23_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3011, TARGET_ENE_0, 999, 0, 0, 0, 0)
                    return true
                else
                    f23_arg2:ClearSubGoal()
                    f23_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3016, TARGET_ENE_0, 999, 0, 0, 0, 0)
                    return true
                end
            elseif f23_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_B, 330, 50, 6) and f23_arg1:GetAttackPassedTime(3005) >= 3 and f23_arg1:GetAttackPassedTime(3006) >= 3 then
                if f23_local0 <= 50 then
                    f23_arg2:ClearSubGoal()
                    f23_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3005, TARGET_ENE_0, 4, 0, 0, 0, 0)
                    return true
                else
                    f23_arg2:ClearSubGoal()
                    f23_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3006, TARGET_ENE_0, 4, 0, 0, 0, 0)
                    return true
                end
            end
        elseif f23_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 180, 50, 10) then
            if f23_arg1:GetAttackPassedTime(3004) >= 10 then
                f23_arg2:ClearSubGoal()
                f23_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3004, TARGET_ENE_0, 999, 0, 0, 0, 0)
                return true
            elseif f23_arg1:GetAttackPassedTime(3018) >= 10 then
                f23_arg2:ClearSubGoal()
                f23_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3018, TARGET_ENE_0, 999, 0, 0, 0, 0)
                return true
            elseif f23_arg1:GetAttackPassedTime(3017) >= 30 then
                f23_arg2:ClearSubGoal()
                f23_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3017, TARGET_ENE_0, 999, 0, 0, 0, 0)
                return true
            end
        end
    end
    if f23_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f23_arg1:HasSpecialEffectId(TARGET_SELF, 5025) then
        if f23_local2 > 4 and f23_local2 < 6 then
            if f23_arg1:GetAttackPassedTime(3004) >= 10 then
                f23_arg2:ClearSubGoal()
                f23_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3004, TARGET_ENE_0, 0, 0, 0)
                return true
            end
        elseif f23_local2 < 3 then
            if f23_local0 <= 30 then
                f23_arg2:ClearSubGoal()
                f23_arg2:AddSubGoal(GOAL_COMMON_LeaveTarget, 2, TARGET_ENE_0, 8, TARGET_ENE_0, true, -1)
                f23_arg2:AddSubGoal(GOAL_COMMON_SidewayMove, 1.5, TARGET_ENE_0, f23_arg1:GetRandam_Int(0, 1), f23_arg1:GetRandam_Int(30, 45), true, true, -1)
                return true
            else
                f23_arg2:ClearSubGoal()
                f23_arg2:AddSubGoal(GOAL_COMMON_SidewayMove, 1.5, TARGET_ENE_0, f23_arg1:GetRandam_Int(0, 1), f23_arg1:GetRandam_Int(30, 45), true, true, -1)
                return true
            end
        end
    end
    if f23_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f23_arg1:HasSpecialEffectId(TARGET_SELF, 5036) and f23_local2 < 2.5 and f23_arg1:GetTimer(10) < 1 then
        f23_arg2:ClearSubGoal()
        f23_arg2:AddSubGoal(GOAL_COMMON_AttackTunableSpin, 10, 3000, TARGET_ENE_0, 0, 0, 0)
        return true
    end
    if f23_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f23_arg1:HasSpecialEffectId(TARGET_SELF, 5033) then
        if f23_local0 > 30 then
            f23_arg2:ClearSubGoal()
            f23_arg1:SetTimer(0, 5)
            f23_arg1:SetTimer(10, 3.5)
            f23_arg2:AddSubGoal(GOAL_COMMON_ApproachTarget, 3.5, TARGET_ENE_0, 0, TARGET_ENE_0, true, 9920)
            return true
        else
            f23_arg2:ClearSubGoal()
            f23_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3008, TARGET_ENE_0, 999, 0, 0, 0, 0)
            return true
        end
    end
    if f23_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f23_arg1:HasSpecialEffectId(TARGET_SELF, 5034) then
        if f23_local0 > 30 then
            f23_arg2:ClearSubGoal()
            f23_arg1:SetTimer(0, 5)
            f23_arg1:SetTimer(10, 3.5)
            f23_arg2:AddSubGoal(GOAL_COMMON_ApproachTarget, 3.5, TARGET_ENE_0, 0, TARGET_ENE_0, true, 9920)
            return true
        else
            f23_arg2:ClearSubGoal()
            f23_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3009, TARGET_ENE_0, 999, 0, 0, 0, 0)
            return true
        end
    end
    if f23_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f23_arg1:HasSpecialEffectId(TARGET_SELF, 5030) then
        if f23_local0 <= 70 and f23_local2 < 2.5 and f23_arg1:IsFinishTimer(0) == true then
            if f23_local1 <= 50 then
                f23_arg2:ClearSubGoal()
                f23_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3005, TARGET_ENE_0, 4, 0, 0, 0, 0)
                return true
            else
                f23_arg2:ClearSubGoal()
                f23_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3006, TARGET_ENE_0, 4, 0, 0, 0, 0)
                return true
            end
        elseif f23_local2 > 4 then
            if f23_arg1:IsFinishTimer(0) == false then
                f23_arg2:ClearSubGoal()
                f23_arg2:AddSubGoal(GOAL_COMMON_TurnAround, 2.5, TARGET_ENE_0, AI_DIR_TYPE_B, 10, true, false, 9920)
                return true
            elseif f23_local1 <= 30 then
                f23_arg2:ClearSubGoal()
                f23_arg2:AddSubGoal(GOAL_COMMON_SidewayMove, 1.5, TARGET_ENE_0, f23_arg1:GetRandam_Int(0, 1), f23_arg1:GetRandam_Int(30, 45), true, true, -1)
                return true
            end
        end
    end
    if f23_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f23_arg1:HasSpecialEffectId(TARGET_SELF, 5035) and f23_local2 < 3 then
        if f23_arg1:HasSpecialEffectId(TARGET_ENE_0, 51) then
            if f23_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 90, 50, 10) then
                f23_arg2:ClearSubGoal()
                f23_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3015, TARGET_ENE_0, 4, 0, 0, 0, 0)
                return true
            end
        elseif f23_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 90, 50, 10) and f23_arg1:GetAttackPassedTime(3015) >= 10 then
            f23_arg2:ClearSubGoal()
            f23_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3015, TARGET_ENE_0, 4, 0, 0, 0, 0)
            return true
        elseif f23_arg1:GetAttackPassedTime(3005) >= 10 and f23_arg1:GetAttackPassedTime(3006) >= 10 then
            if f23_local0 <= 50 then
                f23_arg2:ClearSubGoal()
                f23_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3005, TARGET_ENE_0, 4, 0, 0, 0, 0)
                return true
            else
                f23_arg2:ClearSubGoal()
                f23_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3006, TARGET_ENE_0, 4, 0, 0, 0, 0)
                return true
            end
        end
    end
    if f23_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f23_arg1:HasSpecialEffectId(TARGET_SELF, 5031) and f23_local0 <= 30 and f23_local2 > 1.5 and f23_local2 < 3 then
        f23_arg2:ClearSubGoal()
        f23_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3013, TARGET_ENE_0, 4, 0, 0, 0, 0)
        return true
    end
    if f23_arg1:IsInterupt(INTERUPT_ActivateSpecialEffect) and f23_arg1:HasSpecialEffectId(TARGET_SELF, 5032) then
        if f23_local2 < 1.5 and f23_arg1:GetAttackPassedTime(3005) >= 5 and f23_arg1:GetAttackPassedTime(3006) >= 5 then
            if f23_local0 <= 50 then
                f23_arg2:ClearSubGoal()
                f23_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3005, TARGET_ENE_0, 4, 0, 0, 0, 0)
                return true
            else
                f23_arg2:ClearSubGoal()
                f23_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3006, TARGET_ENE_0, 4, 0, 0, 0, 0)
                return true
            end
        elseif f23_local0 <= 40 and f23_local2 > 1.5 and f23_local2 < 3 then
            if f23_local1 <= 50 then
                f23_arg2:ClearSubGoal()
                f23_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3016, TARGET_ENE_0, 4, 0, 0, 0, 0)
                return true
            elseif f23_arg1:GetAttackPassedTime(3019) >= 10 then
                f23_arg2:ClearSubGoal()
                f23_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3019, TARGET_ENE_0, 4, 0, 0, 0, 0)
                return true
            end
        elseif f23_local2 > 4 and f23_local2 < 7 and f23_arg1:GetAttackPassedTime(3004) >= 10 then
            f23_arg2:ClearSubGoal()
            f23_arg2:AddSubGoal(GOAL_COMMON_ComboRepeat, 10, 3004, TARGET_ENE_0, 4, 0, 0, 0, 0)
            return true
        end
    end
    return false
    
end

RegisterTableGoal(GOAL_DaemonBloodLaity355000_AfterAttackAct, "DaemonBloodLaity355001_AfterAttackAct")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_DaemonBloodLaity35501_AfterAttackAct, true)

Goal.Activate = function (f24_arg0, f24_arg1, f24_arg2)
    local f24_local0 = f24_arg1:GetDist(TARGET_ENE_0)
    local f24_local1 = f24_arg1:GetToTargetAngle(TARGET_ENE_0)
    f24_arg1:SetStringIndexedNumber("DistMin_AAA", -999)
    f24_arg1:SetStringIndexedNumber("DistMax_AAA", 7)
    f24_arg1:SetStringIndexedNumber("BaseDir_AAA", AI_DIR_TYPE_F)
    f24_arg1:SetStringIndexedNumber("Angle_AAA", 180)
    f24_arg1:SetStringIndexedNumber("DistMin_Inter_AAA", 1)
    f24_arg1:SetStringIndexedNumber("DistMax_Inter_AAA", 10)
    f24_arg1:SetStringIndexedNumber("BaseAng_Inter_AAA", 0)
    f24_arg1:SetStringIndexedNumber("Ang_Inter_AAA", 180)
    if f24_local0 >= 5 then
        f24_arg1:SetStringIndexedNumber("Odds_Guard_AAA", 80)
        f24_arg1:SetStringIndexedNumber("Odds_NoAct_AAA", 70)
        f24_arg1:SetStringIndexedNumber("Odds_BackAndSide_AAA", 30)
    elseif f24_local0 >= 2 then
        f24_arg1:SetStringIndexedNumber("Odds_Guard_AAA", 80)
        f24_arg1:SetStringIndexedNumber("Odds_NoAct_AAA", 50)
        f24_arg1:SetStringIndexedNumber("Odds_BackAndSide_AAA", 30)
        f24_arg1:SetStringIndexedNumber("Odds_Back_AAA", 10)
        f24_arg1:SetStringIndexedNumber("Odds_Backstep_AAA", 10)
    else
        f24_arg1:SetStringIndexedNumber("Odds_Guard_AAA", 80)
        f24_arg1:SetStringIndexedNumber("Odds_NoAct_AAA", 50)
        f24_arg1:SetStringIndexedNumber("Odds_BackAndSide_AAA", 10)
        f24_arg1:SetStringIndexedNumber("Odds_Back_AAA", 10)
        f24_arg1:SetStringIndexedNumber("Odds_Backstep_AAA", 5)
        f24_arg1:SetStringIndexedNumber("Odds_Sidestep_AAA", 10)
        f24_arg1:SetStringIndexedNumber("Odds_BsAndSide_AAA", 15)
    end
    f24_arg2:AddSubGoal(GOAL_COMMON_AfterAttackAct, 10)
    
end

Goal.Update = function (f25_arg0, f25_arg1, f25_arg2)
    return Update_Default_NoSubGoal(f25_arg0, f25_arg1, f25_arg2)
    
end


