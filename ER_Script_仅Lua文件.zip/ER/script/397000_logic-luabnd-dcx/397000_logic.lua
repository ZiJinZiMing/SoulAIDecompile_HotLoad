﻿function BeastProgeny397000_Logic(f1_arg0)
    COMMON_Initialize(f1_arg0)
    if COMMON_EasySetup_Initial(f1_arg0) == false then
        local f1_local0 = f1_arg0:GetEventRequest()
        local f1_local1 = f1_arg0:GetDist(TARGET_ENE_0)
        local f1_local2 = f1_arg0:IsSearchTarget(TARGET_ENE_0)
        local f1_local3 = f1_arg0:GetDist(POINT_INITIAL)
        local f1_local4 = GetCurrentTimeType(f1_arg0)
        local f1_local5 = f1_arg0:GetPrevTargetState()
        local f1_local6 = f1_arg0:GetCurrTargetState()
        local f1_local7 = f1_arg0:HasSpecialEffectId(TARGET_SELF, 14651)
        local f1_local8 = f1_arg0:HasSpecialEffectId(TARGET_SELF, 14650)
        local f1_local9 = f1_arg0:IsBattleState()
        COMMON_EasySetup3(f1_arg0)
    end
    
end

function BeastProgeny397000_Interupt(f2_arg0, f2_arg1)
    
end


