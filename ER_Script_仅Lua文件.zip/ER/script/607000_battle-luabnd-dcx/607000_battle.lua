﻿RegisterTableGoal(GOAL_Wildguillemots607000_Battle, "GOAL_Wildguillemots607000_Battle")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_Wildguillemots607000_Battle, true)

Goal.Initialize = function (f1_arg0, f1_arg1, f1_arg2, f1_arg3)
    
end

Goal.Activate = function (f2_arg0, f2_arg1, f2_arg2)
    Init_Pseudo_Global(f2_arg1, f2_arg2)
    local f2_local0 = {}
    local f2_local1 = {}
    local f2_local2 = {}
    Common_Clear_Param(f2_local0, f2_local1, f2_local2)
    f2_arg1:DeleteObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f2_arg1:AddObserveSpecialEffectAttribute(TARGET_SELF, 5039)
    local f2_local3 = f2_arg1:GetDist(TARGET_ENE_0)
    local f2_local4 = f2_arg1:GetDistY(TARGET_ENE_0)
    local f2_local5 = f2_arg1:GetHpRate(TARGET_SELF)
    local f2_local6 = f2_arg1:GetRandam_Int(1, 100)
    local f2_local7 = f2_arg1:GetExcelParam(AI_EXCEL_THINK_PARAM_TYPE__thinkAttr_doAdmirer)
    if f2_local7 == 1 and f2_arg1:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Kankyaku then
        if f2_local5 < 1 then
            f2_local0[1] = 100
        elseif f2_local3 >= 20 then
            if f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 100) then
                f2_local0[2] = 15
                f2_local0[3] = 15
                f2_local0[4] = 15
                f2_local0[5] = 15
                f2_local0[20] = 0
                f2_local0[21] = 0
                f2_local0[22] = 0
                f2_local0[23] = 10
                f2_local0[24] = 30
            else
                f2_local0[2] = 15
                f2_local0[3] = 15
                f2_local0[4] = 15
                f2_local0[5] = 15
                f2_local0[20] = 0
                f2_local0[21] = 0
                f2_local0[22] = 0
                f2_local0[23] = 10
                f2_local0[24] = 30
            end
        elseif f2_local3 >= 15 then
            if f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 100) then
                f2_local0[2] = 15
                f2_local0[3] = 15
                f2_local0[4] = 15
                f2_local0[5] = 15
                f2_local0[20] = 0
                f2_local0[21] = 0
                f2_local0[22] = 0
                f2_local0[23] = 10
                f2_local0[24] = 30
            elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_L, 120, 180, 100) then
                f2_local0[2] = 15
                f2_local0[3] = 15
                f2_local0[4] = 15
                f2_local0[5] = 15
                f2_local0[20] = 0
                f2_local0[21] = 0
                f2_local0[22] = 0
                f2_local0[23] = 10
                f2_local0[24] = 30
            elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_R, 120, 180, 100) then
                f2_local0[2] = 15
                f2_local0[3] = 15
                f2_local0[4] = 15
                f2_local0[5] = 15
                f2_local0[20] = 0
                f2_local0[21] = 0
                f2_local0[22] = 0
                f2_local0[23] = 10
                f2_local0[24] = 30
            else
                f2_local0[2] = 15
                f2_local0[3] = 15
                f2_local0[4] = 15
                f2_local0[5] = 15
                f2_local0[20] = 0
                f2_local0[21] = 0
                f2_local0[22] = 0
                f2_local0[23] = 10
                f2_local0[24] = 30
            end
        elseif f2_local3 >= 10 then
            if f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 100) then
                f2_local0[2] = 15
                f2_local0[3] = 15
                f2_local0[4] = 15
                f2_local0[5] = 15
                f2_local0[20] = 0
                f2_local0[21] = 0
                f2_local0[22] = 0
                f2_local0[23] = 10
                f2_local0[24] = 30
            elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_L, 120, 180, 100) then
                f2_local0[2] = 15
                f2_local0[3] = 15
                f2_local0[4] = 15
                f2_local0[5] = 15
                f2_local0[20] = 0
                f2_local0[21] = 0
                f2_local0[22] = 0
                f2_local0[23] = 10
                f2_local0[24] = 30
            elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_R, 120, 180, 100) then
                f2_local0[2] = 15
                f2_local0[3] = 15
                f2_local0[4] = 15
                f2_local0[5] = 15
                f2_local0[20] = 0
                f2_local0[21] = 0
                f2_local0[22] = 0
                f2_local0[23] = 10
                f2_local0[24] = 30
            else
                f2_local0[2] = 15
                f2_local0[3] = 15
                f2_local0[4] = 15
                f2_local0[5] = 15
                f2_local0[20] = 0
                f2_local0[21] = 0
                f2_local0[22] = 0
                f2_local0[23] = 10
                f2_local0[24] = 30
            end
        elseif f2_local3 >= 5 then
            if f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 100) then
                f2_local0[2] = 15
                f2_local0[3] = 15
                f2_local0[4] = 15
                f2_local0[5] = 15
                f2_local0[20] = 0
                f2_local0[21] = 0
                f2_local0[22] = 0
                f2_local0[23] = 10
                f2_local0[24] = 30
            elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_L, 120, 180, 100) then
                f2_local0[2] = 15
                f2_local0[3] = 15
                f2_local0[4] = 15
                f2_local0[5] = 15
                f2_local0[20] = 0
                f2_local0[21] = 0
                f2_local0[22] = 0
                f2_local0[23] = 10
                f2_local0[24] = 30
            elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_R, 120, 180, 100) then
                f2_local0[2] = 15
                f2_local0[3] = 15
                f2_local0[4] = 15
                f2_local0[5] = 15
                f2_local0[20] = 0
                f2_local0[21] = 0
                f2_local0[22] = 0
                f2_local0[23] = 10
                f2_local0[24] = 30
            else
                f2_local0[2] = 15
                f2_local0[3] = 15
                f2_local0[4] = 15
                f2_local0[5] = 15
                f2_local0[20] = 0
                f2_local0[21] = 0
                f2_local0[22] = 0
                f2_local0[23] = 10
                f2_local0[24] = 30
            end
        elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 100) then
            f2_local0[2] = 15
            f2_local0[3] = 15
            f2_local0[4] = 15
            f2_local0[5] = 15
            f2_local0[20] = 0
            f2_local0[21] = 0
            f2_local0[22] = 0
            f2_local0[23] = 10
            f2_local0[24] = 30
        elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_L, 120, 180, 100) then
            f2_local0[2] = 15
            f2_local0[3] = 15
            f2_local0[4] = 15
            f2_local0[5] = 15
            f2_local0[20] = 0
            f2_local0[21] = 0
            f2_local0[22] = 0
            f2_local0[23] = 10
            f2_local0[24] = 30
        elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_R, 120, 180, 100) then
            f2_local0[2] = 15
            f2_local0[3] = 15
            f2_local0[4] = 15
            f2_local0[5] = 15
            f2_local0[20] = 0
            f2_local0[21] = 0
            f2_local0[22] = 0
            f2_local0[23] = 10
            f2_local0[24] = 30
        else
            f2_local0[2] = 15
            f2_local0[3] = 15
            f2_local0[4] = 15
            f2_local0[5] = 15
            f2_local0[20] = 0
            f2_local0[21] = 0
            f2_local0[22] = 0
            f2_local0[23] = 10
            f2_local0[24] = 30
        end
    elseif f2_local7 == 1 and f2_arg1:GetTeamOrder(ORDER_TYPE_Role) == ROLE_TYPE_Torimaki then
        if f2_local5 < 1 then
            f2_local0[1] = 100
        elseif f2_local3 >= 20 then
            if f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 100) then
                f2_local0[2] = 15
                f2_local0[3] = 15
                f2_local0[4] = 15
                f2_local0[5] = 15
                f2_local0[20] = 0
                f2_local0[21] = 0
                f2_local0[22] = 0
                f2_local0[23] = 10
                f2_local0[24] = 30
            else
                f2_local0[2] = 15
                f2_local0[3] = 15
                f2_local0[4] = 15
                f2_local0[5] = 15
                f2_local0[20] = 0
                f2_local0[21] = 0
                f2_local0[22] = 0
                f2_local0[23] = 10
                f2_local0[24] = 30
            end
        elseif f2_local3 >= 15 then
            if f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 100) then
                f2_local0[2] = 15
                f2_local0[3] = 15
                f2_local0[4] = 15
                f2_local0[5] = 15
                f2_local0[20] = 0
                f2_local0[21] = 0
                f2_local0[22] = 0
                f2_local0[23] = 10
                f2_local0[24] = 30
            elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_L, 120, 180, 100) then
                f2_local0[2] = 15
                f2_local0[3] = 15
                f2_local0[4] = 15
                f2_local0[5] = 15
                f2_local0[20] = 0
                f2_local0[21] = 0
                f2_local0[22] = 0
                f2_local0[23] = 10
                f2_local0[24] = 30
            elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_R, 120, 180, 100) then
                f2_local0[2] = 15
                f2_local0[3] = 15
                f2_local0[4] = 15
                f2_local0[5] = 15
                f2_local0[20] = 0
                f2_local0[21] = 0
                f2_local0[22] = 0
                f2_local0[23] = 10
                f2_local0[24] = 30
            else
                f2_local0[2] = 15
                f2_local0[3] = 15
                f2_local0[4] = 15
                f2_local0[5] = 15
                f2_local0[20] = 0
                f2_local0[21] = 0
                f2_local0[22] = 0
                f2_local0[23] = 10
                f2_local0[24] = 30
            end
        elseif f2_local3 >= 10 then
            if f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 100) then
                f2_local0[2] = 15
                f2_local0[3] = 15
                f2_local0[4] = 15
                f2_local0[5] = 15
                f2_local0[20] = 0
                f2_local0[21] = 0
                f2_local0[22] = 0
                f2_local0[23] = 10
                f2_local0[24] = 30
            elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_L, 120, 180, 100) then
                f2_local0[2] = 15
                f2_local0[3] = 15
                f2_local0[4] = 15
                f2_local0[5] = 15
                f2_local0[20] = 0
                f2_local0[21] = 0
                f2_local0[22] = 0
                f2_local0[23] = 10
                f2_local0[24] = 30
            elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_R, 120, 180, 100) then
                f2_local0[2] = 15
                f2_local0[3] = 15
                f2_local0[4] = 15
                f2_local0[5] = 15
                f2_local0[20] = 0
                f2_local0[21] = 0
                f2_local0[22] = 0
                f2_local0[23] = 10
                f2_local0[24] = 30
            else
                f2_local0[2] = 15
                f2_local0[3] = 15
                f2_local0[4] = 15
                f2_local0[5] = 15
                f2_local0[20] = 0
                f2_local0[21] = 0
                f2_local0[22] = 0
                f2_local0[23] = 10
                f2_local0[24] = 30
            end
        elseif f2_local3 >= 5 then
            if f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 100) then
                f2_local0[2] = 15
                f2_local0[3] = 15
                f2_local0[4] = 15
                f2_local0[5] = 15
                f2_local0[20] = 0
                f2_local0[21] = 0
                f2_local0[22] = 0
                f2_local0[23] = 10
                f2_local0[24] = 30
            elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_L, 120, 180, 100) then
                f2_local0[2] = 15
                f2_local0[3] = 15
                f2_local0[4] = 15
                f2_local0[5] = 15
                f2_local0[20] = 0
                f2_local0[21] = 0
                f2_local0[22] = 0
                f2_local0[23] = 10
                f2_local0[24] = 30
            elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_R, 120, 180, 100) then
                f2_local0[2] = 15
                f2_local0[3] = 15
                f2_local0[4] = 15
                f2_local0[5] = 15
                f2_local0[20] = 0
                f2_local0[21] = 0
                f2_local0[22] = 0
                f2_local0[23] = 10
                f2_local0[24] = 30
            else
                f2_local0[2] = 15
                f2_local0[3] = 15
                f2_local0[4] = 15
                f2_local0[5] = 15
                f2_local0[20] = 0
                f2_local0[21] = 0
                f2_local0[22] = 0
                f2_local0[23] = 10
                f2_local0[24] = 30
            end
        elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 100) then
            f2_local0[2] = 15
            f2_local0[3] = 15
            f2_local0[4] = 15
            f2_local0[5] = 15
            f2_local0[20] = 0
            f2_local0[21] = 0
            f2_local0[22] = 0
            f2_local0[23] = 10
            f2_local0[24] = 30
        elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_L, 120, 180, 100) then
            f2_local0[2] = 15
            f2_local0[3] = 15
            f2_local0[4] = 15
            f2_local0[5] = 15
            f2_local0[20] = 0
            f2_local0[21] = 0
            f2_local0[22] = 0
            f2_local0[23] = 10
            f2_local0[24] = 30
        elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_R, 120, 180, 100) then
            f2_local0[2] = 15
            f2_local0[3] = 15
            f2_local0[4] = 15
            f2_local0[5] = 15
            f2_local0[20] = 0
            f2_local0[21] = 0
            f2_local0[22] = 0
            f2_local0[23] = 10
            f2_local0[24] = 30
        else
            f2_local0[2] = 15
            f2_local0[3] = 15
            f2_local0[4] = 15
            f2_local0[5] = 15
            f2_local0[20] = 0
            f2_local0[21] = 0
            f2_local0[22] = 0
            f2_local0[23] = 10
            f2_local0[24] = 30
        end
    elseif f2_local5 < 1 then
        f2_local0[1] = 100
    elseif f2_local3 >= 20 then
        if f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 100) then
            f2_local0[2] = 15
            f2_local0[3] = 15
            f2_local0[4] = 15
            f2_local0[5] = 15
            f2_local0[20] = 0
            f2_local0[21] = 0
            f2_local0[22] = 0
            f2_local0[23] = 10
            f2_local0[24] = 30
        else
            f2_local0[2] = 15
            f2_local0[3] = 15
            f2_local0[4] = 15
            f2_local0[5] = 15
            f2_local0[20] = 0
            f2_local0[21] = 0
            f2_local0[22] = 0
            f2_local0[23] = 10
            f2_local0[24] = 30
        end
    elseif f2_local3 >= 15 then
        if f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 100) then
            f2_local0[2] = 15
            f2_local0[3] = 15
            f2_local0[4] = 15
            f2_local0[5] = 15
            f2_local0[20] = 0
            f2_local0[21] = 0
            f2_local0[22] = 0
            f2_local0[23] = 10
            f2_local0[24] = 30
        elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_L, 120, 180, 100) then
            f2_local0[2] = 15
            f2_local0[3] = 15
            f2_local0[4] = 15
            f2_local0[5] = 15
            f2_local0[20] = 0
            f2_local0[21] = 0
            f2_local0[22] = 0
            f2_local0[23] = 10
            f2_local0[24] = 30
        elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_R, 120, 180, 100) then
            f2_local0[2] = 15
            f2_local0[3] = 15
            f2_local0[4] = 15
            f2_local0[5] = 15
            f2_local0[20] = 0
            f2_local0[21] = 0
            f2_local0[22] = 0
            f2_local0[23] = 10
            f2_local0[24] = 30
        else
            f2_local0[2] = 15
            f2_local0[3] = 15
            f2_local0[4] = 15
            f2_local0[5] = 15
            f2_local0[20] = 0
            f2_local0[21] = 0
            f2_local0[22] = 0
            f2_local0[23] = 10
            f2_local0[24] = 30
        end
    elseif f2_local3 >= 10 then
        if f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 100) then
            f2_local0[2] = 15
            f2_local0[3] = 15
            f2_local0[4] = 15
            f2_local0[5] = 15
            f2_local0[20] = 0
            f2_local0[21] = 0
            f2_local0[22] = 0
            f2_local0[23] = 10
            f2_local0[24] = 30
        elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_L, 120, 180, 100) then
            f2_local0[2] = 15
            f2_local0[3] = 15
            f2_local0[4] = 15
            f2_local0[5] = 15
            f2_local0[20] = 0
            f2_local0[21] = 0
            f2_local0[22] = 0
            f2_local0[23] = 10
            f2_local0[24] = 30
        elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_R, 120, 180, 100) then
            f2_local0[2] = 15
            f2_local0[3] = 15
            f2_local0[4] = 15
            f2_local0[5] = 15
            f2_local0[20] = 0
            f2_local0[21] = 0
            f2_local0[22] = 0
            f2_local0[23] = 10
            f2_local0[24] = 30
        else
            f2_local0[2] = 15
            f2_local0[3] = 15
            f2_local0[4] = 15
            f2_local0[5] = 15
            f2_local0[20] = 0
            f2_local0[21] = 0
            f2_local0[22] = 0
            f2_local0[23] = 10
            f2_local0[24] = 30
        end
    elseif f2_local3 >= 5 then
        if f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 100) then
            f2_local0[2] = 15
            f2_local0[3] = 15
            f2_local0[4] = 15
            f2_local0[5] = 15
            f2_local0[20] = 0
            f2_local0[21] = 0
            f2_local0[22] = 0
            f2_local0[23] = 10
            f2_local0[24] = 30
        elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_L, 120, 180, 100) then
            f2_local0[2] = 15
            f2_local0[3] = 15
            f2_local0[4] = 15
            f2_local0[5] = 15
            f2_local0[20] = 0
            f2_local0[21] = 0
            f2_local0[22] = 0
            f2_local0[23] = 10
            f2_local0[24] = 30
        elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_R, 120, 180, 100) then
            f2_local0[2] = 15
            f2_local0[3] = 15
            f2_local0[4] = 15
            f2_local0[5] = 15
            f2_local0[20] = 0
            f2_local0[21] = 0
            f2_local0[22] = 0
            f2_local0[23] = 10
            f2_local0[24] = 30
        else
            f2_local0[2] = 15
            f2_local0[3] = 15
            f2_local0[4] = 15
            f2_local0[5] = 15
            f2_local0[20] = 0
            f2_local0[21] = 0
            f2_local0[22] = 0
            f2_local0[23] = 10
            f2_local0[24] = 30
        end
    elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 120, 180, 100) then
        f2_local0[2] = 15
        f2_local0[3] = 15
        f2_local0[4] = 15
        f2_local0[5] = 15
        f2_local0[20] = 0
        f2_local0[21] = 0
        f2_local0[22] = 0
        f2_local0[23] = 10
        f2_local0[24] = 30
    elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_L, 120, 180, 100) then
        f2_local0[2] = 15
        f2_local0[3] = 15
        f2_local0[4] = 15
        f2_local0[5] = 15
        f2_local0[20] = 0
        f2_local0[21] = 0
        f2_local0[22] = 0
        f2_local0[23] = 10
        f2_local0[24] = 30
    elseif f2_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_R, 120, 180, 100) then
        f2_local0[2] = 15
        f2_local0[3] = 15
        f2_local0[4] = 15
        f2_local0[5] = 15
        f2_local0[20] = 0
        f2_local0[21] = 0
        f2_local0[22] = 0
        f2_local0[23] = 10
        f2_local0[24] = 30
    else
        f2_local0[2] = 15
        f2_local0[3] = 15
        f2_local0[4] = 15
        f2_local0[5] = 15
        f2_local0[20] = 0
        f2_local0[21] = 0
        f2_local0[22] = 0
        f2_local0[23] = 10
        f2_local0[24] = 30
    end
    f2_local0[1] = SetCoolTime(f2_arg1, f2_arg2, 3000, 5, f2_local0[1], 1)
    f2_local0[2] = SetCoolTime(f2_arg1, f2_arg2, 3020, 20, f2_local0[2], 1)
    f2_local0[3] = SetCoolTime(f2_arg1, f2_arg2, 3021, 20, f2_local0[3], 1)
    f2_local0[4] = SetCoolTime(f2_arg1, f2_arg2, 3022, 20, f2_local0[4], 1)
    f2_local0[5] = SetCoolTime(f2_arg1, f2_arg2, 3023, 20, f2_local0[5], 1)
    f2_local1[1] = REGIST_FUNC(f2_arg1, f2_arg2, Wildguillemots607000_Act01)
    f2_local1[2] = REGIST_FUNC(f2_arg1, f2_arg2, Wildguillemots607000_Act02)
    f2_local1[3] = REGIST_FUNC(f2_arg1, f2_arg2, Wildguillemots607000_Act03)
    f2_local1[4] = REGIST_FUNC(f2_arg1, f2_arg2, Wildguillemots607000_Act04)
    f2_local1[5] = REGIST_FUNC(f2_arg1, f2_arg2, Wildguillemots607000_Act05)
    f2_local1[20] = REGIST_FUNC(f2_arg1, f2_arg2, Wildguillemots607000_Act20)
    f2_local1[21] = REGIST_FUNC(f2_arg1, f2_arg2, Wildguillemots607000_Act21)
    f2_local1[22] = REGIST_FUNC(f2_arg1, f2_arg2, Wildguillemots607000_Act22)
    f2_local1[23] = REGIST_FUNC(f2_arg1, f2_arg2, Wildguillemots607000_Act23)
    f2_local1[24] = REGIST_FUNC(f2_arg1, f2_arg2, Wildguillemots607000_Act24)
    local f2_local8 = REGIST_FUNC(f2_arg1, f2_arg2, Wildguillemots607000_ActAfter_AdjustSpace)
    Common_Battle_Activate(f2_arg1, f2_arg2, f2_local0, f2_local1, f2_local8, f2_local2)
    
end

function Wildguillemots607000_Act01(f3_arg0, f3_arg1, f3_arg2)
    local f3_local0 = 30 - f3_arg0:GetMapHitRadius(TARGET_SELF)
    local f3_local1 = f3_local0 + 0
    local f3_local2 = f3_local0 + 10
    local f3_local3 = 0
    local f3_local4 = 0
    local f3_local5 = 3
    local f3_local6 = 3
    local f3_local7 = 3000
    local f3_local8 = 5 - f3_arg0:GetMapHitRadius(TARGET_SELF) + 999
    local f3_local9 = 0
    local f3_local10 = 0
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, f3_local7, TARGET_ENE_0, f3_local8, f3_local9, f3_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wildguillemots607000_Act02(f4_arg0, f4_arg1, f4_arg2)
    local f4_local0 = 30 - f4_arg0:GetMapHitRadius(TARGET_SELF)
    local f4_local1 = f4_local0 + 0
    local f4_local2 = f4_local0 + 10
    local f4_local3 = 0
    local f4_local4 = 0
    local f4_local5 = 3
    local f4_local6 = 3
    f4_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    local f4_local7 = 3020
    local f4_local8 = 5 - f4_arg0:GetMapHitRadius(TARGET_SELF) + 999
    local f4_local9 = 0
    local f4_local10 = 0
    f4_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, f4_local7, TARGET_ENE_0, f4_local8, f4_local9, f4_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wildguillemots607000_Act03(f5_arg0, f5_arg1, f5_arg2)
    local f5_local0 = 30 - f5_arg0:GetMapHitRadius(TARGET_SELF)
    local f5_local1 = f5_local0 + 0
    local f5_local2 = f5_local0 + 10
    local f5_local3 = 0
    local f5_local4 = 0
    local f5_local5 = 3
    local f5_local6 = 3
    f5_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    local f5_local7 = 3021
    local f5_local8 = 5 - f5_arg0:GetMapHitRadius(TARGET_SELF) + 999
    local f5_local9 = 0
    local f5_local10 = 0
    f5_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, f5_local7, TARGET_ENE_0, f5_local8, f5_local9, f5_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wildguillemots607000_Act04(f6_arg0, f6_arg1, f6_arg2)
    local f6_local0 = 30 - f6_arg0:GetMapHitRadius(TARGET_SELF)
    local f6_local1 = f6_local0 + 0
    local f6_local2 = f6_local0 + 10
    local f6_local3 = 0
    local f6_local4 = 0
    local f6_local5 = 3
    local f6_local6 = 3
    f6_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    local f6_local7 = 3022
    local f6_local8 = 5 - f6_arg0:GetMapHitRadius(TARGET_SELF) + 999
    local f6_local9 = 0
    local f6_local10 = 0
    f6_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, f6_local7, TARGET_ENE_0, f6_local8, f6_local9, f6_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wildguillemots607000_Act05(f7_arg0, f7_arg1, f7_arg2)
    local f7_local0 = 30 - f7_arg0:GetMapHitRadius(TARGET_SELF)
    local f7_local1 = f7_local0 + 0
    local f7_local2 = f7_local0 + 10
    local f7_local3 = 0
    local f7_local4 = 0
    local f7_local5 = 3
    local f7_local6 = 3
    f7_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    local f7_local7 = 3023
    local f7_local8 = 5 - f7_arg0:GetMapHitRadius(TARGET_SELF) + 999
    local f7_local9 = 0
    local f7_local10 = 0
    f7_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 50, f7_local7, TARGET_ENE_0, f7_local8, f7_local9, f7_local10, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wildguillemots607000_Act20(f8_arg0, f8_arg1, f8_arg2)
    f8_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f8_arg1:AddSubGoal(GOAL_COMMON_ApproachTarget, f8_arg0:GetRandam_Float(2, 2.5), TARGET_ENE_0, 5, TARGET_SELF, true, -1)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wildguillemots607000_Act21(f9_arg0, f9_arg1, f9_arg2)
    local f9_local0 = f9_arg0:GetMapHitRadius(TARGET_SELF)
    f9_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    if f9_arg0:GetExistMeshOnLineDistEx(TARGET_SELF, AI_DIR_TYPE_B, 2, f9_local0, 0) >= 2 then
        f9_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 2, TARGET_ENE_0, 30, TARGET_ENE_0, true, -1)
    else
        f9_arg1:AddSubGoal(GOAL_COMMON_SidewayMove, f9_arg0:GetRandam_Float(2, 2.5), TARGET_ENE_0, f9_arg0:GetRandam_Int(0, 1), f9_arg0:GetRandam_Int(30, 45), true, true, -1)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wildguillemots607000_Act22(f10_arg0, f10_arg1, f10_arg2)
    f10_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f10_arg1:AddSubGoal(GOAL_COMMON_Turn, 2, TARGET_ENE_0, 90, -1, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wildguillemots607000_Act23(f11_arg0, f11_arg1, f11_arg2)
    f11_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f11_arg1:AddSubGoal(GOAL_COMMON_Wait, f11_arg0:GetRandam_Float(4, 5), TARGET_SELF, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wildguillemots607000_Act24(f12_arg0, f12_arg1, f12_arg2)
    f12_arg0:AddObserveSpecialEffectAttribute(TARGET_SELF, 5025)
    f12_arg1:AddSubGoal(GOAL_COMMON_WalkAround_Anywhere, -1, 1, 7, true, -1, 0, 1, false, false)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function Wildguillemots607000_ActAfter_AdjustSpace(f13_arg0, f13_arg1, f13_arg2)
    f13_arg1:AddSubGoal(GOAL_Wildguillemots607000_AfterAttackAct, 10)
    
end

Goal.Update = function (f14_arg0, f14_arg1, f14_arg2)
    return Update_Default_NoSubGoal(f14_arg0, f14_arg1, f14_arg2)
    
end

Goal.Terminate = function (f15_arg0, f15_arg1, f15_arg2)
    
end

Goal.Interrupt = function (f16_arg0, f16_arg1, f16_arg2)
    local f16_local0 = f16_arg1:GetDist(TARGET_ENE_0)
    local f16_local1 = 5 - f16_arg1:GetMapHitRadius(TARGET_SELF)
    local f16_local2 = 0
    local f16_local3 = 0
    local f16_local4 = f16_arg1:GetRandam_Int(1, 100)
    local f16_local5 = f16_arg1:GetHpRate(TARGET_SELF)
    if f16_arg1:HasSpecialEffectId(TARGET_SELF, 5110) == true or f16_arg1:HasSpecialEffectAttribute(TARGET_SELF, SP_EFFECT_TYPE_SLEEP) == true then
        return false
    end
    if f16_arg1:IsInterupt(INTERUPT_FindAttack) and f16_arg1:HasSpecialEffectId(TARGET_SELF, 5039) == false and f16_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 360, 180, 4) then
        f16_arg2:ClearSubGoal()
        f16_arg2:AddSubGoal(GOAL_COMMON_Wait, 0.3, TARGET_SELF)
        f16_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 50, 3000, TARGET_ENE_0, 999, 0, 0, 0, 0)
        return true
    end
    if f16_arg1:IsInterupt(INTERUPT_Shoot) and f16_arg1:HasSpecialEffectId(TARGET_SELF, 5039) == false then
        if f16_arg1:IsInsideTargetCustom(TARGET_ENE_0, TARGET_SELF, AI_DIR_TYPE_B, 120, 180, 50) then
            return true
        elseif f16_arg1:IsInsideTargetCustom(TARGET_ENE_0, TARGET_SELF, AI_DIR_TYPE_L, 120, 180, 50) then
            return true
        elseif f16_arg1:IsInsideTargetCustom(TARGET_ENE_0, TARGET_SELF, AI_DIR_TYPE_R, 120, 180, 50) then
            return true
        elseif f16_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_SOUND, AI_DIR_TYPE_F, 120, 180, 5) then
            f16_arg2:ClearSubGoal()
            f16_arg2:AddSubGoal(GOAL_COMMON_Wait, 0.3, TARGET_SELF)
            f16_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 50, 3000, TARGET_ENE_0, 999, 0, 0, 0, 0)
            return true
        elseif f16_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_SOUND, AI_DIR_TYPE_L, 120, 180, 5) then
            f16_arg2:ClearSubGoal()
            f16_arg2:AddSubGoal(GOAL_COMMON_Wait, 0.3, TARGET_SELF)
            f16_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 50, 3000, TARGET_ENE_0, 999, 0, 0, 0, 0)
            return true
        elseif f16_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_SOUND, AI_DIR_TYPE_R, 120, 180, 5) then
            f16_arg2:ClearSubGoal()
            f16_arg2:AddSubGoal(GOAL_COMMON_Wait, 0.3, TARGET_SELF)
            f16_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 50, 3000, TARGET_ENE_0, 999, 0, 0, 0, 0)
            return true
        elseif f16_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_SOUND, AI_DIR_TYPE_B, 120, 180, 5) then
            f16_arg2:ClearSubGoal()
            f16_arg2:AddSubGoal(GOAL_COMMON_Wait, 0.3, TARGET_SELF)
            f16_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 50, 3000, TARGET_ENE_0, 999, 0, 0, 0, 0)
        elseif f16_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_SOUND, AI_DIR_TYPE_F, 120, 180, 10) then
            f16_arg2:ClearSubGoal()
            f16_arg2:AddSubGoal(GOAL_COMMON_Wait, 0.5, TARGET_SELF)
            f16_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 50, 3000, TARGET_ENE_0, 999, 0, 0, 0, 0)
            return true
        elseif f16_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_SOUND, AI_DIR_TYPE_L, 120, 180, 10) then
            f16_arg2:ClearSubGoal()
            f16_arg2:AddSubGoal(GOAL_COMMON_Wait, 0.5, TARGET_SELF)
            f16_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 50, 3000, TARGET_ENE_0, 999, 0, 0, 0, 0)
            return true
        elseif f16_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_SOUND, AI_DIR_TYPE_R, 120, 180, 10) then
            f16_arg2:ClearSubGoal()
            f16_arg2:AddSubGoal(GOAL_COMMON_Wait, 0.5, TARGET_SELF)
            f16_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 50, 3000, TARGET_ENE_0, 999, 0, 0, 0, 0)
            return true
        elseif f16_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_SOUND, AI_DIR_TYPE_B, 120, 180, 10) then
            f16_arg2:ClearSubGoal()
            f16_arg2:AddSubGoal(GOAL_COMMON_Wait, 0.5, TARGET_SELF)
            f16_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 50, 3000, TARGET_ENE_0, 999, 0, 0, 0, 0)
        elseif f16_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_SOUND, AI_DIR_TYPE_F, 120, 180, 20) then
            f16_arg2:ClearSubGoal()
            f16_arg2:AddSubGoal(GOAL_COMMON_Wait, 0.7, TARGET_SELF)
            f16_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 50, 3000, TARGET_ENE_0, 999, 0, 0, 0, 0)
            return true
        elseif f16_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_SOUND, AI_DIR_TYPE_L, 120, 180, 20) then
            f16_arg2:ClearSubGoal()
            f16_arg2:AddSubGoal(GOAL_COMMON_Wait, 0.7, TARGET_SELF)
            f16_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 50, 3000, TARGET_ENE_0, 999, 0, 0, 0, 0)
            return true
        elseif f16_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_SOUND, AI_DIR_TYPE_R, 120, 180, 20) then
            f16_arg2:ClearSubGoal()
            f16_arg2:AddSubGoal(GOAL_COMMON_Wait, 0.7, TARGET_SELF)
            f16_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 50, 3000, TARGET_ENE_0, 999, 0, 0, 0, 0)
            return true
        elseif f16_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_SOUND, AI_DIR_TYPE_B, 120, 180, 20) then
            f16_arg2:ClearSubGoal()
            f16_arg2:AddSubGoal(GOAL_COMMON_Wait, 0.7, TARGET_SELF)
            f16_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 50, 3000, TARGET_ENE_0, 999, 0, 0, 0, 0)
            return true
        elseif f16_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_SOUND, AI_DIR_TYPE_F, 120, 180, 30) then
            f16_arg2:ClearSubGoal()
            f16_arg2:AddSubGoal(GOAL_COMMON_Wait, 0.9, TARGET_SELF)
            f16_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 50, 3000, TARGET_ENE_0, 999, 0, 0, 0, 0)
            return true
        elseif f16_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_SOUND, AI_DIR_TYPE_L, 120, 180, 30) then
            f16_arg2:ClearSubGoal()
            f16_arg2:AddSubGoal(GOAL_COMMON_Wait, 0.9, TARGET_SELF)
            f16_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 50, 3000, TARGET_ENE_0, 999, 0, 0, 0, 0)
            return true
        elseif f16_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_SOUND, AI_DIR_TYPE_R, 120, 180, 30) then
            f16_arg2:ClearSubGoal()
            f16_arg2:AddSubGoal(GOAL_COMMON_Wait, 0.9, TARGET_SELF)
            f16_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 50, 3000, TARGET_ENE_0, 999, 0, 0, 0, 0)
            return true
        elseif f16_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_SOUND, AI_DIR_TYPE_B, 120, 180, 30) then
            f16_arg2:ClearSubGoal()
            f16_arg2:AddSubGoal(GOAL_COMMON_Wait, 0.9, TARGET_SELF)
            f16_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 50, 3000, TARGET_ENE_0, 999, 0, 0, 0, 0)
            return true
        elseif f16_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_SOUND, AI_DIR_TYPE_F, 120, 180, 40) then
            f16_arg2:ClearSubGoal()
            f16_arg2:AddSubGoal(GOAL_COMMON_Wait, 1.1, TARGET_SELF)
            f16_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 50, 3000, TARGET_ENE_0, 999, 0, 0, 0, 0)
            return true
        elseif f16_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_SOUND, AI_DIR_TYPE_L, 120, 180, 40) then
            f16_arg2:ClearSubGoal()
            f16_arg2:AddSubGoal(GOAL_COMMON_Wait, 1.1, TARGET_SELF)
            f16_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 50, 3000, TARGET_ENE_0, 999, 0, 0, 0, 0)
            return true
        elseif f16_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_SOUND, AI_DIR_TYPE_R, 120, 180, 40) then
            f16_arg2:ClearSubGoal()
            f16_arg2:AddSubGoal(GOAL_COMMON_Wait, 1.1, TARGET_SELF)
            f16_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 50, 3000, TARGET_ENE_0, 999, 0, 0, 0, 0)
            return true
        elseif f16_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_SOUND, AI_DIR_TYPE_B, 120, 180, 40) then
            f16_arg2:ClearSubGoal()
            f16_arg2:AddSubGoal(GOAL_COMMON_Wait, 1.1, TARGET_SELF)
            f16_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 50, 3000, TARGET_ENE_0, 999, 0, 0, 0, 0)
            return true
        end
    end
    if f16_arg1:IsInterupt(INTERUPT_Damaged) and f16_arg1:HasSpecialEffectId(TARGET_SELF, 5039) == false and f16_arg1:IsInsideTargetCustom(TARGET_SELF, TARGET_ENE_0, AI_DIR_TYPE_F, 360, 180, 50) then
        f16_arg2:ClearSubGoal()
        f16_arg2:AddSubGoal(GOAL_COMMON_ComboFinal, 50, 3000, TARGET_ENE_0, 999, 0, 0, 0, 0)
        return true
    end
    return false
    
end

RegisterTableGoal(GOAL_Wildguillemots607000_AfterAttackAct, "GOAL_Wildguillemots607000_AfterAttackAct")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_Wildguillemots607000_AfterAttackAct, true)

Goal.Activate = function (f17_arg0, f17_arg1, f17_arg2)
    
end

Goal.Update = function (f18_arg0, f18_arg1, f18_arg2)
    return Update_Default_NoSubGoal(f18_arg0, f18_arg1, f18_arg2)
    
end


