﻿RegisterTableGoal(GOAL_RedEyeGypsyDonkey321000_Battle, "RedEyeGypsyDonkey321000_Battle")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_RedEyeGypsyDonkey321000_Battle, true)

Goal.Initialize = function (f1_arg0, f1_arg1, f1_arg2, f1_arg3)
    
end

Goal.Activate = function (f2_arg0, f2_arg1, f2_arg2)
    Init_Pseudo_Global(f2_arg1, f2_arg2)
    local f2_local0 = {}
    local f2_local1 = {}
    local f2_local2 = {}
    Common_Clear_Param(f2_local0, f2_local1, f2_local2)
    local f2_local3 = f2_arg1:GetDist(TARGET_ENE_0)
    local f2_local4 = f2_arg1:GetHpRate(TARGET_SELF)
    local f2_local5 = f2_arg1:GetRandam_Int(1, 100)
    if f2_local3 >= 15 and f2_arg1:IsFinishTimer(0) == true then
        f2_local0[1] = 90
        f2_local0[21] = 10
    elseif f2_local3 >= 15 and f2_arg1:IsFinishTimer(0) == false then
        f2_local0[21] = 100
    elseif f2_local3 >= 3 then
        f2_local0[2] = 90
        f2_local0[21] = 10
    else
        f2_local0[26] = 100
    end
    f2_local0[1] = SetCoolTime(f2_arg1, f2_arg2, 3015, 30, f2_local0[1], 0)
    f2_local0[2] = SetCoolTime(f2_arg1, f2_arg2, 3016, 30, f2_local0[2], 0)
    f2_local1[1] = REGIST_FUNC(f2_arg1, f2_arg2, RedEyeGypsyDonkey321000_Act01)
    f2_local1[2] = REGIST_FUNC(f2_arg1, f2_arg2, RedEyeGypsyDonkey321000_Act02)
    f2_local1[20] = REGIST_FUNC(f2_arg1, f2_arg2, RedEyeGypsyDonkey321000_Act20)
    f2_local1[21] = REGIST_FUNC(f2_arg1, f2_arg2, RedEyeGypsyDonkey321000_Act21)
    f2_local1[22] = REGIST_FUNC(f2_arg1, f2_arg2, RedEyeGypsyDonkey321000_Act22)
    f2_local1[23] = REGIST_FUNC(f2_arg1, f2_arg2, RedEyeGypsyDonkey321000_Act23)
    f2_local1[24] = REGIST_FUNC(f2_arg1, f2_arg2, RedEyeGypsyDonkey321000_Act24)
    f2_local1[25] = REGIST_FUNC(f2_arg1, f2_arg2, RedEyeGypsyDonkey321000_Act25)
    f2_local1[26] = REGIST_FUNC(f2_arg1, f2_arg2, RedEyeGypsyDonkey321000_Act26)
    local f2_local6 = REGIST_FUNC(f2_arg1, f2_arg2, RedEyeGypsyDonkey321000_ActAfter_AdjustSpace)
    Common_Battle_Activate(f2_arg1, f2_arg2, f2_local0, f2_local1, f2_local6, f2_local2)
    
end

function RedEyeGypsyDonkey321000_Act01(f3_arg0, f3_arg1, f3_arg2)
    local f3_local0 = 3015
    local f3_local1 = 5 - f3_arg0:GetMapHitRadius(TARGET_SELF) + 99
    local f3_local2 = 0
    local f3_local3 = 0
    f3_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 5, f3_local0, TARGET_ENE_0, f3_local1, f3_local2, f3_local3, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RedEyeGypsyDonkey321000_Act02(f4_arg0, f4_arg1, f4_arg2)
    local f4_local0 = 3016
    local f4_local1 = 5 - f4_arg0:GetMapHitRadius(TARGET_SELF) + 99
    local f4_local2 = 0
    local f4_local3 = 0
    f4_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 5, f4_local0, TARGET_ENE_0, f4_local1, f4_local2, f4_local3, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RedEyeGypsyDonkey321000_Act20(f5_arg0, f5_arg1, f5_arg2)
    if f5_arg0:GetHpRate(TARGET_SELF) >= 0.9 then
        f5_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 5, TARGET_ENE_0, f5_arg0:GetRandam_Int(5, 10), TARGET_SELF, false, 0):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
    else
        f5_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 5, TARGET_ENE_0, f5_arg0:GetRandam_Int(16, 20), TARGET_SELF, false, 0):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f5_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, 1, TARGET_SELF, 1, TARGET_SELF, true, -1, AI_DIR_TYPE_F, 5)
    end
    f5_arg0:SetTimer(0, 15)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RedEyeGypsyDonkey321000_Act21(f6_arg0, f6_arg1, f6_arg2)
    f6_arg1:AddSubGoal(GOAL_COMMON_Wait, 1, TARGET_NONE, 0, 0, 0)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RedEyeGypsyDonkey321000_Act22(f7_arg0, f7_arg1, f7_arg2)
    f7_arg1:AddSubGoal(GOAL_COMMON_WalkAround_Anywhere, 5, 3, 5, true, -1, 0, -1, false, false)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RedEyeGypsyDonkey321000_Act23(f8_arg0, f8_arg1, f8_arg2)
    local f8_local0 = f8_arg0:GetDist(TARGET_ENE_0)
    local f8_local1 = f8_arg0:GetRandam_Int(AI_DIR_TYPE_ToBL, AI_DIR_TYPE_ToBR)
    if f8_local0 <= 5 then
        f8_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, 10, TARGET_ENE_0, 1, TARGET_SELF, false, -1, f8_local1, 7.5)
    else
        f8_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, 10, TARGET_ENE_0, 1, TARGET_SELF, true, -1, f8_local1, 7.5)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RedEyeGypsyDonkey321000_Act24(f9_arg0, f9_arg1, f9_arg2)
    local f9_local0 = 3039
    local f9_local1 = 5 - f9_arg0:GetMapHitRadius(TARGET_SELF) + 99
    local f9_local2 = 0
    local f9_local3 = 0
    f9_arg1:AddSubGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 5, f9_local0, TARGET_ENE_0, f9_local1, f9_local2, f9_local3, 0, 0)
    f9_arg0:SetTimer(0, 15)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RedEyeGypsyDonkey321000_Act25(f10_arg0, f10_arg1, f10_arg2)
    if f10_arg0:GetHpRate(TARGET_SELF) >= 0.9 then
        f10_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 5, TARGET_ENE_0, f10_arg0:GetRandam_Int(5, 10), TARGET_SELF, false, 0):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
    else
        f10_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget, 5, TARGET_ENE_0, f10_arg0:GetRandam_Int(18, 20), TARGET_SELF, false, 0):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f10_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, 1, TARGET_SELF, 1, TARGET_SELF, true, -1, AI_DIR_TYPE_F, 5)
    end
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RedEyeGypsyDonkey321000_Act26(f11_arg0, f11_arg1, f11_arg2)
    if f11_arg0:HasSpecialEffectId(TARGET_SELF, 5160) then
        if f11_arg0:GetHpRate(TARGET_SELF) >= 0.9 then
            f11_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget_Continuous, 5, TARGET_ENE_0, f11_arg0:GetRandam_Int(5, 10), TARGET_SELF, true, -1, GUARD_GOAL_DESIRE_RET_Continue, false, 2)
        else
            f11_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget_Continuous, 5, TARGET_ENE_0, f11_arg0:GetRandam_Int(18, 22), TARGET_SELF, false, -1, GUARD_GOAL_DESIRE_RET_Continue, false, 2):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
            f11_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, 1, TARGET_SELF, 1, TARGET_SELF, true, -1, AI_DIR_TYPE_F, 5)
        end
    elseif f11_arg0:GetHpRate(TARGET_SELF) >= 0.9 then
        f11_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget_Escape, 5, TARGET_ENE_0, f11_arg0:GetRandam_Int(5, 10), TARGET_SELF, true, 1.5)
    else
        f11_arg1:AddSubGoal(GOAL_COMMON_LeaveTarget_Escape, 5, TARGET_ENE_0, f11_arg0:GetRandam_Int(18, 22), TARGET_SELF, false, 1.5):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
        f11_arg1:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, 1, TARGET_SELF, 1, TARGET_SELF, true, -1, AI_DIR_TYPE_F, 5)
    end
    f11_arg0:SetTimer(0, 15)
    GetWellSpace_Odds = 0
    return GetWellSpace_Odds
    
end

function RedEyeGypsyDonkey321000_ActAfter_AdjustSpace(f12_arg0, f12_arg1, f12_arg2)
    f12_arg1:AddSubGoal(GOAL_RedEyeGypsyDonkey321000_AfterAttackAct, 10)
    
end

Goal.Update = function (f13_arg0, f13_arg1, f13_arg2)
    return Update_Default_NoSubGoal(f13_arg0, f13_arg1, f13_arg2)
    
end

Goal.Terminate = function (f14_arg0, f14_arg1, f14_arg2)
    
end

Goal.Interrupt = function (f15_arg0, f15_arg1, f15_arg2)
    local f15_local0 = f15_arg1:GetDist(TARGET_ENE_0)
    local f15_local1 = f15_arg1:GetDist(TARGET_FRI_0)
    local f15_local2 = 5 - f15_arg1:GetMapHitRadius(TARGET_SELF)
    local f15_local3 = f15_arg1:GetRandam_Int(1, 100)
    local f15_local4 = f15_arg1:GetHpRate(TARGET_SELF)
    if f15_arg1:HasSpecialEffectId(TARGET_SELF, 5110) == true or f15_arg1:HasSpecialEffectAttribute(TARGET_SELF, SP_EFFECT_TYPE_SLEEP) == true then
        return false
    end
    if f15_arg1:IsInterupt(INTERUPT_Damaged) then
        f15_arg2:ClearSubGoal()
        if f15_local1 >= 0 and f15_local1 <= 20 then
            f15_arg2:AddSubGoal(GOAL_COMMON_ApproachTarget, 5, TARGET_FRI_0, 1.2, TARGET_SELF, false, -1)
            f15_arg2:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, 1, TARGET_SELF, 1, TARGET_SELF, true, -1, AI_DIR_TYPE_F, 5)
            f15_arg1:SetTimer(0, 15)
            return true
        elseif f15_arg1:HasSpecialEffectId(TARGET_SELF, 5160) then
            f15_arg2:AddSubGoal(GOAL_COMMON_LeaveTarget_Continuous, 5, TARGET_ENE_0, f15_arg1:GetRandam_Int(25, 35), TARGET_SELF, false, -1, GUARD_GOAL_DESIRE_RET_Continue, false, 2):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
            f15_arg2:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, 1, TARGET_SELF, 1, TARGET_SELF, true, -1, AI_DIR_TYPE_F, 5)
            f15_arg1:SetTimer(0, 15)
            return true
        else
            f15_arg2:AddSubGoal(GOAL_COMMON_LeaveTarget_Escape, 5, TARGET_ENE_0, f15_arg1:GetRandam_Int(25, 35), TARGET_SELF, false, 1.5):SetFailedEndOption(AI_GOAL_FAILED_END_OPT__PARENT_NEXT_SUB_GOAL)
            f15_arg2:AddSubGoal(GOAL_COMMON_ApproachSettingDirection, 1, TARGET_SELF, 1, TARGET_SELF, true, -1, AI_DIR_TYPE_F, 5)
            f15_arg1:SetTimer(0, 15)
            return true
        end
    end
    return false
    
end

RegisterTableGoal(GOAL_RedEyeGypsyDonkey321000_AfterAttackAct, "RedEyeGypsyDonkey321000_AfterAttackAct")
REGISTER_GOAL_NO_SUB_GOAL(GOAL_RedEyeGypsyDonkey321000_AfterAttackAct, true)

Goal.Activate = function (f16_arg0, f16_arg1, f16_arg2)
    
end

Goal.Update = function (f17_arg0, f17_arg1, f17_arg2)
    return Update_Default_NoSubGoal(f17_arg0, f17_arg1, f17_arg2)
    
end


