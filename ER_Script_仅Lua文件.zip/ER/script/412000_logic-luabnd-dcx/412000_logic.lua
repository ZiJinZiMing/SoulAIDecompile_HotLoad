﻿function DemiHumanBerserk412000_Logic(f1_arg0)
    COMMON_Initialize(f1_arg0)
    if COMMON_EasySetup_Initial(f1_arg0) == false then
        local f1_local0 = f1_arg0:GetEventRequest()
        local f1_local1 = f1_arg0:IsSearchTarget(TARGET_ENE_0)
        local f1_local2 = f1_arg0:GetDist(POINT_INITIAL)
        local f1_local3 = GetCurrentTimeType(f1_arg0)
        local f1_local4 = f1_arg0:GetPrevTargetState()
        local f1_local5 = f1_arg0:IsBattleState()
        if f1_arg0:HasSpecialEffectId(TARGET_SELF, 10545) == true then
            f1_arg0:AddTopGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, 3038, TARGET_ENE_0, 999, 0, 0, 0, 0)
        elseif f1_arg0:HasSpecialEffectId(TARGET_SELF, 10544) == true then
            f1_arg0:AddTopGoal(GOAL_COMMON_ComboTunable_SuccessAngle180, 10, 3037, TARGET_ENE_0, 999, 0, 0, 0, 0)
        elseif f1_local3 == PLAN_TIME_TYPE_NIGHT or f1_local3 == PLAN_TIME_TYPE_MIDNIGHT then
            if f1_arg0:HasSpecialEffectId(TARGET_SELF, 10543) == true then
                if f1_arg0:IsBattleState() == true or f1_arg0:IsSearchLowState() == true or f1_arg0:IsSearchHighState() == true or f1_arg0:IsCautionState() == true then
                    COMMON_EasySetup3(f1_arg0)
                else
                    f1_arg0:AddTopGoal(GOAL_COMMON_WalkAround_Anywhere, -1, 2, 10, true, -1, 3, 1, false, false)
                end
            elseif f1_arg0:HasSpecialEffectId(TARGET_SELF, 10541) == true then
                if f1_arg0:IsBattleState() == true or f1_arg0:IsSearchLowState() == true or f1_arg0:IsSearchHighState() == true or f1_arg0:IsCautionState() == true then
                    COMMON_EasySetup3(f1_arg0)
                else
                    f1_arg0:AddTopGoal(GOAL_COMMON_WalkAround_Anywhere, -1, 2, 10, true, -1, 3, 1, false, false)
                end
            elseif f1_arg0:HasSpecialEffectId(TARGET_SELF, 10541) == false then
                if f1_arg0:IsBattleState() == true then
                    f1_arg0:AddTopGoal(GOAL_COMMON_Wait, f1_arg0:GetRandam_Float(0, 0.25), TARGET_ENE_0, 0, 0, 0)
                    f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, 3021, TARGET_ENE_0, DIST_None, 0, 0)
                else
                    f1_arg0:AddTopGoal(GOAL_COMMON_Wait, f1_arg0:GetRandam_Float(0, 3), TARGET_ENE_0, 0, 0, 0)
                    f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, 3021, TARGET_ENE_0, DIST_None, 0, 0)
                end
            end
        elseif f1_local3 == PLAN_TIME_TYPE_MORNING or f1_local3 == PLAN_TIME_TYPE_DAYTIME or f1_local3 == PLAN_TIME_TYPE_EVENING then
            if f1_arg0:HasSpecialEffectId(TARGET_SELF, 10541) == true then
                if f1_arg0:IsBattleState() == true then
                    f1_arg0:AddTopGoal(GOAL_COMMON_Wait, f1_arg0:GetRandam_Float(0, 0.25), TARGET_ENE_0, 0, 0, 0)
                    f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, 3022, TARGET_ENE_0, DIST_None, 0, 0)
                else
                    f1_arg0:AddTopGoal(GOAL_COMMON_Wait, f1_arg0:GetRandam_Float(0, 3), TARGET_ENE_0, 0, 0, 0)
                    f1_arg0:AddTopGoal(GOAL_COMMON_AttackTunableSpin, 10, 3022, TARGET_ENE_0, DIST_None, 0, 0)
                end
            elseif f1_arg0:HasSpecialEffectId(TARGET_SELF, 10541) == false then
                COMMON_EasySetup3(f1_arg0)
            end
        else
            COMMON_EasySetup3(f1_arg0)
        end
    end
    
end

function DemiHumanBerserk412000_Interupt(f2_arg0, f2_arg1)
    
end

function DemiHumanBerserk412000_NoneBattleCheck(f3_arg0)
    if f3_arg0:IsBattleState() == false and f3_arg0:IsCautionState() == false and f3_arg0:IsFindState() == false and f3_arg0:IsSearchLowState() == false and f3_arg0:IsSearchHighState() == false then
        return true
    else
        return false
    end
    
end


